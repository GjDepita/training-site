$(function() {
    const initDateTimePicker = () => {
        $('.cwms-date').datetimepicker({
            format: 'YYYY-MM-DD'
        });
        $('.cwms-time').datetimepicker({
            format: 'hh:mm A'
        });
        $('.cwms-datetime').datetimepicker({ 
            format: 'YYYY-MM-DD hh:mm A'
        });
        $('.cwms-datetime-12hrs').datetimepicker({ 
            format: 'YYYY-MM-DD hh:mm A'
        });
        $('.cwms-daterange').daterangepicker({ 
            opens: 'left' 
        });
        $('.cwms-daterange_date').daterangepicker({ 
            opens: 'right',
            singleDatePicker: true,
            showDropdowns: true,
            locale: {
                format: 'YYYY-MM-DD'
            },
        });
    }
    initDateTimePicker();
    $('body').on('generatePOData', function( e, data ){
        initDateTimePicker();
    });
});