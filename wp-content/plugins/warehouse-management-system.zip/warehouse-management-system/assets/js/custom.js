/**
 * Resize function without multiple trigger
 * 
 * Usage:
 * $(window).smartresize(function(){  
 *     // code here
 * });
 */
(function($,sr){
    // debouncing function from John Hann
    // http://unscriptable.com/index.php/2009/03/20/debouncing-javascript-methods/
    var debounce = function (func, threshold, execAsap) {
      var timeout;

        return function debounced () {
            var obj = this, args = arguments;
            function delayed () {
                if (!execAsap)
                    func.apply(obj, args); 
                timeout = null; 
            }

            if (timeout)
                clearTimeout(timeout);
            else if (execAsap)
                func.apply(obj, args);

            timeout = setTimeout(delayed, threshold || 100); 
        };
    };

    // smartresize 
    jQuery.fn[sr] = function(fn){  return fn ? this.bind('resize', debounce(fn)) : this.trigger(sr); };

})(jQuery,'smartresize');
/**
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

var CURRENT_URL = window.location.href.split('#')[0].split('?')[0],
    $BODY = $('body'),
    $MENU_TOGGLE = $('#menu_toggle'),
    $SIDEBAR_MENU = $('#sidebar-menu'),
    $SIDEBAR_FOOTER = $('.sidebar-footer'),
    $LEFT_COL = $('.left_col'),
    $RIGHT_COL = $('.right_col'),
    $NAV_MENU = $('.nav_menu'),
    $FOOTER = $('footer');

// Sidebar
function init_sidebar() {
	// TODO: This is some kind of easy fix, maybe we can improve this
	var setContentHeight = function () {
		// reset height
		$RIGHT_COL.css('min-height', $(window).height());

		var bodyHeight = $BODY.outerHeight(),
			footerHeight = $BODY.hasClass('footer_fixed') ? -10 : $FOOTER.height(),
			leftColHeight = $LEFT_COL.eq(1).height() + $SIDEBAR_FOOTER.height(),
			contentHeight = bodyHeight < leftColHeight ? leftColHeight : bodyHeight;

		// normalize content
		contentHeight -= $NAV_MENU.height() + footerHeight;

		$RIGHT_COL.css('min-height', contentHeight);
	};

  	$SIDEBAR_MENU.find('a').on('click', function(ev) {
        var $li = $(this).parent();

        if ($li.is('.active')) {
            $li.removeClass('active active-sm');
            $('ul:first', $li).slideUp(function() {
                setContentHeight();
            });
        } else {
            // prevent closing menu if we are on child menu
            if (!$li.parent().is('.child_menu')) {
                $SIDEBAR_MENU.find('li').removeClass('active active-sm');
                $SIDEBAR_MENU.find('li ul').slideUp();
            }else
            {
				$li.parent().find('li').removeClass('active');
				if ( $BODY.is( ".nav-sm" ) )
				{
					$SIDEBAR_MENU.find( "li" ).removeClass( "active active-sm" );
					$SIDEBAR_MENU.find( "li ul" ).slideUp();
				}
			}
            $li.addClass('active');

            $('ul:first', $li).slideDown(function() {
                setContentHeight();
            });
        }
    });

	// toggle small or large menu 
	$MENU_TOGGLE.on('click', function() {
			
			if ($BODY.hasClass('nav-md')) {
				$SIDEBAR_MENU.find('li.active ul').hide();
				$SIDEBAR_MENU.find('li.active').addClass('active-sm').removeClass('active');
			} else {
				$SIDEBAR_MENU.find('li.active-sm ul').show();
				$SIDEBAR_MENU.find('li.active-sm').addClass('active').removeClass('active-sm');
			}

		$BODY.toggleClass('nav-md nav-sm');

		setContentHeight();

		$('.dataTable').each ( function () { $(this).dataTable().fnDraw(); });
	});

	// check active menu
	$SIDEBAR_MENU.find('a[href="' + CURRENT_URL + '"]').parent('li').addClass('current-page');

	$SIDEBAR_MENU.find('a').filter(function () {
		return this.href == CURRENT_URL;
	}).parent('li').addClass('current-page').parents('ul').slideDown(function() {
		setContentHeight();
	}).parent().addClass('active');

	// recompute content when resizing
	$(window).smartresize(function(){  
		setContentHeight();
	});

	setContentHeight();

	// fixed sidebar
	if ($.fn.mCustomScrollbar) {
		$('.menu_fixed').mCustomScrollbar({
			autoHideScrollbar: true,
			theme: 'minimal',
			mouseWheel:{ preventDefault: true }
		});
	}
};
// Panel toolbox
$(document).ready(function() {
	$('.collapse-link').on('click', function() {
		var $BOX_PANEL = $(this).closest('.x_panel'),
			$ICON = $(this).find('i'),
			$BOX_CONTENT = $BOX_PANEL.find('.x_content');	
		// fix for some div with hardcoded fix class
		if ($BOX_PANEL.attr('style')) {
			$BOX_CONTENT.slideToggle(200, function(){
				$BOX_PANEL.removeAttr('style');
			});
		} else {
			$BOX_CONTENT.slideToggle(200); 
			$BOX_PANEL.css('height', 'auto');  
		}
		$ICON.toggleClass('fa-chevron-up fa-chevron-down');
	});
	$('.close-link').click(function () {
		var $BOX_PANEL = $(this).closest('.x_panel');
		$BOX_PANEL.remove();
	});
});
// /Panel toolbox

// Tooltip
$(document).ready(function() {
	$('[data-toggle="tooltip"]').tooltip({
		container: 'body'
	});
});
// NProgress
if (typeof NProgress != 'undefined') {
	$(document).ready(function () {
		NProgress.start();
	});

	$(window).load(function () {
		NProgress.done();
	});
}
//hover and retain popover when on popover content
var originalLeave = $.fn.popover.Constructor.prototype.leave;
$.fn.popover.Constructor.prototype.leave = function(obj) {
	var self = obj instanceof this.constructor ?
	obj : $(obj.currentTarget)[this.type](this.getDelegateOptions()).data('bs.' + this.type);
	var container, timeout;
	originalLeave.call(this, obj);
	if (obj.currentTarget) {
		container = $(obj.currentTarget).siblings('.popover');
		timeout = self.timeout;
		container.one('mouseenter', function() {
			//We entered the actual popover – call off the dogs
			clearTimeout(timeout);
			//Let's monitor popover content instead
			container.one('mouseleave', function() {
			$.fn.popover.Constructor.prototype.leave.call(self, self);
			});
		});
	}
};
$('body').popover({
	selector: '[data-popover]',
	trigger: 'click hover',
	delay: {
		show: 50,
		hide: 400
	}
});
const loader = ( string = 'loading...') => {
	return `<div class="loader-wrapper">
	<div class="loder-crcil"></div>
	  <div class="text">${string}</div>
	</div>`;
}
const getRange = (startDate, endDate, type) => {
	let fromDate 	= moment(startDate)
	let toDate 		= moment(endDate)
	let diff 		= toDate.diff(fromDate, type)
	let range 		= []
	for (let i = 0; i < diff; i++) {
	range.push(moment(startDate).add(i, type).format('YYYY-MM-DD'))
	}
	range.push( endDate.format('YYYY-MM-DD') );
	return range
}
const updateGraph = ( chart, data, datesRange ) => {
	const newData = [];
	$.each( data, function( index, value ){
		newData.push( value );
	});
	chart.data.labels   = datesRange;
	chart.data.datasets  = newData;
	chart.update();
}
const updateTotals = ( $wrapper, totals ) => {
	$wrapper.find('.cwms-total_collection').text(totals.collection);
	$wrapper.find('.cwms-total_receivables').text(totals.receivable);
	$wrapper.find('.cwms-total_inbounds').text(totals.inbound);
}

$(document).ready(function() {
	const dashStartDate   = moment().subtract(60, 'days');
    const dashEndtDate    = moment();

	init_sidebar();

	if( $('#cwms-report_chart').length ){
		const chartWrapper  = $('#cwms-dashboard_graph_wrapper');
		const ctx 			= document.getElementById('cwms-report_chart');
		const datesRange 	= getRange( dashStartDate, dashEndtDate, 'days');
		let dashboardChart 	= new Chart( ctx, {
				type: 'line',
				data: {},
				options: {
					scales: {
						y: {
							beginAtZero: true
						}
					}
				}
			});

		$.ajax({
			type 	: 'post',
			dataType : 'json',
			url 	: cwmsCustomHandlder.ajaxurl,
			data 	: {
				action : 'cwms_get_dashboard_data',
				datesRange : datesRange
			},
			beforeSend:function(){
				chartWrapper.find('.dashboard_graph-sections').css({'display':'none'});
				$('#cwms-dashboard-daterange').html( dashStartDate.format('MMMM D, YYYY') + ' - ' + dashEndtDate.format('MMMM D, YYYY') );
				$('.cwms-current_activity_dates').html( dashStartDate.format('MMMM D, YYYY') + ' - ' + dashEndtDate.format('MMMM D, YYYY') );
				chartWrapper.append( loader('Processing...') );
			},
			success:function(res){
				chartWrapper.find( '.loader-wrapper' ).remove();
				chartWrapper.find('.dashboard_graph-sections').css({'display':'block'});
				updateGraph( dashboardChart, res.graph, datesRange );
				updateTotals( chartWrapper, res.totals );
			}
		});

		// Callback
		function cb(start, end) {
			$('#cwms-dashboard-daterange').html( start.format('MMMM D, YYYY') + ' - ' + end.format('MMMM D, YYYY') );
			$('.cwms-current_activity_dates').html( start.format('MMMM D, YYYY') + ' - ' + end.format('MMMM D, YYYY') );
			const newRange 	= getRange( start, end, 'days');
			$.ajax({
				type 	: 'post',
				dataType : 'json',
				url 	: cwmsCustomHandlder.ajaxurl,
				data 	: {
					action : 'cwms_get_dashboard_data',
					datesRange : newRange
				},
				beforeSend:function(){
					chartWrapper.find('.dashboard_graph-sections').css({'display':'none'});
					chartWrapper.append( loader('Processing...') );
				},
				success:function(res){
					chartWrapper.find( '.loader-wrapper' ).remove();
					chartWrapper.find('.dashboard_graph-sections').css({'display':'block'});
					updateGraph( dashboardChart, res.graph, newRange );
					updateTotals( chartWrapper, res.totals );
				}
			});
		}

		// Datepicker
		$('#cwms-dashboard-daterange').daterangepicker({
			startDate: dashStartDate,
			endDate: dashEndtDate,
			ranges: {
				'Today'          : [moment(), moment()],
                'Yesterday'      : [moment().subtract(1, 'days'), moment().subtract(1, 'days')],
                'Last 7 Days'    : [moment().subtract(6, 'days'), moment()],
                'Last 30 Days'   : [moment().subtract(29, 'days'), moment()],
                'This Month'     : [moment().startOf('month'), moment().endOf('month')],
                'This Year'      : [moment().startOf('year'), moment()]
			}
		}, cb);
	}

});	