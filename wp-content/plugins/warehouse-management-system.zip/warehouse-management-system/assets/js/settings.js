jQuery(document).ready( function($){

    const generalForm       = $('#cwms-general-settings-form');
    const uploadLogoModal   = $('#cwms-upload-logo-modal');

    if ($(".js-switch")[0]) {
        var elems = Array.prototype.slice.call(document.querySelectorAll('.js-switch'));
        elems.forEach(function (html) {
            var switchery = new Switchery(html, {
                color: '#26B99A'
            });
        });
    }

    const readFile = (input) => {
        if (input.files && input.files[0]) {
            var reader = new FileReader();
            reader.onload = function (e) {
                $('#cwms-uploaded-logo').croppie('bind', {
                    url: e.target.result
                });
            }
            reader.readAsDataURL(input.files[0]);
        }
    }
    $uploadCrop = $('#cwms-uploaded-logo').croppie({
        enableExif: true,
        viewport: {
            width: 320,
            height: 120,
        },
        boundary: {
            width: 420,
            height: 280
        },
        // url:'https://via.placeholder.com/420x280'
    });
    uploadLogoModal.on('change', '#cwms-upload_logo', function () { readFile(this); });
    uploadLogoModal.on('click', '#cwms-save_logo', function(e){
        e.preventDefault();
        var uploadValue = uploadLogoModal.find('#cwms-upload_logo').val();
        if( !uploadValue ){
            alert( cwmsAjaxHandler.noFile );
            return false;
        }
        $uploadCrop.croppie( 'result', {
            type: 'base64',
            size: {
                width: 320,
                height: 120
            }
        }).then(function (image) {
            $('#cwms-logo-holder').html(`<img style='width:100%' id='base64image'
            src='${image}' />`);
            generalForm.find('[name="_company_logo"]').val(image);
            uploadLogoModal.modal('hide');
        });
    });

    // Category table
    const ajaxURL           = cwmsAjaxHandler.ajaxurl;
    const dataTableLabels   = cwmsAjaxHandler.dataTableLabels;
    const prodCatTableHeader  = cwmsAjaxHandler.prodCatTableHeader;
    const prodCatElem       = $('#cwms_product_category_table');  
    let prodCatTableParam   = {
        dom: 'Bfrtip',
        "language": dataTableLabels,
        responsive: true,
        processing: true,
        "createdRow": function( row, data, dataIndex ) {
            $(row).attr( 'data-id', data.ID );
        }
    };
    let prodCatColumns      = [] ;
    prodCatTableParam.ajax          = `${ajaxURL}?action=cwms_get_product_categories`;
    prodCatTableHeader.map( elem  => prodCatColumns.push( { data: elem, orderable: false } ) );

    prodCatTableParam.data         = [];
    prodCatTableParam.columns      = prodCatColumns;
    prodCatTableParam.buttons      = [];
    prodCatTableParam.columnDefs   = [];
    prodCatTableParam.select       = null;
    prodCatTableParam.processing   = true;
    prodCatTableParam.order        = [];
    prodCatTableParam.buttons      = [];

    const productCategories = prodCatElem.DataTable(prodCatTableParam);

    // Delete Product category
    prodCatElem.on('click', '.cwms-delete_prodcat', function(){
        const currElem  = $(this);
        const termID    = currElem.closest('.row-actions').data('id');
        if( confirm( cwmsAjaxHandler.proceedConfirmation ) ){
            $.ajax({
                type 	: 'post',
                dataType : 'json',
                url 	: ajaxURL,
                data 	: {
                    action : 'cwms_delete_term',
                    termID : termID,			
                },
                beforeSend:function(){
                    
                },
                success:function(response){
                    if( response.status == 'error'){
                        alert(response.message);
                        return;
                    }
                    productCategories
                    .row( currElem.parents('tr') )
                    .remove()
                    .draw();
                }
            });
        }
    });
});