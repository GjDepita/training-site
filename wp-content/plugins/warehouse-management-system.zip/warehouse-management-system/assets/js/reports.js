jQuery(function() {
    // MAKE SURE TO RUN THE SCRIPT ONLY FOR RECEIVABLE PAGE
    if( !$('#cwms-page-receivables, #cwms-page-create-payment, #cwms-page-collections, #cwms-page-customer, #cwms-page-customers, #cwms-page-unit-sold, #cwms-page-gross-profit').length  ){
        return;
    }
    const ajaxURL           = cwmsReportHandlder.ajaxurl;
    const tableLabels       = cwmsReportHandlder.tableLabels;
    const dataTableTitle    = cwmsReportHandlder.dataTableTitle
    const currency          = cwmsReportHandlder.currency;
    const currencyLocal     = cwmsReportHandlder.currencyLocal;
    const inputTooShort     = cwmsReportHandlder.inputTooShort;
    const errorLoading      = cwmsReportHandlder.errorLoading;
    const loadingMore       = cwmsReportHandlder.loadingMore;
    const noResults         = cwmsReportHandlder.noResults;
    const searching         = cwmsReportHandlder.searching;

    const loader = ( string = 'loading...') => {
        return `<div class="loader-wrapper">
        <div class="loder-crcil"></div>
          <div class="text">${string}</div>
        </div>`;
    }

    const printDiv = ( divID )  => {

        var divToPrint=document.getElementById( divID );
        var newWin=window.open('','Print-Window');
        newWin.document.open();
        newWin.document.write(`
            <html>
                <head>
                    <link href="${cwmsReportHandlder.cwms1661BootstrapStyle}" rel="stylesheet" />
                    <link href="${cwmsReportHandlder.cwms1661ThemeStyle}" rel="stylesheet" />
                    <link href="${cwmsReportHandlder.cwms1661Style}" rel="stylesheet" />
                    <style>
                        .row{ width:100% !import}
                    </style>
                </haed>
                <body onload="window.print()">${divToPrint.innerHTML}</body>
            </html>
        `);
        newWin.document.close();
        setTimeout(function(){newWin.close();},10);

    }

    const download_file = (fileURL, fileName) => {
        // for non-IE
        if (!window.ActiveXObject) {
            var save = document.createElement('a');
            save.href = fileURL;
            save.target = '_blank';
            var filename = fileURL.substring(fileURL.lastIndexOf('/')+1);
            save.download = fileName || filename;
            if ( navigator.userAgent.toLowerCase().match(/(ipad|iphone|safari)/) && navigator.userAgent.search("Chrome") < 0) {
                    document.location = save.href; 
                // window event not working here
                }else{
                    var evt = new MouseEvent('click', {
                        'view': window,
                        'bubbles': true,
                        'cancelable': false
                    });
                    save.dispatchEvent(evt);
                    (window.URL || window.webkitURL).revokeObjectURL(save.href);
                }	
        }
        // for IE < 11
        else if ( !! window.ActiveXObject && document.execCommand)     {
            var _window = window.open(fileURL, '_blank');
            _window.document.close();
            _window.document.execCommand('SaveAs', true, fileName || fileURL)
            _window.close();
        }
    }

    const toCurrency = amount => {
        return new Intl.NumberFormat( currencyLocal, { style: 'currency', currency: currency }).format(amount);
    }

    const getUrlParameter = (sParam) => {
        var sPageURL = window.location.search.substring(1),
            sURLVariables = sPageURL.split('&'),
            sParameterName,
            i;
    
        for (i = 0; i < sURLVariables.length; i++) {
            sParameterName = sURLVariables[i].split('=');
    
            if (sParameterName[0] === sParam) {
                return sParameterName[1] === undefined ? true : parseInt( decodeURIComponent(sParameterName[1] ) );
            }
        }
        return false;
    };

    const start   = moment().subtract(29, 'days');
    const end     = moment();

    // Print Invoice
    $('.page-action').on('click', '#cwms-print_invoice', function( e ){
        e.preventDefault();
        printDiv( $(this).data('printid') );
    });

    // Receivable Table ########################
    const receivebleTableData   = cwmsReportHandlder.receivebleTableData;
    const receivableTable       = $(`#${receivebleTableData.id}`);
    const receivableHeader      = receivebleTableData.headers;
    const salesmanFilterElem                = $('#receivable_salesman_filter');
    const salesmanFilterPlaceholder         = salesmanFilterElem.data('placeholder');
    const customerFilterElem                = $('#receivable_customer_filter');
    const customerFilterPlaceholder         = customerFilterElem.data('placeholder');
    const invoiceStatusFilterElem           = $('#receivable_invoice_filter');
    const invoiceStatusFilterPlaceholder    = invoiceStatusFilterElem.data('placeholder');
    // Area Filter
    const areaStateFilterElem           = $('#receivable_state_filter');
    const areaStateFilterPlaceholder    = areaStateFilterElem.data('placeholder');
    const areaCityFilterElem            = $('#receivable_city_filter');
    const areaCityFilterPlaceholder     = areaCityFilterElem.data('placeholder');

    let receivableColumns       = [];
    let receivableTableParam    = {};
    let receivableStartDate     = start;
    let receivableEndDate       = end;
    let receivableCustomer      = '';
    let receivableCustomerName  = customerFilterPlaceholder;
    let receivableSalesman      = '';
    let receivableSalesmanName  = salesmanFilterPlaceholder;
    let receivableInvoiceStatus = '';
    let receivableInvoiceStatusName = invoiceStatusFilterPlaceholder;

    // Area selected value
    let receivableAreaCity  = '';
    let receivableAreaCityName = areaCityFilterPlaceholder;
    let receivableAreaState = '';
    let receivableAreaStateName = areaStateFilterPlaceholder;

    const dynamicMessage = () => {
        const template = `
            ${receivableStartDate.format('MMMM D, YYYY')} - ${receivableEndDate.format('MMMM D, YYYY')} 
        `;
        return template;
    }

    const getYearMonthsDates = ( selDate ) => {
        let monthDates = [];
        const selYear  = selDate.format('YYYY');
        const selMonth = selDate.format('MM');
        for (let index = 1; index <= 12; index++) {
            const dateStatus        = parseInt( selMonth ) == index ? 1 : 0;
            const loopDate          = new Date(`${selYear}-${index}-01`);
            const momentDateFormat  = moment(loopDate);
            monthDates.push({
                start: momentDateFormat.startOf('month').format('YYYY-MM-DD'),
                end: momentDateFormat.endOf('month').format('YYYY-MM-DD'),
                month: momentDateFormat.format('MMMM'),
                year: momentDateFormat.format('YYYY'),
                status: dateStatus
            });
        }
        return monthDates;
    }

    const getReceivableTableData = () => {
        $.ajax({
            url: `${ajaxURL}?action=cwms_get_all_receivables&customer=${receivableCustomer}&salesman=${receivableSalesman}&invstat=${receivableInvoiceStatus}&city=${receivableAreaCity}&state=${receivableAreaState}&start=${receivableStartDate.format('YYYY-MM-DD')}&end=${receivableEndDate.format('YYYY-MM-DD')}`,
            type: 'get',
            beforeSend: function () {
            },
            success: function ( response ) {
                const {data}        = response;
                let totalAmount     = 0;
                let totalBalance    = 0;
                if( data ){
                    totalAmount   = data.reduce( (acc, curr) => acc + parseFloat( curr._total_amount ), 0 );
                    totalBalance  = data.reduce( (acc, curr) => acc + parseFloat( curr._balance ), 0 );
                }
                $('#receivable_table_report .receivable_daterange').text( receivableStartDate.format('MMMM D, YYYY') + ' - ' + receivableEndDate.format('MMMM D, YYYY') );
                $('#receivable_table_report .receivable_customer').text( receivableCustomerName );
                $('#receivable_table_report .receivable_salesman').text( receivableSalesmanName );
                $('#receivable_table_report .receivable_city').text( receivableAreaCityName );
                $('#receivable_table_report .receivable_state').text( receivableAreaStateName );
                $('#receivable_table_report .receivable_status').text( receivableInvoiceStatusName );
                $('#receivable_table_report .receivable_total_amount').text( toCurrency(totalAmount) );
                $('#receivable_table_report .receivable_total_balance').text( toCurrency(totalBalance) );
                receivable.clear().rows.add(data).draw();
            },
            error: function(xhr, status, error) {
                alert( `Error: ${error} please reload the page and try again` );
            }
        });
    }

    const receivableDatepickerCallback = (start, end) => {
        $('#receivable_daterange_filter').val( start.format('YYYY-MM-DD') + ' - ' + end.format('YYYY-MM-DD') );
        receivableStartDate = start;
        receivableEndDate   = end;
        getReceivableTableData();
    }   

    receivableHeader.map( elem  => receivableColumns.push( { data: elem, exportOptions: { stripHtml: false } } ) );
    receivableTableParam.data       = [];
    receivableTableParam.columns    = receivableColumns;
    receivableTableParam.createdRow = function( row, data, dataIndex ){
            if( data._aged ){
                $(row).addClass('cwms-aged_dr')
            }
        };
    receivableTableParam.dom        = 'Bfrtip';
    receivableTableParam.buttons    = [
        {
            extend: 'excelHtml5',
            text : tableLabels.downloadExcelLabel,
            className: 'btn btn-sm btn-primary',
            title: `${dataTableTitle} - Invoices Report`,
            // messageTop: dynamicMessage(),
            exportOptions: {
                stripHtml: true,
                stripNewlines: false
            }
        },
        {
            extend: 'pdfHtml5',
            text : tableLabels.downloadPDFLabel,
            className: 'btn btn-sm btn-primary',
            title: `${dataTableTitle} - Invoices Report`,
            // messageTop: dynamicMessage(),
            exportOptions: {
                stripHtml: true,
                stripNewlines: false
            }
        }
    ];

    let receivable  = receivableTable.DataTable(receivableTableParam);

    $('#receivable_daterange_filter').daterangepicker({
        opens: 'left',
        locale: {
            format: 'YYYY-MM-DD'
        },
        startDate: start,
        endDate: end,
        ranges: {
           'Today'          : [moment(), moment()],
           'Yesterday'      : [moment().subtract(1, 'days'), moment().subtract(1, 'days')],
           'Last 7 Days'    : [moment().subtract(6, 'days'), moment()],
           'Last 30 Days'   : [moment().subtract(29, 'days'), moment()],
           'This Month'     : [moment().startOf('month'), moment().endOf('month')],
           'Last Month'     : [moment().subtract(1, 'month').startOf('month'), moment().subtract(1, 'month').endOf('month')],
           'This Year'      : [moment().startOf('year'), moment()],
        }
    }, receivableDatepickerCallback);

    receivableDatepickerCallback(receivableStartDate, receivableEndDate);

    // Search for invoice status filter ####
    invoiceStatusFilterElem.select2({
        allowClear: true,
        placeholder: invoiceStatusFilterPlaceholder,
    }).on('select2:select', function(e){
        selectedInvoiceStatus   = e.params.data;
        receivableInvoiceStatus = selectedInvoiceStatus.id;
        receivableInvoiceStatusName = selectedInvoiceStatus.text;
        getReceivableTableData();
    }).on('select2:clear', function(e){
        receivableInvoiceStatus = '';
        receivableInvoiceStatusName = invoiceStatusFilterPlaceholder;
        getReceivableTableData();
    }); 

    // Search for salesman ########
    salesmanFilterElem.select2({
        ajax: {
            url: ajaxURL, // AJAX URL is predefined in WordPress admin
            dataType: 'json',
            delay: 250, // delay in ms while typing when to perform a AJAX search
            data: function (params) {
                return {
                    q: params.term, // search query
                    action: $(this).attr('data-action')
                };
            },
            processResults: function( data ) {
                var options = [];
                if ( data.length > 0 ) {
                    $.each( data, function( index, info ) { // do not forget that "index" is just auto incremented value
                        options.push( { id: info.ID, text: info.display_name, info: info } );
                    });
                }
                return {
                    results: options
                };
            },
            cache: true
        },
        minimumInputLength: 3,
        selectOnClose: true,
        allowClear: true,
        placeholder: salesmanFilterPlaceholder,
        language: {
            inputTooShort: function(args) { return inputTooShort; },
            errorLoading: function() { return errorLoading; },
            loadingMore: function() { return loadingMore; },
            noResults: function() { return noResults; },
            searching: function() { return searching; }
        }
    }).on('select2:select', function(e){
        // Get the selected data an put it in the global variable for repeater 
        selectedSalesman = e.params.data;
        receivableSalesman = selectedSalesman.id;
        receivableSalesmanName  = selectedSalesman.text;
        getReceivableTableData();
    }).on('select2:clear', function(e){
        receivableSalesman = '';
        receivableSalesmanName  = salesmanFilterPlaceholder;
        getReceivableTableData();
    });  

    // Search for customer filter ####
    customerFilterElem.select2({
        ajax: {
            url: ajaxURL, // AJAX URL is predefined in WordPress admin
            dataType: 'json',
            delay: 250, // delay in ms while typing when to perform a AJAX search
            data: function (params) {
                return {
                    q: params.term, // search query
                    action: $(this).attr('data-action')
                };
            },
            processResults: function( data ) {
                var options = [];
                if ( data.length > 0 ) {
                    $.each( data, function( index, info ) { // do not forget that "index" is just auto incremented value
                        options.push( { id: info.ID, text: `${info.display_name} (${info._company})` , info: info } );
                    });
                }
                return {
                    results: options
                };
            },
            cache: true
        },
        minimumInputLength: 3,
        selectOnClose: true,
        allowClear: true,
        placeholder: customerFilterPlaceholder,
        language: {
            inputTooShort: function(args) { return inputTooShort; },
            errorLoading: function() { return errorLoading; },
            loadingMore: function() { return loadingMore; },
            noResults: function() { return noResults; },
            searching: function() { return searching; }
        }
    }).on('select2:select', function(e){
        // Get the selected data an put it in the global variable for repeater 
        selectedCustomer = e.params.data;
        receivableCustomer = selectedCustomer.id;
        receivableCustomerName  = selectedCustomer.text;
        getReceivableTableData();
    }).on('select2:clear', function(e){
        receivableCustomer = '';
        receivableCustomerName  = customerFilterPlaceholder;
        getReceivableTableData();
    });  

    // Search for City filter ####
    areaCityFilterElem.select2({
        allowClear: true,
        placeholder: areaCityFilterPlaceholder,
    }).on('select2:select', function(e){
        receivableAreaCity = e.params.data.text;
        receivableAreaCityName = e.params.data.text;
        getReceivableTableData();
    }).on('select2:clear', function(e){
        receivableAreaCity = '';
        receivableAreaCityName = areaCityFilterPlaceholder;
        getReceivableTableData();
    }); 
   
    // Search for State filter ####
    areaStateFilterElem.select2({
        allowClear: true,
        placeholder: areaStateFilterPlaceholder,
    }).on('select2:select', function(e){
        receivableAreaState = e.params.data.text;
        receivableAreaStateName = e.params.data.text;
        getReceivableTableData();
    }).on('select2:clear', function(e){
        receivableAreaState = '';
        receivableAreaStateName = areaStateFilterPlaceholder;
        getReceivableTableData();
    }); 


    // ############ Customer Report ##############

    const customerTableData   = cwmsReportHandlder.customerTableData;
    let customerColumns       = [];
    let customerTableParam    = {};
    const customerTable       = $(`#${customerTableData.id}`);
    const customerDRP         = $(`#${customerTableData.drpID}`);
    const customerInvTable    = $(`#${customerTableData.custInvTableID}`);
    const customerHeader      = customerTableData.headers;
    const customerInvTblHeader      = customerTableData.custInvTableHeaders;
    
    customerHeader.map( elem  => customerColumns.push( { data: elem } ) );
    customerTableParam.ajax       = { url: ajaxURL + '?action=cwms_get_all_customers' };
    customerTableParam.columns    = customerColumns;
    customerTableParam.dom        = 'Bfrtip';
    customerTableParam.buttons    = [
        {
            extend: 'excelHtml5',
            text : tableLabels.downloadExcelLabel,
            className: 'btn btn-sm btn-primary',
            title: `${dataTableTitle} - Customer List`,
            exportOptions: {
                stripHtml: true,
                stripNewlines: false
            }
        },
        {
            extend: 'pdfHtml5',
            text : tableLabels.downloadPDFLabel,
            className: 'btn btn-sm btn-primary',
            title: `${dataTableTitle} - Customer List`,
            exportOptions: {
                stripHtml: true,
                stripNewlines: false
            }
        }
    ];
    let customer  = customerTable.DataTable(customerTableParam);

    // Customer Invoice Report 
    let customerInvColumns      = [];
    let customerInvTableParam   = {};
    const customerInvFilter     = $(`#cmws-customer_invoices`);
    const custID                = customerDRP.data('id');
    const invFilterPlaceholder  = customerInvFilter.data('placeholder');
    let invFilter               = customerInvFilter.val();
    let custInvDateStart        = null;
    let custInvDateEnd          = null;

    customerInvTblHeader.map( elem  => customerInvColumns.push( { data: elem } ) );
    customerInvTableParam.data       = [];
    customerInvTableParam.columns    = customerInvColumns;
    customerInvTableParam.buttons    = [];
    customerInvTableParam.order      = [[1, 'DESC']];

    let customerInv  = customerInvTable.DataTable(customerInvTableParam);

    const getCustomerInvoices = () => {

        const startDateFormat   = custInvDateStart ? custInvDateStart.format('YYYY-MM-DD') : '' ;
        const endDateFormat     = custInvDateEnd ? custInvDateEnd.format('YYYY-MM-DD') : '' ;
        const reqURL            = `${ajaxURL}?action=cwms_get_customer_invoices&id=${custID}&status=${invFilter}&start=${startDateFormat}&end=${endDateFormat}`;

        $.ajax({
            url: reqURL,
            type: 'get',
            beforeSend: function () {
            },
            success: function ( response ) {
                customerInv.clear().rows.add(response.data).draw();
            },
            error: function(xhr, status, error) {
                alert( `Error: ${error} please reload the page and try again` );
            }
        });
    }

    // Daterangepicker
    function customerDaterangepickerCallback(start, end) {
        const startDateFormat = start ? start.format('MMMM D, YYYY') : '' ;
        const endDateFormat = end ? end.format('MMMM D, YYYY') : '' ;
        $('.cwms-customer_report_daterange').text( startDateFormat + ' - ' + endDateFormat );
        custInvDateStart        = start;
        custInvDateEnd          = end;
        getCustomerInvoices();
    }

    customerDRP.daterangepicker({
        opens: 'left',
        locale: {
            format: 'YYYY-MM-DD'
        },
        startDate: start,
        endDate: end,
        ranges: {
           'Today'          : [moment(), moment()],
           'Yesterday'      : [moment().subtract(1, 'days'), moment().subtract(1, 'days')],
           'Last 7 Days'    : [moment().subtract(6, 'days'), moment()],
           'Last 30 Days'   : [moment().subtract(29, 'days'), moment()],
           'This Month'     : [moment().startOf('month'), moment().endOf('month')],
           'This Year'      : [moment().startOf('year'), moment()]
        }
    }, customerDaterangepickerCallback);
    customerDaterangepickerCallback( null, null);

    // Search for invoice status filter ####
    customerInvFilter.select2({
        allowClear: true,
        placeholder: invFilterPlaceholder,
    }).on('select2:select', function(e){
        seldata   = e.params.data;
        invFilter = seldata.id;
        getCustomerInvoices();
    }).on('select2:clear', function(e){
        invFilter = '';
        getCustomerInvoices();
    }); 

    // Unit Sold Report ###############################################
    const unitSoldTableData   = cwmsReportHandlder.unitSoldTable;
    const unitSoldTable       = $(`#${unitSoldTableData.id}`);
    const unitSoldHeader      = unitSoldTableData.headers;
    const unitSoldDaterangeFilter           = $('#unitsold_daterange_filter');
    const unitSoldProductFilter             = $('#unitsold_product_filter');
    const unitSoldProductFilterPlaceholder  = unitSoldProductFilter.data('placeholder');
    const unitSoldSalesmanFilter            = $('#unitsold_salesman_filter');
    const unitSoldSalesmanFilterPlaceholder  = unitSoldSalesmanFilter.data('placeholder');
    const unitSoldCutomerFilter             = $('#unitsold_customer_filter');
    const unitSoldCutomerFilterPlaceholder  = unitSoldCutomerFilter.data('placeholder');

    // Area filter
    const unitSoldCityFilter             = $('#unitsold_city_filter');
    const unitSoldCityFilterPlaceholder  = unitSoldCityFilter.data('placeholder');
    const unitSoldStateFilter             = $('#unitsold_state_filter');
    const unitSoldStateFilterPlaceholder  = unitSoldStateFilter.data('placeholder');


    let unitSoldColumns       = [];
    let unitSoldTableParam    = {};

    let unitSoldProduct       = '';
    let unitSoldSalesman      = '';
    let unitSoldCustomer      = '';
    let unitSoldAreaCity      = '';
    let unitSoldAreaState     = '';

    let unitSoldProductName  = unitSoldProductFilterPlaceholder;
    let unitSoldCustomerName = unitSoldCutomerFilterPlaceholder;
    let unitSoldSalesmanName = unitSoldSalesmanFilterPlaceholder;
    let unitSoldAreaCityName  = unitSoldCityFilterPlaceholder;
    let unitSoldAreaStateName = unitSoldStateFilterPlaceholder;

    let unitSoldStartDate     = start;
    let unitSoldEndDate       = end;

    const unitSoldDynamicMessage = () => {
        const template = `
            ${unitSoldStartDate.format('MMMM D, YYYY')} - ${unitSoldEndDate.format('MMMM D, YYYY')}
        `;
        return template;
    }


    unitSoldHeader.map( elem  => unitSoldColumns.push( { data: elem } ) );
    unitSoldTableParam.columns    = unitSoldColumns;
    unitSoldTableParam.dom        = 'Bfrtip';
    unitSoldTableParam.buttons    = [
        {
            extend: 'excelHtml5',
            text : tableLabels.downloadExcelLabel,
            className: 'btn btn-sm btn-primary',
            title: `${dataTableTitle} - Unit Sold Report`,
            // messageTop: unitSoldDynamicMessage(),
            exportOptions: {
                stripHtml: true,
                stripNewlines: false
            }
        },
        {
            extend: 'pdfHtml5',
            text : tableLabels.downloadPDFLabel,
            className: 'btn btn-sm btn-primary',
            title: `${dataTableTitle} - Unit Sold Report`,
            // messageTop: unitSoldDynamicMessage(),
            exportOptions: {
                stripHtml: true,
                stripNewlines: false
            }
        }
    ];
    let unitSold  = unitSoldTable.DataTable(unitSoldTableParam);

    const getUnitSoldData = () => {

        $.ajax({
            url: `${ajaxURL}?action=cwms_get_all_unit_sold&product=${unitSoldProduct}&salesman=${unitSoldSalesman}&customer=${unitSoldCustomer}&city=${unitSoldAreaCity}&state=${unitSoldAreaState}&start=${unitSoldStartDate.format('YYYY-MM-DD')}&end=${unitSoldEndDate.format('YYYY-MM-DD')}`,
            type: 'get',
            beforeSend: function () {
            },
            success: function ( response ) {
                const {data}        = response;
                let totalSales    = 0;
                let totalQtySold  = 0;
                if( data ){
                    totalSales      = data.reduce( (acc, curr) => acc + parseFloat( curr._total_sales ), 0 );
                    totalQtySold    = data.reduce( (acc, curr) => acc + parseFloat( curr.total_delivered ), 0 );
                }
                $('#unit_sold_table_report .unit_sold_daterange').text( unitSoldStartDate.format('MMMM D, YYYY') + ' - ' + unitSoldEndDate.format('MMMM D, YYYY') );
                $('#unit_sold_table_report .unit_sold_product').text( unitSoldProductName );
                $('#unit_sold_table_report .unit_sold_customer').text( unitSoldCustomerName );
                $('#unit_sold_table_report .unit_sold_salesman').text( unitSoldSalesmanName );
                $('#unit_sold_table_report .unit_sold_city').text( unitSoldAreaCityName );
                $('#unit_sold_table_report .unit_sold_state').text( unitSoldAreaStateName );
                $('#unit_sold_table_report .unit_sold_total_qty').text( totalQtySold );
                $('#unit_sold_table_report .unit_sold_total_amount').text( toCurrency(totalSales) );
                unitSold.clear().rows.add(response.data).draw();
            },
            error: function(xhr, status, error) {
                alert( `Error: ${error} please reload the page and try again` );
            }
        });
    }

    // Daterangepicker
    function unitSoldDaterangepickerCallback(start, end) {
        unitSoldStartDate   = start;
        unitSoldEndDate     = end;
        getUnitSoldData();
    }

    unitSoldDaterangeFilter.daterangepicker({
        opens: 'left',
        locale: {
            format: 'YYYY-MM-DD'
        },
        startDate: start,
        endDate: end,
        ranges: {
           'Today'          : [moment(), moment()],
           'Yesterday'      : [moment().subtract(1, 'days'), moment().subtract(1, 'days')],
           'Last 7 Days'    : [moment().subtract(6, 'days'), moment()],
           'Last 30 Days'   : [moment().subtract(29, 'days'), moment()],
           'This Month'     : [moment().startOf('month'), moment().endOf('month')],
           'This Year'      : [moment().startOf('year'), moment()]
        }
    }, unitSoldDaterangepickerCallback);
    unitSoldDaterangepickerCallback( unitSoldStartDate, unitSoldEndDate );

    // Search for product ####
    unitSoldProductFilter.select2({
        ajax: {
            url: ajaxURL, // AJAX URL is predefined in WordPress admin
            dataType: 'json',
            delay: 250, // delay in ms while typing when to perform a AJAX search
            data: function (params) {
                return {
                    q: params.term, // search query
                    action: $(this).attr('data-action')
                };
            },
            processResults: function( data ) {
                var options = [];
                if ( data.length > 0 ) {
                    $.each( data, function( index, info ) { // do not forget that "index" is just auto incremented value
                        options.push( { id: info.ID, text: info._name, info: info } );
                    });
                }
                return {
                    results: options
                };
            },
            cache: true
        },
        minimumInputLength: 3,
        selectOnClose: true,
        language: {
            inputTooShort: function(args) { return inputTooShort; },
            errorLoading: function() { return errorLoading; },
            loadingMore: function() { return loadingMore; },
            noResults: function() { return noResults; },
            searching: function() { return searching; }
        },
        allowClear: true,
        placeholder: unitSoldProductFilterPlaceholder,
    }).on('select2:select', function(e){
        selData                 = e.params.data;
        unitSoldProduct         = selData.id;
        unitSoldProductName     = selData.text;
        getUnitSoldData();
    }).on('select2:clear', function(e){
        unitSoldProduct         = '';
        unitSoldProductName     = unitSoldProductFilterPlaceholder;
        getUnitSoldData();
    }); 

    // Search for Salesman ####
    unitSoldSalesmanFilter.select2({
        ajax: {
            url: ajaxURL, // AJAX URL is predefined in WordPress admin
            dataType: 'json',
            delay: 250, // delay in ms while typing when to perform a AJAX search
            data: function (params) {
                return {
                    q: params.term, // search query
                    action: $(this).attr('data-action')
                };
            },
            processResults: function( data ) {
                var options = [];
                if ( data.length > 0 ) {
                    $.each( data, function( index, info ) { // do not forget that "index" is just auto incremented value
                        options.push( { id: info.ID, text: info.display_name, info: info } );
                    });
                }
                return {
                    results: options
                };
            },
            cache: true
        },
        minimumInputLength: 3,
        selectOnClose: true,
        language: {
            inputTooShort: function(args) { return inputTooShort; },
            errorLoading: function() { return errorLoading; },
            loadingMore: function() { return loadingMore; },
            noResults: function() { return noResults; },
            searching: function() { return searching; }
        },
        allowClear: true,
        placeholder: unitSoldSalesmanFilterPlaceholder,
    }).on('select2:select', function(e){
        selData                 = e.params.data;
        unitSoldSalesman        = selData.id;
        unitSoldSalesmanName    = selData.text;
        getUnitSoldData();
    }).on('select2:clear', function(e){
        unitSoldSalesman        = '';
        unitSoldSalesmanName    = unitSoldSalesmanFilterPlaceholder;
        getUnitSoldData();
    }); 

    // Search for customer ####
    unitSoldCutomerFilter.select2({
        ajax: {
            url: ajaxURL, // AJAX URL is predefined in WordPress admin
            dataType: 'json',
            delay: 250, // delay in ms while typing when to perform a AJAX search
            data: function (params) {
                return {
                    q: params.term, // search query
                    action: $(this).attr('data-action')
                };
            },
            processResults: function( data ) {
                var options = [];
                if ( data.length > 0 ) {
                    $.each( data, function( index, info ) { // do not forget that "index" is just auto incremented value
                        options.push( { id: info.ID, text: `${info.display_name} (${info._company})`, info: info } );
                    });
                }
                return {
                    results: options
                };
            },
            cache: true
        },
        minimumInputLength: 3,
        selectOnClose: true,
        language: {
            inputTooShort: function(args) { return inputTooShort; },
            errorLoading: function() { return errorLoading; },
            loadingMore: function() { return loadingMore; },
            noResults: function() { return noResults; },
            searching: function() { return searching; }
        },
        allowClear: true,
        placeholder: unitSoldCutomerFilterPlaceholder,
    }).on('select2:select', function(e){
        selData                 = e.params.data;
        unitSoldCustomer        = selData.id;
        unitSoldCustomerName    = selData.text;
        getUnitSoldData();
    }).on('select2:clear', function(e){
        unitSoldCustomer        = '';
        unitSoldCustomerName    = unitSoldCutomerFilterPlaceholder
        getUnitSoldData();
    }); 

    // Search for City filter 
    unitSoldCityFilter.select2({
        allowClear: true,
        placeholder: unitSoldCityFilterPlaceholder,
    }).on('select2:select', function(e){
        unitSoldAreaCity = e.params.data.text;
        unitSoldAreaCityName = e.params.data.text;
        getUnitSoldData();
    }).on('select2:clear', function(e){
        unitSoldAreaCity = '';
        unitSoldAreaCityName = unitSoldCityFilterPlaceholder;
        getUnitSoldData();
    }); 
   
    // Search for State filter ####
    unitSoldStateFilter.select2({
        allowClear: true,
        placeholder: unitSoldStateFilterPlaceholder,
    }).on('select2:select', function(e){
        unitSoldAreaState = e.params.data.text;
        unitSoldAreaStateName = e.params.data.text;
        getUnitSoldData();
    }).on('select2:clear', function(e){
        unitSoldAreaState = '';
        unitSoldAreaStateName = unitSoldStateFilterPlaceholder;
        getUnitSoldData();
    }); 

    // Gross and Profit Loss ***************
    let grossProfitColumns           = [];
    let grossProfitTableParam        = {};
    let grossProfitData              = [];
    let revenueAmount               = 0;
    let cogsAmount                  = 0;

    let grossProfitStartDate        = start;
    let grossProfitEndDate          = end;

    const grossProfitHandler         = cwmsReportHandlder.grossProfitTable;
    const grossProfitContentID       = $('#cwms-page-gross-profit');
    const grossProfitDaterangeFilter = $('#gross-profit_daterange_filter');
    const grossProfitCalcWrapID      = $('#cwms1661_grossprofit-calculator-wrapper');
    const revenueCalcTable          = $('#cwms1661_grossprofit-revenue-table');
    const cogsCalcTable             = $('#cwms1661_grossprofit-cogs-table');
    const grossProfitCalcTable       = $('#cwms1661_grossprofit-table');
    const expensesCalcTable         = $('#cwms1661_grossprofit-expenses-table');
    const netIncomeCalcTable        = $('#cwms1661_grossprofit-netincome-table');

    if( grossProfitHandler ){
        const grossProfitTable           = $(`#${grossProfitHandler.tblInvoiceID}`);
        const grossProfitHeader          = grossProfitHandler.headers;
        const errorMessage              = grossProfitHandler.errorMessage;

        grossProfitHeader.map( elem  => grossProfitColumns.push( { data: elem } ) );
        grossProfitTableParam.columns    = grossProfitColumns;
        grossProfitTableParam.dom        = 'Bfrtip';
        grossProfitTableParam.buttons    = [];
        let grossProfit                  = grossProfitTable.DataTable(grossProfitTableParam);
    }
    

    const grossProfitReset = () => {
        grossProfitCalcWrapID.find('input').val('');
        grossProfitCalcWrapID.find('.calc_amount').data('amount', 0.00);
    } 

    grossProfitCalcWrapID.on( 'input', 'input.cmws-currency', () => (  grossProfitCalculator() ) );

    const grossProfitCalculator = ( ) => {
        let grossProfitAmount = 0;
        let totalRevenue     = parseFloat( revenueAmount );
        let totalExpense     = 0;
        
        // Calculate Other Revenue
        const otherRevenueAmount = parseFloat( revenueCalcTable.find('input').val() );
        if( ! isNaN( otherRevenueAmount ) && otherRevenueAmount != undefined ){
            totalRevenue += otherRevenueAmount;
        }

        // Calculate Expenses
        expensesCalcTable.find('.calc_amount input').each( function(){
            const expenseCost = parseFloat( $(this).val() );
            if( ! isNaN( expenseCost ) && expenseCost != undefined ){
                totalExpense += expenseCost;
            }
        });

        grossProfitAmount = totalRevenue - cogsAmount;

        // Revenue
        revenueCalcTable.find('#__sales_revenue .__sales_revenue_data').text(toCurrency( revenueAmount.toFixed(2) ));
        revenueCalcTable.find('#__sales_revenue .__sales_revenue_data').attr('data-amount', revenueAmount );
        revenueCalcTable.find('.__total_revenue').text(toCurrency( totalRevenue.toFixed(2) ));
        // COGS
        cogsCalcTable.find('#__cogs .__cogs_data').text( toCurrency( cogsAmount.toFixed(2) )).attr('data-amount', cogsAmount );
        cogsCalcTable.find('.__total_cogs').text( toCurrency( cogsAmount.toFixed(2) ));
        // GROSS PROFIT
        grossProfitCalcTable.find('.__gross_profit').text( toCurrency( grossProfitAmount.toFixed(2) ));

        // Expenses
        expensesCalcTable.find('.__total_expense').text( toCurrency( totalExpense.toFixed(2) ) );

        // NET INCOME
        const netIncome = grossProfitAmount - totalExpense;
        netIncomeCalcTable.find('.__net_income').text( toCurrency( netIncome.toFixed(2) ) );

    }

    const populateGrossProfitData    = ( ) => {
        let _cost_price   = 0;
        let _retail_price = 0;
        let _discount     = 0;
        let _cod_discount = 0;
        let _tax          = 0;
        let _others       = 0;
        let _total_amount = 0;
        $.each( grossProfitData, function( index, value ){
            _cost_price   += parseFloat( value._cost_price );
            _retail_price += parseFloat( value._retail_price );
            _discount     += parseFloat( value._discount );
            _cod_discount += parseFloat( value._cod_discount );
            _tax          += parseFloat( value._tax );
            _others       += parseFloat( value._others );
            _total_amount += parseFloat( value._total_amount );
        } );

        grossProfitTable.find( '._cost_price' ).text( _cost_price.toFixed(2) );
        grossProfitTable.find( '._retail_price' ).text( _retail_price.toFixed(2) );
        grossProfitTable.find( '._discount' ).text( _discount.toFixed(2) );
        grossProfitTable.find( '._cod_discount' ).text( _cod_discount.toFixed(2) );
        grossProfitTable.find( '._tax' ).text( _tax.toFixed(2) );
        grossProfitTable.find( '._others' ).text( _others.toFixed(2) );
        grossProfitTable.find( '._total_amount' ).text( _total_amount.toFixed(2) );

        // Populate data to Calculator template
        revenueAmount   = _total_amount;
        cogsAmount      = _cost_price;
        grossProfitReset();
        grossProfitCalculator( );
    }

    if( grossProfitDaterangeFilter.length ){
        
        const getGrossProfitLoss = () => {
            grossProfitContentID.find('#cwms1661_grossprofit-content-wrapper .loader-wrapper').remove();
            // Add date range in page title
            grossProfitContentID.find('.gross-profit_daterange_header').text( `${grossProfitStartDate.format('MMMM D, YYYY')} - ${grossProfitEndDate.format('MMMM D, YYYY')}`);

            $.ajax({
                type 	: 'post',
                dataType : 'json',
                url 	: ajaxURL,
                data 	: {
                    action : 'cwms_get_grossprofit_records',
                    datesRange : { start: grossProfitStartDate.format('YYYY-MM-DD'), end : grossProfitEndDate.format('YYYY-MM-DD') }
                },
                beforeSend:function(){
                    grossProfitContentID.find('#cwms1661_grossprofit-content-wrapper').append(loader( 'Loading...' ));
                },
                success:function(res){
                    grossProfitContentID.find('#cwms1661_grossprofit-content-wrapper .loader-wrapper').remove();
                    grossProfit.clear().rows.add(res.data).draw();
                    grossProfitData = res.data
                    populateGrossProfitData(  );
                },
                error: function(xhr, status, error) {
                    alert( `Error: ${error} please reload the page and try again` );
                }
            });
        }

        function grossProfitDaterangepickerCallback(start, end) {
            grossProfitStartDate   = start;
            grossProfitEndDate     = end;
            getGrossProfitLoss();
        }

        grossProfitDaterangeFilter.daterangepicker({
            opens: 'right',
            locale: {
                format: 'YYYY-MM-DD'
            },
            startDate: grossProfitStartDate,
            endDate: grossProfitEndDate,
            ranges: {
                'Today'          : [moment(), moment()],
                'Yesterday'      : [moment().subtract(1, 'days'), moment().subtract(1, 'days')],
                'Last 7 Days'    : [moment().subtract(6, 'days'), moment()],
                'Last 30 Days'   : [moment().subtract(29, 'days'), moment()],
                'This Month'     : [moment().startOf('month'), moment().endOf('month')],
                'Last Month'     : [moment().subtract(1,'months').startOf('month'), moment().subtract(1,'months').endOf('month')],
                'This Year'      : [moment().startOf('year'), moment()]
            }
        }, grossProfitDaterangepickerCallback);
        grossProfitDaterangepickerCallback( grossProfitStartDate, grossProfitEndDate );
    }

    grossProfitCalcWrapID.on('click', '.cwms-download-profitloss-statement', function( e ){
        e.preventDefault();
        const currElem = $(this);
        if( grossProfitData.length === 0 ){
            alert( errorMessage );
            return;
        }

        let otherRevenueAmount = parseFloat( revenueCalcTable.find('input').val() );
        if( isNaN( otherRevenueAmount ) || otherRevenueAmount == undefined ){
            otherRevenueAmount = 0;
        }
        const expensesData       = [];

        expensesCalcTable.find('.calc_amount input').each( function(){
            const currElem    = $(this);
            let expenseCost   = parseFloat( currElem.val() );
            if( isNaN( expenseCost ) || expenseCost == undefined ){
                expenseCost = 0
            }
            expensesData.push(
                {
                    'label' : currElem.closest('tr').find('th').text(),
                    'amount' : expenseCost
                }
            )
        });
        $.ajax({
            type 	: 'post',
            dataType : 'json',
            url 	: ajaxURL,
            data 	: {
                action : 'cwms_download_grossprofit_statement',
                dateRange : `${grossProfitStartDate.format('MMMM D, YYYY')} - ${grossProfitEndDate.format('MMMM D, YYYY')}`,
                records: grossProfitData,
                revenueAmount: revenueAmount,
                otherRevenueAmount: otherRevenueAmount,
                cogsAmount: cogsAmount,
                expensesData : expensesData
            },
            beforeSend:function(){
                currElem.prop('disabled', true );
                grossProfitContentID.find('#cwms1661_grossprofit-content-wrapper').append(loader( 'Loading...' ));
            },
            success:function(res){
                currElem.prop('disabled', false );
                grossProfitContentID.find('#cwms1661_grossprofit-content-wrapper .loader-wrapper').remove();
                download_file( res.file_url, res.file_name );   
            },
            error: function(xhr, status, error) {
                alert( `Error: ${error} please reload the page and try again` );
            }
        });

    });

});