jQuery(document).ready(function($){  
    const ajaxURL               = cwmsAjaxHanlder.ajaxurl; 
    const dashboardURL          = cwmsAjaxHanlder.dashboardURL; 
    const tableLabels           = cwmsAjaxHanlder.tableLabels;
    const dataTableTitle        = cwmsAjaxHanlder.dataTableTitle
    const processLabel          = cwmsAjaxHanlder.processingLabel;
    const deleteConfirmation    = cwmsAjaxHanlder.deleteConfirmation;
    const proceedConfirmation   = cwmsAjaxHanlder.proceedConfirmation;
    const noItemSelectedMessage = cwmsAjaxHanlder.noItemSelectedMessage;
    const bulkDeleteLabel       = cwmsAjaxHanlder.bulkDeleteLabel;
    const invoiceSequence       = cwmsAjaxHanlder.invoice_sequence;

    const currency          = cwmsAjaxHanlder.currency;
    const currencyLocal     = cwmsAjaxHanlder.currencyLocal;
    const inputTooShort     = cwmsAjaxHanlder.inputTooShort;
    const errorLoading      = cwmsAjaxHanlder.errorLoading;
    const loadingMore       = cwmsAjaxHanlder.loadingMore;
    const noResults         = cwmsAjaxHanlder.noResults;
    const searching         = cwmsAjaxHanlder.searching;

    const dataTableObject = {
        dom: 'Bfrtip',
        columnDefs: [ {
                "targets": 0,
                'checkboxes': { 'selectRow': true }
            } ],
        'select': { 'style': 'multi' },
        order: [],
        "language": cwmsAjaxHanlder.tableLabels,
        responsive: true,
        processing: true,
        "createdRow": function( row, data, dataIndex ) {
            $(row).attr( 'data-id', data.ID );
        }
    };

    const download_file = (fileURL, fileName) => {
        // for non-IE
        if (!window.ActiveXObject) {
            var save = document.createElement('a');
            save.href = fileURL;
            save.target = '_blank';
            var filename = fileURL.substring(fileURL.lastIndexOf('/')+1);
            save.download = fileName || filename;
            if ( navigator.userAgent.toLowerCase().match(/(ipad|iphone|safari)/) && navigator.userAgent.search("Chrome") < 0) {
                    document.location = save.href; 
                // window event not working here
                }else{
                    var evt = new MouseEvent('click', {
                        'view': window,
                        'bubbles': true,
                        'cancelable': false
                    });
                    save.dispatchEvent(evt);
                    (window.URL || window.webkitURL).revokeObjectURL(save.href);
                }	
        }
        // for IE < 11
        else if ( !! window.ActiveXObject && document.execCommand)     {
            var _window = window.open(fileURL, '_blank');
            _window.document.close();
            _window.document.execCommand('SaveAs', true, fileName || fileURL)
            _window.close();
        }
    }

    const loader = ( string = 'loading...') => {
        return `<div class="loader-wrapper">
        <div class="loder-crcil"></div>
          <div class="text">${string}</div>
        </div>`;
    }
    // Function  helpers
    $.fn.dataTable.Api.register( 'processing()', function ( show ) {
        return this.iterator( 'table', function ( ctx ) {
            ctx.oApi._fnProcessingDisplay( ctx, show );
        } );
    } );
    const getTableSelectedRowIds = ( currTable ) => {
        let ids = [];
        currTable.find('tbody tr').each( function(){
            if( !$(this).find('.dt-checkboxes').is(":checked") ){
                return; // continue the loop
            }
            ids.push( $(this).data('id') );
        });
        return ids;
    }
    const resetTableCheckboxes = ( currTable ) => {
        currTable.find('tbody tr, thead tr').each( function(){
            $(this).find('.dt-checkboxes, .dt-checkboxes-select-all [type="checkbox"]').prop('checked', false );
        });
    }
    const disableTableCheckboxes = ( currTable ) => {
        currTable.find('tbody tr, thead tr').each( function(){
            $(this).find('.dt-checkboxes, .dt-checkboxes-select-all [type="checkbox"]').prop('disabled', true );
        });
    }

    // #######################  Membership Notification  ####################################

    const dislpayMembershipNotification = () => {
        $.ajax({
            type 	: 'post',
            dataType : 'HTML',
            url 	: ajaxURL,
            data 	: {
                action : 'cwms_display_membership_notification',
            },
            beforeSend:function(){ },
            success:function(html){
                $('body').find('#cwms-membership_notification_wrapper').html(html);
            }
        });
    }

    dislpayMembershipNotification();
    
    // #######################  Product datatable  ####################################

    const productTableData  = cwmsAjaxHanlder.productTableData;
    const productTableWrap  = $('#cwms-all-products-wrapper');
    const productTable      = $(`#${productTableData.id}`);
    const productModal      = $(`#${productTableData.modalID}`);
    const priceModal        = $(`#${productTableData.priceModalID}`);
    const supplierPriceModal        = $(`#${productTableData.supplierPriceModalID}`);
    const productHeader     = productTableData.headers;
    const productFields     = productTableData.productFields;
    let productColumns      = [{data: 'ID', mData:'ID'}];
    let productTableParam   = dataTableObject;

    // Area filter
    const productThresholdFilter             = $('#product_threshold_filter');
    const productThresholdFilterPlaceholder  = productThresholdFilter.data('placeholder');
    const productCatFilter                = $('#product_cat_filter');
    const productCatFilterPlaceholder     = productCatFilter.data('placeholder');
    const productSubcatFilter             = $('#product_subcat_filter');
    const productSubcatFilterPlaceholder  = productSubcatFilter.data('placeholder');

    let productCat              = null;
    let productSubcat           = null;
    let threshold               = $('#product_threshold_filter').length ? $('#product_threshold_filter').val() : 0 ;

    productHeader.map( elem  => productColumns.push( { data: elem } ) );
    productTableParam.ajax     = { url: `${ajaxURL}?action=cwms_getproducts&threshold=${threshold}` };
    productTableParam.columns  = productColumns;

    productTableParam.buttons  = [
        {
            text: bulkDeleteLabel,
            className: 'dataTable-bulk-delete btn btn-sm btn-danger',
            action: function ( e, dt, node, config ) {
                const rows_selected = getTableSelectedRowIds(productTable);
                if( !rows_selected.length ){
                    alert(noItemSelectedMessage);
                    return;
                };
                if( !confirm(deleteConfirmation) ){
                    resetTableCheckboxes(productTable);
                    return;
                }
                $.ajax({
                    type 	: 'post',
                    dataType : 'json',
                    url 	: ajaxURL,
                    data 	: {
                        action : 'cwms_bulkdelete_product',
                        ids : rows_selected,			
                    },
                    beforeSend:function(){
                        supplier.processing( true );
                    },
                    success:function(response){
                        resetTableCheckboxes(productTable);
                        if( response.status == 'error'){
                            alert(response.message);
                            supplier.processing( false );
                            return;
                        }
                        location.reload(true);
                    }
                });
            },
        },
        {
            text : tableLabels.downloadExcelLabel,
            className: 'btn btn-sm btn-primary',
            action: function( e, dt, node, config ){
                const tableData     = product.rows().data();
                const reportLabel   = $('#product_threshold_filter option:selected').text();
                if( tableData.length == 0){
                    alert( tableLabels.emptyTable )
                    return;
                }

                let parsedData  = []
                $.each( tableData, function( index, valObj ){
                    const formattedData = {};
                    $.each( productHeader, function( index, valHeader ){
                        if( valHeader == "_cost_price" || valHeader == "_history" ){
                            return;
                        }
                        const headerLabel = productFields[valHeader].label;
                        formattedData[headerLabel] = valObj._data[valHeader];
                    }); 
                    parsedData.push( formattedData );
                });
                var csv  = Papa.unparse( parsedData );
                var blob = new Blob([csv]);
                if (window.navigator.msSaveOrOpenBlob){  // IE hack; see http://msdn.microsoft.com/en-us/library/ie/hh779016.aspx
                    window.navigator.msSaveBlob(blob, reportLabel+"-report.csv");
                }else{
                    var a = window.document.createElement("a");
                    a.href = window.URL.createObjectURL(blob, {type: "text/plain"});
                    a.download = reportLabel+"-report.csv";
                    document.body.appendChild(a);
                    a.click();  // IE: "Access is denied"; see: https://connect.microsoft.com/IE/feedback/details/797361/ie-10-treats-blob-url-as-cross-origin-and-denies-access
                    document.body.removeChild(a);
                }
            }
        }
    ];
    if( !productTableData.delete ){
        productTableParam.buttons = [];
    }

    productTableParam.order    = [];

    const product  = productTable.DataTable(productTableParam);
    const getProducts = () => {
        $.ajax({
            url: `${ajaxURL}?action=cwms_getproducts&threshold=${threshold}&cat=${productCat}&subcat=${productSubcat}`,
            type: 'get',
            beforeSend: function () {
                productTableWrap.find('.filter-section select, .filter-section input').prop('disabled', true );
                productTableWrap.find(`.dataTables_wrapper`).addClass('d-none');
                productTableWrap.append( loader() )
            },
            success: function ( response ) {
                productTableWrap.find('.filter-section select, .filter-section input').prop('disabled', false )
                productTableWrap.find( '.loader-wrapper' ).remove();
                productTableWrap.find(`.dataTables_wrapper`).removeClass('d-none');
                product.clear().rows.add(response.data).draw();
            }
        });
    }
    // Search for parent category filter 
    productThresholdFilter.select2({
        allowClear: true,
        placeholder: productThresholdFilterPlaceholder,
    }).on('select2:select', function(e){
        threshold = e.params.data.id;
        getProducts();
    }).on('select2:clear', function(e){
        threshold = 0;
        getProducts();
    }); 


    // Search for parent category filter 
    productCatFilter.select2({
        allowClear: true,
        placeholder: productCatFilterPlaceholder,
    }).on('select2:select', function(e){
        productCat = e.params.data.id;
        getProducts();
    }).on('select2:clear', function(e){
        productCat = null;
        getProducts();
    }); 

    // Search for parent subcategory  filter 
    productSubcatFilter.select2({
        allowClear: true,
        placeholder: productSubcatFilterPlaceholder,
    }).on('select2:select', function(e){
        productSubcat = e.params.data.id;
        getProducts();
    }).on('select2:clear', function(e){
        productSubcat = null;
        getProducts();
    }); 

    // Delete product script
    $('#cwms_productsTable').on('click', '.row-actions .cwms-delete_product', function(e){
        e.preventDefault();
        const currElem      = $(this);
        const currRow       = currElem.closest('tr');
        if( ! confirm(deleteConfirmation) ){
            return;
        }
        $.ajax({
			type 	: 'post',
			dataType : 'json',
			url 	: ajaxURL,
			data 	: {
				action : 'cwms_delete_product',
				productID : currElem.closest('.row-actions').data('id'),			
            },
			beforeSend:function(){
				currRow.html(`<td class="cwms-tblrow" colspan="${currRow.children('td').length}">${processLabel}</td>`);
			},
			success:function(response){
                const rowClass = response.code != 200 ? 'cwms-error' : 'cwms-success' ;
				currRow.addClass(rowClass).find('td').text(response.message);
                if( response.code == 200 ){
                    setTimeout( function(){ currRow.remove() }, 3000 )
                }
			}
		});
    });

    // Product history
    let currPage        = 1;
    let productID       = null;
    let currPricePage   = 1;
    let currProdPriceID = null;
    const displayProductHistory = ( data ) => {
        const tbldBody = productModal.find('#cwms-payment-records_table tbody');
        data.forEach( element => {
            tbldBody.append(
                `
                <tr>
                    <td>${element.type_label}</td>
                    <td>${element.trans_number}</td>
                    <td>${element.qty_added}</td>
                    <td>${element.created_date}</td>
                    <td>${element.created_by}</td>
                    <td>${element.remarks}</td>
                </tr>
                `
            );
        });
    }
    const displayProductPriceHistory = ( data ) => {
        const tbldBody = priceModal.find('#cwms-product-price-records_table tbody');
        data.forEach( element => {
            tbldBody.append(
                `
                <tr>
                    <td>${element.po_number}</td>
                    <td>${element.vendor_name}</td>
                    <td>${element.created_date}</td>
                    <td>${element.cost_price}</td>
                </tr>
                `
            );
        });
    }
    // Inventory history
    $('#cwms_productsTable').on('click', '.cwms-view-history', function( e ){
        e.preventDefault();
        const productName = $(this).data('title');
        productID = $(this).data('id');
        productModal.find('.modal-title').text(productName);

        currPage    = 1;
        $.ajax({
			type 	: 'post',
			dataType : 'json',
			url 	: ajaxURL,
			data 	: {
				action : 'cwms_get_product_history',
				productID : productID,
                currPage : currPage	
            },
			beforeSend:function(){
                productModal.find('#cwms-payment-records_table tbody').html("");
                productModal.find('#cwms-payment-records_table tfoot').html(
                    '<tr><td colspan="6" style="text-align:center;"><a href="#" id="cwms-show-more_history">Show more</a></td></tr>'
                );
                productModal.find('#cwms-payment-records_wrapper').css({'display':'none'});
				productModal.find('.modal-body').append( loader() );
			},
			success:function(response){
                displayProductHistory( response );
                productModal.find('#cwms-payment-records_wrapper').css({'display':'block'});
				productModal.find('.modal-body .loader-wrapper').remove( );
                if( response.length < 12 ){
                    productModal.find('#cwms-payment-records_table tfoot').html("");
                }
			}
		});
    });

    productModal.on( 'click', '#cwms-show-more_history', function( e ){
        e.preventDefault();
        currPage++;
        $.ajax({
			type 	: 'post',
			dataType : 'json',
			url 	: ajaxURL,
			data 	: {
				action : 'cwms_get_product_history',
				productID : productID,
                currPage : currPage	
            },
			beforeSend:function(){
                
			},
			success:function(response){
                displayProductHistory( response );
                if( response.length < 12 ){
                    productModal.find('#cwms-payment-records_table tfoot').html('');
                }
			}
		});
    });
    // Price history
    $('#cwms_productsTable').on('click', '.cwms-view-price_history', function( e ){
        e.preventDefault();
        const productName   = $(this).data('title');
        currProdPriceID     = $(this).data('id');
        priceModal.find('.modal-title').text(productName);

        currPricePage    = 1;
        $.ajax({
			type 	: 'post',
			dataType : 'json',
			url 	: ajaxURL,
			data 	: {
				action : 'cwms_get_product_price_history',
				currProdPriceID : currProdPriceID,
                currPricePage : currPricePage	
            },
			beforeSend:function(){
                priceModal.find('#cwms-product-price-records_table tbody').html("");
                priceModal.find('#cwms-product-price-records_table tfoot').html(
                    '<tr><td colspan="4" style="text-align:center;"><a href="#" id="cwms-show-more_price_history">Show more</a></td></tr>'
                );
                priceModal.find('#cwms-product-price-records_wrapper').css({'display':'none'});
				priceModal.find('.modal-body').append( loader() );
			},
			success:function(response){
                displayProductPriceHistory( response );
                priceModal.find('#cwms-product-price-records_wrapper').css({'display':'block'});
				priceModal.find('.modal-body .loader-wrapper').remove( );
                if( response.length < 12 ){
                    priceModal.find('#cwms-product-price-records_table tfoot').html("");
                }
			}
		});
    });

    priceModal.on( 'click', '#cwms-show-more_price_history', function( e ){
        e.preventDefault();
        currPricePage++;
        $.ajax({
			type 	: 'post',
			dataType : 'json',
			url 	: ajaxURL,
			data 	: {
				action : 'cwms_get_product_price_history',
				currProdPriceID : currProdPriceID,
                currPricePage : currPricePage	
            },
			beforeSend:function(){
                
			},
			success:function(response){
                displayProductPriceHistory( response );
                if( response.length < 12 ){
                    priceModal.find('#cwms-product-price-records_table tfoot').html('');
                }
			}
		});
    });

    // Supplier Price history
    const displaySuppliersPriceHistory = ( data, prodId ) => {
        const contentElem = supplierPriceModal.find('#cwms-product-supplier-price-records_content');
        contentElem.append('<table id="suppliersPriceHistoryTable" class="table table-bordered"></table>');
        let theads      = '';
        let maxRecords  = 0;
        $.each( data, function( index, obj ){
            const tbCol = 'col_' + prodId + '_' + index;
            theads += `<th class="${tbCol}">${obj.supplier_name}</th>`;
            if( maxRecords < obj.records.length ){
                maxRecords = obj.records.length;
            }
        });
        contentElem.find('#suppliersPriceHistoryTable').append(`<thead style="background-color: #eee;"><tr>${theads}</tr></thead><tbody></tbody>`);
        for (let index = 0; index <= maxRecords - 1; index++) {
            const rowID = 'row_' + prodId + '_' + index;
            contentElem.find('#suppliersPriceHistoryTable tbody').append(`<tr id="${rowID}"></tr>`);  
            for (let _index = 0; _index < data.length; _index++) {
                const records = data[_index].records[index];
                const tbCol = 'col_' + prodId + '_' + _index;
                const costPrice = records ? `<strong>${records.cost_price}</strong><br/><a href="${dashboardURL}?cwmspage=view-po&id=${records.po_id}" target="_blank">${records.po_number}</a><br/><i class="text-info">${records.created_date}</i>`  : '--' ;
                contentElem.find(`#suppliersPriceHistoryTable tbody #${rowID}`).append(`<td class="${tbCol}">${costPrice}</td>>`);  
            }
        }
    }
    $('#cwms_productsTable').on('click', '.cwms-view-price_supplier', function( e ){
        e.preventDefault();
        const productName   = $(this).data('title');
        currProdPriceID     = $(this).data('id');
        supplierPriceModal.find('.modal-title').text(productName);

        currPricePage    = 1;
        $.ajax({
			type 	: 'post',
			dataType : 'json',
			url 	: ajaxURL,
			data 	: {
				action : 'cwms_get_product_suppliers_price_history',
				currProdPriceID : currProdPriceID,
                currPricePage : currPricePage	
            },
			beforeSend:function(){
                supplierPriceModal.find('#cwms-product-supplier-price-records_content').html('');
                supplierPriceModal.find('#cwms-product-price-records_wrapper').css({'display':'none'});
				supplierPriceModal.find('.modal-body').append( loader() );
			},
			success:function(response){
                supplierPriceModal.find('#cwms-product-price-records_wrapper').css({'display':'block'});
				supplierPriceModal.find('.modal-body .loader-wrapper').remove( );
                if( response.length ){
                    displaySuppliersPriceHistory( response, currProdPriceID );
                }else{
                    supplierPriceModal.find('#cwms-product-supplier-price-records_content').html(`
                        <div class="text-center alert alert-danger">No records found.</div>
                    `);
                }
			}
		});
    });
    $('#cwms-product-price_supplier-modal').on('mouseenter', '#suppliersPriceHistoryTable td, #suppliersPriceHistoryTable th', function(){
        const classAttr = $(this).attr('class');
        $('#cwms-product-price_supplier-modal').find( `#suppliersPriceHistoryTable td.${classAttr}` ).addClass('highlight');
    });
    $('#cwms-product-price_supplier-modal').on('mouseleave', '#suppliersPriceHistoryTable td, #suppliersPriceHistoryTable th', function(){
        $('#cwms-product-price_supplier-modal').find( `#suppliersPriceHistoryTable td`).removeClass('highlight');
    });

    // Product Form - Category
    if( !cwmsAjaxHanlder.subCatAllOption ){
        const productFormElem = $('#cwms-product-form');
        productFormElem.on('change', 'select[name="_category"]', function(){
            const children = $(this).find('option:selected').data('children')
            if( children && children.length ){
                productFormElem.find('select[name="_sub_category"]').prop( 'disabled', false );
                $.each( children, function( index, value ){
                    productFormElem.find('select[name="_sub_category"]').append(`<option value="${value.id}">${value.label}</option>`);
                })
            }else{
                productFormElem.find('select[name="_sub_category"]').prop( 'disabled', true );
                productFormElem.find('select[name="_sub_category"] option').not(':first').remove();
            }
        } );
    }
    
    // #######################  Suppliers datatable  ####################################

    const supplierTableData = cwmsAjaxHanlder.supplierTableData
    
    let supplierTableParam  = dataTableObject;
    let supplierColumns     = [{data: 'ID', mData:'ID'}];
    const supplierTable     = $(`#${supplierTableData.id}`);
    const supplierHeader    = supplierTableData.headers;
    supplierHeader.map( elem  => supplierColumns.push( { data: elem } ) );

    supplierTableParam.ajax     = { url: ajaxURL + '?action=cwms_get_suppliers' };
    supplierTableParam.columns  = supplierColumns;
    supplierTableParam.buttons  = [{
                text: bulkDeleteLabel,
                className: 'dataTable-bulk-delete btn btn-sm btn-danger',
                action: function ( e, dt, node, config ) {
                    const rows_selected = getTableSelectedRowIds(supplierTable);
                    if( !rows_selected.length ){
                        alert(noItemSelectedMessage);
                        return;
                    };
                    if( !confirm(deleteConfirmation) ){
                        resetTableCheckboxes(supplierTable);
                        return;
                    }
                    $.ajax({
                        type 	: 'post',
                        dataType : 'json',
                        url 	: ajaxURL,
                        data 	: {
                            action : 'cwms_bulkdelete_supplier',
                            ids : rows_selected,			
                        },
                        beforeSend:function(){
                            supplier.processing( true );
                        },
                        success:function(response){
                            resetTableCheckboxes(supplierTable);
                            if( response.status == 'error'){
                                alert(response.message);
                                supplier.processing( false );
                                return;
                            }
                            location.reload(true);
                        }
                    });
                }
            },
            {
                extend: 'excelHtml5',
                text : tableLabels.downloadExcelLabel,
                className: 'btn btn-sm btn-primary',
                title: `${dataTableTitle} - Suppliers List`,
                // messageTop: dynamicMessage(),
                exportOptions: {
                    stripHtml: true,
                    stripNewlines: false
                }
            }
        ];
    if( !supplierTableData.delete ){
        supplierTableParam.buttons = [];
    }
    const supplier  = supplierTable.DataTable(supplierTableParam);
    if( !supplierTableData.delete ){
        setTimeout( function(){
            disableTableCheckboxes(supplierTable);
        }, 500 )
    }
    // Delete supplier script
    supplierTable.on('click', '.row-actions .cwms-delete_supplier', function(e){
        e.preventDefault();
        const currElem      = $(this);
        const currRow       = currElem.closest('tr');
        if( ! confirm(deleteConfirmation) ){
            return;
        }
        $.ajax({
			type 	: 'post',
			dataType : 'json',
			url 	: ajaxURL,
			data 	: {
				action : 'cwms_delete_supplier',
				id : currRow.closest('tr').data('id'),			
            },
			beforeSend:function(){
				currRow.html(`<td class="cwms-tblrow" colspan="${currRow.children('td').length}">${processLabel}</td>`);
			},
			success:function(response){
                const rowClass = response.code != 200 ? 'cwms-error' : 'cwms-success' ;
				currRow.addClass(rowClass).find('td').text(response.message);
                if( response.code == 200 ){
                    setTimeout( function(){ currRow.remove() }, 3000 )
                }
			}
		});
    });

    // #######################  Users datatable  ####################################

    const roleFilterElem        = $('#alluser_role_filter');
    const roleFilterPlcHolder   = roleFilterElem.data('placeholder');
    const userTableData         = cwmsAjaxHanlder.userTableData;
    const downloadHeaders       = userTableData.downloadHeaders;
    let userTableParam          = dataTableObject;
    let userColumns             = [{data: 'ID', mData:'ID'}];
    let userRoleFilter          = 'all';
    const userTable             = $(`#${userTableData.id}`);
    const userHeader            = Object.keys(downloadHeaders);
    userHeader.map( elem  => userColumns.push( { data: elem } ) );

    userTableParam.ajax     = { url: `${ajaxURL}?action=cwms_get_users&role=${userRoleFilter}` };
    userTableParam.columns  = userColumns;
    userTableParam.buttons  = [
        {
            text: bulkDeleteLabel,
            className: 'dataTable-bulk-delete btn btn-sm btn-danger',
            action: function ( e, dt, node, config ) {
                const rows_selected = getTableSelectedRowIds(userTable);
                if( !rows_selected.length ){
                    alert(noItemSelectedMessage);
                    return;
                };
                if( !confirm(deleteConfirmation) ){
                    resetTableCheckboxes(userTable);
                    return;
                }
                $.ajax({
                    type 	: 'post',
                    dataType : 'json',
                    url 	: ajaxURL,
                    data 	: {
                        action : 'cwms_bulkdelete_users',
                        ids : rows_selected,			
                    },
                    beforeSend:function(){
                        user.processing( true );
                    },
                    success:function(response){
                        resetTableCheckboxes(userTable);
                        if( response.status == 'error'){
                            alert(response.message);
                            user.processing( false );
                            return;
                        }
                        location.reload(true);
                    }
                });
            }
        },
        {
            text : tableLabels.downloadRecords,
            className: 'btn btn-sm btn-primary',
            action: function( e, dt, node, config ){
                const tableData     = user.rows().data();
                const filteredRole   = $('#alluser_role_filter').val();
                const reportLabel   = filteredRole ? cwmsAjaxHanlder.userRoles[filteredRole] : 'Users' ;

                if( tableData.length == 0){
                    alert( tableLabels.emptyTable )
                    return;
                }
                let parsedData  = [];
                $.each( tableData, function( index, valObj ){
                    const formattedData = {};
                    $.each( userHeader, function( index, valHeader ){
                        if (valHeader == 'username') return;
                        const headerLabel = downloadHeaders[valHeader];
                        const regX = /(<([^>]+)>)/ig;
                        formattedData[headerLabel] = valObj[valHeader].replace(regX, '' );
                    }); 
                    parsedData.push( formattedData );
                });
                var csv  = Papa.unparse( parsedData );
                var blob = new Blob([csv]);
                if (window.navigator.msSaveOrOpenBlob){  // IE hack; see http://msdn.microsoft.com/en-us/library/ie/hh779016.aspx
                    window.navigator.msSaveBlob(blob, reportLabel+"-records.csv");
                }else{
                    var a = window.document.createElement("a");
                    a.href = window.URL.createObjectURL(blob, {type: "text/plain"});
                    a.download = reportLabel+"-records.csv";
                    document.body.appendChild(a);
                    a.click();  // IE: "Access is denied"; see: https://connect.microsoft.com/IE/feedback/details/797361/ie-10-treats-blob-url-as-cross-origin-and-denies-access
                    document.body.removeChild(a);
                }
            }
        }
    ];
    if( !userTableData.delete ){
        userTableParam.buttons = [];
    }
    const user  = userTable.DataTable(userTableParam);
    const getAllUsersData = ( ) => {
        $.ajax({
            url: `${ajaxURL}?action=cwms_get_users&role=${userRoleFilter}`,
            type: 'get',
            beforeSend: function () {
                userTable.addClass('d-none');
                userTable.closest('.table-reponsive').prepend( loader('Processing...') );
            },
            success: function ( response ) {
                userTable.closest('.table-reponsive').find( '.loader-wrapper' ).remove();
                userTable.removeClass('d-none');
                user.clear().rows.add(response.data).draw();
            }
        });
    }

    if( !userTableData.delete ){
        setTimeout( function(){
            disableTableCheckboxes(userTable);
        }, 500 )
    }
    // Delete function for the user 
    user.on('click', '.row-actions .cwms-delete_user', function(e){
        e.preventDefault();
        const currElem      = $(this);
        const currRow       = currElem.closest('tr');
        if( ! confirm(deleteConfirmation) ){
            return;
        }
        $.ajax({
			type 	: 'post',
			dataType : 'json',
			url 	: ajaxURL,
			data 	: {
				action : 'cwms_delete_user',
				id : currRow.data('id'),			
            },
			beforeSend:function(){
				currRow.html(`<td class="cwms-tblrow" colspan="${currRow.children('td').length}">${processLabel}</td>`);
			},
			success:function(response){
                const rowClass = response.code != 200 ? 'cwms-error' : 'cwms-success' ;
				currRow.addClass(rowClass).find('td').text(response.message);
                if( response.code == 200 ){
                    setTimeout( function(){ currRow.remove() }, 3000 )
                }
			}
		});
    });

    const hideDeleteBtn = ( filterValue ) => {
        if( 'cwms_inactive_account' == filterValue ){
            $('body').find('.dt-buttons .dataTable-bulk-delete').addClass('d-none');
        }else{
            $('body').find('.dt-buttons .dataTable-bulk-delete').removeClass('d-none');
        }
    }

    // Search user role
    roleFilterElem.select2({
        allowClear: true
    }).on('select2:select', function(e){
        userRoleFilter = e.params.data.id;
        hideDeleteBtn( userRoleFilter );
        getAllUsersData();
    }).on('select2:clear', function(e){
        userRoleFilter = 'all';
        hideDeleteBtn( userRoleFilter );
        getAllUsersData();
    });  

    // #######################  PO datatable  ####################################
    
    const poTableData  = cwmsAjaxHanlder.poTableData;
    let poTableParam  = dataTableObject;
    let poColumns     = poTableData.status != 'cwms-completed' ? [{data: 'ID', mData:'ID'}] : [];
    const poTable     = $(`#${poTableData.id}`);
    const poHeader    = poTableData.headers;
    poHeader.map( elem  => poColumns.push( { data: elem } ) );
    poTableParam.ajax     = { url: ajaxURL + '?action=cwms_get_all_po&status=' + poTableData.status };
    poTableParam.columns  = poColumns;
    poTableParam.buttons  = [];
    poTableParam.order    = [ [4, 'DESC'], [1, 'ASC'], [2, 'ASC'] ];

    if( poTableData.status == 'cwms-completed' ){
        poTableParam.order      = [ [3, 'DESC'], [0, 'ASC'], [1, 'ASC'] ];
        poTableParam.columnDefs = [];
        poTableParam.select     = null;
    }

    const po  = poTable.DataTable(poTableParam);

    poTable.on('click', '.cwms-delete_po', function(e){
        e.preventDefault();
        const currElem = $(this);
        const currRow  = currElem.closest('tr');
        const poID     = currElem.closest('.row-actions').data('id');
        if( !confirm(deleteConfirmation) ){
            return;
        }
        $.ajax({
			type 	: 'post',
			dataType : 'json',
			url 	: ajaxURL,
			data 	: {
				action : 'cwms_delete_po',
                poID : poID
            },
			beforeSend:function(){
				currRow.html(`<td class="cwms-tblrow" colspan="${currRow.children('td').length}">${processLabel}</td>`);
			},
			success:function(response){
                const rowClass = response.code != 200 ? 'cwms-error' : 'cwms-success' ;
				currRow.addClass(rowClass).find('td').text(response.message);
                if( response.code == 200 ){
                    setTimeout( function(){ currRow.remove() }, 3000 )
                }
			}
		});
    });
    
    $('#cwms-page-all-po').on('click', '.cwms-po_bulk_actions', function(e){
        e.preventDefault();
        const actionType = $(this).data('action');
        if( $(this).parent().hasClass('disabled') || actionType == poTableData.status ){
            return;
        }
        const rows_selected = getTableSelectedRowIds(poTable);
        if( !rows_selected.length ){
            alert(noItemSelectedMessage);
            return;
        };

        const confirmMessage = actionType == 'cwms-delete' ? deleteConfirmation : proceedConfirmation ;

        if( !confirm(confirmMessage) ){
            resetTableCheckboxes(productTable);
            return;
        }

        $.ajax({
			type 	: 'post',
			dataType : 'json',
			url 	: ajaxURL,
			data 	: {
				action : 'cwms_po_bulk_action',
                poIds : rows_selected,
				actionType : actionType,
                poTableData : poTableData	
            },
			beforeSend:function(){
				$('body').append('<div class="loading">loading....</div>');
			},
			success:function(res){

                if( res.status == 'error' ){
                    const template = `
                        <div id="cwms-notification_error" class="alert alert-danger text-center">${res.message}</div>
                    `;
                    $('#cwms-page_content').prepend(template);
                    setTimeout( function(){
                        $('body').find('#cwms-notification_error').remove();
                    }, 3000 );
                    $('body').find('.loading').remove();
                }else{
                    location.reload();
                }
               
			}
		});
    });

    // #######################  Sales Order datatable  ####################################

    const soTableData  = cwmsAjaxHanlder.soTableData;
    let soTableParam  = dataTableObject;
    let soColumns     = soTableData.status != 'cwms-completed' ? [{data: 'ID', mData:'ID'}] : [];
    const soTable     = $(`#${soTableData.id}`);
    const soHeader    = soTableData.headers;
    soHeader.map( elem  => soColumns.push( { data: elem, 'sClass': `tblrow${elem.trim()}` } ) );

    soTableParam.ajax     = { url: ajaxURL + '?action=cwms_get_all_so&status=' + soTableData.status  };
    soTableParam.columns  = soColumns;
    soTableParam.buttons  = [];
    soTableParam.order    = [[2, 'DESC'], [1, 'ASC']];

    if( soTableData.status == 'cwms-completed' ){   
        soTableParam.order      = [[1, 'DESC'], [0, 'ASC']];
        soTableParam.columnDefs = [];
        soTableParam.select     = null;
    }
    const so  = soTable.DataTable(soTableParam);

    soTable.on('click', '.cwms-delete_so', function(e){
        e.preventDefault();
        const currElem = $(this);
        const currRow  = currElem.closest('tr');
        const soID     = currElem.closest('.row-actions').data('id');
        if( !confirm(deleteConfirmation) ){
            return;
        }
        $.ajax({
			type 	: 'post',
			dataType : 'json',
			url 	: ajaxURL,
			data 	: {
				action : 'cwms_delete_so',
                soID : soID
            },
			beforeSend:function(){
				currRow.html(`<td class="cwms-tblrow" colspan="${currRow.children('td').length}">${processLabel}</td>`);
			},
			success:function(response){
                const rowClass = response.code != 200 ? 'cwms-error' : 'cwms-success' ;
				currRow.addClass(rowClass).find('td').text(response.message);
                if( response.code == 200 ){
                    setTimeout( function(){ currRow.remove() }, 3000 )
                }
			}
		});
    });    

    $('#cwms-page-all-so').on('click', '.cwms-so_bulk_actions', function(e){
        e.preventDefault();
        const actionType = $(this).data('action');
        if( $(this).parent().hasClass('disabled') || actionType == soTableData.status ){
            return;
        }
        const rows_selected = getTableSelectedRowIds(soTable);
        if( !rows_selected.length ){
            alert(noItemSelectedMessage);
            return;
        };
        if( !confirm(deleteConfirmation) ){
            resetTableCheckboxes(productTable);
            return;
        }
        $.ajax({
			type 	: 'post',
			dataType : 'json',
			url 	: ajaxURL,
			data 	: {
				action : 'cwms_so_bulk_action',
                soIds : rows_selected,
				actionType : actionType,
                soTableData : soTableData	
            },
			beforeSend:function(){
				$('body').append('<div class="loading">loading....</div>');
			},
			success:function(res){

                if( res.status == 'error' ){
                    const template = `
                        <div id="cwms-notification_error" class="alert alert-danger text-center">${res.message}</div>
                    `;
                    $('#cwms-page_content').prepend(template);
                    setTimeout( function(){
                        $('body').find('#cwms-notification_error').remove();
                    }, 3000 );
                    $('body').find('.loading').remove();
                }else{
                    location.reload();
                }
               
			}
		});
    });

    // #######################  Invoice datatable  ####################################
    const disbledOtionStatus    = ['cwms-completed'];
    const invoiceTableData      = cwmsAjaxHanlder.invoiceTableData;
    let invoiceTableParam       = dataTableObject;
    let invoiceColumns          = ! disbledOtionStatus.includes( invoiceTableData.status ) ? [{data: 'ID', mData:'ID'}] : [];
    const invoiceTable          = $(`#${invoiceTableData.id}`);
    const invoiceHeader         = invoiceTableData.headers;
    invoiceHeader.map( elem  => invoiceColumns.push( { data: elem, 'sClass': `tblrow${elem.trim()}` } ) );

    invoiceTableParam.ajax     = { url: ajaxURL + '?action=cwms_get_all_invoice&status=' + invoiceTableData.status  };
    invoiceTableParam.columns  = invoiceColumns;
    invoiceTableParam.buttons  = [];
    invoiceTableParam.order    = [[3, 'DESC'], [1, 'DESC'], [2, 'ASC']];

    if( invoiceSequence ){
        invoiceTableParam.order    = [[1, 'DESC'], [2, 'ASC']];
    }

    if( invoiceTableData.status == 'cwms-completed' ){
        invoiceTableParam.order    = [[2, 'DESC'], [0, 'DESC'], [1, 'ASC']];
        if( invoiceSequence ){
            invoiceTableParam.order    = [[0, 'DESC'], [1, 'ASC']];
        }
    }

    if( disbledOtionStatus.includes( invoiceTableData.status ) ){
        invoiceTableParam.columnDefs    = [];
        invoiceTableParam.select        = null;
    }

    const invoice  = invoiceTable.DataTable(invoiceTableParam);

    invoiceTable.on('click', '.cwms-delete_so', function(e){
        e.preventDefault();
        const currElem      = $(this);
        const currRow       = currElem.closest('tr');
        const invoiceID     = currElem.closest('.row-actions').data('id');
        if( !confirm(deleteConfirmation) ){
            return;
        }

        $.ajax({
			type 	: 'post',
			dataType : 'json',
			url 	: ajaxURL,
			data 	: {
				action : 'cwms_delete_invoice',
                invoiceID : invoiceID
            },
			beforeSend:function(){
				currRow.html(`<td class="cwms-tblrow" colspan="${currRow.children('td').length}">${processLabel}</td>`);
			},
			success:function(response){
                const rowClass = response.code != 200 ? 'cwms-error' : 'cwms-success' ;
				currRow.addClass(rowClass).find('td').text(response.message);
                if( response.code == 200 ){
                    setTimeout( function(){ currRow.remove() }, 3000 )
                }
			}
		});
    }); 

    $('#cwms-page-invoices').on('click', '.cwms-invoice_bulk_actions', function(e){
        e.preventDefault();
        const actionType = $(this).data('action');
        if( $(this).parent().hasClass('disabled') || actionType == invoiceTableData.status ){
            return;
        }
        const rows_selected = getTableSelectedRowIds(invoiceTable);
        if( !rows_selected.length ){
            alert(noItemSelectedMessage);
            return;
        };
        if( !confirm(proceedConfirmation) ){
            resetTableCheckboxes(productTable);
            return;
        }

        $.ajax({
			type 	: 'post',
			dataType : 'json',
			url 	: ajaxURL,
			data 	: {
				action : 'cwms_invoice_bulk_action',
                invoiceIds : rows_selected,
				actionType : actionType,
                invoiceTableData : invoiceTableData	
            },
			beforeSend:function(){
				$('body').append('<div class="loading">loading....</div>');
			},
			success:function(res){
                if( res.status == 'error' ){
                    const template = `
                        <div id="cwms-notification_error" class="alert alert-danger text-center">${res.message}</div>
                    `;
                    $('#cwms-page_content').prepend(template);
                    setTimeout( function(){
                        $('body').find('#cwms-notification_error').remove();
                    }, 3000 );
                    $('body').find('.loading').remove();
                }else{
                    location.reload();
                }
			}
		});
    });

    // #######################  Returns datatable  ####################################
    const returnsTableData  = cwmsAjaxHanlder.returnInvoiceTable;
    let returnsTableParam   = dataTableObject;
    let returnsColumns      = [];
    const returnsTableElem  = $(`#${returnsTableData.id}`);
    const returnsHeader     = returnsTableData.headers;
    returnsHeader.map( elem  => returnsColumns.push( { data: elem } ) );

    returnsTableParam.ajax      = { url: ajaxURL + '?action=cwms_get_all_returns' };
    returnsTableParam.columns   = returnsColumns;
    returnsTableParam.buttons   = [];
    returnsTableParam.columnDefs = [];
    returnsTableParam.select    = null;
    returnsTableParam.order     = [[4, 'DESC'], [0, 'ASC']];

    const returns               = returnsTableElem.DataTable(returnsTableParam);

    // #######################  RTV datatable  ####################################
    const rtvTableData  = cwmsAjaxHanlder.rtvTable;
    let rtvTableParam   = dataTableObject;
    let rtvColumns      = [] ;
    const rtvTableElem  = $(`#${rtvTableData.id}`);
    const rtvHeader     = rtvTableData.headers;
    rtvHeader.map( elem  => rtvColumns.push( { data: elem } ) );

    rtvTableParam.ajax         = { url: ajaxURL + '?action=cwms_get_all_rtvs' };
    rtvTableParam.columns      = rtvColumns;
    rtvTableParam.columnDefs   = [];
    rtvTableParam.select       = null;
    rtvTableParam.order     = [[2, 'DESC'], [0, 'ASC']];

    rtvTableParam.dom        = 'Bfrtip';
    rtvTableParam.buttons    = [
        {
            extend: 'excelHtml5',
            text : tableLabels.downloadExcelLabel,
            title: `${dataTableTitle} - RTV Report`,
            className: 'btn btn-sm btn-primary',
            title: ` ${dataTableTitle} - ${rtvTableData.reportLabel}`,
            exportOptions: {
                stripHtml: true,
                stripNewlines: false
            }
        },
        {
            extend: 'pdfHtml5',
            text : tableLabels.downloadPDFLabel,
            title: `${dataTableTitle} - RTV Report`,
            className: 'btn btn-sm btn-primary',
            title: ` ${dataTableTitle} - ${rtvTableData.reportLabel}`,
            exportOptions: {
                stripHtml: true,
                stripNewlines: false
            }
        }
    ];

    const rtv               = rtvTableElem.DataTable(rtvTableParam);

    // #######################  Payments datatable  ####################################
    
    const paymentsTableData             = cwmsAjaxHanlder.paymentsTable;
    const paymentsTableElem             = $(`#${paymentsTableData.id}`);
    const paymentsHeader                = paymentsTableData.headers;
    const allPaymentDatepicker          = $('#allpayment_daterange_filter');

    const apSalesmanFilter             = $('#allpayment_salesman_filter');
    const apSalesmanFilterPlaceholder  = apSalesmanFilter.data('placeholder');
    const apCustomerFilterElem         = $('#allpayment_customer_filter');
    const apCustomerFilterPlaceholder  = apCustomerFilterElem.data('placeholder');
    const apTypeFilterElem             = $('#allpayment_type_filter');
    const apTypeFilterPlaceholder      = apTypeFilterElem.data('placeholder');
    const apStatusFilterElem           = $('#allpayment_status_filter');
    const apStatusFilterPlaceholder    = apStatusFilterElem.data('placeholder');
    const apAssignmentFilterElem           = $('#allpayment_assigned_filter');
    const apAssignmentFilterPlaceholder    = apAssignmentFilterElem.data('placeholder');

    let allPaymentStartDate     = moment().subtract(29, 'days');
    let allPaymentEndDate       = moment();
    let allPaymentType          = '';
    let allPaymentStatus        = '';
    let allPaymentCustID        = '';
    let allPaymentAgentID       = '';
    let allPaymentAssingment    = 'all';

    let allPaymentSalesmanName      = '';

    const dynamicMessage = () => {
        const template = `
            ${ paymentsTableData.reportLabel} : ${allPaymentStartDate.format('MMMM D, YYYY')} - ${allPaymentEndDate.format('MMMM D, YYYY')} 
        `;
        return template;
    }

    const getYearMonthsDates = ( selDate ) => {
        let monthDates = [];
        const selYear  = selDate.format('YYYY');
        const selMonth = selDate.format('MM');
        for (let index = 1; index <= 12; index++) {
            const dateStatus        = parseInt( selMonth ) == index ? 1 : 0;
            const loopDate          = new Date(`${selYear}-${index}-01`);
            const momentDateFormat  = moment(loopDate);
            monthDates.push({
                start: momentDateFormat.startOf('month').format('YYYY-MM-DD'),
                end: momentDateFormat.endOf('month').format('YYYY-MM-DD'),
                month: momentDateFormat.format('MMMM'),
                year: momentDateFormat.format('YYYY'),
                status: dateStatus
            });
        }
        return monthDates;
    }

    let paymentsTableParam   = dataTableObject;
    let paymentsColumns      = [] ;

    delete paymentsTableParam['ajax'];

    paymentsHeader.map( elem  => paymentsColumns.push( { data: elem } ) );

    paymentsTableParam.data         = [];
    paymentsTableParam.columns      = paymentsColumns;
    paymentsTableParam.buttons      = [];
    paymentsTableParam.columnDefs   = [];
    paymentsTableParam.select       = null;
    paymentsTableParam.processing   = true;
    paymentsTableParam.order        = [[6, 'DESC'], [0, 'DESC']];
    paymentsTableParam.buttons    = [
        {
            extend: 'excelHtml5',
            text : tableLabels.downloadExcelLabel,
            className: 'btn btn-sm btn-primary',
            title: `${dataTableTitle} - Payments Report`,
            messageTop: dynamicMessage(),
            exportOptions: {
                stripHtml: true,
                stripNewlines: false
            }
        },
        {
            extend: 'pdfHtml5',
            text : tableLabels.downloadPDFLabel,
            className: 'btn btn-sm btn-primary',
            title: `${dataTableTitle} - Payments Report`,
            messageTop: dynamicMessage(),
            orientation: 'landscape',
            pageSize: 'LEGAL',
            exportOptions: {
                stripHtml: true,
                stripNewlines: false
            }
        },
        {
            text : tableLabels.downloadSummCollectionLabel,
            className: 'download-summary_collection btn btn-sm btn-primary',
            action: function ( e, dt, node, config ) {
                downloadSummaryCollections();
            }
        },
    ];
    paymentsTableParam.scrollX = true;

    const allPayments               = paymentsTableElem.DataTable(paymentsTableParam);

    const downloadSummaryCollections = () => {
        const collectionDateRange = {
            dates: getYearMonthsDates(allPaymentEndDate),
            end: allPaymentEndDate.format('YYYY-MM-DD') 
        };

        const collectionCustomer        = allPaymentCustID;
        const collectionSalesman        = allPaymentAgentID;
        const collectionPaymentType     = allPaymentType;
        const collectionPaymentStatus   = allPaymentStatus;

        if( ! allPayments.data().count() ){
            alert( tableLabels.emptyTable );
            return;
        }

        $.ajax({
            type 	: 'post',
            dataType : 'json',
            url 	: ajaxURL,
            data 	: {
                action : 'cwms_get_payment_summary_collection',
                dateRange : collectionDateRange,			
                customerID : collectionCustomer,			
                salesmanID : collectionSalesman,			
                paymentType : collectionPaymentType,			
                paymentStatus : collectionPaymentStatus,			
            },
            beforeSend:function(){
            },
            success:function(response){
                download_file(response.file_url, response.file_name);
            }
        });
    }

    const updateCustomerAllPaymentsTable = () => {
        $.ajax({
            url:  `${ajaxURL}?action=cwms_get_all_payments&agent_id=${allPaymentAgentID}&customer_id=${allPaymentCustID}&type=${allPaymentType}&status=${allPaymentStatus}&assignment=${allPaymentAssingment}&start=${allPaymentStartDate.format('YYYY-MM-DD')}&end=${allPaymentEndDate.format('YYYY-MM-DD')}`,
            type: 'get',
            beforeSend: function () { },
            success: function ( response ) {
                allPayments.clear();
                allPayments.rows.add(response.data);
                allPayments.draw();
            }
        });
    }

    if( allPaymentDatepicker.length ){

        function allPaymentsRecordsCallback(start, end) {        
            allPaymentStartDate   = start;
            allPaymentEndDate     = end;
            updateCustomerAllPaymentsTable();
        }

        allPaymentDatepicker.daterangepicker({
            opens: 'left',
            locale: {
                format: 'YYYY-MM-DD'
            },
            startDate: allPaymentStartDate,
            endDate: allPaymentEndDate,
            ranges: {
                'Today'          : [moment(), moment()],
                'Yesterday'      : [moment().subtract(1, 'days'), moment().subtract(1, 'days')],
                'Last 7 Days'    : [moment().subtract(6, 'days'), moment()],
                'Last 30 Days'   : [moment().subtract(29, 'days'), moment()],
                'This Month'     : [moment().startOf('month'), moment().endOf('month')],
                'This Year'      : [moment().startOf('year'), moment()]
            }
        }, allPaymentsRecordsCallback );

        allPaymentsRecordsCallback( allPaymentStartDate, allPaymentEndDate );
    }

    // ALL Payment Filters

     // Search for salesman ########
     apSalesmanFilter.select2({
        ajax: {
            url: ajaxURL, // AJAX URL is predefined in WordPress admin
            dataType: 'json',
            delay: 250, // delay in ms while typing when to perform a AJAX search
            data: function (params) {
                return {
                    q: params.term, // search query
                    action: $(this).attr('data-action')
                };
            },
            processResults: function( data ) {
                var options = [];
                if ( data.length > 0 ) {
                    $.each( data, function( index, info ) { // do not forget that "index" is just auto incremented value
                        options.push( { id: info.ID, text: info.display_name, info: info } );
                    });
                }
                return {
                    results: options
                };
            },
            cache: true
        },
        minimumInputLength: 3,
        selectOnClose: true,
        allowClear: true,
        placeholder: apSalesmanFilterPlaceholder,
        language: {
            inputTooShort: function(args) { return inputTooShort; },
            errorLoading: function() { return errorLoading; },
            loadingMore: function() { return loadingMore; },
            noResults: function() { return noResults; },
            searching: function() { return searching; }
        }
    }).on('select2:select', function(e){
        // Get the selected data an put it in the global variable for repeater 
        selectedSalesman        = e.params.data;
        allPaymentAgentID       = selectedSalesman.id;
        allPaymentSalesmanName  = selectedSalesman.text;
        updateCustomerAllPaymentsTable();
    }).on('select2:clear', function(e){
        allPaymentAgentID       = '';
        allPaymentSalesmanName  = apSalesmanFilterPlaceholder;
        updateCustomerAllPaymentsTable();
    });  

    // Select Customer
    apCustomerFilterElem.select2({
        allowClear: true,
        placeholder: apCustomerFilterPlaceholder,
        ajax: {
            url: ajaxURL, // AJAX URL is predefined in WordPress admin
            dataType: 'json',
            delay: 250, // delay in ms while typing when to perform a AJAX search
            data: function (params) {
                return {
                    q: params.term, // search query
                    action: $(this).attr('data-action')
                };
            },
            processResults: function( data ) {
                var options = [];
                if ( data.length > 0 ) {
                    $.each( data, function( index, info ) { // do not forget that "index" is just auto incremented value
                        options.push( { id: info.ID, text: info.display_name, info: info } );
                    });
                }
                return {
                    results: options
                };
            },
            cache: true
        },
        minimumInputLength: 3,
        selectOnClose: true,
        language: {
            inputTooShort: function(args) { return inputTooShort; },
            errorLoading: function() { return errorLoading; },
            loadingMore: function() { return loadingMore; },
            noResults: function() { return noResults; },
            searching: function() { return searching; }
        }
    }).on('select2:select', function(e){
        selectedInvoiceStatus   = e.params.data;
        allPaymentCustID        = selectedInvoiceStatus.id;
        updateCustomerAllPaymentsTable();
    }).on('select2:clear', function(e){
        allPaymentCustID    = '';
        updateCustomerAllPaymentsTable();
    }); 

    // Select Payment Type
    apTypeFilterElem.select2({
        allowClear: true,
        placeholder: apTypeFilterPlaceholder,
    }).on('select2:select', function(e){
        selectedInvoiceStatus   = e.params.data;
        allPaymentType          = selectedInvoiceStatus.id;
        updateCustomerAllPaymentsTable();
    }).on('select2:clear', function(e){
        allPaymentType          = '';
        updateCustomerAllPaymentsTable();
    }); 
    // Select Payment Status
    apStatusFilterElem.select2({
        allowClear: true,
        placeholder: apStatusFilterPlaceholder,
    }).on('select2:select', function(e){
        selectedInvoiceStatus   = e.params.data;
        allPaymentStatus        = selectedInvoiceStatus.id;
        updateCustomerAllPaymentsTable();
    }).on('select2:clear', function(e){
        allPaymentStatus        = '';
        updateCustomerAllPaymentsTable();
    }); 

    // Select Assignment Status
    apAssignmentFilterElem.select2({
        allowClear: true,
        placeholder: apAssignmentFilterPlaceholder,
    }).on('select2:select', function(e){
        selectedInvoiceStatus       = e.params.data;
        allPaymentAssingment        = selectedInvoiceStatus.id;
        updateCustomerAllPaymentsTable();
    }).on('select2:clear', function(e){
        allPaymentAssingment        = 'all';
        updateCustomerAllPaymentsTable();
    }); 
});