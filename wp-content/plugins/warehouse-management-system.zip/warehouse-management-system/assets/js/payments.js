jQuery(function() {
    const ajaxURL             = cwmsPaymentHandlder.ajaxurl;
    const customerTableData   = cwmsPaymentHandlder.customerTableData;
    const paymentTypes        = customerTableData.paymentTypes;
    const paymentValidations  = customerTableData.paymentValidations;
    const createPaymentForm   = $(`#${customerTableData.createPaymentForm}`);
    const unpaidInvTableID    = $(`#${customerTableData.unpaidInvTableID}`);
    const allCustPaymentTableID    = $(`#${customerTableData.allCustPaymentTableID}`);
    const invoiceListTable    = $(`#cwms_invoices_list_table`);
    const paymentListTable    = $(`#cwms_invoices_payments_table`);
    const paymentModalForm    = $(`#cwms-invoices-payment-form`);
    const custAllPaymentsDatepicker    = $('#payment_daterange_filter');
    const currCustomerID     = customerTableData.customerID;

    const inputTooShort     = cwmsPaymentHandlder.inputTooShort;
    const errorLoading      = cwmsPaymentHandlder.errorLoading;
    const loadingMore       = cwmsPaymentHandlder.loadingMore;
    const noResults         = cwmsPaymentHandlder.noResults;
    const searching         = cwmsPaymentHandlder.searching;

    let payments             = [];
    let invoices             = [];
    let totalPaymentAmount   = 0;
    let paymentAmountBalance = 0;
    let totalPaidAmount      = 0;
    let invoiceError         = false;
    let paymentError         = false;
    let creditBalance        = 0;

    if( ! ( unpaidInvTableID.length || allCustPaymentTableID.length ) ){
        return;
    }
    const validateCurrency = (e) => {
        // Allow: backspace, delete, tab, escape, enter and .
        if ($.inArray(e.keyCode, [46, 8, 9, 27, 13, 110, 190]) !== -1 ||
            // Allow: Ctrl+A
            (e.keyCode == 65 && e.ctrlKey === true) ||
            // Allow: Ctrl+C
            (e.keyCode == 67 && e.ctrlKey === true) ||
            // Allow: Ctrl+X
            (e.keyCode == 88 && e.ctrlKey === true) ||
            // Allow: home, end, left, right
            (e.keyCode >= 35 && e.keyCode <= 39)) {
                // let it happen, don't do anything
                return;
        }
        // Ensure that it is a number and stop the keypress
        if ((e.shiftKey || (e.keyCode < 48 || e.keyCode > 57)) && (e.keyCode < 96 || e.keyCode > 105)) {
            e.preventDefault();
        }
    }

    const uniqueKey = () => {
        const chars = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
        var result  = '';
        for (var i = 6; i > 0; --i) result += chars[Math.floor(Math.random() * chars.length)];
        return result;
    }

    const loader = ( string = 'loading...') => {
        return `<div class="loader-wrapper">
        <div class="loder-crcil"></div>
          <div class="text">${string}</div>
        </div>`;
    }

    // Initailize 
    $('body').on( 'keydown', '.amount_field', function( e ){
        validateCurrency(e);
    });
    const searchChequeElem = $('#cwms-search_cheque');
    const searchChequePlaceholder = searchChequeElem.attr('placeholder');
    searchChequeElem.select2({
        placeholder: searchChequePlaceholder,
        ajax: {
            url: ajaxURL, // AJAX URL is predefined in WordPress admin
            dataType: 'json',
            delay: 250, // delay in ms while typing when to perform a AJAX search
            data: function (params) {
                return {
                    q: params.term, // search query
                    custID: customerTableData.customerID, // search query
                    action: $(this).attr('data-action')
                };
            },
            processResults: function( data ) {
                var options = [];
                if ( data.length > 0 ) {
                    $.each( data, function( index, info ) { // do not forget that "index" is just auto incremented value
                        options.push( { id: info.ID, text: info.cheque_number, info: info } );
                    });
                }
                return {
                    results: options
                };
            },
            cache: true
        },
        minimumInputLength: 3,
        selectOnClose: true,
        language: {
            inputTooShort: function(args) { return inputTooShort; },
            errorLoading: function() { return errorLoading; },
            loadingMore: function() { return loadingMore; },
            noResults: function() { return noResults; },
            searching: function() { return searching; }
        },
        allowClear: true,
        dropdownParent: $('.cwms-search_cheque_wrapper')
    }).on('select2:select', function(e){
        chequeInfo                 = e.params.data.info;
        const parentForm = searchChequeElem.closest('form');
        parentForm.find('[name="payment_amount"]').val(chequeInfo.amount);
        parentForm.find('[name="cheque_number"]').val(chequeInfo.cheque_number);
        parentForm.find('[name="cheque_date"]').val(chequeInfo.cheque_date);
        parentForm.find('[name="cheque_bank"]').val(chequeInfo.cheque_bank);
        parentForm.find('[name="status"]').val(chequeInfo.status);
    }).on('select2:clear', function(e){
    }); 

    // Unpaid Invoice Table
    let unpaidInvTableParam        = {};
    unpaidInvTableParam.ajax       = { url: ajaxURL + '?action=cwms_get_customer_unpaid_invoices&id='+customerTableData.customerID };
    unpaidInvTableParam.columns    = [
        {data:'invoice_number'},
        {data:'total_amount'},
        {data:'total_paid'},
        {data:'balance'},
        {data:'action'}
    ];
    unpaidInvTableParam.buttons    = [];
    unpaidInvTableParam.order      = [[0, 'desc']];
    unpaidInvTableParam.pageLength = 10;
    let unpaidInvTable = unpaidInvTableID.DataTable(unpaidInvTableParam);

    // Add Invoice to Form
    const generateInvoiceField = ( invoice ) => {
        const disabledAttr = payments.length == 0 ? 'disabled' : '';
        return `
            <tr class="row-invoice" data-id="${invoice.id}" data-balance="${invoice.balance}">
                <td style="width:26px;"><i class="fa fa-minus-circle text-danger cursor-pointer removetopayment" style="font-size: 1.5em;"></i></td>
                <td>
                    ${invoice.invoice_number}
                    <input type="hidden" name="payment_invoices[${invoice.id}][id]" value="${invoice.id}"/>
                </td>
                <td><input type="text" class="amount_field amount_paid" name="payment_invoices[${invoice.id}][amount_paid]" ${disabledAttr} value="" required/></td>
                <td><input type="text" class="amount_field adjustment" name="payment_invoices[${invoice.id}][adjustment]" ${disabledAttr} value=""/></td>
                <td class="invoice_amount">${invoice.balance}</td>
                <td class="payment_balance">${invoice.balance}</td>
            </tr>
        `;
    }
    const updateInvoiceList = ( invoice ) => {
        if( invoices.length ){
            invoiceListTable.find('.empty-invoices').remove();
        }else{
            invoiceListTable.find('tbody').append(`<tr class="empty-invoices"><td colspan="5">${cwmsPaymentHandlder.emptyInvoiceTable}</td></tr>`);
        }
        invoiceListTable.find('tbody').append( generateInvoiceField( invoice  ) );
        calculatePayments();
    }
    const addInvoice  = ( $elem ) => {
        const invoiceData = $elem.data('invoice');
        invoices.push( invoiceData );
        unpaidInvTable.row( $elem.parents('tr') ).remove().draw();
        updateInvoiceList( invoiceData );
        paymentListTable.removeClass('d-none');
        calculatePayments();
    }
    const removeInvoice  = ( $elem ) => {
        const invoiceID  =  $elem.closest('tr').data('id');
        const invoiceKey = invoices.findIndex( elem => elem.id == invoiceID );
        const invoiceInfo = invoices[invoiceKey];
        // Remove row to table
        $elem.closest('tr').remove();
        invoices.splice( invoiceKey, 1 );

        // Hide the payment table
        if( invoices.length == 0 ){
            paymentListTable.addClass('d-none');
        }

        unpaidInvTable.row.add( {
            "invoice_number": invoiceInfo.invoice_number,
            "total_amount":  invoiceInfo.total_amount,
            "total_paid":   invoiceInfo.total_paid,
            "balance": invoiceInfo.balance,
            "action":  `<i class="fa fa-2x fa-plus-circle text-success cursor-pointer addtopayment-invoices" title="${cwmsPaymentHandlder.addPaymentInvoice}" data-invoice='${JSON.stringify(invoiceInfo)}'></i>`
        } ).draw();
        calculatePayments();
    }
    unpaidInvTableID.on('click', '.addtopayment-invoices', function(){ 
        addInvoice( $(this) );
    });
    invoiceListTable.on('click', '.removetopayment', function(){ 
        removeInvoice( $(this) );
    });
    invoiceListTable.on('input', '.amount_field', function( e ){
        e.preventDefault();
        invoiceError     = false;
        const rowElem    = $(this).closest('tr');
        let rowBalance   = parseFloat( rowElem.data( 'balance') );
        rowElem.find('.amount_field').each( function( index, elem ){
            let paidAmount = $(this).val();
            paidAmount =  isNaN(paidAmount) || ! paidAmount ? 0 : paidAmount;
            rowBalance -= paidAmount;
        } );
        rowElem.find('.payment_balance').text( rowBalance.toFixed(2) );
        calculatePayments();
        // Check paid amount if greater the payable amount
        // Display warning
        invoiceListTable.find('thead .warning-exceed_amount').remove();

        if( rowBalance < 0 ){
            invoiceError = true;
            invoiceListTable.find('thead').prepend(
                `<tr class="warning-exceed_amount">
                    <th class="alert-danger" colspan="${rowElem.find('td').length}">${cwmsPaymentHandlder.paymentExceeded}</th>
                </tr>`
            );
            rowElem.addClass('alert-danger');
        }else{
            rowElem.removeClass('alert-danger');
        }

    } );

    // Payment Form
    const calculatePayments = () => {
        paymentError = false;
        // Calculate total payment made
        totalPaymentAmount = payments.reduce(
                (accumulator, currentValue) => accumulator + parseFloat( currentValue.payment_amount ), 0 );

        // Calculate amount paid
        totalPaidAmount    = 0;
        let totalBalance   = 0;

        invoiceListTable.find('.amount_paid').each( function(){
            let paidAmount = $(this).val();
            paidAmount =  isNaN(paidAmount) || ! paidAmount ? 0 : paidAmount;
            totalPaidAmount += parseFloat( paidAmount );
        });

        // Get total balance
        invoiceListTable.find('.payment_balance').each( function(){
            totalBalance += parseFloat( $(this).text() );
        });

        // Calculate payments balance
        paymentAmountBalance = parseFloat( totalPaymentAmount ) - parseFloat( totalPaidAmount );

        // Payment invoices
        paymentListTable.find('tfoot .payment_total').text( parseFloat( totalPaymentAmount ).toFixed(2) );
        paymentListTable.find('tfoot .paid_amount').text( parseFloat( totalPaidAmount ).toFixed(2) );
        paymentListTable.find('tfoot .payment_balance').text( paymentAmountBalance.toFixed(2) );

        // Invoices Table
        invoiceListTable.find('tfoot .total_balance').text( totalBalance.toFixed(2) );

        // Add notification when amount paid is greater than payment amount
        paymentListTable.find('thead .warning-exceed_amount').remove();
        if( totalPaymentAmount < totalPaidAmount ){
            paymentError = true;
            paymentListTable.find('thead').prepend(
                `<tr class="warning-exceed_amount">
                    <th class="alert-danger" colspan="${paymentListTable.find('thead tr th').length}">${cwmsPaymentHandlder.excDeclaredAmount}</th>
                </tr>`
            );
        }

    }
    const updatePaymentList  = ( payment ) => {
        let paymentHeader = `<strong>${paymentTypes[payment.payment_type]}</strong>`;
        if( payment.payment_type == "_cheque" ){
            paymentHeader += `<span class="d-block text-sm cheque_number">${payment.cheque_number}</span>`; 
            paymentHeader += `<span class="d-block text-sm cheque_date">${payment.cheque_date}</span>`; 
            paymentHeader += `<span class="d-block text-sm cheque_bank">${payment.cheque_bank}</span>`; 
        }       
        paymentListTable.find('tbody').append(
            `
            <tr class="row-payment" data-key="${payment.uniqueKey}">
                <td style="width:26px;"><i class="fa fa-minus-circle text-danger cursor-pointer removepayment" style="font-size: 1.5em;"></i></td>
                <td>${paymentHeader}</td>
                <td>${paymentValidations[payment.status]}</td>
                <td>${ parseFloat( payment.payment_amount ).toFixed(2) }</td>
            </tr>
            `
        );
    }
    const enableStatusOptions = ( $elem ) => {
        $elem.find( 'option' ).prop( 'disabled', false );
    }
    const disableStatusOptions = ( $elem, exptValue = '' ) => {
        $elem.find( 'option' ).each( function( index ){
            if( $(this).attr( 'value' ) == exptValue ){
                return;
            }
            $(this).prop('disabled',true );
        } );
    }
    const clearAmountFields = () => {
        invoiceListTable.find('.amount_field').prop('disabled', false);
    }
    const resetFormFields = () => {
        paymentModalForm.find('#cwms_cheque-information').css({'display':'none'});
        paymentModalForm.find('#cwms_cheque-information input[type="text"]').val('').prop('required', false );
        paymentModalForm.find('[name="status"]').val('_cleared');
        disableStatusOptions( paymentModalForm.find('[name="status"]'), '_cleared' );
    }
    const removePayment  = ( $elem ) => {

        const paymentUniqueKey  =  $elem.closest('tr').data('key');
        const paymentKey        = payments.findIndex( elem => elem.uniqueKey == paymentUniqueKey );  
        // Check is credit payment is removed
        // Enable the credit payment options
        if( payments[paymentKey].payment_type == '_credit' ){
            paymentModalForm.find('[name="payment_type"] option[value="_credit"]').prop('disabled', false );
        }    
        $elem.closest('tr').remove();
        payments.splice( paymentKey, 1 );
        calculatePayments();
    }
    const getUserCredit  = ( ) => {
        $.ajax({
            type 	: 'post',
            dataType : 'json',
            url 	: ajaxURL,
            data 	: { action : 'cwms_get_customer_credit', customerID : currCustomerID },
            beforeSend:function(){ 
                creditBalance = 0;
                paymentModalForm.find('[type="submit"]').prop( 'disabled', true );
            },
            success:function(res){ 
                creditBalance = parseFloat( res );
                paymentModalForm.find('[type="submit"]').prop( 'disabled', false );
                paymentModalForm.find('[name="payment_amount"]').val( res ).prop( 'readonly', true );
                resetFormFields();
            }
        });
    }

    paymentListTable.on('click', '.removepayment', function(){ 
        removePayment( $(this) );
    });
    paymentModalForm.on('change', '[name="payment_type"]', function(){  
        const paymentType = $(this).val();
        paymentModalForm.find('[name="payment_amount"]').val('').prop( 'readonly', false );
        if( '_cheque' == paymentType ){
            paymentModalForm.find('#cwms_cheque-information').css({'display':'block'});
            paymentModalForm.find('#cwms_cheque-information input[type="text"]').prop('required', true );
            paymentModalForm.find('[name="status"]').val('');
            enableStatusOptions( paymentModalForm.find('[name="status"]') );   
        }else if( '_credit' == paymentType ){
            getUserCredit();
        }else{
            resetFormFields();
        }
        paymentModalForm.find('#cwms_cheque-information [data-action="cwms_search_unassigned_cheque"]').prop('required', false );
    });
    paymentModalForm.on('submit', function( e ){
        e.preventDefault();

        let payment = {};
        $.each( $(this).serializeArray(), function( index, obj ){
            payment[obj.name] = obj.value;
        });
        payment['uniqueKey']        = uniqueKey();

        // Check if Credit is already added in the payments
        // Do not allow to have duplicate credit in payments
        const hasCredit       = payments.find(element => element.payment_type == "_credit" );
        if( hasCredit && payment['payment_type'] == "_credit"  ){
            alert( 'Credit already added in the payments.' );
            resetFormFields();
            paymentModalForm.find('[name="payment_amount"]').prop( 'readonly', false );
            return;
        }
        if( payment['payment_type'] == "_credit" ){
            payment['payment_amount']   = creditBalance;
            // Disabled the Credit options if already have credit in the payments list
            paymentModalForm.find('[name="payment_type"] option[value="_credit"]').prop('disabled', true );
        }

        payments.push( payment );
        calculatePayments();
        updatePaymentList( payment );
        clearAmountFields();
        $(this).trigger("reset");
        resetFormFields();
        paymentModalForm.find('[name="payment_amount"]').prop( 'readonly', false );
        $('#cwms-customer_payment_registry-modal').modal('toggle');
    });
    
    // Create payment
    createPaymentForm.on('click', '#cwms-submit_payment', function(e){
        e.preventDefault();
        if( payments.length == 0 ){
            alert( cwmsPaymentHandlder.noPayments);
            return;
        }
        if( invoices.length == 0 ){
            alert( cwmsPaymentHandlder.noInvSelectedMessage);
            return;
        }
        if( invoiceError ){
            alert( cwmsPaymentHandlder.paymentExceeded);
            return;
        }
        if( paymentError ){
            alert( cwmsPaymentHandlder.excDeclaredAmount);
            return;
        }
        let paymentTemplates = '';
        $.each( payments, function( index, obj ){
            for (const key in obj) {
                paymentTemplates += `<input type="hidden" name="payments[${index}][${key}]" value="${obj[key]}" />`;
            }
        });
        createPaymentForm.append(paymentTemplates);
        createPaymentForm.find('[type="submit"]').trigger('click');
    });

    // Customer All payment reports ##############
    // Setting up global variables
    let startDate       = moment().subtract(29, 'days');
    let endDate         = moment();
    let paymentType     = '';
    let paymentStatus   = '';
    let allPaymentsTableParam    = {};

    const allPaymentsHeader      = [
        {data:'receipt_number'},
        {data:'payment_type'},
        {data:'created_by'},
        {data:'created_date'},
        {data:'paid_by'},
        {data:'amount'},
        {data:'remarks'},
        {data:'status'},
        {data:'actions'}
    ];
    allPaymentsTableParam.columns       = allPaymentsHeader;
    allPaymentsTableParam.processing    = true;
    allPaymentsTableParam.order         = [[0, 'DESC'], [3, 'DESC']];
    allPaymentsTableParam.ajax          = { url: `${ajaxURL}?action=cwms_get_customer_all_payments&id=${currCustomerID}&type=${paymentType}&status=${paymentStatus}&start=${startDate.format('YYYY-MM-DD')}&end=${endDate.format('YYYY-MM-DD')}` };
    let allCustomerPayments             = allCustPaymentTableID.DataTable(allPaymentsTableParam);

    const updateCustomerAllPaymentsTable = () => {
        $.ajax({
            url:  `${ajaxURL}?action=cwms_get_customer_all_payments&id=${currCustomerID}&type=${paymentType}&status=${paymentStatus}&start=${startDate.format('YYYY-MM-DD')}&end=${endDate.format('YYYY-MM-DD')}`,
            type: 'get',
            beforeSend: function () { },
            success: function ( response ) {
                allCustomerPayments.clear();
                allCustomerPayments.rows.add(response.data);
                allCustomerPayments.draw();
            }
        });
    }
    if( custAllPaymentsDatepicker.length ){
        function customerAllPaymentRecordsCallback(start, end) {        
            startDate   = start;
            endDate     = end;
            updateCustomerAllPaymentsTable();
        }

        custAllPaymentsDatepicker.daterangepicker({
            opens: 'left',
            locale: {
                format: 'YYYY-MM-DD'
            },
            startDate: startDate,
            endDate: endDate,
            ranges: {
                'Today'          : [moment(), moment()],
                'Yesterday'      : [moment().subtract(1, 'days'), moment().subtract(1, 'days')],
                'Last 7 Days'    : [moment().subtract(6, 'days'), moment()],
                'Last 30 Days'   : [moment().subtract(29, 'days'), moment()],
                'This Month'     : [moment().startOf('month'), moment().endOf('month')],
                'This Year'      : [moment().startOf('year'), moment()]
            }
        }, customerAllPaymentRecordsCallback);
    }

    $('#cwms-page-customer').on('change', '#payment_type_filter', function(){
        paymentType = $(this).val();
        updateCustomerAllPaymentsTable();
    });
    $('#cwms-page-customer').on('change', '#payment_status_filter', function(){
        paymentStatus = $(this).val();
        updateCustomerAllPaymentsTable();
    });

    // Update payment status
    // Show all payment status data
    const udpatePaymentModalID   = $('#cwms-update-check-payment-modal');
    allCustPaymentTableID.on('click', '.cwms-customer_update_payment_status', function( e ){
        e.preventDefault();
        const paymentID     = $(this).data('id');
        const prcr          = $(this).data('prcr');
        const ptype         = $(this).data('ptype');
        const amount        = $(this).data('amount');
        $.ajax({
            type 	: 'post',
            dataType : 'json',
            url 	: ajaxURL,
            data 	: {
                action : 'cwms_customer_update_payment_status',
                paymentID : paymentID
            },
            beforeSend:function(){
                // reset form data and fields
                udpatePaymentModalID.find('.modal-title').text( `${prcr} : ${ptype} - ${amount}` );
                udpatePaymentModalID.find('.modal-body .cwms-payment-form, .modal-body .cwms-payment-informations, .modal-body #cwms_cheque-information').addClass( 'd-none' );  
                udpatePaymentModalID.find('#cwms-payment-submit').removeClass('d-none');
                udpatePaymentModalID.find('.modal-body').append( loader() );  
                udpatePaymentModalID.find('.modal-body #cwms_invoices_table tbody').html('');
                udpatePaymentModalID.find('.modal-body #cwms_payments_table tbody').html('');
                udpatePaymentModalID.find('.modal-body [name="payment_id"]').val('');
                enableStatusOptions( udpatePaymentModalID.find('[name="status"]') ); 
                udpatePaymentModalID.find('[name="status"]').prop('disabled', false );
            },
            success:function(res){
                const paymentInfo       = res.data.payment_info;
                const paymentInvoice    = res.data.payments;
                const additionalInfo    = res.data.additional_info;
                const currPayment       = paymentInfo.find(element => element.ID == paymentID );
                // Success
                udpatePaymentModalID.find('.modal-body .loader-wrapper').remove( );   
                if( res.status == 'error' ){
                    udpatePaymentModalID.find('.modal-body').prepend( `<div class="alert alert-danger">${res.message}</div>` ); 
                    return;
                }
                // Add invoices
                $.each( paymentInvoice, function( index, data ){
                    const rowElem = `
                        <tr>
                            <td>${data.invoice_number}</td>
                            <td>${data.amount_paid}</td>
                            <td>${data.adjustment}</td>
                        </tr>
                    `;
                    udpatePaymentModalID.find('.modal-body #cwms_invoices_table tbody').append( rowElem  );   
                });
                $.each( paymentInfo, function( index, data ){
                    const className = data.ID == paymentID ? 'alert alert-info' : '' ;
                    const rowElem = `
                        <tr class="${className}">
                            <td><strong>${paymentTypes[data.payment_type]}<strong></td>
                            <td>${paymentValidations[data.status]}</td>
                            <td>${data.amount}</td>
                        </tr>
                    `;
                    udpatePaymentModalID.find('.modal-body #cwms_payments_table tbody').append( rowElem  );   
                });
                udpatePaymentModalID.find('.modal-body .cwms-payment-form, .modal-body .cwms-payment-informations').removeClass( 'd-none' );   

                // Update form data based on the selected payment to update
                $.each( currPayment, function( index, data ){
                    if( ! udpatePaymentModalID.find(`.modal-body .cwms-payment-form #${index}`).length ){
                        return;
                    }
                    if( index == 'payment_type' ){
                        data = paymentTypes[data];
                    }
                    udpatePaymentModalID.find(`.modal-body .cwms-payment-form #${index}`).val( data );   
                });
                // Show Cheque information if payment tyle is Cheque
                if( currPayment.payment_type == "_cheque" ){
                    udpatePaymentModalID.find(`.modal-body #cwms_cheque-information`).removeClass('d-none');
                    udpatePaymentModalID.find('.modal-body [name="payment_id"]').val(paymentID);
                }else{
                    disableStatusOptions( udpatePaymentModalID.find('[name="status"]'), '_cleared' );
                    udpatePaymentModalID.find('[name="status"]').prop('disabled', true );
                    udpatePaymentModalID.find('#cwms-payment-submit').addClass('d-none');
                }
                // Adding data for the payment details sections
                $.each( additionalInfo, function( index, value ){
                    udpatePaymentModalID.find(`.cwms-payment-payment_details #${index}`).val( value );
                });
            }
        });
    });

    // Customer Invoice Payments ########
    const customerRecordsDRP        = $('#cmws-paymentRecords_daterange');
    let invoicePaymentsTableID      = $('#cwms-invoices_payments_table');
    let invoicePaymentsStartDate    = moment().subtract(29, 'days');
    let invoicePaymentsEndDate      = moment();
    let invoicePaymentsTableParam    = {};
    const invoicePaymentsHeader      = [
        {data:'payment_no'},
        {data:'_po_number'},
        {data:'created_date'},
        {data:'created_by'},
        {data:'amount_paid'},
        {data:'paid_by'},
        {data:'remarks'}
    ];
    invoicePaymentsTableParam.columns      = invoicePaymentsHeader;
    invoicePaymentsTableParam.processing   = true;
    invoicePaymentsTableParam.order        = [[0, 'DESC']];
    invoicePaymentsTableParam.ajax         = { url: `${ajaxURL}?action=cwms_get_customer_payment_records&id=${currCustomerID}&start=${invoicePaymentsStartDate.format('YYYY-MM-DD')}&end=${invoicePaymentsEndDate.format('YYYY-MM-DD')}` };
    let invoicePayments                    = invoicePaymentsTableID.DataTable(invoicePaymentsTableParam);

    const updateCustomerInvoicePaymentsTable = () => {
        $.ajax({
            url:  `${ajaxURL}?action=cwms_get_customer_payment_records&id=${currCustomerID}&start=${invoicePaymentsStartDate.format('YYYY-MM-DD')}&end=${invoicePaymentsEndDate.format('YYYY-MM-DD')}`,
            type: 'get',
            beforeSend: function () { },
            success: function ( response ) {
                invoicePayments.clear();
                invoicePayments.rows.add(response.data);
                invoicePayments.draw();
            }
        });
    }

    function customerPaymentRecordsCallback(start, end) {        
        invoicePaymentsStartDate   = start;
        invoicePaymentsEndDate     = end;
        updateCustomerInvoicePaymentsTable();
    }
    customerRecordsDRP.daterangepicker({
        opens: 'left',
        locale: {
            format: 'YYYY-MM-DD'
        },
        startDate: invoicePaymentsStartDate,
        endDate: invoicePaymentsEndDate,
        ranges: {
        'Today'          : [moment(), moment()],
        'Yesterday'      : [moment().subtract(1, 'days'), moment().subtract(1, 'days')],
        'Last 7 Days'    : [moment().subtract(6, 'days'), moment()],
        'Last 30 Days'   : [moment().subtract(29, 'days'), moment()],
        'This Month'     : [moment().startOf('month'), moment().endOf('month')],
        'This Year'      : [moment().startOf('year'), moment()]
        },
        // parentEl: "#cwms-customer-payments-modal .modal-body" 
    }, customerPaymentRecordsCallback);

    // Customer Unassigned cheque reports ##############
    let unassignedStartDate = moment().subtract(29, 'days');
    let unassignedEndDate   = moment();
    let custUnassignedChequeTableID     = $('#cwms_customerAllUnassingedChequesTable');
    let custUnassignedChequeDatepicker  = $('#unassinged_cheques_daterange_filter');
    let UnassignedChequeTableParam    = {};
    const UnassignedChequeHeader      = [
        {data:'cheque_number'},
        {data:'cheque_bank'},
        {data:'created_by'},
        {data:'created_date'},
        {data:'paid_by'},
        {data:'amount'},
        {data:'status'}
    ];
    UnassignedChequeTableParam.columns      = UnassignedChequeHeader;
    UnassignedChequeTableParam.processing   = true;
    // UnassignedChequeTableParam.ajax         = { url: `${ajaxURL}?action=cwms_get_customer_unassigned_cheques&id=${currCustomerID}&start=${unassignedStartDate.format('YYYY-MM-DD')}&end=${unassignedEndDate.format('YYYY-MM-DD')}` };
    let unassignedCheques                   = custUnassignedChequeTableID.DataTable(UnassignedChequeTableParam);

    const updateCustomerAllUnassingedChequesTable = () => {
        $.ajax({
            url:  `${ajaxURL}?action=cwms_get_customer_unassigned_cheques&id=${currCustomerID}&start=${unassignedStartDate.format('YYYY-MM-DD')}&end=${unassignedEndDate.format('YYYY-MM-DD')}`,
            type: 'get',
            beforeSend: function () { },
            success: function ( response ) {
                unassignedCheques.clear();
                unassignedCheques.rows.add(response.data);
                unassignedCheques.draw();
            }
        });
    }
    function customerUnassignedChequeRecordsCallback(start, end) {        
        unassignedStartDate   = start;
        unassignedEndDate     = end;
        updateCustomerAllUnassingedChequesTable();
    }

    custUnassignedChequeDatepicker.daterangepicker({
        opens: 'left',
        locale: {
            format: 'YYYY-MM-DD'
        },
        startDate: unassignedStartDate,
        endDate: unassignedEndDate,
        ranges: {
            'Today'          : [moment(), moment()],
            'Yesterday'      : [moment().subtract(1, 'days'), moment().subtract(1, 'days')],
            'Last 7 Days'    : [moment().subtract(6, 'days'), moment()],
            'Last 30 Days'   : [moment().subtract(29, 'days'), moment()],
            'This Month'     : [moment().startOf('month'), moment().endOf('month')],
            'This Year'      : [moment().startOf('year'), moment()]
        }
    }, customerUnassignedChequeRecordsCallback);
    customerUnassignedChequeRecordsCallback( unassignedStartDate, unassignedEndDate );

    // Customer Stale cheque reports ##############
    let staledStartDate             = moment().subtract(29, 'days');
    let staledEndDate               = moment();
    let custStaledChequeDatepicker  = $('#staled_cheques_daterange_filter');
    let custStaledChequeTableID     = $('#cwms_customerAllStaledChequesTable');

    let staledChequeTableParam    = {};
    const StaledChequeHeader      = [
        {data:'cheque_number'},
        {data:'cheque_bank'},
        {data:'created_by'},
        {data:'created_date'},
        {data:'paid_by'},
        {data:'amount'}
    ];
    staledChequeTableParam.columns      = StaledChequeHeader;
    staledChequeTableParam.processing   = true;
    staledChequeTableParam.ajax         = { url: `${ajaxURL}?action=cwms_get_customer_staled_cheques&id=${currCustomerID}&start=${staledStartDate.format('YYYY-MM-DD')}&end=${staledEndDate.format('YYYY-MM-DD')}` };
    let staledCheques                   = custStaledChequeTableID.DataTable(staledChequeTableParam);

    const updateCustomerStaledChequesTable = () => {
        $.ajax({
            url:  `${ajaxURL}?action=cwms_get_customer_staled_cheques&id=${currCustomerID}&start=${staledStartDate.format('YYYY-MM-DD')}&end=${staledEndDate.format('YYYY-MM-DD')}`,
            type: 'get',
            beforeSend: function () { },
            success: function ( response ) {
                staledCheques.clear();
                staledCheques.rows.add(response.data);
                staledCheques.draw();
            }
        });
    }
    function customerStaledChequeRecordsCallback(start, end) {        
        staledStartDate   = start;
        staledEndDate     = end;
        updateCustomerStaledChequesTable();
    }

    custStaledChequeDatepicker.daterangepicker({
        opens: 'left',
        locale: {
            format: 'YYYY-MM-DD'
        },
        startDate: staledStartDate,
        endDate: staledEndDate,
        ranges: {
            'Today'          : [moment(), moment()],
            'Yesterday'      : [moment().subtract(1, 'days'), moment().subtract(1, 'days')],
            'Last 7 Days'    : [moment().subtract(6, 'days'), moment()],
            'Last 30 Days'   : [moment().subtract(29, 'days'), moment()],
            'This Month'     : [moment().startOf('month'), moment().endOf('month')],
            'This Year'      : [moment().startOf('year'), moment()]
        }
    }, customerStaledChequeRecordsCallback);

    // Show credit history #################
    const creditHistoryModal    = $('#cwms-credit-history-modal');
    const perPage   = 12;
    let currPage    = 1;

    const generateCreditHistory = ( data ) => {

        $.each( data, function( index, value ){
            creditHistoryModal.find('table#cwms_credit_history-table tbody').append(
                `
                <tr>
                    <td>${value.created_date}</td>
                    <td>${value.created_by}</td>
                    <td>${value.amount}</td>
                    <td>${value.remarks}</td>
                </tr>
                `
            );
        });
    }
    
    $('#cwms-page-customer').on('click', '.cwms-show_credit_history', function( e ){
        e.preventDefault();
        currPage    = 1;
        $.ajax({
            url:  ajaxURL,
            type: 'post',
            dataType: 'json',
            data: {
                action: 'cwms_get_customer_credit_history',
                id : currCustomerID,
                perPage: perPage,
                currPage : currPage 
            },
            beforeSend: function () { 
                creditHistoryModal.find('.modal-body').prepend( loader() );
                creditHistoryModal.find('.credit_history-table-wrapper').addClass('d-none');
                creditHistoryModal.find('#cwms_credit_history-table tfoot tr').removeClass('d-none');
                creditHistoryModal.find('#cwms_credit_history-table tbody').html('');
            },
            success: function ( response ) {
                creditHistoryModal.find('.modal-body .loader-wrapper').remove( );
                creditHistoryModal.find('.credit_history-table-wrapper').removeClass('d-none');
                generateCreditHistory( response );
                currPage++;
            }
        });
    });

    creditHistoryModal.on('click', '#cwms-showmore_credit_history', function( e ){
        e.preventDefault();
        const currElem = $(this);
        $.ajax({
            url:  ajaxURL,
            type: 'post',
            dataType: 'json',
            data: {
                action: 'cwms_get_customer_credit_history',
                id : currCustomerID,
                perPage: perPage,
                currPage : currPage 
            },
            beforeSend: function () { 
                currElem.find('.fa').addClass('fa-spinner fa-spin');
            },
            success: function ( response ) {
                currElem.find('.fa').removeClass('fa-spinner fa-spin');
                if( response.length == 0 || response.length < perPage ){
                    currElem.closest('tr').addClass('d-none');
                }
                generateCreditHistory( response );
                currPage++;
            }
        });
    });
    // Agent Options
    // const payemtnSelectAgent = $('#cwms_invoices_payments_table [name="agent_id"]');
    // payemtnSelectAgent.select2({
    //     ajax: {
    //         url: ajaxURL, // AJAX URL is predefined in WordPress admin
    //         dataType: 'json',
    //         delay: 250, // delay in ms while typing when to perform a AJAX search
    //         data: function (params) {
    //             return {
    //                 q: params.term, // search query
    //                 action: $(this).attr('data-action')
    //             };
    //         },
    //         processResults: function( data ) {
    //             var options = [];
    //             if ( data.length > 0 ) {
    //                 $.each( data, function( index, info ) { // do not forget that "index" is just auto incremented value
    //                     options.push( { id: info.ID, text: info.display_name, info: info } );
    //                 });
    //             }
    //             return {
    //                 results: options
    //             };
    //         },
    //         cache: true
    //     },
    //     minimumInputLength: 3,
    //     selectOnClose: true,
    //     language: {
    //         inputTooShort: function(args) { return inputTooShort; },
    //         errorLoading: function() { return errorLoading; },
    //         loadingMore: function() { return loadingMore; },
    //         noResults: function() { return noResults; },
    //         searching: function() { return searching; }
    //     },
    //     allowClear: true,
    //     placeholder: payemtnSelectAgent.attr('placeholder'),
    // }); 

});