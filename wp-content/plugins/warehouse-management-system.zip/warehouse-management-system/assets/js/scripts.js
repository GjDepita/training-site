jQuery(document).ready( function( $ ){
    const ajaxURL           = cwmsAjaxHanlder.ajaxurl;
    const inputTooShort     = cwmsAjaxHanlder.inputTooShort;
    const errorLoading      = cwmsAjaxHanlder.errorLoading;
    const loadingMore       = cwmsAjaxHanlder.loadingMore;
    const noResults         = cwmsAjaxHanlder.noResults;
    const searching         = cwmsAjaxHanlder.searching;
    const placeholder       = cwmsAjaxHanlder.placeholder;
    const deleteConfirmation        = cwmsAjaxHanlder.deleteConfirmation;
    const deleteConfirmData         = cwmsAjaxHanlder.deleteConfirmData;
    const noSupplier        = cwmsAjaxHanlder.noSupplier;
    const noCustomer        = cwmsAjaxHanlder.noCustomer;
    const noItemSelectedMessage     = cwmsAjaxHanlder.noItemSelectedMessage;
    const purchaseOrderLabel        = cwmsAjaxHanlder.purchaseOrderLabel;
    const allItemSelectedMessage    = cwmsAjaxHanlder.allItemSelectedMessage;
    const poLabel           = cwmsAjaxHanlder.poLabel;
    const drLabel           = cwmsAjaxHanlder.drLabel;
    const dateLabel         = cwmsAjaxHanlder.dateLabel;
    const drLimit           = cwmsAjaxHanlder.dr_limit;
    const drLimitMessage    = cwmsAjaxHanlder.dr_limit_message;

    const loader = ( string = 'loading...') => {
        return `<div class="loader-wrapper">
        <div class="loder-crcil"></div>
          <div class="text">${string}</div>
        </div>`;
    }

    /* Function helpers */
    // validations
    const validateCurrency = (e) => {
        // Allow: backspace, delete, tab, escape, enter and .
        if ($.inArray(e.keyCode, [46, 8, 9, 27, 13, 110, 190]) !== -1 ||
            // Allow: Ctrl+A
            (e.keyCode == 65 && e.ctrlKey === true) ||
            // Allow: Ctrl+C
            (e.keyCode == 67 && e.ctrlKey === true) ||
            // Allow: Ctrl+X
            (e.keyCode == 88 && e.ctrlKey === true) ||
            // Allow: home, end, left, right
            (e.keyCode >= 35 && e.keyCode <= 39)) {
                // let it happen, don't do anything
                return;
        }
        // Ensure that it is a number and stop the keypress
        if ((e.shiftKey || (e.keyCode < 48 || e.keyCode > 57)) && (e.keyCode < 96 || e.keyCode > 105)) {
            e.preventDefault();
        }
    }
    //** Script for number
    const validateNumber = (e) => {
        // Allow: backspace, delete, tab, escape, enter and .
        if ($.inArray(e.keyCode, [46, 8, 9, 27, 13]) !== -1 ||
            // Allow: Ctrl+A
            (e.keyCode == 65 && e.ctrlKey === true) ||
            // Allow: Ctrl+C
            (e.keyCode == 67 && e.ctrlKey === true) ||
            // Allow: Ctrl+X
            (e.keyCode == 88 && e.ctrlKey === true) ||
            // Allow: home, end, left, right
            (e.keyCode >= 35 && e.keyCode <= 39)) {
                // let it happen, don't do anything
                return;
        }
        // Ensure that it is a number and stop the keypress
        if ((e.shiftKey || (e.keyCode < 48 || e.keyCode > 57)) && (e.keyCode < 96 || e.keyCode > 105) ) {
            e.preventDefault();
        }
    }
    const validateDiscount = ( e ) => {
        // Allow: backspace, delete, tab, escape, enter and .
        if ($.inArray(e.keyCode, [46, 8, 9, 27, 13, 53, 188, 190]) !== -1 ||
            // Allow: Ctrl+A
            (e.keyCode == 65 && e.ctrlKey === true) ||
            // Allow: Ctrl+C
            (e.keyCode == 67 && e.ctrlKey === true) ||
            // Allow: Ctrl+X
            (e.keyCode == 88 && e.ctrlKey === true) ||
            // Allow: home, end, left, right
            (e.keyCode >= 35 && e.keyCode <= 39)) {
                // let it happen, don't do anything
                return;
        }
        // Ensure that it is a number and stop the keypress
        if ((e.shiftKey || (e.keyCode < 48 || e.keyCode > 57)) && (e.keyCode < 96 || e.keyCode > 105) ) {
            e.preventDefault();
        }
    }
    const validateNumberFieldInit = () => {
        $('body').on( 'keydown', '.cmws-number', function( e ){
            validateNumber(e);
        });
        $('body').on( 'keydown', '.cmws-currency, .cmws-decimal', function( e ){
            validateCurrency(e);
        });
        $('body').on( 'keydown', '.cmws-discount', function( e ){
            validateDiscount(e);
        });
    }
    // Initialize currency and number field
    validateNumberFieldInit();

    // Limit character 
    $('body').on('input', '[data-limitchar]', function(){
        const parentElem = $(this).parent();
        const charLimit  = $(this).data('limitchar');
        const fieldValue = $(this).val();
        if( fieldValue.length > charLimit ){
            $(this).val( fieldValue.slice(0, -1) );
            parentElem.find('.desciption').addClass( 'alert alert-danger');
            return
        }
        parentElem.find('.desciption').removeClass( 'alert alert-danger');
    });

    // Password toggle & checked

    const checkPassword = (str) => {
        const pssRegEx = /^(?=.*[0-9])(?=.*[!~@#$%^&*])[a-zA-Z0-9!~@#$%^&*]{6,}$/;
        return pssRegEx.test(str);
     }


    $('body').on('click', '.cwms-password-toggle', function(){
        const currElem   = $(this);
        const currfField = $(this).closest('div').find('input');
        if( currfField.attr('type') == 'password' ){
            currfField.attr('type', 'text');
            currElem.removeClass('fa-eye').addClass('fa-eye-slash');
        }else{
            currfField.attr('type', 'password');
            currElem.removeClass('fa-eye-slash').addClass('fa-eye');
        }
    });

    $('body').on('input', '.cwms-password-field input', function(){
        const formElem          = $(this).closest('form');
        const messageWrapper    = $('.cwms-password-message_wrapper');
        const pass              = $('.cwms-password-field input[name="_password"]').val();
        const cpass             = $('.cwms-password-field input[name="_cpassword"]').val();
        messageWrapper.html('');
        formElem.find('[type="submit"]').prop( 'disabled', true ).addClass('disabled');
        if( pass.length <= 6 ){
            messageWrapper.append(
                `<div class="alert alert-danger">${cwmsAjaxHanlder.passLimit}.</div>`
            );
            return;
        }
        if( pass !== cpass && cpass.length > 0 ){
            messageWrapper.append(
                `<div class="alert alert-danger">${cwmsAjaxHanlder.passNotMatch}.</div>`
            );
            return;
        }

        if( ! checkPassword( pass ) ){
            messageWrapper.append(
                `<div class="alert alert-danger">${cwmsAjaxHanlder.passAllowedChars}.</div>`
            );
            return;
        }

        if( cpass.length === 0 ){
            messageWrapper.append(
                `<div class="alert alert-danger">${cwmsAjaxHanlder.passConfirm}.</div>`
            );
            return;
        }

        messageWrapper.append(
            `<div class="alert alert-success">${cwmsAjaxHanlder.passMatch}.</div>`
        );
        formElem.find('[type="submit"]').prop('disabled', false ).removeClass('disabled');

    });


    
    // Discount auto calculation
    const calculatProductCost = ( qty, cost, discounts ) => {
        let totalCost           = 0;
        let discAmount          = 0;
        let firstDiscType       = '';
        let lastDiscType        = '';
        let hasPCTDiscType      = false;
        let exclFixdDiscount    = 0;
        let hasDiscError        = false;

        if( discounts.length ){
            const discArray     = discounts.split(",");
            let costPrice       = parseFloat(cost);
            $.each( discArray, function( index, discValue ){
                if( discValue.trim().length == 0 ){
                    hasDiscError = false;
                    return;
                }
                const isPecentage = discValue.includes("%");
                if(  isNaN(discValue) && !isPecentage ){
                    hasDiscError = false;
                    return;
                }   

                // Check for the discounting series format
                const currDiscType = isPecentage ? 'pct' : 'fxd';
                if( index  == 0 ){
                    firstDiscType = currDiscType;
                }
                // Check if Percentage discount is already applied to be able to exclude the Fixed discount from discount
                if( !hasPCTDiscType && currDiscType == 'pct' ){
                    hasPCTDiscType = true;
                }
                /*
                * Sample sequence for reference
                1:  5%, 10, 5%      = false
                2:  10, 5%, 10, 10  = false
                3:  10, 10, 5%, 5%  = true
                4:  5%, 5%, 10, 10  = true
                */
                // Check the 3rd Loop
                if( index == 2 && ( firstDiscType != lastDiscType && lastDiscType != currDiscType ) ){
                    // Check the third discount type
                    // if the 1st and 2nd is not match - the 3rd must be the same discount type
                    // if not the same alert popup is will show and stop the process
                    hasDiscError = true;
                    lastDiscType = currDiscType;
                    return false; // breaks    
                }
                // Check the 4th Loop
                if( index > 2 && lastDiscType != currDiscType ){
                    hasDiscError = true;
                    lastDiscType = currDiscType;
                    return false; // breaks  
                }

                if( hasPCTDiscType && currDiscType == 'fxd' ){
                    exclFixdDiscount += parseFloat(discValue);
                    lastDiscType = currDiscType;
                    return; // continue loop
                }

                // keep checking the last dicsount type
                hasDiscError = false;
                lastDiscType = currDiscType;

                if( isPecentage ){
                    discAmount += costPrice * ( parseFloat(discValue) / 100 );
                    costPrice  = costPrice - ( costPrice * ( parseFloat(discValue) / 100 ) );
                    
                }else{
                    discAmount += parseFloat(discValue);
                    costPrice  = costPrice - parseFloat(discValue);
                }
            } );
            const discCostPrice = cost - discAmount;
            totalCost           = ( discCostPrice * qty ) - exclFixdDiscount
            return { 
                costPrice: discCostPrice, 
                totalCost: totalCost, 
                exclFixdDiscount : exclFixdDiscount,
                hasDiscError : hasDiscError
            };
        }

        totalCost = qty * cost;

        return { 
            costPrice: cost, 
            totalCost: totalCost, 
            exclFixdDiscount : exclFixdDiscount,
            hasDiscError : hasDiscError
        };
    }

    // Select2 
    $('.cwms-select2').select2({
        placeholder: placeholder,
        allowClear: true,
    });
    // Search product item
    let selectedProduct      = null;
    const productSearchElem  = $('#cwms-search_product');
    const productPlaceholder = productSearchElem.length && productSearchElem.attr('aria-placeholder') ? productSearchElem.attr('aria-placeholder') : placeholder;
    productSearchElem.select2({
        ajax: {
            url: ajaxURL, // AJAX URL is predefined in WordPress admin
            dataType: 'json',
            delay: 250, // delay in ms while typing when to perform a AJAX search
            data: function (params) {
                return {
                    q: params.term, // search query
                    action: $(this).attr('data-action')
                };
            },
            processResults: function( data ) {
                var options = [];
                if ( data ) {
                    $.each( data, function( index, info ) { // do not forget that "index" is just auto incremented value
                        let optLabel = info._name;
                        if( info._upc ){
                            optLabel = optLabel+` (${info._upc})`
                        }
                        options.push( { id: info._name, text: optLabel, info: info } );
                    });
                }
                return {
                    results: options
                };
            },
            cache: true
        },
        minimumInputLength: 3,
        selectOnClose: true,
        placeholder: productPlaceholder,
        language: {
            inputTooShort: function(args) { return inputTooShort; },
            errorLoading: function() { return errorLoading; },
            loadingMore: function() { return loadingMore; },
            noResults: function() { return noResults; },
            searching: function() { return searching; }
        }
    }).on('select2:select', function(e){
        // Get the selected data an put it in the global variable for repeater 
        selectedProduct = e.params.data;
        $('[data-repeater-create]').prop('disabled', false);
    }); 

    // Search PO select options 
    const poForm              = $('#cwms-po_form');
    const poRecievingWrap     = $('#cwms-po_receiving_form_wrapper');
    let receivePOData         = null;
    const receivePOWrapper    = $('#cwms-search_po_result_wrapper');
    const searchPOSelectElem  = $('#cwms-search_po');
    const searchPOPlaceholder = searchPOSelectElem.length && searchPOSelectElem.attr('aria-placeholder') ? searchPOSelectElem.attr('aria-placeholder') : placeholder;

    const generatePOData = () => {
        const supplier  = receivePOData._supplier_details;
        poRecievingWrap.find( '[name="cwms_po_id"]' ).val( receivePOData.ID );
        // Clean up product data
        poRecievingWrap.find('#cwms-receiving-poitems-table [data-repeater-list="cwms_po_products"]').html('');
        poRecievingWrap.find('#cwms-supplier-details').html(
            `
            <span class="supplier-name"><strong>${supplier._company_name}</strong></span></br>
            <span class="contact-name">${supplier._name}</span></br>
            <span class="supplier-address">
                ${supplier._address_1} ${supplier._address_2}<br/>
                ${supplier._city} ${supplier._state}<br/>
                ${supplier._postcode} ${supplier._country}
            </span><br/>
            ${supplier._phone}<br/>  
            ${supplier._email}
            `
        );
        poRecievingWrap.find('#po-header-po-details').html(
            `
            <h1>${purchaseOrderLabel}</h1>
            ${dateLabel}: <input type="text" name="_receipt_date" class="cwms-date" value="${receivePOData._date_created}"><br/>
            <span class="cwms-dr_number">${drLabel}#: <input type="text" name="_dr_number" value="" required></span><br/>
            <span class="cwms-po_number">${poLabel}#: ${receivePOData._po_number}</span><br/>
            <strong>${receivePOData._status}</strong>
            `
        );
        $.each( receivePOData._products , function( index, product ) { // do not forget that "index" is just auto incremented value
            const elemRow  = `
                <tr data-row="${product.ID}" data-repeater-item>
                    <td class="col-upc">
                        ${product.upc}
                        <input type="hidden" data-name="id" name="cwms_po_products[${index}][product_id]" value="${product.product_id}">    
                        <input type="hidden" data-name="upc" name="cwms_po_products[${index}][upc]" value="${product.upc}">
                        <input type="hidden" data-name="name" name="cwms_po_products[${index}][name]" value="${product.name}">
                        <input type="hidden" data-name="unit" name="cwms_po_products[${index}][unit]" value="${product.unit}">
                        <input type="hidden" data-name="qty" name="cwms_po_products[${index}][qty_ordered]" value="${ parseInt(product.qty_ordered)}">
                        <input type="hidden" data-name="retail-price" name="cwms_po_products[${index}][retail_price]" value="${product.retail_price}">
                    </td>
                    <td class="col-name">${product.name}</td>
                    <td class="col-qty">${parseInt(product.qty_ordered)}</td>
                    <td class="col-qty_delivered"><input type="text" class="cmws-currency cwms-calculate" data-name="qty_delivered" name="cwms_po_products[${index}][qty_delivered]" value="${parseInt(product.qty_delivered)}" /></td>
                    <td class="col-unit">${product.unit}</td>
                    <td class="col-cost_price"><input type="text" class="cmws-currency cwms-calculate" data-name="cost-price" name="cwms_po_products[${index}][cost_price]" value="${product.cost_price}" /></td>
                    <td class="col-discount"><input type="text" class="cmws-discount cwms-calculate" data-name="discount" name="cwms_po_products[${index}][discount]" value="${product.discount}" /></td>
                    <td class="col-total">${product.total.toFixed(2)}</td>
                </tr>
            `;
            poRecievingWrap.find('#cwms-receiving-poitems-table [data-repeater-list="cwms_po_products"]').append(elemRow);
        });
        poRecievingWrap.find('.amount_due_subtotal').html( receivePOData._sub_total.toFixed(2) );
        poRecievingWrap.find('[name="remarks"]').val( receivePOData._remarks );
        poRecievingWrap.find('[name="cod_discount"]').val( receivePOData._cod_discount.toFixed(2) );
        poRecievingWrap.find('[name="tax"]').val( receivePOData._tax.toFixed(2) );
        poRecievingWrap.find('[name="others"]').val( receivePOData._others.toFixed(2) );
        poRecievingWrap.find('.amount_due_total').text( parseFloat(receivePOData._total_amount).toFixed(2) );    
        $( document.body ).trigger( 'generatePOData', receivePOData );
    }

    searchPOSelectElem.select2({
        ajax: {
            url: ajaxURL, // AJAX URL is predefined in WordPress admin
            dataType: 'json',
            delay: 250, // delay in ms while typing when to perform a AJAX search
            data: function (params) {
                return {
                    q: params.term, // search query
                    action: $(this).attr('data-action')
                };
            },
            processResults: function( data ) {
                var options = [];
                if ( data ) {
                    $.each( data, function( index, info ) { // do not forget that "index" is just auto incremented value
                        // const drNumber = info._dr_number ? `(${drLabel}# ${info._dr_number})` : '--' ;
                        options.push( { id: info.ID, text: `${info.title}` , info: info } );
                    });
                }
                return {
                    results: options
                };
            },
            cache: true
        },
        minimumInputLength: 3,
        selectOnClose: true,
        placeholder: searchPOPlaceholder,
        language: {
            inputTooShort: function(args) { return inputTooShort; },
            errorLoading: function() { return errorLoading; },
            loadingMore: function() { return loadingMore; },
            noResults: function() { return noResults; },
            searching: function() { return searching; }
        }
    }).on('select2:select', function(e){
        // Get the selected data an put it in the global variable for repeater 
        receivePOData = e.params.data.info;
        searchPOSelectElem.val(null).trigger('change');
        receivePOWrapper.remove();
        poRecievingWrap.removeClass('d-none').css('margin-top', '38px');
        generatePOData();
    }); 

    // Search Supplier
    let selectedSupplier        = null;
    const supplierPlaceholder   = $('#cwms-search_supplier').length && $('#cwms-search_supplier').attr('aria-placeholder') ? $('#cwms-search_supplier').attr('aria-placeholder') : placeholder;
    const searchedSupplierModal = $('#cwms-search-supplier-modal');
    const generateSupplierDetails = () => {
        const supplier = selectedSupplier.info;
        const template = `
            <span class="supplier-name"><strong>${supplier._company_name}</strong></span></br>
            <span class="contact-name">${supplier._name}</span></br>
            <span class="supplier-address">
                ${supplier._address_1} ${supplier._address_2}<br/>
                ${supplier._city} ${supplier._state}<br/>
                ${supplier._postcode} ${supplier._country}
            </span><br/>
            ${supplier._phone}<br/>  
            ${supplier._email}
            <input type="hidden" name="_supplier_id" value="${supplier.ID}" />
        `;
        poForm.find('#cwms-supplier-details').html(template);
    }   
    $('#cwms-search_supplier').select2({
        dropdownParent: $('#cwms-search-supplier-modal .modal-body'),
        minimumInputLength: 3,
        selectOnClose: true,
        placeholder: supplierPlaceholder,
        language: {
            inputTooShort: function(args) { return inputTooShort; },
            errorLoading: function() { return errorLoading; },
            loadingMore: function() { return loadingMore; },
            noResults: function() { return noResults; },
            searching: function() { return searching; }
        },
        ajax: {
            url: ajaxURL, // AJAX URL is predefined in WordPress admin
            dataType: 'json',
            delay: 250, // delay in ms while typing when to perform a AJAX search
            data: function (params) {
                return {
                    q: params.term, // search query
                    action: $(this).attr('data-action')
                };
            },
            processResults: function( data ) {
                var options = [];
                if ( data ) {
                    $.each( data, function( index, info ) { // do not forget that "index" is just auto incremented value
                        let optLabel = `${info._company_name} (${info._name})`;
                        options.push( { id: info.ID, text: optLabel, info: info } );
                    });
                }
                return {
                    results: options
                };
            },
            cache: true
        }
    }).on('select2:select', function(e){
        // Get the selected data an put it in the global variable for repeater 
        selectedSupplier = e.params.data;
        searchedSupplierModal.find('#cwms-add_searched_supplier').prop('disabled', false);
    }); 
    $('#cwms-search-supplier-modal').on('click', '#cwms-add_searched_supplier', function(e){
        e.preventDefault();
        generateSupplierDetails();
        searchedSupplierModal.modal('hide');
        $(this).prop('disabled', true);
        $(".cwms-select2-search").val('').trigger('change');
    });

    // Purchase Order table calculator
    const removePOProduct  = ( deleteElement, poID, productID ) => {
        $.ajax({
			type 	: 'post',
			dataType : 'json',
			url 	: ajaxURL,
			data 	: {
				action : 'cwms_remove_po_product',
                poID : poID,
				productID : productID
            },
			beforeSend:function(){
				poForm.find('#cmws-submit-form_po').prop('disabled', true );
			},
			success:function(res){
                poForm.find('#cmws-submit-form_po').prop('disabled', false );
                if( ! res.result ){
                    alert( res.message );
                    return
                } 
                $(this).slideUp(deleteElement);
                setTimeout( function(){
                    tablePOCalculator( );
                }, 1000);

			}
		});
    }
    const tableReceivingPOCalculator      = (  ) => { 
        const tblElem       = $('#cwms-receiving-poitems-table');
        const tblLength     = tblElem.find('thead tr').children('th').length;
        let hasDiscError    = false;

        let subTotal = 0;
        let total    = 0;
        let codDisc  = $('#cwms-receiving-amountdue-table [name="cod_discount"]').val();
        let tax      = $('#cwms-receiving-amountdue-table [name="tax"]').val();
        let others   = $('#cwms-receiving-amountdue-table [name="others"]').val();

        // Sanitize Value
        codDisc      = isNaN(codDisc) || ! codDisc ? 0 : codDisc;
        tax          = isNaN(tax) || ! tax ? 0 : tax;
        others       = isNaN(others) || ! others ? 0 : others;
        total        += ( parseFloat(tax) + parseFloat(others) ) - parseFloat(codDisc);

        // Clean the Discount error message
        tblElem.find('tr.disc-error-row').remove();

        tblElem.find('tbody [data-repeater-item]').each(function( index, elem ){
            let rowQty              = parseFloat( $(this).find('[data-name="qty_delivered"]').val() );
            let rowSupplierCost     = parseFloat( $(this).find('[data-name="cost-price"]').val() );
            const discountElem      = $(this).find('[data-name="discount"]');
            const discounts         = discountElem.val();
            // Sanitize value
            rowQty                  = isNaN(rowQty) || ! rowQty ? 0 : rowQty;
            rowSupplierCost         = isNaN(rowSupplierCost) || ! rowSupplierCost ? 0 : rowSupplierCost;
           
            // Calculate the Item cost based on the given discount
            const calcProductCost   = calculatProductCost( rowQty, rowSupplierCost, discounts );
            const rowTotal          = calcProductCost.totalCost;

            hasDiscError            = calcProductCost.hasDiscError;
            if( calcProductCost.hasDiscError ){
                discountElem.addClass('text-danger');
            }else{
                discountElem.removeClass('text-danger');
            }
            
            subTotal    += rowTotal;
            total       += rowTotal; 
            $(this).find('.col-total').text( rowTotal.toFixed(2) );
        });

        if( hasDiscError ){
            tblElem.find('tbody').append(
                `<tr class="disc-error-row">
                    <td colspan="${tblLength + 1}" class="alert alert-danger">Discount format error</td>
                </tr>`
            );
        }

        $('#cwms-receiving-amountdue-table .amount_due_subtotal').text( subTotal.toFixed(2) );
        $('#cwms-receiving-amountdue-table .amount_due_total').text( total.toFixed(2) );
    }
    const tablePOCalculator      = (  ) => { 

        const tblElem       = $('#cwms-poitems-table');
        const tblLength     = tblElem.find('thead tr').children('th').length;
        let hasDiscError    = false;
        let subTotal = 0;
        let total    = 0;
        let codDisc  = $('#cwms-amountdue-table [name="cod_discount"]').val();
        let tax      = $('#cwms-amountdue-table [name="tax"]').val();
        let others   = $('#cwms-amountdue-table [name="others"]').val();

        // Sanitize Value
        codDisc      = isNaN(codDisc) || ! codDisc ? 0 : codDisc;
        tax          = isNaN(tax) || ! tax ? 0 : tax;
        others       = isNaN(others) || ! others ? 0 : others;
        total        += ( parseFloat(tax) + parseFloat(others) ) - parseFloat(codDisc);

        // Clean the Discount error message
        tblElem.find('tr.disc-error-row').remove();

        tblElem.find('tbody [data-repeater-item]').each(function( index, elem ){
            let rowQty              = parseFloat( $(this).find('[data-name="qty"]').val() );
            let rowSupplierCost     = parseFloat( $(this).find('[data-name="cost-price"]').val() );
            const discountElem      = $(this).find('[data-name="discount"]');
            const discounts         = discountElem.val();

            // Sanitize value
            rowQty                  = isNaN(rowQty) || ! rowQty ? 0 : rowQty;
            rowSupplierCost         = isNaN(rowSupplierCost) || ! rowSupplierCost ? 0 : rowSupplierCost;
            
            // Calculate the Item cost based on the given discount
            const calcProductCost   = calculatProductCost( rowQty, rowSupplierCost, discounts );
            const rowTotal          = calcProductCost.totalCost;

            hasDiscError            = calcProductCost.hasDiscError;
            if( calcProductCost.hasDiscError ){
                discountElem.addClass('text-danger');
            }else{
                discountElem.removeClass('text-danger');
            }

            subTotal    += rowTotal;
            total       += rowTotal; 

            $(this).find('.col-total').text( rowTotal.toFixed(2) );
        });

        if( hasDiscError ){
            tblElem.find('tbody').append(
                `<tr class="disc-error-row">
                    <td colspan="${tblLength + 1}" class="alert alert-danger">Discount format error</td>
                </tr>`
            );
        }
        
        $('#cwms-amountdue-table .amount_due_subtotal').text( subTotal.toFixed(2) );
        $('#cwms-amountdue-table .amount_due_total').text( total.toFixed(2) );
    }
    const populateSearchedData = ( $row ) => {
        if( !selectedProduct ){
            return;
        }

        const data          = selectedProduct.info;
        const costPrice     = data._cost_price ? parseFloat( data._cost_price ) : 0 ;
        const retailPrice   = data._retail_price ? parseFloat( data._retail_price ) : 0 ;
        const total         = parseFloat( 1 * retailPrice );

        if( costPrice == 0 ){
            alert( `${data._name} has ZERO amount of Cost Price!` );
        }

        // Add the selected data to row
        $row.attr("data-row", null);
        $row.find('[data-name="id"]').val(data.ID);
        $row.find('[data-name="upc"]').val(data._upc);
        $row.find('[data-name="name"]').val(data._name);
        $row.find('[data-name="qty"]').val(1);
        $row.find('[data-name="unit"]').val(data._unit);
        $row.find('[data-name="cost-price"]').val( costPrice.toFixed(2) );
        $row.find('[data-name="retail-price"]').val( retailPrice.toFixed(2)  );
        $row.find('.col-upc').text(data._upc);
        $row.find('.col-name').text(data._name);
        $row.find('.col-unit').text(data._unit);
        $row.find('.col-total').text( total.toFixed(2) );

        // Disable the "Add Item" button after adding the value to the table row
        $('[data-repeater-create]').prop('disabled', true);
        // Clear Select2 options
        $(".cwms-select2-search").val('').trigger('change');
    }
    $('#cwms-po_form').on('input', '.cwms-calculate', function(){
        tablePOCalculator();
    });
    $('#cwms-po_receiving_form').on('input', '.cwms-calculate', function(){
        tableReceivingPOCalculator();
    });

    const repeaterPOElem = $('.cwms_po_items');
    repeaterPOElem.repeater({
        // initEmpty: cwmsAjaxHanlder.emptyRepeater,
        initEmpty: cwmsAjaxHanlder.poTableData.emptyRepeater,
        show: function () {
            $(this).slideDown();
            validateNumberFieldInit();
            populateSearchedData( $(this) );
            tablePOCalculator( );
        },
        hide: function (deleteElement) {
            if(confirm( deleteConfirmData )) {
                // Get the rowdata
                const poID      = $(this).closest('table').data('poid');
                const prodID    = $(this).data('row');
                if( !poID || !prodID ){
                    $(this).slideUp(deleteElement);
                    setTimeout( function(){
                        tablePOCalculator( );
                    }, 1000);
                    return;
                }
                removePOProduct( deleteElement, poID, prodID );
            }
        },
        isFirstItemUndeletable: false
    });
    
    poForm.on('click', '#cmws-submit-form_po', function(e){
        e.preventDefault();
        if( ! poForm.find('[name="_supplier_id"]').length || ! parseInt( poForm.find('[name="_supplier_id"]').val() ) ){
            alert( noSupplier );
            return;
        }
        if( !$('#cwms-poitems-table').find('tbody tr').length ){
            alert( noItemSelectedMessage );
            return;
        }
        poForm.find('[type="submit"]').trigger('click');
    });

     // Search Customer
    let selectedCustomer        = null;
    const soForm                = $('#cwms-so_form');
    const searchCustomerField   = $('#cwms-search_customer');
    const customerPlaceholder   = searchCustomerField.length && searchCustomerField.attr('aria-placeholder') ? searchCustomerField.attr('aria-placeholder') : placeholder;
    const searchedCustomerModal = $('#cwms-search-customer-modal');
    const generateCustomerDetails = () => {
        const customer = selectedCustomer.info;
        const template = `
            <span class="customer-company"><strong>${customer._company}</strong></span></br>
            <span class="contact-name">${customer.display_name}</span></br>
            <span class="customer-address">
                ${customer._address_1} ${customer._address_2}<br/>
                ${customer._city} ${customer._state}<br/>
                ${customer._postcode} ${customer._country}
            </span><br/>
            ${customer._phone}<br/>  
            ${customer._email}
            <input type="hidden" name="_customer_id" value="${customer.ID}" />
        `;

        soForm.find('#cwms-customer-details').html(template);
    }   
    searchCustomerField.select2({
        dropdownParent: $('#cwms-search-customer-modal .modal-body'),
        minimumInputLength: 3,
        selectOnClose: true,
        placeholder: customerPlaceholder,
        language: {
            inputTooShort: function(args) { return inputTooShort; },
            errorLoading: function() { return errorLoading; },
            loadingMore: function() { return loadingMore; },
            noResults: function() { return noResults; },
            searching: function() { return searching; }
        },
        ajax: {
            url: ajaxURL, // AJAX URL is predefined in WordPress admin
            dataType: 'json',
            delay: 250, // delay in ms while typing when to perform a AJAX search
            data: function (params) {
                return {
                    q: params.term, // search query
                    action: $(this).attr('data-action')
                };
            },
            processResults: function( data ) {
                var options = [];
                if ( data ) {
                    $.each( data, function( index, info ) { // do not forget that "index" is just auto incremented value
                        options.push( { id: info.ID, text: `${info._company} (${info.display_name})`, info: info } );
                    });
                }
                return {
                    results: options
                };
            },
            cache: true
        }
    }).on('select2:select', function(e){
        selectedCustomer = e.params.data;
        searchedCustomerModal.find('#cwms-add_searched_customer').prop('disabled', false);
    }); 
    searchedCustomerModal.on('click', '#cwms-add_searched_customer', function(e){
        e.preventDefault();
        generateCustomerDetails();
        searchedCustomerModal.modal('hide');
        $(this).prop('disabled', true);
        searchCustomerField.val('').trigger('change');
    });
    soForm.on('click', '#cmws-submit-form_so', function(e){
        e.preventDefault();
        if( ! soForm.find('[name="_customer_id"]').length || ! parseInt( soForm.find('[name="_customer_id"]').val() ) ){
            alert( noCustomer );
            return;
        }
        if( !$('#cwms-poitems-table').find('tbody tr').length ){
            alert( noItemSelectedMessage );
            return;
        }
        soForm.find('[type="submit"]').trigger('click');
    });

    // Sales Order product repeater ####################################
    /*
     * selected products is save : selectedProduct 
     */
    const repeaterSOElem    = $('.cwms_so_items');
    const tableSOCalculator = ( ) => {

        const tblElem       = $('#cwms-poitems-table');
        const tblLength     = tblElem.find('thead tr').children('th').length;
        let hasDiscError    = false;
        let subTotal        = 0;
        let total           = 0;
        let codDisc         = $('#cwms-amountdue-table [name="cod_discount"]').val();
        let tax             = $('#cwms-amountdue-table [name="tax"]').val();
        let others          = $('#cwms-amountdue-table [name="others"]').val();

        // Sanitize Value
        codDisc      = isNaN(codDisc) || ! codDisc ? 0 : codDisc;
        tax          = isNaN(tax) || ! tax ? 0 : tax;
        others       = isNaN(others) || ! others ? 0 : others;
        total        += ( parseFloat(tax) + parseFloat(others) ) - parseFloat(codDisc);

        // Clean the Discount error message
        tblElem.find('tr.disc-error-row').remove();

        tblElem.find('tbody [data-repeater-item]').each(function( index, elem ){
            let rowQty          = parseFloat( $(this).find('[data-name="qty"]').val() );
            let rowRetailCost   = parseFloat( $(this).find('[data-name="retail-price"]').val() );
            const discountElem  = $(this).find('[data-name="discount"]');
            const discounts     = discountElem.val();

            // Sanitize value
            rowQty          = isNaN(rowQty) || ! rowQty ? 0 : rowQty;
            rowRetailCost   = isNaN(rowRetailCost) || ! rowRetailCost ? 0 : rowRetailCost;

            const calcProductCost   = calculatProductCost( rowQty, rowRetailCost, discounts );
            const rowTotal          = calcProductCost.totalCost;
            hasDiscError            = calcProductCost.hasDiscError;
            if( calcProductCost.hasDiscError ){
                discountElem.addClass('text-danger');
            }else{
                discountElem.removeClass('text-danger');
            }
            
            subTotal    += rowTotal;
            total       += rowTotal; 

            $(this).find('.col-total').text( rowTotal.toFixed(2) );
        });

        if( hasDiscError ){
            tblElem.find('tbody').append(
                `<tr class="disc-error-row">
                    <td colspan="${tblLength + 1}" class="alert alert-danger">Discount format error</td>
                </tr>`
            );
        }

        $('#cwms-amountdue-table .amount_due_subtotal').text( subTotal.toFixed(2) );
        $('#cwms-amountdue-table .amount_due_total').text( total.toFixed(2) );
    }
    const populateSOSearchedData = ( $row ) => {
        if( !selectedProduct ){
            return;
        }
        const data          = selectedProduct.info;
        const costPrice     = data._cost_price ? parseFloat( data._cost_price ) : 0;
        const retailPrice   = data._retail_price ? parseFloat( data._retail_price ) : 0;
        const total         = parseFloat( 1 * retailPrice );
        const discount      = data._discount ? data._discount.trim() : '';

        if( retailPrice == 0 ){
            alert( `Warning: Product "${data._name}" retail price is ZERO!` );
        }

        // // Add the selected data to row
        $row.find('[data-name="id"]').val(data.ID);
        $row.find('[data-name="upc"]').val(data._upc);
        $row.find('[data-name="name"]').val(data._name);
        $row.find('[data-name="unit"]').val(data._unit);
        $row.find('[data-name="cost-price"]').val( costPrice.toFixed(2) );
        $row.find('[data-name="qty"]').val(1);
        $row.find('[data-name="retail-price"]').val( retailPrice.toFixed(2)  );
        $row.find('[data-name="discount"]').val( discount );
        $row.find('.col-upc').text(data._upc);
        $row.find('.col-name').text(data._name);
        $row.find('.col-unit').text(data._unit);
        $row.find('.col-total').text( total.toFixed(2) );

        // // Disable the "Add Item" button after adding the value to the table row
        $('[data-repeater-create]').prop('disabled', true);
        // // Clear Select2 options
        $(".cwms-select2-search").val('').trigger('change');
        $( document.body ).trigger( 'populateSOSearchedData', selectedProduct );
    }

    const getSOProductLength = () => {
        return repeaterSOElem.find('[data-repeater-list="cwms_so_products"] [data-repeater-item]').length;
    }

    repeaterSOElem.repeater({
        initEmpty: cwmsAjaxHanlder.soTableData.emptyRepeater,
        defaultValues: {
            'disc-type': 'fxd'
        },
        show: function () {
            repeaterSOElem.find('.product-limit-error').remove();
            if( getSOProductLength() > drLimit ){
                $( `<div class="product-limit-error alert alert-danger">Warning: ${drLimitMessage}</div>` ).insertBefore( "#cwms-poitems-table" );
                productSearchElem.val(null).trigger('change');
            }
            $(this).slideDown();
            validateNumberFieldInit();
            populateSOSearchedData( $(this) );
            tableSOCalculator( );
        },
        hide: function (deleteElement) {
            if(confirm( deleteConfirmation )) {
                $(this).slideUp(deleteElement);
                // Set timeout to calculate the updated element
                setTimeout( function(){
                    if( getSOProductLength() <= drLimit ){
                        repeaterSOElem.find('.product-limit-error').remove();
                    }
                    tableSOCalculator( );
                }, 1000);
            }
        },
        isFirstItemUndeletable: false
    });
    // Calculate products in Sales Order
    $('#cwms-so_form').on('input', '.cwms-calculate', function(){
        tableSOCalculator();
    });

    // Invoice  #####################################################
    let searchedSOData          = null;
    let searchedDrNo            = null;
    let searchedInvNo           = null;
    const invoiceForm           = $('#cwms-invoice_form');
    const invoicingSoForm       = $('#cwms-invoicing_so_form');
    const repeaterInvoiceElem   = $('.cwms_invoice_items');
    const searchSOWrapper       = $('#cwms-search_so_result_wrapper');
    const invoicingSOWrapper    = $('#cwms-so_invoicing_form_wrapper');
    const searchedSOSelectElem  = $('#cwms-search_so');
    const searchSOPlaceholder   = searchedSOSelectElem.length && searchedSOSelectElem.attr('aria-placeholder') ? searchedSOSelectElem.attr('aria-placeholder') : placeholder;

    const generateSOData = ( hasNotApplied ) => {
        const products          = searchedSOData._products;
        invoicingSOWrapper.find('#cmws-submit-form_invoice').prop('disabled', false );
        if( searchedSOData._products.length > drLimit ){
            invoicingSOWrapper.find('#product-info .product-limit-error').remove();
            invoicingSOWrapper.find('#product-info').prepend(`
                <div class="product-limit-error alert alert-danger">Warning: ${drLimitMessage}</div>
            `);
            invoicingSOWrapper.find('#cmws-submit-form_invoice').prop('disabled', true );
        }

        const customer  = searchedSOData._customer_details;
        // Clean products data
        invoicingSOWrapper.find('#cwms-invoicing-soitems-table [data-repeater-list="cwms_invoice_products"]').html('');
        invoicingSOWrapper.find('#cwms-customer-details').html(
            `
            <input type="hidden" name="_customer_id" value="${customer.ID}" />
            <input type="hidden" name="_so_id" value="${searchedSOData.ID}" />
            <span class="customer-company_name"><strong>${customer._company}</strong></span></br>
            <span class="contact-name">${customer.display_name}</span></br>
            <span class="customer-address">
                ${customer._address_1} ${customer._address_2}<br/>
                ${customer._city} ${customer._state}<br/>
                ${customer._postcode} ${customer._country}
            </span><br/>
            ${customer._phone}<br/>  
            ${customer._email}
            `
        );
        invoicingSOWrapper.find('#po-header-po-details').html(
            `
            <h1>${purchaseOrderLabel}</h1>
            ${dateLabel}: ${searchedSOData._date_created}<br/>
            <span class="cwms-po_number" style="font-size: 1.5em; font-weight: bold; color: #1cbb9c;">${poLabel}#: ${searchedSOData._po_number}</span><br/>
            <strong>${searchedSOData._status}</strong>
            `
        );
        $.each( products, function( index, product ) { // do not forget that "index" is just auto incremented value
            if( product.applied && hasNotApplied ){
                return;
            }
            const elemRow  = `
                <tr data-row="${product.id}" data-repeater-item>
                    <td class="col-delete" style="width:24px;"><i data-repeater-delete class="fa fa-trash text-danger"></i></td>
                    <td class="col-upc">
                        ${product.upc}
                        <input type="hidden" data-name="id" name="cwms_invoice_products[${index}][product_id]" value="${product.id}">    
                        <input type="hidden" data-name="upc" name="cwms_invoice_products[${index}][upc]" value="${product.upc}">
                        <input type="hidden" data-name="name" name="cwms_invoice_products[${index}][name]" value="${product.name}">
                        <input type="hidden" data-name="unit" name="cwms_invoice_products[${index}][unit]" value="${product.unit}">
                        <input type="hidden" data-name="qty" name="cwms_invoice_products[${index}][qty_ordered]" value="${product.qty_ordered}">
                        <input type="hidden" data-name="retail_price" name="cwms_invoice_products[${index}][retail_price]" value="${product.retail_price}">
                        <input type="hidden" data-name="cost_price" name="cwms_invoice_products[${index}][cost_price]" value="${product.cost_price}">
                    </td>
                    <td class="col-name">${product.name}</td>
                    <td class="col-qty">${product.qty_ordered}</td>
                    <td class="col-qty_delivered"><input type="text" class="cmws-currency cwms-calculate" data-name="qty_delivered" name="cwms_invoice_products[${index}][qty_delivered]" value="${product.qty_ordered}" /></td>
                    <td class="col-unit">${product.unit}</td>
                    <td class="col-unit_price">${product.retail_price}</td>
                    <td class="col-discount"><input type="text" class="cmws-discount cwms-calculate" data-name="discount" name="cwms_invoice_products[${index}][discount]" value="${product.discount}" /></td>
                    <td class="col-total">${product.total.toFixed(2)}</td>
                </tr>
            `;
            invoicingSOWrapper.find('#cwms-invoicing-soitems-table [data-repeater-list="cwms_invoice_products"]').append(elemRow);
        });
        invoicingSOWrapper.find('.amount_due_subtotal').html( searchedSOData._sub_total.toFixed(2) );
        invoicingSOWrapper.find('[name="remarks"]').val( searchedSOData._remarks );
        invoicingSOWrapper.find('[name="terms"]').val( searchedSOData._terms );
        invoicingSOWrapper.find('[name="cod_discount"]').val( searchedSOData._cod_discount.toFixed(2) );
        invoicingSOWrapper.find('[name="tax"]').val( searchedSOData._tax.toFixed(2) );
        invoicingSOWrapper.find('[name="others"]').val( searchedSOData._others.toFixed(2) );
        invoicingSOWrapper.find('.amount_due_total').text( parseFloat(searchedSOData._total_amount).toFixed(2) );  

        // DR / Invoice
        invoicingSOWrapper.find('[name="_invoice_number"]').val( searchedInvNo );
        invoicingSOWrapper.find('._invoice_number').text( searchedInvNo );
        invoicingSOWrapper.find('[name="_invoice_dr_no"]').val( searchedDrNo );
        invoicingSOWrapper.find('[name="_so_id"]').val( searchedSOData.ID );

        // Assigned Agent
        invoicingSOWrapper.find('[name="_assigned_agent"]').val( searchedSOData._assigned_agent );
        invoicingSOWrapper.find('[name="_assigned_whseman"]').val( searchedSOData._assigned_whseman );
        invoicingSOWrapper.find('._assigned_agent_name').text( searchedSOData._assigned_agent_name );
        invoicingSOWrapper.find('._assigned_whseman_name').text( searchedSOData._assigned_whseman_name );

    }

    searchedSOSelectElem.select2({
        ajax: {
            url: ajaxURL, // AJAX URL is predefined in WordPress admin
            dataType: 'json',
            delay: 250, // delay in ms while typing when to perform a AJAX search
            data: function (params) {
                return {
                    q: params.term, // search query
                    action: $(this).attr('data-action')
                };
            },
            processResults: function( res ) {
                var options = [];
                if ( res.data ) {
                    $.each( res.data, function( index, info ) { // do not forget that "index" is just auto incremented value
                        options.push( { id: info.ID, text: info.title, info: info, drno: res.drno, invno: res.invno } );
                    });
                }
                return {
                    results: options
                };
            },
            cache: true
        },
        minimumInputLength: 3,
        selectOnClose: true,
        placeholder: searchSOPlaceholder,
        language: {
            inputTooShort: function(args) { return inputTooShort; },
            errorLoading: function() { return errorLoading; },
            loadingMore: function() { return loadingMore; },
            noResults: function() { return noResults; },
            searching: function() { return searching; }
        }
    }).on('select2:select', function(e){
        // Get the selected data an put it in the global variable for repeater 
        searchedSOData = e.params.data.info;
        searchedDrNo   = e.params.data.drno;
        searchedInvNo  = e.params.data.invno;

        let addAppliedProduct   = true;
        const products          = searchedSOData._products;
        const hasNotApplied     = products.find((element) => ! element.applied );

        if( ! hasNotApplied ){
            addAppliedProduct = confirm(allItemSelectedMessage);
        }

        searchedSOSelectElem.val(null).trigger('change');
        if( addAppliedProduct ){
            searchSOWrapper.remove();
            invoicingSOWrapper.removeClass('d-none').css('margin-top', '38px');
            generateSOData( hasNotApplied );
        }else{
            invoicingSOWrapper.addClass('d-none');
        }
    }); 

    const tableInvoiceCalculator = ( ) => {

        const tblElem       = $('#cwms-poitems-table, #cwms-invoicing-soitems-table');
        const repItemsELem  = tblElem.find('tbody [data-repeater-item]');
        const tblLength     = tblElem.find('thead tr').children('th').length;
        let hasDiscError    = false;
        let subTotal        = 0;
        let total           = 0;
        let codDisc         = $('#cwms-amountdue-table [name="cod_discount"]').val();
        let tax             = $('#cwms-amountdue-table [name="tax"]').val();
        let others          = $('#cwms-amountdue-table [name="others"]').val();

        if( repItemsELem.length <= drLimit ){
            invoicingSOWrapper.find('#product-info .product-limit-error').remove();
            invoicingSOWrapper.find('#cmws-submit-form_invoice').prop('disabled', false );
        }

        // Sanitize Value
        codDisc      = isNaN(codDisc) || ! codDisc ? 0 : codDisc;
        tax          = isNaN(tax) || ! tax ? 0 : tax;
        others       = isNaN(others) || ! others ? 0 : others;
        total        += ( parseFloat(tax) + parseFloat(others) ) - parseFloat(codDisc);

        // Clean the Discount error message
        tblElem.find('tr.disc-error-row').remove();

        repItemsELem.each(function( index, elem ){
            // let rowQty          = parseFloat( $(this).find('[data-name="qty"]').val() );
            let rowQty          = parseFloat( $(this).find('[data-name="qty_delivered"]').val() );
            let rowRetailCost   = parseFloat( $(this).find('[data-name="retail_price"]').val() );
            const discountElem  = $(this).find('[data-name="discount"]');
            const discounts     = discountElem.val();

            // Sanitize value
            rowQty          = isNaN(rowQty) || ! rowQty ? 0 : rowQty;
            rowRetailCost   = isNaN(rowRetailCost) || ! rowRetailCost ? 0 : rowRetailCost;

            // Calculate the Item cost based on the given discount
            const calcProductCost   = calculatProductCost( rowQty, rowRetailCost, discounts );
            const rowTotal          = calcProductCost.totalCost;
            subTotal    += rowTotal;
            total       += rowTotal; 

            hasDiscError            = calcProductCost.hasDiscError;
            if( calcProductCost.hasDiscError ){
                discountElem.addClass('text-danger');
            }else{
                discountElem.removeClass('text-danger');
            }

            $(this).find('.col-total').text( rowTotal.toFixed(2) );
        });

        if( hasDiscError ){
            tblElem.find('tbody').append(
                `<tr class="disc-error-row">
                    <td colspan="${tblLength + 1}" class="alert alert-danger">Discount format error</td>
                </tr>`
            );
        }

        $('#cwms-amountdue-table .amount_due_subtotal').text( subTotal.toFixed(2) );
        $('#cwms-amountdue-table .amount_due_total').text( total.toFixed(2) );
    }

    const populateInvoiceSearchedData = ( $row ) => {
        if( !selectedProduct ){
            return;
        }
   
        const data          = selectedProduct.info;
        const costPrice     = parseFloat( data._cost_price );
        const retailPrice   = parseFloat( data._retail_price );
        const total         = parseFloat( 1 * retailPrice );
        const discount      = null;
        // // Add the selected data to row
        $row.find('[data-name="product_id"]').val(data.ID);
        $row.find('[data-name="upc"]').val(data._upc);
        $row.find('[data-name="name"]').val(data._name);
        $row.find('[data-name="cost_price"]').val(costPrice);
        $row.find('[data-name="qty"]').val(0);
        $row.find('[data-name="qty_delivered"]').val(1);
        $row.find('[data-name="retail_price"]').val( retailPrice.toFixed(2)  );
        $row.find('.col-qty').text(0);
        $row.find('.col-upc').text(data._upc);
        $row.find('.col-name').text(data._name);
        $row.find('.col-total').text( total.toFixed(2) );

        // // Disable the "Add Item" button after adding the value to the table row
        $('[data-repeater-create]').prop('disabled', true);
        // // Clear Select2 options
        $(".cwms-select2-search").val('').trigger('change');
    }

    repeaterInvoiceElem.repeater({
        initEmpty: cwmsAjaxHanlder.invoiceTableData.emptyRepeater,
        defaultValues: {
            'id': null
        },
        show: function () {
            const repItemsELem = $('#cwms-poitems-table, #cwms-invoicing-soitems-table').find('tbody [data-repeater-item]');
            if( repItemsELem.length > drLimit ){
               alert(drLimitMessage);
               $(this).remove();
               return;
            }
            $(this).slideDown();
            validateNumberFieldInit();
            populateInvoiceSearchedData( $(this) );
            tableInvoiceCalculator( );
            
        },
        hide: function (deleteElement) {
            if(confirm( deleteConfirmation )) {
                $(this).slideUp(deleteElement);
                // Set timeout to calculate the updated element
                setTimeout( function(){
                    tableInvoiceCalculator( );
                }, 1000);
            }
        },
        isFirstItemUndeletable: false
    });

    // DR Checker
    let drCheckerTimer;
    let drNoInit    = null;
    let isDrSet     = false;

    const checkDrNumber = ( drNumber ) => {
        $.ajax({
            type 	: 'post',
            dataType : 'json',
            url 	: ajaxURL,
            data 	: {
                action : 'cwms_check_invoice_dr',
                drNo : drNumber,			
            },
            beforeSend:function(){
                invoicingSOWrapper.find('#cmws-submit-form_invoice').prop('disabled', true );
            },
            success:function(response){
                const productLength = repeaterInvoiceElem.find('[data-repeater-list="cwms_invoice_products"] [data-repeater-item]').length;
                if( response.status == 'error' ){
                    invoicingSOWrapper.prepend(
                        `<div class="drno-error alert alert-danger text-center">${response.message}</div>`
                    );
                    return;
                }
                if( productLength > drLimit  ){
                    return;
                }
                invoicingSOWrapper.find('#cmws-submit-form_invoice').prop('disabled', false );
            }
        });
    }
   
    invoicingSOWrapper.on('focus', '[name="_invoice_dr_no"]', function(){
        if( !isDrSet ){
            drNoInit    = $(this).val();
            isDrSet     = true;
        }
    });
    invoicingSOWrapper.on('input', '[name="_invoice_dr_no"]', function(){
        drNo = $(this).val();
        invoicingSOWrapper.find('.drno-error').remove();
        clearTimeout(drCheckerTimer);
        drCheckerTimer = setTimeout( function(){
            checkDrNumber( drNo );
        }, 1000 );
    });

    // SUBMIT INVOICING FORM SALES ORDER
    invoicingSoForm.on('input', '.cwms-calculate', function(){
        tableInvoiceCalculator();
    });
    invoicingSoForm.on('click', '#cmws-submit-form_invoice', function(e){
        e.preventDefault();
        if( !$('#cwms-invoicing-soitems-table').find('tbody tr[data-repeater-item]').length ){
            alert( noItemSelectedMessage );
            return;
        }
        invoicingSoForm.find('[type="submit"]').trigger('click');
    });
    // SUBMIT CREATE INVOICE
    invoiceForm.on('click', '#cmws-submit-form_invoice', function(e){
        e.preventDefault();
        if( !$('#cwms-poitems-table').find('tbody tr').length ){
            alert( noItemSelectedMessage );
            return;
        }
        invoiceForm.find('[type="submit"]').trigger('click');
    });

    invoiceForm.on('input', '.cwms-calculate', function(){
        tableInvoiceCalculator();
    });

    // Return - Invoice scripts #################################
    // cwms-search_return_result_wrapper
    let searchedReturnInvoiceData   = null;
    const returnTranslation         = cwmsAjaxHanlder.returnInvoiceTable;
    const returnFormWrapper         = $('#cwms-return_form_wrapper');
    const returnPlaceholerWrapper   = $('#cwms-search_return_placeholder_wrapper');
    const searchedRetInvSelectElem  = $('#cwms-search_invoice_return');
    const searchRetInvPlaceholder   = searchedRetInvSelectElem.length && searchedRetInvSelectElem.attr('aria-placeholder') ? searchedRetInvSelectElem.attr('aria-placeholder') : placeholder;

    const generateSelectElem = ( rowIndex ) => {
        const remark_options  = returnTranslation.remark_options;
        let remarkSelectElem  = `<select class="return_remarks form-control form-control-sm" name="cwms_invoice_products[${rowIndex}][remarks]" style="width: fit-content;" >`; 
        $.each( remark_options, function( index, option ){
            const value = index != 0 ? index : ''; 
            remarkSelectElem += `<option value="${value}">${option}</option>`;
        });
        remarkSelectElem  += `</select>`; 
        return remarkSelectElem;
    }

    const generateReturnInvoiceData = () => {
        const customer        = searchedReturnInvoiceData._customer_details;

        // Adding return information
        returnFormWrapper.find('._invoice_dr_no').text(searchedReturnInvoiceData._dr_no);
        returnFormWrapper.find('._invoice_number').text(searchedReturnInvoiceData._invoice_number);
        returnFormWrapper.find('[name="_invoice_id"]').val(searchedReturnInvoiceData.ID);

        // Clean products data
        returnFormWrapper.find('#cwms-invoicing-returnitems-table [data-repeater-list="cwms_invoice_products"]').html('');
        returnFormWrapper.find('#cwms-customer-details').html(
            `
            <input type="hidden" name="_customer_id" value="${customer.ID}" />
            <span class="customer-company_name"><strong>${customer._company}</strong></span></br>
            <span class="contact-name">${customer.display_name}</span></br>
            <span class="customer-address">
                ${customer._address_1} ${customer._address_2}<br/>
                ${customer._city} ${customer._state}<br/>
                ${customer._postcode} ${customer._country}
            </span><br/>
            ${customer._phone}<br/>  
            ${customer._email}
            `
        );
        $.each( searchedReturnInvoiceData._products , function( index, product ) { // do not forget that "index" is just auto incremented value
            const elemRow  = `
                <tr data-row="${product.ID}" data-repeater-item>
                    <td class="col-upc">${product.upc}
                        <input type="hidden" data-name="id" name="cwms_invoice_products[${index}][ID]" value="${product.ID}">   
                        <input type="hidden" data-name="product_id" name="cwms_invoice_products[${index}][product_id]" value="${product.product_id}">   
                        <input type="hidden" data-name="name" name="cwms_invoice_products[${index}][name]" value="${product.name}">   
                        <input type="hidden" data-name="retail_price" name="cwms_invoice_products[${index}][retail_price]" value="${product.retail_price}">   
                        <input type="hidden" data-name="cost_price" name="cwms_invoice_products[${index}][cost_price]" value="${product.cost_price}">   
                    </td>
                    <td class="col-name">${product.name}</td>
                    <td class="col-qty_delivered">${product.qty_delivered}</td>
                    <td class="col-qty_returned">
                        <input type="text" class="cmws-currency cwms-calculate form-control form-control-sm" data-name="qty_returned" name="cwms_invoice_products[${index}][qty_returned]" value="0" style="width: 60px;" />
                    </td>
                    <td class="col-unit">${product.unit}</td>
                    <td class="col-unit_price">${generateSelectElem(index)}</td>
                </tr>
            `;
            returnFormWrapper.find('#cwms-invoicing-returnitems-table [data-repeater-list="cwms_invoice_products"]').append(elemRow);
        });
        // Assigned Agent
        returnFormWrapper.find('._assigned_agent_name').text( searchedReturnInvoiceData._assigned_agent_name );
        returnFormWrapper.find('[name="_pullout_no"]').val('');
    }

    $('#cwms-return_invoice_form').on('input', '.cwms-calculate', function(){
        // Add required attribute in the select element
        const selElem = $(this).closest('tr').find('.return_remarks');
        selElem.prop('required', $(this).val() > 0 );
    });

    // Saerch for the invoice to return
    searchedRetInvSelectElem.select2({
        ajax: {
            url: ajaxURL, // AJAX URL is predefined in WordPress admin
            dataType: 'json',
            delay: 250, // delay in ms while typing when to perform a AJAX search
            data: function (params) {
                return {
                    q: params.term, // search query
                    action: $(this).attr('data-action')
                };
            },
            processResults: function( data ) {
                var options = [];
                if ( data ) {
                    $.each( data, function( index, info ) { // do not forget that "index" is just auto incremented value
                        options.push( { id: info.ID, text: info.title, info: info } );
                    });
                }
                return {
                    results: options
                };
            },
            cache: true
        },
        minimumInputLength: 3,
        selectOnClose: true,
        placeholder: searchRetInvPlaceholder,
        language: {
            inputTooShort: function(args) { return inputTooShort; },
            errorLoading: function() { return errorLoading; },
            loadingMore: function() { return loadingMore; },
            noResults: function() { return noResults; },
            searching: function() { return searching; }
        }
    }).on('select2:select', function(e){
        // Get the selected data an put it in the global variable for repeater 
        searchedReturnInvoiceData = e.params.data.info;
        searchedRetInvSelectElem.val(null).trigger('change');
        returnPlaceholerWrapper.remove();
        returnFormWrapper.removeClass('d-none').css('margin-top', '38px');
        generateReturnInvoiceData();
    }); 
});