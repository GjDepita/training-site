jQuery(document).ready( function( $ ){
    const ajaxurl           = cwmsImportAjaxHandler.ajaxurl;
    const processedLabel    = cwmsImportAjaxHandler.processedLabel;
    const processComplete   = cwmsImportAjaxHandler.processComplete;
    const uploadLabel       = cwmsImportAjaxHandler.uploadLabel;
    const productHeaders    = cwmsImportAjaxHandler.productHeaders;
    const supplierHeaders   = cwmsImportAjaxHandler.supplierHeaders;
    const userHeaders       = cwmsImportAjaxHandler.userHeaders;
    const _importWrapper    = $('#cwms-import-form_wrapper');
    const _importForm       = $('#cwms-import-form');
    const _importResult     = $('#cwms-import-result_wrapper');
    const _progressReport   = $("#cwms-progress-report");
    
    let rowCount        = 0;
    let errorCount      = 0;
    let firstError       = undefined;
    let _fileName        = '';
    let _processed      = 0;
    let _records        = [];
    let _completed      = false;
    let _action         = null;
    let _security       = null;
    let importErrors    = [];

    // Function helpers
    const removeErrorNotification = () => {
        _importForm.find('.error-message').remove();
    }
    const errorNotification = msg => {
        removeErrorNotification();
        _importForm.prepend( `<div class="error-message alert alert-danger">${msg}</div>` );
    }
    const removeErrorList = () => {
        const parentElement = $('#cwms-page_content');
        parentElement.find( '.error-list_wrapper' ).remove();
    }
    const displayErrorList = () => {
        const parentElement = $('#cwms-page_content');
        removeErrorList();
        if( ! importErrors.length ){
            return;
        }
        parentElement.prepend(`
            <div class="error-list_wrapper alert alert-danger">
                <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span></button>
                <p><strong>${importErrors.length}</strong> Error(s) during import process.</p>
                <ul class="error-list"></ul>
            </div>
        `);
        $.each( importErrors, function(i,value){
            parentElement.find('.error-list_wrapper .error-list').append(`<li>${value}</li>`);
        } );
    }
    const isFileHeaderMatched  = ( data ) => {
        let actionHeaders = null;
        if( 'cwms-import-products' == _action ){
            actionHeaders = productHeaders;
        }else if( 'cwms-import-suppliers' == _action ){
            actionHeaders = supplierHeaders;
        }else if( 'cwms-import-users' == _action ){
            actionHeaders = userHeaders;
        }
        if( !actionHeaders ){
            return false;
        }
        const headers       = Object.keys(actionHeaders).map(element => {
            return element.toLowerCase();
          });
        const firstElement  = data.shift().map(element => {
            return element.toLowerCase();
          });

        return JSON.stringify(headers) === JSON.stringify(firstElement);
    }

    const processRecord = ( _startIndex = 0 ) => {
        if( _records.length  == 0 ) return;

        let _percent        = 0;
        const _totalRecords = _records.length;
        const _perBatch     = 25;
        const _endIndex     = Math.min(_startIndex + _perBatch, _records.length);
        const _batch        = _records.slice(_startIndex, _endIndex);

        $.ajax({
            type : "post",
            dataType : "json",
            url : ajaxurl,
            data : {
                action : _action, 
                records : _batch, 
                security : _security
            },
            success: function(res) {   

                $.each( res, function( i, data ){
                    if( data.status == 'error'){
                        importErrors.push( data.message );
                    }
                });

                _processed += _batch.length; 

                if ( _endIndex < _records.length ) {
                    processRecord(_endIndex);
                } else {
                    _importForm.find("input[name='cwms-import_file']").val("");
                    _completed = true;
                }
            },
            error: function(xhr, status, error) {
                console.error('Error processing batch:', _batch, error);
            }
            }).done(function(){
                _percent = Math.ceil( _processed / _totalRecords * 100 );
                _progressReport.find("#cwms-progress_bar .progress-indicator").css( {'width': `${_percent}%` } );
                if( ! _completed ){
                    _progressReport.find(".info").html( `${processedLabel} ${_processed} / ${_totalRecords}` );						
                }else{
                    _progressReport.find("#cwms-progress_bar .progress-indicator").removeClass('animate');
                    _progressReport.find(".info").html(`<p class='success'>${processComplete}</p>`);
                    _completed = false;
                    _processed = 0;
                    _importForm.find('#cwms-file_upload_label').html(`<b>${uploadLabel}</b>`);
                    enableButton();
                    displayErrorList();
                }
            });
    };

    const  downloadCSV = ( data, filename ) => {
        var csv = Papa.unparse(data);
        var csvData = new Blob([csv], {type: 'text/csv;charset=utf-8;'});
        var csvURL =  null;
        if (navigator.msSaveBlob)
        {
            csvURL = navigator.msSaveBlob(csvData, filename+'.csv');
        }
        else
        {
            csvURL = window.URL.createObjectURL(csvData);
        }

        var tempLink = document.createElement('a');
        tempLink.href = csvURL;
        tempLink.setAttribute('download', filename+'.csv');
        tempLink.click();
    }
    const config = () => {
        return {
            complete: completeFn,
            error: errorFn,
            // header: true,
        };
    }
    const now = () => {
	    return typeof window.performance !== 'undefined' ? window.performance.now() : 0;
    }
    const errorFn = (err, file) => {
        end = now();
    }
    const completeFn = (results) => {
        end = now();

        if (results && results.errors)
        {
            if (results.errors)
            {
                errorCount = results.errors.length;
                firstError = results.errors[0];
            }
            if (results.data && results.data.length > 0)
                rowCount = results.data.length;
        }
        
        // Check if file header is correct
        if( ! isFileHeaderMatched( results.data ) ){
            errorNotification( 'File header incorrect!' );
            enableButton();
            return false;
        }

        // Remove the file header
        _records        = results.data;
        importErrors    = [];
        _importResult.css({'display':'block'});
        _progressReport.find("#cwms-progress_bar .progress-indicator").addClass('animate');

        processRecord();
    }

    const enableButton = () => {
        _importForm.find('[type="submit"]').prop('disabled', false);
    }
    const disableButton = () => {
        _importForm.find('[type="submit"]').prop('disabled', true);
    }
    _importForm.find("input[name='cwms-import_file']").change(function( e ){
        _importForm.find('#cwms-file_upload_label').html(`<b>${e.target.files[0].name}</b>`);
    });

    _importForm.on('submit', function( e ){
        e.preventDefault();
        disableButton();
        removeErrorNotification()
        _action       = _importForm.find("input[name='action']").val();
        _security     = _importForm.find("input[name='security']").val();
        const _file   = _importForm.find("input[name='cwms-import_file']");
        _file.parse({
            config: config(),
            before: function(file, inputElem)
            {  
                start = now();
                _fileName = file.name;
            },
            error: function(err, file)
            {
                firstError = firstError || err;
                errorCount++;
            },
            complete: function()
            {
                end = now();
            }
        });
    });

    _importWrapper.on('click', '#cwms-download_csv_template', function( e ){
        e.preventDefault();
        const dataType  = $(this).data('type');
        let dataHeaders = [];
        if( dataType == 'cwms-import-products' ){
            dataHeaders.push(productHeaders);
        }else if( dataType == 'cwms-import-suppliers' ){
            dataHeaders.push(supplierHeaders);
        }else if( dataType == 'cwms-import-users' ){
            dataHeaders.push(userHeaders);
        }
        if( ! dataHeaders.length ){
            alert( 'Header is empty' );
            return;
        }
        downloadCSV( dataHeaders, dataType );
    });
});