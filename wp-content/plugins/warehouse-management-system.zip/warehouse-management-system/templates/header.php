<!DOCTYPE html>
<html <?php language_attributes(); ?>>
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <!-- Meta, title, CSS, favicons, etc. -->
    <meta charset="<?php bloginfo( 'charset' ); ?>">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="shortcut icon" href="<?php echo cwms1661_favicon_url(); ?>" type="image/x-icon">
	  <link rel="icon" href="<?php echo cwms1661_favicon_url(); ?>" type="image/x-icon">	
    <title><?php echo bloginfo( 'name' ) ?> | <?php the_title(); ?></title>
    <?php wp_head(); ?>
    <?php do_action('cwms1661_dashboard_header'); ?>
  </head>
  <?php if( is_user_logged_in() ): $template = 'content'; ?>
  <body class="nav-md page-<?php echo get_the_ID(); ?>">
    <div class="container body">
      <div class="main_container">
      <?php endif; ?>