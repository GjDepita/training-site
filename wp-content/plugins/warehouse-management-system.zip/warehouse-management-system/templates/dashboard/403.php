<div class="col-middle">
    <div class="text-center text-center">
        <h1 class="error-number">403</h1>
        <h2><?php esc_html_e("Permission denied, please contact administrator.", "wpcodigo_wms" ); ?></h2>
    </div>
</div>
<script>
    window.history.replaceState({}, document.title, '<?php echo cwms1661_dashboard_home().'?'.cwms1661_clean_url_parameter(['cwms-message']); ?>' );
</script>