<?php 
    $current_date       = date( 'Y-m-d', current_time( 'timestamp' ) ); 
    $dashboard_roles    = array_keys( cwms1661_dashboard_roles() );
    $users              = get_users( array( 'role__in' => $dashboard_roles ) );
?>
<div class="row tile_count">
    <div class="col-md-2 col-sm-4 col-xs-6 tile_stats_count">
        <a href="<?php echo esc_url( cwms1661_dashboard_home().'?cwmspage=all-po' ); ?>">
            <span class="count_top"><i class="fa fa-cart-arrow-down"></i> <?php esc_html_e('Total Inbounds', 'wpcodigo_wms' ); ?></span>
            <div class="count blue"><?php echo cwms1661_posts_count_date( CWMS1661_PO_POST_TYPE, $current_date, $current_date ); ?></div>
            <span class="count_bottom"> <?php printf( __( 'as of %s', 'wpcodigo_wms'), '<span class="dark tile_date">'.$current_date.'<span>' ); ?></span>
        </a>
    </div>
    <div class="col-md-2 col-sm-4 col-xs-6 tile_stats_count">
        <a href="<?php echo esc_url( cwms1661_dashboard_home().'?cwmspage=all-so' ); ?>">
            <span class="count_top"><i class="fa fa-folder-open-o"></i> <?php esc_html_e('Total Sales Order', 'wpcodigo_wms' ); ?></span>
            <div class="count blue"><?php echo cwms1661_posts_count_date( CWMS1661_SO_POST_TYPE, $current_date, $current_date ); ?></div>
            <span class="count_bottom"> <?php printf( __( 'as of %s', 'wpcodigo_wms'), '<span class="dark tile_date">'.$current_date.'<span>' ); ?></span>
        </a>
    </div>
    <div class="col-md-2 col-sm-4 col-xs-6 tile_stats_count">
        <a href="<?php echo esc_url( cwms1661_dashboard_home().'?cwmspage=invoices' ); ?>">
            <span class="count_top"><i class="fa fa-truck"></i> <?php esc_html_e('Total Invoice', 'wpcodigo_wms' ); ?></span>
            <div class="count blue"><?php echo cwms1661_posts_count_date( CWMS1661_INVOICE_POST_TYPE, $current_date, $current_date ); ?></div>
            <span class="count_bottom"> <?php printf( __( 'as of %s', 'wpcodigo_wms'), '<span class="dark tile_date">'.$current_date.'<span>' ); ?></span>
        </a>
    </div>
    <div class="col-md-2 col-sm-4 col-xs-6 tile_stats_count">
        <a href="<?php echo esc_url( cwms1661_dashboard_home().'?cwmspage=all-products' ); ?>">
            <span class="count_top"><i class="fa fa-cubes"></i> <?php esc_html_e('Total Products', 'wpcodigo_wms' ); ?></span>
            <div class="count blue"><?php echo cwms1661_post_count( CWMS1661_PRODUCT_POST_TYPE ); ?></div>
        </a>
    </div>
    <div class="col-md-2 col-sm-4 col-xs-6 tile_stats_count">
        <a href="<?php echo esc_url( cwms1661_dashboard_home().'?cwmspage=all-suppliers' ); ?>">
            <span class="count_top"><i class="fa fa-book"></i> <?php esc_html_e('Total Suppliers', 'wpcodigo_wms' ); ?></span>
            <div class="count blue"><?php echo cwms1661_post_count( CWMS1661_SUPPLIER_POST_TYPE ); ?></div>
        </a>
    </div>
    <div class="col-md-2 col-sm-4 col-xs-6 tile_stats_count">
        <a href="<?php echo esc_url( cwms1661_dashboard_home().'?cwmspage=all-users' ); ?>">
            <span class="count_top"><i class="fa fa-user"></i> <?php esc_html_e('Total Users', 'wpcodigo_wms' ); ?></span>
            <div class="count blue"><?php echo count( $users ); ?></div>
        </a>
    </div>
</div>
<!-- /top tiles -->

<div class="row">
    <div class="col-md-12 col-sm-12 col-xs-12">
        <div id="cwms-dashboard_graph_wrapper" class="dashboard_graph" style="min-height: 130px;">

            <div class="row x_title">
                <div class="col-md-6">
                    <h3><?php esc_html_e('Current Activities', 'wpcodigo_wms' ); ?> <span class="cwms-current_activity_dates" style="font-size: .7em; color: #787878; margin-left: 18px;"></span></h3>
                </div>
                <div class="col-md-6">
                    <div id="cwms-dashboard-daterange" class="pull-right" style="background: #fff; cursor: pointer; padding: 5px 10px; border: 1px solid #ccc; margin-bottom: 12px;">
                        <i class="glyphicon glyphicon-calendar fa fa-calendar"></i>&nbsp;
                        <span></span> <b class="caret"></b>
                    </div>
                </div>
            </div>

            <div class="col-md-9 col-sm-9 col-xs-12 dashboard_graph-sections">
                <canvas id="cwms-report_chart" class="report-placeholder"></canvas>
            </div>
            <div class="col-md-3 col-sm-3 col-xs-12 bg-white dashboard_graph-sections">
                <div class="col-md-12 col-sm-12 col-xs-6">
                    <div class="tile_count" style="margin-top: 0;">
                        <div class="tile_stats_count" style="padding: 0; margin: 0;">
                            <span class="count_top"><i class="fa fa-money"></i> <?php esc_html_e('Total Collections', 'wpcodigo_wms' ); ?></span>
                            <div class="count cwms-total_collection blue" style="font-size: 1.5em; line-height: inherit;">0.00</div>
                        </div>
                    </div>
                </div>
                <div class="col-md-12 col-sm-12 col-xs-6">
                    <div class="tile_count" style="margin-top: 0;">
                        <div class="tile_stats_count" style="padding: 0; margin: 0;">
                            <span class="count_top"><i class="fa fa-money"></i> <?php esc_html_e('Total Receivables', 'wpcodigo_wms' ); ?></span>
                            <div class="count cwms-total_receivables blue" style="font-size: 1.5em; line-height: inherit;">0.00</div>
                        </div>
                    </div>
                </div>
                <div class="col-md-12 col-sm-12 col-xs-6">
                    <div class="tile_count" style="margin-top: 0;">
                        <div class="tile_stats_count" style="padding: 0; margin: 0;">
                            <span class="count_top"><i class="fa fa-money"></i> <?php esc_html_e('Total PO', 'wpcodigo_wms' ); ?></span>
                            <div class="count cwms-total_inbounds blue" style="font-size: 1.5em; line-height: inherit;">0.00</div>
                        </div>
                    </div>
                </div>

                <div class="col-md-12 col-sm-12 col-xs-6 cwms-shortcut_links_wrapper">
                    <section class="header x_title">
                        <h3 class="line_30"><?php esc_html_e('Shortcuts', 'wpcodigo_wms' ); ?></h3>
                    </section>
                    <ul id="cwms-shortcut_links" class="quick-list">
                        <?php foreach( cwms1661_dashboard_shortcuts_menu() as $menu ): ?>
                            <li >
                                <i class="<?php echo esc_attr( $menu['icon'] ); ?>"></i><a class="green" href="<?php echo esc_url( cwms1661_dashboard_home().'?cwmspage='.esc_attr( $menu['page-slug'] ) ); ?>"><?php echo esc_html( $menu['label'] ); ?></a>
                            </li>
                        <?php endforeach; ?>
                    </ul>
                </div>
            </div>

            <div class="clearfix"></div>
            
        </div>
    </div>

</div>
