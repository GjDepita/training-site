<form method="POST" action="options.php">
    <?php settings_fields( 'cwms1661_settings_group' ); ?>
    <?php do_settings_sections( 'cwms1661_settings_group' ); ?>
    <table class="form-table">
        <tr>
            <th><?php esc_html_e('Dashboard Page', 'wpcodigo_wms'); ?></th>
            <td>
                <select name="cwms1661_dashboard_page" id="cwms1661_dashboard_page" required>
                    <option value=""><?php esc_html_e('Select Page', 'wpcodigo_wms'); ?></option>
                    <?php foreach( get_pages() as $page ): ?>
                        <option value="<?php echo $page->ID; ?>" <?php selected( cwms1661_dashboard_page(), $page->ID ); ?>><?php echo $page->post_title; ?></option>
                    <?php endforeach; ?>
                </select>
            </td>
        </tr>
    </table>
    <input class="primary button-primary" type="submit" name="submit" value="<?php esc_html_e('Save Settings', 'wpcodigo_wms' ); ?>" />
</form>