<div id="wpbody-content" class="cwms-dashboard_wrapper">
    <section id="cwms-header_section">
        <a id="wordpress-logo" title="<?php esc_html_e('Wordpress Dashboard', 'wpcodigo_wms'); ?>" href="<?php echo admin_url(); ?>"><span class="dashicons dashicons-wordpress"></span></a>
        <h1 class="cwms-header_title"><?php echo apply_filters('cwms_dashboard_header_title', __('WMS by Codigo', 'wpcodigo_wms')); ?><span class="cwms-header_version"><?php echo __('Version', 'wpcodigo_wms').' '.CWMS1661_VERSION; ?></span></h1>
    </section>
    <section id="cwms-content_section">
        <?php do_action('cwms_before_admin_dashboard_navigation'); ?>
        <div class="cwms-content_navigation nav-tab-wrapper">
            <?php do_action('cwms_admin_dashboard_navigation'); ?>
        </div>
        <div class="cwms-content_body">
            <?php do_action('cwms_admin_dashboard_body'); ?>
        </div>
        <?php do_action('cwms_after_admin_dashboard_body'); ?>
    </section>
    <?php do_action('cwms_admin_dashboard_footer'); ?>
</div>
