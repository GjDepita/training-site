<?php 
  $content_template = $post->ID == cwms1661_dashboard_page() ? 'dashboard' : 'loop' ; 
  $page_slug        = isset($_GET['cwmspage']) ? urlencode( $_GET['cwmspage'] ) : '';
?>
<?php include_once('navigation.php'); ?>
  <!-- page content -->
  <div class="right_col" role="main">
    <section class="page-title">
      <div class="title_left">
        <h1 class="text-uppercase h3"><?php echo cwms1661_get_dashboard_title( $page_slug ); ?> <?php do_action('cwms1661_after_page_title_'.$page_slug ); ?></h1>
      </div>
    </section>
    <?php do_action('cwms1661_after_page_title_section_'.$page_slug ); ?>
    <div class="clearfix"></div>
    <?php do_action('cwms_before_page-'.$page_slug); ?>
    <section id="cwms-page-<?php echo $page_slug; ?>" class="row">
      <?php do_action('cwms_before_page_content'); ?>
      <div class="col-md-12 col-sm-12 col-xs-12 p-4">
        <div id="cwms-page_content" class="x_panel">
          <?php include_once( cwms1661_get_template_path('content-'.$content_template) ); ?>
        </div>
      </div>
    </section>
  </div>
  <!-- /page content -->