<body class="login">
    <div>
      <a class="hiddenanchor" id="signup"></a>
      <a class="hiddenanchor" id="signin"></a>
      <div class="login_wrapper">
        <div class="animate form login_form">
          <?php do_action( 'wcms1661_before_form_login' ); ?>
          <section class="login_content">
            <?php include_once( cwms1661_get_template_path( 'form-login', 'forms') ); ?>
          </section>
          <?php do_action( 'wcms1661_after_form_login' ); ?>
        </div>

        <!-- <div id="register" class="animate form registration_form">
          <?php do_action( 'wcms1661_before_form_register' ); ?>
          <section class="login_content">
            <?php //include_once( cwms1661_get_template_path( 'form-register', 'forms') ); ?>
          </section>
          <?php do_action( 'wcms1661_after_form_register' ); ?>
        </div> -->
      </div>
    </div>
  </body>