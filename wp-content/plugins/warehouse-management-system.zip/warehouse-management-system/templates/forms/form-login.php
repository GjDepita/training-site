<?php $username = isset($_GET['username']) ? sanitize_text_field($_GET['username']) : '' ; ?>
<?php $redirect_to = ( is_ssl() ? 'https://' : 'http://' ) . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI']; ?>
<div class="login-main-wrap">
    <div class="login-form-wrap">
        <form name="loginform" id="loginform" action="<?php echo bloginfo('url').'/wp-login.php' ?>" method="post">
            <h1><?php esc_html_e('Login', 'wpcodigo_wms' ); ?></h1>
            <div class="form-username-wrap">
                <input type="text" class="form-control" name="log" placeholder="<?php esc_html_e('Username / Email', 'wpcodigo_wms' ); ?>" value="<?php echo esc_attr( $username ); ?>" required="required" />
            </div>
            <div class="form-password-wrap" style="position: relative;">
                <input type="password" class="form-control" name="pwd" placeholder="<?php esc_html_e('Password', 'wpcodigo_wms' ); ?>" required="required" />
                <i class="fa fa-2x fa-eye cwms-password-toggle" style="
                    margin: 0;
                    position: absolute;
                    top: 50%;
                    right: 6px;
                    -ms-transform: translate(-50%, -50%);
                    transform: translate(-50%, -50%);
                    cursor: pointer;
                "></i>
            </div>
            <div class="form-actions-wrap">
                <button type="submit" name="wp-submit" id="wp-submit" class="btn btn-primary login-btn"><?php esc_html_e('Log in', 'wpcodigo_wms' ); ?></button>
                <input type="hidden" name="redirect_to" value="<?php echo esc_url( $redirect_to ); ?>" />
                <a class="reset_pass" href="<?php echo wp_lostpassword_url(); ?>"><?php esc_html_e('Lost your password?', 'wpcodigo_wms' ); ?></a>
            </div>
        </form>
    </div>
    <div class="site-logo-wrap">
        <?php echo cwms1661_logo(  true ); ?>
    </div>
</div>
<div class="login-footer-wrap">
    <?php do_action('wcms_login_footer'); ?>
</div>
<script>
    document.body.addEventListener('click', function(event) {
        if (event.target.classList.contains('cwms-password-toggle')) {
            const currElem = event.target;
            const currfField = currElem.closest('div').querySelector('input');

            if (currfField.getAttribute('type') === 'password') {
                currfField.setAttribute('type', 'text');
                currElem.classList.remove('fa-eye');
                currElem.classList.add('fa-eye-slash');
            } else {
                currfField.setAttribute('type', 'password');
                currElem.classList.remove('fa-eye-slash');
                currElem.classList.add('fa-eye');
            }
        }
    });
</script>