<form>
    <h1><?php esc_html_e('Create Account', 'wpcodigo_wms' ); ?></h1>
    <div>
        <input type="text" class="form-control" placeholder="<?php esc_html_e('Username"', 'wpcodigo_wms' ); ?>" required="required" />
    </div>
    <div>
        <input type="email" class="form-control" placeholder="<?php esc_html_e('Email"', 'wpcodigo_wms' ); ?>" required="required" />
    </div>
    <div>
        <input type="password" class="form-control" placeholder="<?php esc_html_e('Password"', 'wpcodigo_wms' ); ?>" required="required" />
    </div>
    <div>
        <a class="btn btn-default submit" href="index.html"><?php esc_html_e('Submit', 'wpcodigo_wms' ); ?></a>
    </div>

    <div class="clearfix"></div>

    <div class="separator">
        <p class="change_link"><?php esc_html_e('Already a member ?', 'wpcodigo_wms' ); ?>
            <a href="#signin" class="to_register"> <?php esc_html_e('Log in', 'wpcodigo_wms' ); ?> </a>
        </p>

        <div class="clearfix"></div>
        <br />

        <div>
            <h1><i class="fa fa-paw"></i> <?php echo bloginfo('name'); ?></h1>
            <?php do_action('wcms_login_footer'); ?>
        </div>
    </div>
</form>