  <?php if( is_user_logged_in() ): ?>
    <!-- footer content -->
        <footer>
          <div class="pull-right">
            
          </div>
          <div class="clearfix"></div>
        </footer>
        <!-- /footer content -->
      </div> <!-- /main_container-->
    </div> <!-- /container body -->

    <?php wp_footer(); ?>
    <?php do_action('cwms1661_dashboard_footer'); ?> 
  </body>
  <?php endif; ?>
</html>