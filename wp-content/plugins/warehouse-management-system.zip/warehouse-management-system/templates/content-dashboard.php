<?php
if( !isset($_GET['cwmspage']) 
    || empty($_GET['cwmspage']) 
    || ! array_key_exists( urlencode($_GET['cwmspage']), cwms1661_registered_dashboard_pages() )
    ):
    include_once( cwms1661_get_template_path('home', 'dashboard') );
else:
    $file_path = cwms1661_get_template_path( urlencode($_GET['cwmspage']), 'dashboard');
    if( !file_exists( $file_path ) ){
        $file_path = apply_filters( 'cwms1661_404_file_path', cwms1661_get_template_path( 404, 'dashboard') );
    }
    include_once( apply_filters( 'cwms1661_content_template_'.urlencode($_GET['cwmspage']), $file_path ) );
endif;