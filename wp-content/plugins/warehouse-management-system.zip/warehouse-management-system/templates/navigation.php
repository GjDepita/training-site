<div class="col-md-3 left_col">
    <div class="left_col scroll-view">
    <div class="navbar nav_title" style="border: 0; margin-top: 10px;">
        <a href="<?php echo cwms1661_dashboard_home(); ?>" class="site_title"><?php echo cwms1661_logo(true); ?></a>
    </div>

    <div class="clearfix"></div>

    <!-- menu profile quick info -->
    <div class="profile clearfix">
        <div class="profile_pic">
        <img src="<?php echo get_avatar_url($current_user->ID); ?>" alt="..." class="img-circle profile_img">
        </div>
        <div class="profile_info">
        <h2><?php echo $current_user->display_name; ?></h2>
        <p><?php echo implode(", ", cwms1661_user_roles_label( $current_user ) ); ?></p>
        </div>
    </div>
    <!-- /menu profile quick info -->

    <br />
    <!-- sidebar menu -->
    <div id="sidebar-menu" class="main_menu_side hidden-print main_menu">
        <div class="menu_section">
            <h3><?php esc_html_e('Menus', 'wpcodigo_wms'); ?></h3>
            <ul class="nav side-menu">
                <?php foreach ( cwms1661_dashboard_menus() as $mvalue ): ?>
                    <?php if( empty( $mvalue['subs'] ) ): ?>
                        <li id="menu-<?php echo $mvalue['id']; ?>" class="nav-list">
                            <a href="<?php echo cwms1661_dashboard_home().'?cwmspage='.$mvalue['id']; ?>"><i class="<?php echo $mvalue['classes']; ?>"></i><?php echo $mvalue['label'] ?></a>
                        </li>
                    <?php continue; endif; ?>
                    <li id="menu-<?php echo $mvalue['id']; ?>" class="nav-list <?php echo esc_attr( $mvalue['id'] ); ?> <?php echo cwms1661_nav_active($mvalue['id']) ? 'active' : ''; ?>">
                        <a><i class="<?php echo $mvalue['classes']; ?>"></i> <?php echo $mvalue['label']; ?> <span class="fa fa-chevron-down"></span></a>
                        <?php if( ! empty( $mvalue['subs'] ) ): ?>
                        <ul class="nav child_menu" <?php echo cwms1661_nav_active($mvalue['id']) ? 'style="display: block;"' : ''; ?>>
                            <?php foreach ( $mvalue['subs'] as $sub_page => $sub_label ): ?>
                                <li class="<?php echo esc_attr($sub_page); ?> <?php echo cwms1661_subnav_active( $sub_page ) ? 'active' : ''; ?>"><a href="<?php echo cwms1661_dashboard_home().'?cwmspage='.$sub_page; ?>"><?php echo $sub_label; ?></a></li>
                            <?php endforeach; ?>
                        </ul>
                        <?php endif; ?>
                    </li>
                <?php endforeach; ?>
            </ul>
        </div>
    </div>
    <!-- /sidebar menu -->

    <!-- /menu footer buttons -->
    <div class="sidebar-footer hidden-small">
        <?php if( is_cwms1661_admin( ) ): ?>
            <a data-toggle="tooltip" data-placement="top" title="<?php esc_html_e('Settings', 'wpcodigo_wms'); ?>" href="<?php echo cwms1661_dashboard_home().'?cwmspage=settings'; ?>">
                <span class="glyphicon glyphicon-cog" aria-hidden="true"></span>
            </a>
        <?php endif; ?>
        <a data-toggle="tooltip" data-placement="top" title="<?php esc_html_e('Logout', 'wpcodigo_wms'); ?>" href="<?php echo wp_logout_url( cwms1661_dashboard_home() ); ?>" style="<?php echo !is_cwms1661_admin( ) ? 'width:100% !important;' : '' ; ?>">
            <span class="glyphicon glyphicon-off" aria-hidden="true"></span>
        </a>
    </div>
    <!-- /menu footer buttons -->
    </div>
</div>

<!-- top navigation -->
<div class="top_nav">
    <div class="nav_menu">
    <nav>
        <div class="nav toggle">
        <a id="menu_toggle"><i class="fa fa-bars"></i></a>
        </div>

        <ul class="nav navbar-nav navbar-right">
            <li class="">
                <a href="javascript:;" class="user-profile dropdown-toggle" data-toggle="dropdown" aria-expanded="false">
                    <img src="<?php echo get_avatar_url($current_user->ID); ?>" alt=""><?php echo $current_user->display_name; ?>
                    <span class=" fa fa-angle-down"></span>
                </a>
                <ul class="dropdown-menu dropdown-usermenu pull-right">
                    <li><a href="<?php echo cwms1661_dashboard_home().'?cwmspage=edit-profile'; ?>"> <?php esc_html_e('Profile', 'wpcodigo_wms'); ?></a></li>
                    <?php if( is_cwms1661_admin( ) ): ?>
                        <li>
                            <a href="<?php echo cwms1661_dashboard_home().'?cwmspage=settings'; ?>"><span><?php esc_html_e('Settings', 'wpcodigo_wms'); ?></span></a>
                        </li>
                    <?php endif; ?>
                    <li><a href="<?php echo wp_logout_url( cwms1661_dashboard_home() ); ?>"><i class="fa fa-sign-out pull-right"></i> <?php esc_html_e('Log Out', 'wpcodigo_wms'); ?></a></li>
                </ul>
            </li>
        </ul>
    </nav>
    </div>
</div>
<!-- /top navigation -->