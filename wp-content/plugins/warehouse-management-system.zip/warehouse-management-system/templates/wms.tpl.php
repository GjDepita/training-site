<?php $current_user = wp_get_current_user(); $template = 'content-login'; ?>
<?php include_once( cwms1661_get_template_path( 'header' ) ); ?>
<?php include_once( cwms1661_get_template_path( $template )); ?> 
<?php include_once( cwms1661_get_template_path( 'footer' ) ); ?>