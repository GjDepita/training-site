<?php
/**
 * Plugin Name: WMS by Codigo
 * Plugin URI: https://codigo.com/
 * Description: A Warehouse Management System that helps you manage your warehousing process and product distribution.
 * Version: 2.9.1
 * Author: Codigo
 * Author URI: https://codigo.com
 * Text Domain: wpcodigo_wms
 * Domain Path: /i18n/languages/
 * Requires at least: 6.0
 * Requires PHP: 7.4
 */
/*
 ** https://github.com/ColorlibHQ/gentelella **
 */

defined( 'ABSPATH' ) || exit;

if ( ! defined( 'CWMS1661_PLUGIN_FILE' ) ) {
	define( 'CWMS1661_PLUGIN_FILE', __FILE__ );
}

// Include the main WooCommerce class.
if ( ! class_exists( 'CWMS1661', false ) ) {
	include_once dirname( CWMS1661_PLUGIN_FILE ) . '/includes/wms.php';
}
cwms116_initilize();