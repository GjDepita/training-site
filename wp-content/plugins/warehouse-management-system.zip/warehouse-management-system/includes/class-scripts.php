<?php
defined( 'ABSPATH' ) || exit;

if ( ! class_exists( 'CWMS1661_Assets', false ) ) :

    class CWMS1661_Assets {
        function __construct()
        {
            // Admin
			add_action( 'admin_enqueue_scripts', array( $this, 'admin_scripts' ) );
            // Frontend
            add_action( 'wp_enqueue_scripts', array( $this, 'scripts' ) );
            // Dequeue Scripts
            add_action( 'wp_print_styles', array( $this, 'dequeue_scripts' ), 100 );
        }

        public function admin_scripts(){
            $screen    = get_current_screen();
            if( $screen->id !== 'toplevel_page_cwms-dashboard'){
                return false;
            }
            // Styles
            wp_enqueue_style( 'cwms1661-main-style', CWMS1661_PLUGIN_URL.'assets/admin/css/main.css' );
            wp_enqueue_style( 'cwms1661-style', CWMS1661_PLUGIN_URL.'assets/admin/css/styles.css' );
            // Scrips
            wp_enqueue_script( 'cwms1661-script', CWMS1661_PLUGIN_URL.'assets/admin/js/scripts.js' , array(), CWMS1661_VERSION, true );
        }
        public function scripts(){
            if( ! cwms1661_is_dashboard() ){
                return false;
            }
            // Make sure that the current page is the admin page
            wp_enqueue_style( 'cwms1661-bootstrap-style', CWMS1661_PLUGIN_URL.'assets/css/bootstrap.min.css' );
            wp_enqueue_style( 'cwms1661-fontawesome-style', CWMS1661_PLUGIN_URL.'assets/css/font-awesome.css' );
            wp_enqueue_style( 'cwms1661-nprogress-style', CWMS1661_PLUGIN_URL.'assets/css/nprogress.css' );
            wp_enqueue_style( 'cwms1661-animate-style', CWMS1661_PLUGIN_URL.'assets/css/animate.min.css' );
            wp_enqueue_style( 'cwms1661-theme-style', CWMS1661_PLUGIN_URL.'assets/css/custom.css' );
            if( ! is_user_logged_in() ){
                return false;
            }
            // Styles     
            wp_enqueue_style( 'cwms1661-select2-style', CWMS1661_PLUGIN_URL.'assets/css/select2.min.css' );      
            wp_enqueue_style( 'cwms1661-dataTables-style', CWMS1661_PLUGIN_URL.'assets/css/datatables.min.css' );      
            wp_enqueue_style( 'cwms1661-dataTableCheckbox-style', CWMS1661_PLUGIN_URL.'assets/css/dataTables.checkboxes.css' );      
            wp_enqueue_style( 'cwms1661-bootstrap-datetimepicker-style', CWMS1661_PLUGIN_URL.'assets/css/bootstrap-datetimepicker.min.css' );
            wp_enqueue_style( 'cwms1661-daterangepicker-style', CWMS1661_PLUGIN_URL.'assets/css/daterangepicker.css' );
            wp_enqueue_style( 'cwms1661-style', CWMS1661_PLUGIN_URL.'assets/css/style.css' );

            // Scripts
            
            wp_enqueue_script( 'cwms1661-moment-script', CWMS1661_PLUGIN_URL.'assets/js/moment.min.js' , array(), CWMS1661_VERSION, true );
            wp_enqueue_script( 'cwms1661-jquery-script', CWMS1661_PLUGIN_URL.'assets/js/jquery.min.js' , array(), CWMS1661_VERSION, true );
            wp_enqueue_script( 'cwms1661-bootstrap-script', CWMS1661_PLUGIN_URL.'assets/js/bootstrap.min.js' , array(), CWMS1661_VERSION, true );   
            wp_enqueue_script( 'cwms1661-chart-script', CWMS1661_PLUGIN_URL.'assets/js/chart.js' , array(), CWMS1661_VERSION, true );
            wp_enqueue_script( 'cwms1661-papaparse-script', CWMS1661_PLUGIN_URL.'assets/js/papaparse.min.js' , array(), CWMS1661_VERSION, true );
            // Date and Time Picker
            wp_enqueue_script( 'cwms1661-bootstrap-datetimepicker-script', CWMS1661_PLUGIN_URL.'assets/js/bootstrap-datetimepicker.min.js' , array(), CWMS1661_VERSION, true );
            wp_enqueue_script( 'cwms1661-daterangepicker-script', CWMS1661_PLUGIN_URL.'assets/js/daterangepicker.js' , array(), CWMS1661_VERSION, true );
            wp_enqueue_script( 'cwms1661-nprogress-script', CWMS1661_PLUGIN_URL.'assets/js/nprogress.js' , array(), CWMS1661_VERSION, true );
            // Select2
            wp_enqueue_script( 'cwms1661-select2-script', CWMS1661_PLUGIN_URL.'assets/js/select2.full.min.js' , array(), CWMS1661_VERSION, true );
            // Repeater
            wp_enqueue_script( 'cwms1661-repeater-script', CWMS1661_PLUGIN_URL.'assets/js/jquery.repeater.min.js' , array(), CWMS1661_VERSION, true );
            
            // Datatable
            wp_enqueue_script( 'cwms1661-dataTables-script', CWMS1661_PLUGIN_URL.'assets/js/datatables.min.js' , array(), CWMS1661_VERSION, true );
            // Datatable plugins - Start
            wp_enqueue_script( 'cwms1661-bootstrap-buttons-script', CWMS1661_PLUGIN_URL.'assets/js/dataTables.buttons.js' , array(), CWMS1661_VERSION, true );
            wp_enqueue_script( 'cwms1661-dataTableChecbox-script', CWMS1661_PLUGIN_URL.'assets/js/dataTables.checkboxes.min.js' , array(), CWMS1661_VERSION, true );
            wp_enqueue_script( 'cwms1661-dataTablesJSZIP-script', CWMS1661_PLUGIN_URL.'assets/js/dataTables.jszip.min.js' , array(), CWMS1661_VERSION, true );
            wp_enqueue_script( 'cwms1661-dataTablesPDFMAKE-script', CWMS1661_PLUGIN_URL.'assets/js/dataTables.pdfmake.min.js' , array(), CWMS1661_VERSION, true );
            wp_enqueue_script( 'cwms1661-dataTablesVFSFont-script', CWMS1661_PLUGIN_URL.'assets/js/dataTables.vfs_fonts.js' , array(), CWMS1661_VERSION, true );
            wp_enqueue_script( 'cwms1661-dataTablesButtonsHTML5-script', CWMS1661_PLUGIN_URL.'assets/js/dataTables.buttons.html5.min.js' , array(), CWMS1661_VERSION, true );
            // Datatable plugins - END
            
            wp_enqueue_script( 'cwms1661-theme-custom-script', CWMS1661_PLUGIN_URL.'assets/js/custom.js' , array('cwms1661-jquery-script', 'cwms1661-chart-script'), CWMS1661_VERSION, true );
            wp_enqueue_script( 'cwms1661-theme-datetime-script', CWMS1661_PLUGIN_URL.'assets/js/datetime-scripts.js' , array('cwms1661-jquery-script', 'cwms1661-bootstrap-datetimepicker-script', 'cwms1661-daterangepicker-script'), CWMS1661_VERSION, true );

            wp_enqueue_script( 'cwms1661-theme-script', CWMS1661_PLUGIN_URL.'assets/js/scripts.js' , array('cwms1661-jquery-script', 'cwms1661-bootstrap-datetimepicker-script', 'cwms1661-daterangepicker-script'), CWMS1661_VERSION, true );
            wp_enqueue_script( 'cwms1661-ajax-script', CWMS1661_PLUGIN_URL.'assets/js/ajax-scripts.js' , array('cwms1661-jquery-script','cwms1661-dataTables-script', 'cwms1661-bootstrap-buttons-script', 'cwms1661-papaparse-script'), CWMS1661_VERSION, true );

            wp_enqueue_script( 
                'cwms1661-report-script', 
                CWMS1661_PLUGIN_URL.'assets/js/reports.js' , 
                array(
                    'cwms1661-jquery-script',
                    'cwms1661-dataTables-script',
                    'cwms1661-bootstrap-buttons-script',
                    'cwms1661-dataTablesJSZIP-script',
                    'cwms1661-dataTablesPDFMAKE-script',
                    'cwms1661-dataTablesVFSFont-script',
                    'cwms1661-dataTablesButtonsHTML5-script'
                ), 
                CWMS1661_VERSION, 
                true 
            );

            wp_enqueue_script( 'cwms1661-payments-script', CWMS1661_PLUGIN_URL.'assets/js/payments.js' , array('cwms1661-jquery-script','cwms1661-dataTables-script', 'cwms1661-bootstrap-buttons-script'), CWMS1661_VERSION, true );
            wp_enqueue_script( 'cwms1661-print-script', CWMS1661_PLUGIN_URL.'assets/js/print.js' , array('cwms1661-jquery-script','cwms1661-dataTables-script', 'cwms1661-bootstrap-buttons-script'), CWMS1661_VERSION, true );
            wp_localize_script( 'cwms1661-theme-script', 'cwmsAjaxHanlder', cwms1661_script_translations() );

            $translations           = apply_filters( 'cwms1661_ajax_localize_script_translations', cwms1661_script_translations() );

            $report_translations    = array_merge(
                cwms1661_script_translations(),
                array(
                    'cwms1661BootstrapStyle' => CWMS1661_PLUGIN_URL.'assets/css/bootstrap.min.css',
                    'cwms1661ThemeStyle' => CWMS1661_PLUGIN_URL.'assets/css/custom.css',
                    'cwms1661Style' => CWMS1661_PLUGIN_URL.'assets/css/style.css'
                )
            );

            $report_translations    = apply_filters( 'cwms1661_report_localize_script_translations', $report_translations );
            $print_translations     = array(
                'ajaxurl' => cwms1661_script_translations()['ajaxurl']
            );

            wp_localize_script( 'cwms1661-ajax-script', 'cwmsAjaxHanlder', $translations );
            wp_localize_script( 'cwms1661-report-script', 'cwmsReportHandlder', $report_translations );
            wp_localize_script( 'cwms1661-payments-script', 'cwmsPaymentHandlder', $report_translations );
            wp_localize_script( 'cwms1661-print-script', 'cwmsPrintHandlder', $print_translations );
            wp_localize_script( 'cwms1661-theme-custom-script', 'cwmsCustomHandlder', $print_translations );
        }
        public function dequeue_scripts(){
            global $wp_scripts, $wp_styles;
            if( ! cwms1661_is_dashboard() ){
                return false;
            }
            $_scripts = array();
            // Print all loaded Scripts (JS)
            foreach( $wp_scripts->queue as $script ) :
                $source =  $wp_scripts->registered[$script]->src;
                $ex_source = explode('/', $source );
                if( !in_array( $script, cwms1661_registered_scripts() ) ){
                    $_scripts[] = $wp_scripts->registered[$script]->handle;
                    wp_dequeue_script( $wp_scripts->registered[$script]->handle );
                }
            endforeach;
            $_styles = array();
            // Print all loaded Styles (CSS)
            foreach( $wp_styles->queue as $style ) :
                $source =  $wp_styles->registered[$style]->src;
                $ex_source = explode('/', $source );
                if( !in_array( $style, cwms1661_registered_styles() ) ){
                    $_styles[] = $wp_styles->registered[$style]->handle;
                    wp_dequeue_style( $wp_styles->registered[$style]->handle );
                }
            endforeach;
            // Dequeue Jquery Script
            $dequeue_script_list = array(
                "jquery-ui-draggable"
            );
            foreach($dequeue_script_list as $dscript){
                wp_deregister_script($dscript);
            }
        }
    }

endif;

return new CWMS1661_Assets();