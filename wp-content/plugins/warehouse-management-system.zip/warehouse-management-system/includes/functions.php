<?php 
defined( 'ABSPATH' ) || exit;
function cwms1661_date_format(){
    return apply_filters( 'cwms1661_date_format', 'Y-m-d');
}
function cwms1661_datetime_format(){
    return apply_filters( 'cwms1661_datetime_format', 'Y-m-d h:i A');
}
function cwms1661_current_date(){
    return apply_filters('cwms1661_current_date', current_datetime()->format(cwms1661_date_format()) );
}
function cwms1661_get_array_pocket( $key, $array ){
    return array_search ( $key, $array);
}
function cwms1661_can_view_cog_roles(){
    $roles = ['administrator', 'cwms_manager', 'cwms_purchaser'];
    return apply_filters('cwms1661_can_view_cog_roles', $roles );
}
function cwms1661_can_view_cog(){
    if( !is_user_logged_in() ){
        return false;
    }
    $view_cog = array_intersect( cwms1661_can_view_cog_roles(), cwms1661_current_user_roles() ) ? true : false ;
    return apply_filters('cwms1661_can_view_cog', $view_cog );
}
// Allow to select all option even regardless of the selected parent category
function cwms1661_subcategory_options_all(){
    return apply_filters('cwms1661_subcategory_options_all', true );
}
function cwms1661_date_diff( $date_start, $date_end ){
    $date_start = strtotime( $date_start );
    $date_end   = strtotime( $date_end );
    $datediff   = $date_start - $date_end;
    return round($datediff / (60 * 60 * 24));
}
function cwms_trim_chars( $string, $limit = 50 , $ext = '...'){
    if( strlen($string) <= $limit ){
        return $string;
    }
    return substr($string, 0, $limit - 1 ) . $ext;
}
function cwms1661_user_fullname( $user_id = null, $role = null ){
    if( ! $user_id ){
        return null;
    }
    $user_info = get_userdata( $user_id );
    if( !$user_info ){
        return false;
    }
    if( $role && !in_array( $role, $user_info->roles ) ){
        return false;
    }
    if( !empty( $user_info->first_name ) && !empty( $user_info->last_name ) ){
        return $user_info->first_name.' '.$user_info->last_name;
    }
    return apply_filters( 'cwms1661_user_fullname',  $user_info->display_name, $user_id, $role );
}
function cwms1661_user_roles_label( $user ){
    global $wp_roles;
    return array_map( function( $role ) use($wp_roles) {
        return $wp_roles->roles[ $role ]['name'];
    }, $user->roles );
}
// User role permission functions 
function cwms1661_dashboard_roles(){
    $roles = array (
        'cwms_manager'      => __('Manager', 'wpcodigo_wms'), 
        'cwms_encoder'      => __('Encoder', 'wpcodigo_wms'),
        'cwms_purchaser'    => __('Purchaser', 'wpcodigo_wms'),
        'cwms_accounting'   => __('Accounting', 'wpcodigo_wms'),
        'cwms_agent'        => __('Salesman', 'wpcodigo_wms'),
        'cwms_whseman'      => __('Whse. Clerk', 'wpcodigo_wms'),
        'cwms_driver'       => __('Driver', 'wpcodigo_wms'),
        'cwms_customer'     => __('Customer', 'wpcodigo_wms')
    );
    return apply_filters( 'cwms1661_dashboard_roles', $roles );
}
function cwms1661_current_user_roles(){
    if( !is_user_logged_in() ){
        return array();
    }
    return wp_get_current_user()->roles;
}
function is_cwms1661_admin( ){
    if( !is_user_logged_in() ){
        return false;
    }
    $allowed_roles = apply_filters('is_cwms1661_admin_roles', array('administrator') );
    $is_admin      =  array_intersect( $allowed_roles,  cwms1661_current_user_roles() ) ? true : false ;
    return apply_filters( 'is_cwms1661_admin', $is_admin );
}
function can_access_cwms1661_gross_profit( ){
    if( !is_user_logged_in() ){
        return false;
    }
    $allowed_roles = apply_filters('can_access_cwms1661_gross_profit_roles', array('administrator') );
    $is_admin      =  array_intersect( $allowed_roles,  cwms1661_current_user_roles() ) ? true : false ;
    return apply_filters( 'can_access_cwms1661_gross_profit', $is_admin );
}
function cwms1661_clean_url_parameter( $exclude_array = array() ){
    $query_array    = explode( '&', $_SERVER['QUERY_STRING'] );
    $filtered_query = array();
    if( empty( $query_array ) || empty($exclude_array) ){
        return false;
    }
    foreach ($query_array as $value) {
        $keyvalue_pairs = explode( '=', $value );
        if( in_array( $keyvalue_pairs[0], $exclude_array ) ){
            continue;
        }
        $filtered_query[] = $value;
    }
    return implode('&', $filtered_query );
}
function cwms1661_get_template_path( $file_name, $subdir = false, $module = false ){
    $file_slug              = strtolower( preg_replace('/\s+/', '_', trim( str_replace( '.tpl', '', $file_name ) ) ) );
    $file_slug              = preg_replace('/[^A-Za-z0-9_]/', '_', $file_slug );
    $custom_template_path   = get_stylesheet_directory().'/wms/'.$file_name.'.php';
    if( file_exists( $custom_template_path ) ){
        return $custom_template_path;
    }
    $subdir       = $subdir ? $subdir .'/' : '';
    $base         = $module ? 'module' : 'templates' ;
    return apply_filters( "cwms1661_get_template_{$file_slug}", CWMS1661_ABSPATH.$base.'/'.$subdir.$file_name.'.php' );
}
function is_cwms1661_post_exist( $product_name, $post_type ){
    global $wpdb;
    if( ! $product_name  ){
        return false;
    }
    $sql = "SELECT ID FROM {$wpdb->posts} WHERE `post_status` LIKE 'publish' AND `post_type` LIKE %s AND `post_title` = %s LIMIT 1";
    $sql = apply_filters( 'is_cwms1661_product_exist_sql', $wpdb->prepare( $sql, $post_type, stripslashes_deep($product_name) ) );
    return $wpdb->get_var( $sql );
}
function cwms1661_get_post_description( $post_id ){
    global $wpdb;
    if( ! $post_id  ){
        return false;
    }
    $sql = "SELECT `post_content` FROM {$wpdb->posts} WHERE `ID` = %d LIMIT 1";
    $sql = apply_filters( 'cwms1661_get_post_description', $wpdb->prepare( $sql, $post_id ) );
    return $wpdb->get_var( $sql );
}
// Reset post type data
function cwms116_delete_records_by_posttype($post_type){
    global $wpdb;
    $result = $wpdb->query( 
        $wpdb->prepare("
            DELETE posts,pt,pm
            FROM {$wpdb->posts} posts
            LEFT JOIN {$wpdb->term_relationships} pt ON pt.object_id = posts.ID
            LEFT JOIN {$wpdb->postmeta} pm ON pm.post_id = posts.ID
            WHERE posts.post_type = %s
            ", 
            $post_type
        ) 
    );
    return $result!==false;
}
function cwms1661_get_data( $post_id, $metakeys, $title, $description = false ){
    // Remove the title in metakeys
    if (($key = array_search($title, $metakeys)) !== false) {
        unset($metakeys[$key]);
    }
    $data       = [ 'ID' => (int)$post_id, $title => html_entity_decode( get_the_title( (int) $post_id ) ) ];
    if( $description ){
        if (($key = array_search($description, $metakeys)) !== false) {
            unset($metakeys[$key]);
        }
        $data[$description] = cwms1661_get_post_description( $post_id );
    }   
    $meta_data  = get_post_meta( (int)$post_id, null );
    foreach( $metakeys as $metakey ){
        $value = null;
        if( array_key_exists($metakey, $meta_data) ){
            $meta_value = $meta_data[$metakey][0];
            $value = is_array( $meta_value ) ? $meta_value : esc_html( $meta_value ) ;
        }
        $data[ $metakey ] = $value;
    }
    return apply_filters('cwms1661_get_data', $data, $post_id, $metakeys, $title );
}
function cwms1661_get_all_data( $post_type, $metakeys, $title, $terms = null, $page = null, $limit = 12   ){
    global $wpdb;
    $parameter = array( $post_type );
    $sql = "SELECT `ID` as id";
    $sql .= " FROM {$wpdb->posts}";
    $sql .= " WHERE `post_status` LIKE 'publish' AND `post_type` LIKE %s";
    $sql .= " ORDER BY `post_title`";
    if( $page ){
        $offset = ($page - 1) * $limit;
        $sql .= " LIMIT %d OFFSET %d";
        $parameter = array_merge( $parameter, array( $limit, $offset ) );
    }
    $sql     = $wpdb->prepare( $sql, $parameter);
    $results = $wpdb->get_col( apply_filters( 'cwms1661_get_all_data_'.$post_type, $sql, $page, $limit ) );
    if( empty($results) ){
        return false;
    }
    $data = [];
    foreach ($results as $post_id ) {
        $data[] = cwms1661_get_data( $post_id, $metakeys, $title );
    }
    return $data;
}

function cwms1661_duplicate( $post_id, $title, $post_type, $post_status ) {
    // $title   = get_the_title( $post_id );
    $post    = array(
        'post_title'  => $title,
        'post_status' => $post_status,
        'post_type'   => $post_type,
        'post_author' => get_current_user_id()
    );
    $new_post_id = wp_insert_post($post);
    if( is_wp_error( $new_post_id ) ){
        return false;
    }
    // Copy post metadata
    $data = get_post_custom($post_id);
    foreach ( $data as $key => $values) {
      foreach ($values as $value) {
        add_post_meta( $new_post_id, $key, $value );
      }
    }
    return $new_post_id;
}
function cwms1661_is_dashboard(){
    global $post;
    if( !$post ){
        return false;
    }
    if( cwms1661_dashboard_page() != $post->ID ){
        return false;
    }
    return true;
}
function cwms1661_dashboard_page(){
    return apply_filters( 'cwms1661_dashboard_page', get_option('cwms1661_dashboard_page', null ) );
}
function cwms1661_dashboard_home(){
    return get_the_permalink( cwms1661_dashboard_page() );
}
function cwms1661_favicon_url(){
    return apply_filters( 'cwms1661_favicon_url', '' );
}
function cwms1661_get_post_label( $post_type ){
    $post_type_obj = get_post_type_object( $post_type );
    return $post_type_obj->label;
}
function cwms1661_discount_type(){
    $discounts = array(
        'fxd' => _x( 'Fixed', 'Discount Type', 'wpcodigo_wms' ),
        'pct' => _x( 'Percentage', 'Discount Type', 'wpcodigo_wms' )
    );
    return $discounts;
}
function cwms1661_discount_type_label( $disc_key = '' ){
    $disc_key = $disc_key ? $disc_key : 'fxd' ;
    return cwms1661_discount_type()[$disc_key];
}
function cwms1661_product_limit( ){
    return apply_filters( 'cwms1661_product_limit', 30 );
}
function cwms1661_payment_types(){
    $payments = array(
        '_cash'     => __('Cash', 'wpcodigo_wms'),
        '_cheque'   => __('Cheque', 'wpcodigo_wms'),
        '_credit'   => __('Credit', 'wpcodigo_wms'),
    );
    return apply_filters( 'cwms1661_payment_types', $payments );
}
function cwms1661_term_options(){
    $terms = array(
        0       => __('COD', 'wpcodigo_wms'),
        15      => __('15 Days', 'wpcodigo_wms'),
        30      => __('30 Days', 'wpcodigo_wms'),
        60      => __('60 Days', 'wpcodigo_wms'),
        90      => __('90 Days', 'wpcodigo_wms'),
        120     => __('120 Days', 'wpcodigo_wms'),
    );
    return apply_filters( 'cwms1661_term_options', $terms );
}
function cwms1661_payment_validation_status(){
    $payments = array(
        '_received'     => __('Received', 'wpcodigo_wms'),
        '_deposited'    => __('Deposited', 'wpcodigo_wms'),
        '_stale'        => __('Return/Stale', 'wpcodigo_wms'),
        '_cleared'      => __('Cleared', 'wpcodigo_wms'),
    );
    return apply_filters( 'cwms1661_payment_validation_status', $payments );
}
function cwms1661_invoice_payment_statuses(){
    $statuses = array(
        '_unpaid'   => __('Unpaid', 'wpcodigo_wms'),
        '_initial'  => __('Initial', 'wpcodigo_wms'),
        '_paid'     => __('Paid', 'wpcodigo_wms'),
    );
    return apply_filters( 'cwms1661_invoice_payment_statuses', $statuses );
}
function cwms1661_return_remarks(){
    $remarks = array(
      'wrp' => __('Wrong pricing', 'wpcodigo_wms'),
      'wro' => __('Wrong order', 'wpcodigo_wms'),
      'ovo' => __('Over order', 'wpcodigo_wms'),
      'dmg' => __('Damage', 'wpcodigo_wms')
    );
    return apply_filters( 'cwms1661_return_remarks', $remarks );
}
function cwms1661_post_statuses(){
    return array(
        'cwms-for-approval' => array(
                'label'                     => _x( 'For Approval', 'CWMS status', 'wpcodigo_wms' ),
                'public'                    => false,
                'exclude_from_search'       => TRUE,
                'show_in_admin_all_list'    => true,
                'show_in_admin_status_list' => true,
                'label_count'               => _n_noop( 'For Approval <span class="count">(%s)</span>', 'For Approval <span class="count">(%s)</span>', 'wpcodigo_wms' ),
            ),
        'cwms-on-hold' => array(
                'label'                     => _x( 'On hold', 'CWMS status', 'wpcodigo_wms' ),
                'public'                    => false,
                'exclude_from_search'       => false,
                'show_in_admin_all_list'    => true,
                'show_in_admin_status_list' => true,
                'label_count'               => _n_noop( 'On hold <span class="count">(%s)</span>', 'On hold <span class="count">(%s)</span>', 'wpcodigo_wms' ),
            ),
        'cwms-approved' => array(
                'label'                     => _x( 'Approved', 'CWMS status', 'wpcodigo_wms' ),
                'public'                    => false,
                'exclude_from_search'       => TRUE,
                'show_in_admin_all_list'    => true,
                'show_in_admin_status_list' => true,
                'label_count'               => _n_noop( 'Approved <span class="count">(%s)</span>', 'Approved <span class="count">(%s)</span>', 'wpcodigo_wms' ),
            ),
        'cwms-processing' => array(
                'label'                     => _x( 'Processing', 'CWMS status', 'wpcodigo_wms' ),
                'public'                    => false,
                'exclude_from_search'       => false,
                'show_in_admin_all_list'    => true,
                'show_in_admin_status_list' => true,
                'label_count'               => _n_noop( 'Processing <span class="count">(%s)</span>', 'Processing <span class="count">(%s)</span>', 'wpcodigo_wms' ),
            ),
        'cwms-cancelled' => array(
                'label'                     => _x( 'Cancelled', 'CWMS status', 'wpcodigo_wms' ),
                'public'                    => false,
                'exclude_from_search'       => false,
                'show_in_admin_all_list'    => true,
                'show_in_admin_status_list' => true,
                'label_count'               => _n_noop( 'Cancelled <span class="count">(%s)</span>', 'Cancelled <span class="count">(%s)</span>', 'wpcodigo_wms' ),
        ),
        'cwms-reserve' => array(
            'label'                     => _x( 'Reserve', 'CWMS status', 'wpcodigo_wms' ),
            'public'                    => false,
            'exclude_from_search'       => false,
            'show_in_admin_all_list'    => true,
            'show_in_admin_status_list' => true,
            'label_count'               => _n_noop( 'Reserve <span class="count">(%s)</span>', 'Reserve <span class="count">(%s)</span>', 'wpcodigo_wms' ),
        ),
        'cwms-completed' => array(
            'label'                     => _x( 'Completed', 'CWMS status', 'wpcodigo_wms' ),
            'public'                    => false,
            'exclude_from_search'       => false,
            'show_in_admin_all_list'    => true,
            'show_in_admin_status_list' => true,
            'label_count'               => _n_noop( 'Completed <span class="count">(%s)</span>', 'Completed <span class="count">(%s)</span>', 'wpcodigo_wms' ),
        ),
    );
}
function cwms1661_edited_statuses(){
    $status = array( 'cwms-for-approval', 'cwms-on-hold' );
    return apply_filters( 'cwms1661_edited_statuses', $status );
}
function cwms1661_registered_scripts(){
    $scripts = array(
        'cwms1661-jquery-script',
        'cwms1661-papaparse-script',
        'cwms1661-chart-script',
        'cwms1661-bootstrap-script',
        'cwms1661-moment-script',
        'cwms1661-daterangepicker-script',
        'cwms1661-nprogress-script',
        'cwms1661-switchery-script',
        'cwms1661-select2-script',
        'cwms1661-repeater-script',
        'cwms1661-dataTables-script',
        'cwms1661-bootstrap-buttons-script',
        'cwms1661-dataTablesJSZIP-script',
        'cwms1661-dataTablesPDFMAKE-script',
        'cwms1661-dataTablesVFSFont-script',
        'cwms1661-dataTablesButtonsHTML5-script',
        'cwms1661-dataTableChecbox-script',
        'cwms1661-theme-custom-script',
        'cwms1661-theme-datetime-script',
        'cwms1661-report-script',
        'cwms1661-payments-script',
        'cwms1661-print-script',
        'cwms1661-theme-script',
        'cwms1661-ajax-script',
        
    );
    return apply_filters('cwms1661_registered_scripts', $scripts );
}
function cwms1661_registered_styles(){
    $styles = array(
        'cwms1661-bootstrap-style',
        'cwms1661-select2-style',
        'cwms1661-dataTables-style',
        'cwms1661-dataTableCheckbox-style',
        'cwms1661-animate-style',
        'cwms1661-switchery-style',
        'cwms1661-bootstrap-datetimepicker-style',
        'cwms1661-daterangepicker-style',
        'cwms1661-fontawesome-style',
        'cwms1661-nprogress-style',
        'cwms1661-theme-style',
        'cwms1661-style'
    );
    return apply_filters('cwms1661_registered_styles', $styles );
}
function cwms1661_datatable_labels(){
    $labels = array(
        "emptyTable"        => esc_html__("No data available in table", 'wpcdigo_wms'),
        "loadingRecords"    => esc_html__("Please wait while loading records.", 'wpcdigo_wms'),
        "processing"        => esc_html__("Please wait processing request.", 'wpcdigo_wms'),
        "search"            => esc_html__("Search:", 'wpcdigo_wms'),
        "zeroRecords"       => esc_html__("No records to display", 'wpcdigo_wms'),
        "downloadExcelLabel"            => esc_html__("Download Excel", 'wpcdigo_wms'),
        "downloadPDFLabel"              => esc_html__("Download PDF", 'wpcdigo_wms'),
        "downloadRecords"               => esc_html__("Download Records", 'wpcdigo_wms'),
        "downloadSummCollectionLabel"   => esc_html__("Accumulated Collection", 'wpcdigo_wms'),
        "lengthMenu"        => sprintf( esc_html__("Display %s records", 'wpcdigo_wms'), '_MENU_'),
        "info"              => sprintf( esc_html__("Showing %s to %s of %s", 'wpcdigo_wms'), '_START_', '_END_', '_TOTAL_' ),
        "paginate"          => array(
            "previous"  => esc_html__("Previous", 'wpcdigo_wms'),
            "next"      => esc_html__("Next", 'wpcdigo_wms'),
        ),
    );
    return apply_filters('cwms1661_datatable_labels', $labels );
}
function cwms1661_script_translations(){
    $dr_product_limit           = cwms1661_product_limit();
    $general_settings           = cwms1661_get_general_settings();

    $translation = array(
        'ajaxurl'               => admin_url( 'admin-ajax.php' ),
        'dashboardURL'          => cwms1661_dashboard_home(),
        'userRoles'             => cwms1661_dashboard_roles(),
        'subCatAllOption'       => cwms1661_subcategory_options_all(),
        'dataTableTitle'        => $general_settings['_company_name'],
        'dataTableMessageTop'   => $general_settings['_address'],
        'currency'              => apply_filters( 'cwms1661_currency', 'PHP' ),
        'currencyLocal'         => apply_filters( 'cwms1661_currency_local', 'ph-PH' ),
        'editLabel'             => esc_html__('Edit', 'wpcodigo_wms'),
        'deleteLabel'           => esc_html__('Delete', 'wpcodigo_wms'),
        'bulkDeleteLabel'       => esc_html__('Bulk Delete', 'wpcodigo_wms'),
        'tableLabels'           => cwms1661_datatable_labels(),
        'processingLabel'       => esc_html__('Processing request', 'wpcodigo_wms'),
        'noItemSelectedMessage' => esc_html__('Cannot process your request no item selected.', 'wpcodigo_wms'),
        'allItemSelectedMessage' => esc_html__('All products already added to invoice, Are you sure you want to proceed?', 'wpcodigo_wms'),
        'proceedConfirmation'   => esc_html__('Are you sure you want to proceed your request?', 'wpcodigo_wms'),
        'deleteConfirmation'    => esc_html__('Are you sure you want to delete selected item(s)?', 'wpcodigo_wms'),
        'deleteConfirmData'     => esc_html__('Are you sure you want to delete selected item(s)? This will delete automatically to attached transaction even save button is not click.', 'wpcodigo_wms'),
        'errorLoading'          => esc_html__('Error loading result.', 'wpcodigo_wms'),
        'loadingMore'           => esc_html__('Loading more result...', 'wpcodigo_wms'),
        'noResults'             => esc_html__('No results found', 'wpcodigo_wms'),
        'searching'             => esc_html__('Searching', 'wpcodigo_wms'),
        'placeholder'           => esc_html__('Search Option', 'wpcodigo_wms'),
        'noSupplier'            => esc_html__('Supplier is Required, Please add supplier.', 'wpcodigo_wms'),
        'noCustomer'            => esc_html__('Customer is Required, Please add customer.', 'wpcodigo_wms'),
        'purchaseOrderLabel'    => esc_html__('RECEIVING REPORT', 'wpcodigo_wms'),
        'poLabel'               => esc_html__('PO', 'wpcodigo_wms'),
        'drLabel'               => esc_html__('DR', 'wpcodigo_wms'),
        'noInvSelectedMessage'  => esc_html__('Cannot process your request no invoice to bill.', 'wpcodigo_wms'),
        'emptyInvoiceTable'     => esc_html__('Select invoices for payment', 'wpcodigo_wms'),
        'addPaymentInvoice'     => esc_html__('Add to payment invoices', 'wpcodigo_wms'),
        'noPayments'            => esc_html__('Sorry no payments added', 'wpcodigo_wms'),
        'paymentExceeded'       => esc_html__('Amount paid exceeded with the balance amount.', 'wpcodigo_wms'),
        'excDeclaredAmount'     => esc_html__('Paid amount exceeded with the declared total payment amount.', 'wpcodigo_wms'),
        'dateLabel'             => esc_html__('DATE', 'wpcodigo_wms'),
        'dr_limit'              => $dr_product_limit,
        'dr_limit_message'      => sprintf( __( "Exceed the product's limit for invoice. Only %d products are allowed.", 'wpcodigo_wms' ), $dr_product_limit ),
        'invoice_sequence'      => cwms1661_dr_senquence_enable(),
        'passLimit'             => esc_html__('Password must be atleast 6 characters', 'wpcodigo_wms'), 
        'passMatch'             => esc_html__('Password matched', 'wpcodigo_wms'), 
        'passNotMatch'          => esc_html__('Password and confirm password not match', 'wpcodigo_wms'), 
        'passAllowedChars'      => esc_html__('Password must have atleast one alphanumeric and special characters', 'wpcodigo_wms'), 
        'passConfirm'            => esc_html__('Password must be confirm', 'wpcodigo_wms')
    );
    return apply_filters('cwms1661_script_translations', $translation );
}
function cwms1661_permissions(){
	return apply_filters( 'cwms1661_permissions', array() );
}
function cwms1661_dashboard_shortcuts_menu(){
    $shortcuts = [];
    $shortcuts = apply_filters( 'cwms1661_dashboard_shortcuts_menu', $shortcuts );
    ksort($shortcuts);
    return $shortcuts;
}
function cwms1661_dashboard_menus(){

    $report_subs = apply_filters( 'cwms1661_dashboard_report_sub_menu', array() );
    $menus = array(
        'dashboard' => array(
            'id'        => 'dashboard',
            'label'     => esc_html__('Dashboard', 'wpcodigo_wms'),
            'classes'   => 'fa fa-tachometer',
            'subs'      => array()
        ),
        'reports' => array(
            'id'        => 'reports',
            'label'     => esc_html__('Reports', 'wpcodigo_wms'),
            'classes'   => 'fa fa-bar-chart-o',
            'subs'      => $report_subs
        )
    );
    if( empty($report_subs) ){
        unset( $menus['reports'] );
    }

    $menus = apply_filters( 'cwms1661_dashboard_menus', $menus );
    ksort($menus);
    return $menus;
}
function cwms1661_remove_assign_product( $post_id, $product_id ){
    global $wpdb;
    $table      = $wpdb->prefix.CWMS1661_TB_PRODUCTS;
    return $wpdb->delete( $table, array( 'ID' => $product_id, 'trans_id' => $post_id ), array( '%d', '%d' ) );
}
function cwms1661_get_assign_product( $post_id ){
    global $wpdb;
    $table      = $wpdb->prefix.CWMS1661_TB_PRODUCTS;
    $sql = "SELECT * FROM {$table} WHERE `trans_id` = %d";
    return $wpdb->get_results( $wpdb->prepare( $sql, $post_id ), ARRAY_A );
}
function cwms1661_assign_product( $post_id, $data, $type ){
    global $wpdb;
    $table      = $wpdb->prefix.CWMS1661_TB_PRODUCTS;
    $product_id = (int)$data['product_id'];
    $found_prod = has_cwms1661_po_product( $post_id, $product_id );
    $data   = array(
        'product_id'        => $product_id, 
        'upc'               => $data['upc'], 
        'name'              => $data['name'], 
        'qty_ordered'       => $data['qty_ordered'],
        'qty_delivered'     => $data['qty_delivered'],
        'unit'              => $data['unit'],
        'cost_price'        => $data['cost_price'],
        'retail_price'      => $data['retail_price'],
        'discount'          => $data['discount'],
        'discount_amount'   => $data['discount_amount'],
        'trans_id'          => $post_id,
        'trans_type'        => $type
    );
    $format  = array( '%d', '%s', '%s', '%f', '%f', '%s', '%f', '%f', '%s', '%f', '%d', '%s' );

    if( ! $found_prod ){
        // Insert new product
        $inserted_row   = $wpdb->insert( $table, $data, $format );
        if( !$inserted_row ){
            return false;
        }
        return $wpdb->insert_id;
    }
    return $wpdb->update($table, $data, array( 'ID' => $found_prod ), $format, array( '%d' ) );
}
function cwms1661_calculate_po_discount( $product ){
    $discount_data      = array_key_exists( 'discount', $product ) ? trim($product['discount']) : '';
    $retail_price       = array_key_exists( 'cost_price', $product ) ? $product['cost_price'] : 0;
    $qty                = array_key_exists( 'qty_ordered', $product ) ? $product['qty_ordered'] : 0;
    $qty                = array_key_exists( 'qty_delivered', $product ) && $product['qty_delivered'] > 0 ? $product['qty_delivered'] : $qty;
    $discounts          = array_filter( explode(",", $discount_data ) );
    $cost               = floatval( $qty ) * floatval( $retail_price );
    $discount_amount    = 0;
    if( !empty($discounts) ){
        $deducted_cost = $cost;
        foreach ($discounts as $discount ) {
            if( str_contains($discount, '%') ){
                $discount_amount += $deducted_cost * ( floatval( $discount ) / 100 );
            }else{
                $discount_amount += floatval( $discount );
            }
            $deducted_cost  = $deducted_cost - $discount_amount;
        }
    }
    return $discount_amount ;
}

function cwms1661_calculate_item_cost( $qty, $cost, $discounts ){
    $discAmount          = 0;
    $firstDiscType        = '';
    $lastDiscType        = '';
    $hasPCTDiscType      = false;
    $exclFixdDiscount    = 0;

    if( trim($discounts) ){
        $discounts       = array_filter( explode(",", $discounts ) );
        $costPrice       = floatval($cost);
        foreach( $discounts as $index => $discValue ){

            if( !trim( $discValue ) ){
                continue;
            }
            $isPecentage =  str_contains($discValue, '%' ); 

            // Check for the discounting series format
            $currDiscType = $isPecentage ? 'pct' : 'fxd';
            if( $index  == 0 ){
                $firstDiscType = $currDiscType;
            }
            // Check if Percentage discount is already applied to be able to exclude the Fixed discount from discount
            if( ! $hasPCTDiscType && $currDiscType == 'pct' ){
                $hasPCTDiscType = true;
            }
            /*
            * Sample sequence for reference
            1:  5%, 10, 5%      = false
            2:  10, 5%, 10, 10  = false
            3:  10, 10, 5%, 5%  = true
            4:  5%, 5%, 10, 10  = true
            */
            // Check the 3rd Loop
            if( $index == 2 && ( $firstDiscType != $lastDiscType && $lastDiscType != $currDiscType ) ){
                // Check the third discount type
                // if the 1st and 2nd is not match - the 3rd must be the same discount type
                // if not the same alert popup is will show and stop the process
                $lastDiscType = $currDiscType;
                break;
            }
            // Check the 4th Loop
            if( $index > 2 && $lastDiscType != $currDiscType ){
                $lastDiscType = $currDiscType;
                break;
            }

            if( $hasPCTDiscType && $currDiscType == 'fxd' ){
                $exclFixdDiscount += floatval($discValue);
                $lastDiscType = $currDiscType;
                continue;
            }

            // keep checking the last dicsount type
            $lastDiscType = $currDiscType;

            if( $isPecentage ){
                $discAmount += $costPrice * ( floatval($discValue) / 100 );
                $costPrice  = $costPrice - ( $costPrice * ( floatval($discValue) / 100 ) );
                
            }else{
                $discAmount += floatval($discValue);
                $costPrice  = $costPrice - floatval($discValue);
            }
        };
        $discCostPrice = $cost - $discAmount;
        return ( $discCostPrice * $qty ) - $exclFixdDiscount;
    }

    return $qty * floatval($cost);
}
function cwms1661_calculate_discount( $product, $qty_key = 'qty_ordered' ){
    $discount_data      = array_key_exists( 'discount', $product ) ? trim($product['discount']) : '';
    $retail_price       = array_key_exists( 'retail_price', $product ) ? $product['retail_price'] : 0;
    $qty                = array_key_exists( $qty_key, $product ) ? $product[$qty_key] : 0;
    $discounts          = array_filter( explode(",", $discount_data ) );
    $cost               = floatval( $qty ) * floatval( $retail_price );
    $discount_amount    = 0;
    if( !empty($discounts) ){
        $deducted_cost = $cost;
        foreach ($discounts as $discount ) {
            if( str_contains($discount, '%') ){
                $discount_amount += $deducted_cost * ( floatval( $discount ) / 100 );
            }else{
                $discount_amount += floatval( $discount );
            }
            $deducted_cost  = $deducted_cost - $discount_amount;
        }
    }
    return $discount_amount ;
}
function cwms1661_remove_zero_product( $products, $product_key = 'qty_delivered'){
    return array_filter( array_map( function( $product ) use($product_key) {
        if( floatval( $product[$product_key] ) <= 0 ){
            return null;
        }
        return $product;
    }, $products ) );
}
function cwms1661_display_address_html( $data ){
    $address = '';
    if( !empty( $data['_address_1'] ) || !empty( $data['_address_2'] ) ){
        $address .= $data['_address_1'].' '.$data['_address_2'].'</br>';
    }
    if( !empty( $data['_city'] ) || !empty( $data['_state'] ) ){
        $address .= $data['_city'].' '.$data['_state'].'</br>';
    }
    if( !empty( $data['_postcode'] ) || !empty( $data['_country'] ) ){
        $address .= $data['_postcode'].' '.$data['_country'];
    }
    return $address;
}
function cwms1661_registered_dashboard_pages(){
    $pages              = [];
    $pages['settings']  = esc_html__('Settings', 'wpcodigo_wms');
    foreach ( cwms1661_dashboard_menus() as $menu ) {
        $pages = array_merge($pages, $menu['subs']);
    }
    return apply_filters('cwms1661_registered_dashboard_pages',  $pages );
}
function cwms1661_get_dashboard_title( $page = '' ){
    $pages = cwms1661_registered_dashboard_pages();
    if( array_key_exists( $page, $pages ) ){
        return $pages[$page];
    }
    return get_the_title();
}
function is_cwms1661_post( $post_id, $post_type, $post_status = array() ){
    global $wpdb;

    if( empty( $post_status ) ){
        $post_status = array_keys( cwms1661_post_statuses() );
    }

    $sql = "SELECT `ID` FROM {$wpdb->posts} WHERE `ID` = %d AND `post_type` LIKE %s AND `post_status` IN ('" . implode("','", $post_status) ."') LIMIT 1";
    $sql = $wpdb->prepare( $sql, $post_id, $post_type );
    return $wpdb->get_var( $sql );
}
function cwms1661_get_status_count( $status, $post_type ){
    global $wpdb;
    return $wpdb->get_var ( $wpdb->prepare( "SELECT count(*) FROM {$wpdb->posts} WHERE `post_status` LIKE %s AND `post_type` LIKE %s", $status, $post_type ) );
}
function cwms1661_format_number( $value, $decimal = 2, $separator = ''  ){
    return number_format( floatval( $value ), $decimal, '.', $separator);
}
function to_cwms1661_currency( $value  ){
    return cwms1661_format_number( $value, 2, ',' );
}
function cwms1661_get_post_count_by_date( $post_type, $date  ){
    global $wpdb;
    $post_statuses      = array_keys( cwms1661_post_statuses() );
    return $wpdb->get_var ( $wpdb->prepare( "SELECT count(*) FROM {$wpdb->posts} WHERE `post_type` LIKE %s AND `post_status` IN ('" . implode("','", $post_statuses) ."') AND CAST( `post_date` as date) LIKE %s", $post_type, $date ) );
}
function cwms1661_posts_count_date( $post_type, $dateStart, $dateEnd ){
    global $wpdb;
    $post_statuses      = array_keys( cwms1661_post_statuses() );
    $sql = " SELECT count(*) FROM {$wpdb->posts} as tblposts";
    $sql .= " WHERE tblposts.post_type LIKE %s AND `post_status` IN ('" . implode("','", $post_statuses) ."') AND CAST( tblposts.post_date as date) between %s and %s";
    $sql = $wpdb->prepare( $sql, $post_type, $dateStart, $dateEnd );
    return cwms1661_format_number( $wpdb->get_var( $sql ), false, ','  );
}
function cwms1661_post_count( $post_type ){
    global $wpdb;
    $post_statuses      = array_keys( cwms1661_post_statuses() );
    $post_statuses[]    = 'publish';
    $sql = " SELECT count(*) FROM {$wpdb->posts} as tblposts";
    $sql .= " WHERE tblposts.post_type LIKE %s AND `post_status` IN ('" . implode("','", $post_statuses) ."')";
    $sql = $wpdb->prepare( $sql, $post_type );
    return cwms1661_format_number( $wpdb->get_var( $sql ), false, ','  );
}