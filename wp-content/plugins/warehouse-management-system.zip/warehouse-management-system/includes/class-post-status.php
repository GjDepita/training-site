<?php
/**
 * Post Types
 *
 * Registers post types and taxonomies.
 */

defined( 'ABSPATH' ) || exit;

/**
 * Post types Class.
 */
class CWMS1661_Post_Status {

    public static function register_post_statuses() {
		foreach ( cwms1661_post_statuses() as $key => $value) {
			register_post_status( $key, $value );
		}
	}

}