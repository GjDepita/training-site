<?php
defined( 'ABSPATH' ) || exit;

/**
 * Admin Pages
 */
class CWMS1661_Admin_Pages {

    public static function init(){
        add_action( 'admin_menu', array(__CLASS__, 'admin_dashboard') );
        add_action( 'admin_init', array(__CLASS__, 'register_settings' ) );
        add_action( 'admin_notices', array(__CLASS__, 'dashboard_notfound_error' ) );
        add_filter( 'display_post_states', array(__CLASS__, 'dashboard_post_states' ), 10, 2 );
        
        // Dashboard - Report Page template
        add_action( 'cwms_admin_dashboard_navigation', array(__CLASS__, 'dashboard_nav_menu' ), 1 );
        add_action( 'cwms_admin_dashboard_body', array(__CLASS__, 'general_settings' ), 1 );
        add_action( 'cwms_admin_dashboard_body', array(__CLASS__, 'license' ), 1 );
    }

    public static function admin_dashboard() {
        add_menu_page(
            __( 'WMS', 'wpcodigo_wms' ),
            __( 'WMS', 'wpcodigo_wms' ),
            'manage_options',
            'cwms-dashboard',
            array(__CLASS__, 'dashboard_template'),
            'dashicons-analytics',
            2
        );
    }

    public static function register_settings(){
        register_setting( 'cwms1661_settings_group', 'cwms1661_dashboard_page' );
    }

    public static function dashboard_notfound_error(){
        $screen    = get_current_screen();
        if( cwms1661_dashboard_page() ){
            return false;
        }
        if( 'toplevel_page_cwms-dashboard' == $screen->id ){
            return false;
        }
        $class          = 'notice notice-error';
        $message        = __( 'Oops, you forgot to setup a Warehouase Management System Dashboard page.', 'wpcodigo_wms' );
        $setting_url    = admin_url('admin.php?page=cwms-dashboard');
        $setup_label    = __( 'Setup', 'wpcodigo_wms' );

        printf( '<div class="%1$s" style="padding: 12px;"><p style="font-size: 1.3em;">%2$s</p> <a href="%3$s" class="button button-secondary button-sm">%4$s</a></div>', esc_attr( $class ), esc_html( $message ), esc_url_raw( $setting_url ), esc_html( $setup_label ) );
    }

    public static function dashboard_post_states( $states, $post ){
        if( $post->ID == cwms1661_dashboard_page() ){
            $states[ 'cwms1661_dashboard' ] = esc_html__( 'WMS Dashboard', 'wpcodigo_wms' );
        }
        return $states;
    }
    
    public static function dashboard_template(){
        include_once CWMS1661_ABSPATH . 'templates/admin/dashboard.php';
    }
    public static function dashboard_nav_menu(){
        $is_active = isset( $_GET['cwmspage'] ) ? $_GET['cwmspage'] : false ;
        ?>
        <a class="nav-tab <?php echo !$is_active ? 'nav-tab-active' : '' ;  ?>" href="<?php echo admin_url('admin.php?page=cwms-dashboard'); ?>" ><?php _e('General Settings','wpcodigo_wms'); ?></a>
        <a class="nav-tab <?php echo $is_active && $is_active == 'license' ? 'nav-tab-active' : '' ;  ?>" href="<?php echo admin_url('admin.php?page=cwms-dashboard&cwmspage=license'); ?>" ><?php _e('License','wpcodigo_wms'); ?></a>
        <?php
    }
    public static function general_settings(){
        if( isset( $_GET['cwmspage'] )  ){
            return false;
        }
        include_once CWMS1661_ABSPATH . 'templates/admin/general-settings.php';
    }
    public static function license(){
        if( !isset( $_GET['cwmspage'] ) || $_GET['cwmspage'] != 'license' ){
            return false;
        }
        include_once CWMS1661_ABSPATH . 'templates/admin/license.php';
    }
}