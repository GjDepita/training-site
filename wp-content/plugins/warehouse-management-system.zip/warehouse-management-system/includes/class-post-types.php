<?php
/**
 * Post Types
 *
 * Registers post types and taxonomies.
 */

defined( 'ABSPATH' ) || exit;

/**
 * Post types Class.
 */
class CWMS1661_Post_Types {

    public static function register_post_types(){
        if ( post_type_exists( CWMS1661_PRODUCT_POST_TYPE ) ) {
			return;
		}
        $supports   = apply_filters( 'cwms1661_post_type_support', array( 'title' ) );
        $debug      = apply_filters( 'cwms1661_post_type_debug', false );
        // Register Custom Post Type
        $product_labels = array(
            'name'                  => _x( 'Products', 'Post Type General Name', 'wpcodigo_wms' ),
            'singular_name'         => _x( 'Product', 'Post Type Singular Name', 'wpcodigo_wms' ),
            'menu_name'             => __( 'Products', 'wpcodigo_wms' ),
            'name_admin_bar'        => __( 'Product', 'wpcodigo_wms' ),
            'archives'              => __( 'Product Archives', 'wpcodigo_wms' ),
            'attributes'            => __( 'Product Attributes', 'wpcodigo_wms' ),
            'parent_item_colon'     => __( 'Parent Product:', 'wpcodigo_wms' ),
            'all_items'             => __( 'All products', 'wpcodigo_wms' ),
            'add_new_item'          => __( 'Add New Product', 'wpcodigo_wms' ),
            'add_new'               => __( 'Add New', 'wpcodigo_wms' ),
            'new_item'              => __( 'New Product', 'wpcodigo_wms' ),
            'edit_item'             => __( 'Edit Product', 'wpcodigo_wms' ),
            'update_item'           => __( 'Update Product', 'wpcodigo_wms' ),
            'view_item'             => __( 'View Product', 'wpcodigo_wms' ),
            'view_items'            => __( 'View Product', 'wpcodigo_wms' ),
            'search_items'          => __( 'Search Product', 'wpcodigo_wms' ),
            'not_found'             => __( 'Not found', 'wpcodigo_wms' ),
            'not_found_in_trash'    => __( 'Not found in Trash', 'wpcodigo_wms' ),
            'featured_image'        => __( 'Featured Image', 'wpcodigo_wms' ),
            'set_featured_image'    => __( 'Set featured image', 'wpcodigo_wms' ),
            'remove_featured_image' => __( 'Remove featured image', 'wpcodigo_wms' ),
            'use_featured_image'    => __( 'Use as featured image', 'wpcodigo_wms' ),
            'insert_into_item'      => __( 'Insert into product', 'wpcodigo_wms' ),
            'uploaded_to_this_item' => __( 'Uploaded to this product', 'wpcodigo_wms' ),
            'items_list'            => __( 'Products list', 'wpcodigo_wms' ),
            'items_list_navigation' => __( 'Products list navigation', 'wpcodigo_wms' ),
            'filter_items_list'     => __( 'Filter products list', 'wpcodigo_wms' ),
        );
        $product_args = array(
            'label'                 => __( 'Product', 'wpcodigo_wms' ),
            'description'           => __( 'Warehouse products', 'wpcodigo_wms' ),
            'labels'                => $product_labels,
            'supports'              => $supports,
            'taxonomies'            => array(),
            'hierarchical'          => false,
            'public'                => false,
            'show_ui'               => $debug,
            'show_in_menu'          => $debug,
            'menu_position'         => 5,
            'show_in_admin_bar'     => $debug,
            'show_in_nav_menus'     => $debug,
            'rewrite'               => false,
            'can_export'            => true,
            'has_archive'           => false,
            'exclude_from_search'   => true,
            'publicly_queryable'    => false,
            'capability_type'       => 'post',
        );
        register_post_type( CWMS1661_PRODUCT_POST_TYPE, apply_filters( 'cwms_register_post_type_product', $product_args ) );
        
        // $product_args['rewrite']       = array( 'slug' => 'product_category' );
        // $product_args['hierarchical']  = true;
        // register_taxonomy( CWMS1661_PRODUCT_TAXONOMY, array( CWMS1661_PRODUCT_POST_TYPE ), $product_args );

        // Supplier post type
        $supplier_labels = array(
            'name'                  => _x( 'Suppliers', 'Post Type General Name', 'wpcodigo_wms' ),
            'singular_name'         => _x( 'Supplier', 'Post Type Singular Name', 'wpcodigo_wms' ),
            'menu_name'             => __( 'Suppliers', 'wpcodigo_wms' ),
            'name_admin_bar'        => __( 'Supplier', 'wpcodigo_wms' ),
            'archives'              => __( 'Supplier Archives', 'wpcodigo_wms' ),
            'attributes'            => __( 'Supplier Attributes', 'wpcodigo_wms' ),
            'parent_item_colon'     => __( 'Parent Supplier:', 'wpcodigo_wms' ),
            'all_items'             => __( 'All Suppliers', 'wpcodigo_wms' ),
            'add_new_item'          => __( 'Add New Supplier', 'wpcodigo_wms' ),
            'add_new'               => __( 'Add New', 'wpcodigo_wms' ),
            'new_item'              => __( 'New Supplier', 'wpcodigo_wms' ),
            'edit_item'             => __( 'Edit Supplier', 'wpcodigo_wms' ),
            'update_item'           => __( 'Update Supplier', 'wpcodigo_wms' ),
            'view_item'             => __( 'View Supplier', 'wpcodigo_wms' ),
            'view_items'            => __( 'View Supplier', 'wpcodigo_wms' ),
            'search_items'          => __( 'Search Supplier', 'wpcodigo_wms' ),
            'not_found'             => __( 'Not found', 'wpcodigo_wms' ),
            'not_found_in_trash'    => __( 'Not found in Trash', 'wpcodigo_wms' ),
            'featured_image'        => __( 'Featured Image', 'wpcodigo_wms' ),
            'set_featured_image'    => __( 'Set featured image', 'wpcodigo_wms' ),
            'remove_featured_image' => __( 'Remove featured image', 'wpcodigo_wms' ),
            'use_featured_image'    => __( 'Use as featured image', 'wpcodigo_wms' ),
            'insert_into_item'      => __( 'Insert into Supplier', 'wpcodigo_wms' ),
            'uploaded_to_this_item' => __( 'Uploaded to this Supplier', 'wpcodigo_wms' ),
            'items_list'            => __( 'Suppliers list', 'wpcodigo_wms' ),
            'items_list_navigation' => __( 'Suppliers list navigation', 'wpcodigo_wms' ),
            'filter_items_list'     => __( 'Filter Suppliers list', 'wpcodigo_wms' ),
        );
        $supplier_args = array(
            'label'                 => __( 'Supplier', 'wpcodigo_wms' ),
            'description'           => __( 'Product Suppliers', 'wpcodigo_wms' ),
            'labels'                => $supplier_labels,
            'supports'              => $supports,
            'taxonomies'            => array(),
            'hierarchical'          => false,
            'public'                => false,
            'show_ui'               => $debug,
            'show_in_menu'          => $debug,
            'menu_position'         => 5,
            'show_in_admin_bar'     => $debug,
            'show_in_nav_menus'     => $debug,
            'rewrite'               => false,
            'can_export'            => true,
            'has_archive'           => false,
            'exclude_from_search'   => true,
            'publicly_queryable'    => false,
            'capability_type'       => 'post',
        );
        register_post_type( CWMS1661_SUPPLIER_POST_TYPE, apply_filters( 'cwms_register_post_type_supplier', $supplier_args ) );

        // Orders post type
        $order_labels = array(
            'name'                  => _x( 'Orders', 'Post Type General Name', 'wpcodigo_wms' ),
            'singular_name'         => _x( 'Order', 'Post Type Singular Name', 'wpcodigo_wms' ),
            'menu_name'             => __( 'Orders', 'wpcodigo_wms' ),
            'name_admin_bar'        => __( 'Order', 'wpcodigo_wms' ),
            'archives'              => __( 'Order Archives', 'wpcodigo_wms' ),
            'attributes'            => __( 'Order Attributes', 'wpcodigo_wms' ),
            'parent_item_colon'     => __( 'Parent Order:', 'wpcodigo_wms' ),
            'all_items'             => __( 'All Orders', 'wpcodigo_wms' ),
            'add_new_item'          => __( 'Add New Order', 'wpcodigo_wms' ),
            'add_new'               => __( 'Add New', 'wpcodigo_wms' ),
            'new_item'              => __( 'New Order', 'wpcodigo_wms' ),
            'edit_item'             => __( 'Edit Order', 'wpcodigo_wms' ),
            'update_item'           => __( 'Update Order', 'wpcodigo_wms' ),
            'view_item'             => __( 'View Order', 'wpcodigo_wms' ),
            'view_items'            => __( 'View Order', 'wpcodigo_wms' ),
            'search_items'          => __( 'Search Order', 'wpcodigo_wms' ),
            'not_found'             => __( 'Not found', 'wpcodigo_wms' ),
            'not_found_in_trash'    => __( 'Not found in Trash', 'wpcodigo_wms' ),
            'featured_image'        => __( 'Featured Image', 'wpcodigo_wms' ),
            'set_featured_image'    => __( 'Set featured image', 'wpcodigo_wms' ),
            'remove_featured_image' => __( 'Remove featured image', 'wpcodigo_wms' ),
            'use_featured_image'    => __( 'Use as featured image', 'wpcodigo_wms' ),
            'insert_into_item'      => __( 'Insert into order', 'wpcodigo_wms' ),
            'uploaded_to_this_item' => __( 'Uploaded to this order', 'wpcodigo_wms' ),
            'items_list'            => __( 'Orders list', 'wpcodigo_wms' ),
            'items_list_navigation' => __( 'Order list navigation', 'wpcodigo_wms' ),
            'filter_items_list'     => __( 'Filter order list', 'wpcodigo_wms' ),
        );
        $order_args = array(
            'label'                 => __( 'Order', 'wpcodigo_wms' ),
            'description'           => __( 'Warehouse orders', 'wpcodigo_wms' ),
            'labels'                => $order_labels,
            'supports'              => $supports,
            'taxonomies'            => array( ),
            'hierarchical'          => false,
            'public'                => false,
            'show_ui'               => $debug,
            'show_in_menu'          => $debug,
            'menu_position'         => 5,
            'show_in_admin_bar'     => $debug,
            'show_in_nav_menus'     => $debug,
            'rewrite'               => false,
            'can_export'            => true,
            'has_archive'           => false,
            'exclude_from_search'   => true,
            'publicly_queryable'    => false,
            'capability_type'       => 'post',
        );
        register_post_type( 'cwms_order', apply_filters('cwms_registerd_post_type_order', $order_args ) );
    }
    public static function register_taxonomy(){
        // Register Custom Taxonomy
        $debug      = apply_filters( 'cwms1661_post_type_debug', false );
        $labels = array(
            'name'                       => _x( 'Categories', 'Category General Name', 'wpcodigo_wms' ),
            'singular_name'              => _x( 'Category', 'Category Singular Name', 'wpcodigo_wms' ),
            'menu_name'                  => __( 'Category', 'wpcodigo_wms' ),
            'all_items'                  => __( 'All Items', 'wpcodigo_wms' ),
            'parent_item'                => __( 'Parent Item', 'wpcodigo_wms' ),
            'parent_item_colon'          => __( 'Parent Item:', 'wpcodigo_wms' ),
            'new_item_name'              => __( 'New Item Name', 'wpcodigo_wms' ),
            'add_new_item'               => __( 'Add New Item', 'wpcodigo_wms' ),
            'edit_item'                  => __( 'Edit Item', 'wpcodigo_wms' ),
            'update_item'                => __( 'Update Item', 'wpcodigo_wms' ),
            'view_item'                  => __( 'View Item', 'wpcodigo_wms' ),
            'separate_items_with_commas' => __( 'Separate items with commas', 'wpcodigo_wms' ),
            'add_or_remove_items'        => __( 'Add or remove items', 'wpcodigo_wms' ),
            'choose_from_most_used'      => __( 'Choose from the most used', 'wpcodigo_wms' ),
            'popular_items'              => __( 'Popular Items', 'wpcodigo_wms' ),
            'search_items'               => __( 'Search Items', 'wpcodigo_wms' ),
            'not_found'                  => __( 'Not Found', 'wpcodigo_wms' ),
            'no_terms'                   => __( 'No items', 'wpcodigo_wms' ),
            'items_list'                 => __( 'Items list', 'wpcodigo_wms' ),
            'items_list_navigation'      => __( 'Items list navigation', 'wpcodigo_wms' ),
        );
        $args = array(
            'labels'                     => $labels,
            'hierarchical'               => true,
            'public'                     => $debug,
            'show_ui'                    => $debug,
            'show_admin_column'          => $debug,
            'show_in_nav_menus'          => $debug,
        );
        register_taxonomy( CWMS1661_PRODUCT_TAXONOMY, array( CWMS1661_PRODUCT_POST_TYPE ), $args );
    }
}