<?php
defined( 'ABSPATH' ) || exit;

class CWMS_DB{
    public static function create() {
		self::product_history();
        self::invoice_products();
        self::payments();
        self::payment_info();
        self::payment_history();
        self::credit_history();
        self::price_history();
        self::rtv_items();
        
	}
    public static function product_history(){
        // WP Globals
        global $table_prefix, $wpdb;

        // Customer Table
        $tableName = $table_prefix . CWMS1661_TBL_PRODUCT_HISTORY;
        $charset_collate     = $wpdb->get_charset_collate();
        // Create Customer Table if not exist
        if( $wpdb->get_var( "show tables like '$tableName'" ) != $tableName ) {

            // Query - Create Table
            $sql = "CREATE TABLE `$tableName` (";
            $sql .= " `ID` BIGINT(20) NOT NULL auto_increment, ";
            $sql .= " `trans_id` BIGINT(20) NOT NULL, ";
            $sql .= " `trans_number` VARCHAR(60) NOT NULL, ";
            $sql .= " `post_type` VARCHAR(60) NOT NULL, ";
            $sql .= " `qty_current` DECIMAL(12, 2) NOT NULL, ";
            $sql .= " `qty_added` DECIMAL(12, 2) NOT NULL, ";
            $sql .= " `unit` VARCHAR(12) NOT NULL, ";
            $sql .= " `product_id` BIGINT(20) NOT NULL, ";
            $sql .= " `created_date` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP, ";
            $sql .= " `created_by` VARCHAR(120) NOT NULL, ";
            $sql .= " `remarks` VARCHAR(260) NOT NULL, ";
            $sql .= " PRIMARY KEY (`ID`)";
            $sql .= ") $charset_collate;";

            // Include Upgrade Script
            require_once( ABSPATH . '/wp-admin/includes/upgrade.php' );
        
            // Create Table
            dbDelta( $sql );
        }
    }

    // Invoice products
    public static function invoice_products(){
        // WP Globals
        global $table_prefix, $wpdb;

        // Customer Table
        $tableName = $table_prefix . CWMS1661_TB_PRODUCTS;
        $charset_collate     = $wpdb->get_charset_collate();
        // Create Customer Table if not exist
        if( $wpdb->get_var( "show tables like '$tableName'" ) != $tableName ) {

            // Query - Create Table
            $sql = "CREATE TABLE `$tableName` (";
            $sql .= " `ID` BIGINT(20) NOT NULL auto_increment, ";
            $sql .= " `product_id` BIGINT(20) NOT NULL, ";
            $sql .= " `upc` VARCHAR(60) NOT NULL, ";
            $sql .= " `name` VARCHAR(60) NOT NULL, ";
            $sql .= " `qty_ordered` DECIMAL(12, 2) NOT NULL, ";
            $sql .= " `qty_delivered` DECIMAL(12, 2) NOT NULL, ";
            $sql .= " `unit` VARCHAR(12) NOT NULL, ";
            $sql .= " `cost_price` DECIMAL(12, 2) NOT NULL, ";
            $sql .= " `retail_price` DECIMAL(12, 2) NOT NULL, ";
            $sql .= " `discount` VARCHAR(60) NOT NULL, ";
            $sql .= " `discount_amount` DECIMAL(12, 2) NOT NULL, ";
            $sql .= " `trans_id` BIGINT(20) NOT NULL, ";
            $sql .= " `trans_type` VARCHAR(60) NOT NULL, ";
            $sql .= " PRIMARY KEY (`ID`)";
            $sql .= ") $charset_collate;";

            // Include Upgrade Script
            require_once( ABSPATH . '/wp-admin/includes/upgrade.php' );
        
            // Create Table
            dbDelta( $sql );

        }
    }

    public static function payments(){
        // WP Globals
        global $table_prefix, $wpdb;

        // Customer Table
        $tableName = $table_prefix . CWMS1661_TBL_PAYMENTS;
        $charset_collate     = $wpdb->get_charset_collate();
        // Create Customer Table if not exist
        if( $wpdb->get_var( "show tables like '$tableName'" ) != $tableName ) {

            // Query - Create Table
            $sql = "CREATE TABLE `$tableName` (";
            $sql .= " `ID` BIGINT(20) NOT NULL auto_increment, ";
            $sql .= " `payment_key` VARCHAR(120) NOT NULL, ";
            $sql .= " `invoice_id` BIGINT(20) NOT NULL, ";
            $sql .= " `amount_paid` DECIMAL(16, 2) NOT NULL, ";
            $sql .= " `adjustment` DECIMAL(16, 2) NOT NULL, ";
            $sql .= " `status` TINYINT(1) NOT NULL DEFAULT 1, ";
            $sql .= " PRIMARY KEY (`ID`)";
            $sql .= ") $charset_collate;";
            // Include Upgrade Script
            require_once( ABSPATH . '/wp-admin/includes/upgrade.php' );
            // Create Table
            dbDelta( $sql );
        }
    }

    public static function payment_info(){
        // WP Globals
        global $table_prefix, $wpdb;

        // Customer Table
        $tableName = $table_prefix . CWMS1661_TBL_PAYMENT_INFO;
        $charset_collate     = $wpdb->get_charset_collate();
        // Create Customer Table if not exist
        if( $wpdb->get_var( "show tables like '$tableName'" ) != $tableName ) {

            // Query - Create Table
            $sql = "CREATE TABLE `$tableName` (";
            $sql .= " `ID` BIGINT(20) NOT NULL auto_increment, ";
            $sql .= " `receipt_number` VARCHAR(120) NOT NULL, ";
            $sql .= " `payment_key` VARCHAR(120) NOT NULL, ";
            $sql .= " `created_date` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP, ";
            $sql .= " `created_by` VARCHAR(60) NOT NULL, ";
            $sql .= " `collected_date` DATE NOT NULL, ";
            $sql .= " `agent_id` BIGINT(20) NOT NULL, ";
            $sql .= " `customer_id` BIGINT(20) NOT NULL, ";
            $sql .= " `paid_by` VARCHAR(60) NOT NULL, ";
            $sql .= " `payment_type` VARCHAR(60) NOT NULL, ";
            $sql .= " `amount` DECIMAL(16, 2) NOT NULL, ";
            $sql .= " `cheque_number` VARCHAR(60) NOT NULL, ";
            $sql .= " `cheque_date` DATE NULL, ";
            $sql .= " `cheque_bank` VARCHAR(120) NOT NULL, ";
            $sql .= " `remarks` VARCHAR(255) NOT NULL, ";
            $sql .= " `status` VARCHAR(60) NOT NULL, ";
            $sql .= " `assigned` TINYINT(1) NOT NULL DEFAULT 1,";
            $sql .= " PRIMARY KEY (`ID`)";
            $sql .= ") $charset_collate;";

            // Include Upgrade Script
            require_once( ABSPATH . '/wp-admin/includes/upgrade.php' );
        
            // Create Table
            dbDelta( $sql );

        }
    }

    public static function payment_history(){
        // WP Globals
        global $table_prefix, $wpdb;

        // Customer Table
        $tableName = $table_prefix . CWMS1661_TBL_PAYMENT_HISTORY;
        $charset_collate     = $wpdb->get_charset_collate();
        // Create Customer Table if not exist
        if( $wpdb->get_var( "show tables like '$tableName'" ) != $tableName ) {

            // Query - Create Table
            $sql = "CREATE TABLE `$tableName` (";
            $sql .= " `ID` BIGINT(20) NOT NULL auto_increment, ";
            $sql .= " `payment_id` BIGINT(20) NOT NULL, ";
            $sql .= " `updated_date` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP, ";
            $sql .= " `updated_by` VARCHAR(60) NOT NULL, ";
            $sql .= " `remarks` VARCHAR(255) NOT NULL, ";
            $sql .= " PRIMARY KEY (`ID`)";
            $sql .= ") $charset_collate;";

            // Include Upgrade Script
            require_once( ABSPATH . '/wp-admin/includes/upgrade.php' );
        
            // Create Table
            dbDelta( $sql );

        }
    }
    public static function credit_history(){
        // WP Globals
        global $table_prefix, $wpdb;

        // Customer Table
        $tableName = $table_prefix . CWMS1661_TBL_CREDIT_HISTORY;
        $charset_collate     = $wpdb->get_charset_collate();
        // Create Customer Table if not exist
        if( $wpdb->get_var( "show tables like '$tableName'" ) != $tableName ) {

            // Query - Create Table
            $sql = "CREATE TABLE `$tableName` (";
            $sql .= " `ID` BIGINT(20) NOT NULL auto_increment, ";
            $sql .= " `customer_id` BIGINT(20) NOT NULL, ";
            $sql .= " `amount` DECIMAL(12, 2) NOT NULL, ";
            $sql .= " `payment_key` VARCHAR(120) NULL, ";
            $sql .= " `created_date` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP, ";
            $sql .= " `created_by` VARCHAR(60) NOT NULL, ";
            $sql .= " `remarks` VARCHAR(255) NOT NULL, ";
            $sql .= " PRIMARY KEY (`ID`)";
            $sql .= ") $charset_collate;";

            // Include Upgrade Script
            require_once( ABSPATH . '/wp-admin/includes/upgrade.php' );
        
            // Create Table
            dbDelta( $sql );

        }
    }

    public static function price_history(){
        // WP Globals
        global $table_prefix, $wpdb;

        // Customer Table
        $tableName = $table_prefix . CWMS1661_TBL_PRODUCT_PRICE_HISTORY;
        $charset_collate     = $wpdb->get_charset_collate();
        // Create Customer Table if not exist
        if( $wpdb->get_var( "show tables like '$tableName'" ) != $tableName ) {

            // Query - Create Table
            $sql = "CREATE TABLE `$tableName` (";
            $sql .= " `ID` BIGINT(20) NOT NULL auto_increment, ";
            $sql .= " `product_id` VARCHAR(60) NOT NULL, ";
            $sql .= " `name` VARCHAR(120) NOT NULL, ";
            $sql .= " `po_id` BIGINT(20) NOT NULL, ";
            $sql .= " `vendor_id` BIGINT(20) NOT NULL, ";
            $sql .= " `vendor_name` VARCHAR(120) NOT NULL, ";
            $sql .= " `created_date` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP, ";
            $sql .= " `created_by` VARCHAR(120) NOT NULL, ";
            $sql .= " `cost_price` DECIMAL(12, 2) NOT NULL, ";
            $sql .= " PRIMARY KEY (`ID`)";
            $sql .= ") $charset_collate;";

            // Include Upgrade Script
            require_once( ABSPATH . '/wp-admin/includes/upgrade.php' );
        
            // Create Table
            dbDelta( $sql );

        }
    }

    public static function rtv_items(){
        // WP Globals
        global $table_prefix, $wpdb;

        // Customer Table
        $tableName = $table_prefix . CWMS1661_TBL_RTV_ITEMS;
        $charset_collate     = $wpdb->get_charset_collate();
        // Create Customer Table if not exist
        if( $wpdb->get_var( "show tables like '$tableName'" ) != $tableName ) {

            // Query - Create Table
            $sql = "CREATE TABLE `$tableName` (";
            $sql .= " `ID` BIGINT(20) NOT NULL auto_increment, ";
            $sql .= " `pullout_no` VARCHAR(60) NOT NULL, ";
            $sql .= " `return_id` BIGINT(20) NOT NULL, ";
            $sql .= " `invoice_id` BIGINT(20) NOT NULL, ";
            $sql .= " `created_date` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP, ";
            $sql .= " `created_by` VARCHAR(120) NOT NULL, ";
            $sql .= " `product_id` BIGINT(20) NOT NULL, ";
            $sql .= " `name` VARCHAR(120) NOT NULL, ";
            $sql .= " `retail_price` VARCHAR(120) NOT NULL, ";
            $sql .= " `cost_price` VARCHAR(120) NOT NULL, ";
            $sql .= " `qty_returned` DECIMAL(12, 2) NOT NULL, ";
            $sql .= " `remarks` VARCHAR(120) NOT NULL, ";
            $sql .= " PRIMARY KEY (`ID`)";
            $sql .= ") $charset_collate;";

            // Include Upgrade Script
            require_once( ABSPATH . '/wp-admin/includes/upgrade.php' );
        
            // Create Table
            dbDelta( $sql );

        }
    }
}