<?php
defined( 'ABSPATH' ) || exit;
/**
 * Product
 */
class CWMS1661_User {
    private $user_id;
    public $can_add_product     = false;
    public $can_update_product  = false;
    public $can_add_supplier     = false;
    public $can_update_supplier  = false;
    public function __construct( $user_id = false ){
        $this->user_id = $user_id ? $user_id : get_current_user_id();
        $this->can_add_product();
        $this->can_update_product();
        $this->can_add_supplier();
        $this->can_update_supplier();
    }
    private function can_add_product(){
        $this->can_add_product = true;
    }
    private function can_update_product(){
        $this->can_update_product = true;
    }
    private function can_add_supplier(){
        $this->can_add_supplier = true;
    }
    private function can_update_supplier(){
        $this->can_update_supplier = true;
    }
}