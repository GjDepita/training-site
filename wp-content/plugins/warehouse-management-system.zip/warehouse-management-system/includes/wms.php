<?php
defined( 'ABSPATH' ) || exit;
function cwms1661_load_textdomain() {
	load_plugin_textdomain( 'wpcodigo_wms', false, plugin_basename( dirname( CWMS1661_PLUGIN_FILE ) ) . '/i18n/languages' );
}
function cwms1661_define( $name, $value ) {
    if ( ! defined( $name ) ) {
        define( $name, $value );
    }
}
// Defined Constant variables
function cwms1661_define_constants(){

    cwms1661_define( 'CWMS1661_ABSPATH', dirname( CWMS1661_PLUGIN_FILE ) . '/' );
    cwms1661_define( 'CWMS1661_PLUGIN_URL', plugin_dir_url( CWMS1661_PLUGIN_FILE ) );
    cwms1661_define( 'CWMS1661_PLUGIN_PATH', plugin_dir_path( CWMS1661_PLUGIN_FILE ) );
    cwms1661_define( 'CWMS1661_PLUGIN_BASENAME', plugin_basename( CWMS1661_PLUGIN_FILE ) );
    cwms1661_define( 'CWMS1661_VERSION', '1.0.0' );
    cwms1661_define( 'CWMS1661_ROUNDING_PRECISION', 6 );
    cwms1661_define( 'CWMS1661_DELIMITER', '|' );
    cwms1661_define( 'CWMS1661_PDF_PAPER_SIZE', 'letter' );

    // Credit AUTH Key 
    /*
     * Please don't change this value for this will use for the customer credit value
     * You may changes this if it is fresh installed and to transactions yet created
     */
    cwms1661_define( 'CWMS1661_CREDIT_KEY', 'x=7XD35d6l{.I2KQX6M|2x$|ut^My?.W{+lGehGaHYOB@Ad+jJcjH}|hO?md0dEG' );

    // Post Types
    cwms1661_define( 'CWMS1661_PRODUCT_POST_TYPE', 'cwms_product' );
    cwms1661_define( 'CWMS1661_SUPPLIER_POST_TYPE', 'cwms_supplier' );
    cwms1661_define( 'CWMS1661_PO_POST_TYPE', 'cwms_inbound' );
    cwms1661_define( 'CWMS1661_SO_POST_TYPE', 'cwms_sales_order' );
    cwms1661_define( 'CWMS1661_INVOICE_POST_TYPE', 'cwms_invoice' );
    cwms1661_define( 'CWMS1661_RETURN_POST_TYPE', 'cwms_return' );

    // TAXONOMY
    cwms1661_define( 'CWMS1661_PRODUCT_TAXONOMY', 'cwms_product_cat' );

    // Database Tables
    cwms1661_define( 'CWMS1661_TB_PRODUCTS', 'cwms_products' );
    cwms1661_define( 'CWMS1661_TBL_PRODUCT_HISTORY', 'cwms_product_history' );
    cwms1661_define( 'CWMS1661_TBL_PAYMENTS', 'cwms_payments' );
    cwms1661_define( 'CWMS1661_TBL_PAYMENT_INFO', 'cwms_payment_info' );
    cwms1661_define( 'CWMS1661_TBL_PAYMENT_HISTORY', 'cwms_payment_history' );
    cwms1661_define( 'CWMS1661_TBL_CREDIT_HISTORY', 'cwms_credit_history' );
    cwms1661_define( 'CWMS1661_TBL_PRODUCT_PRICE_HISTORY', 'cwms_product_price_history' );
    cwms1661_define( 'CWMS1661_TBL_RTV_ITEMS', 'cwms_rtv_items' );

    // Sync membership notification 
    cwms1661_define( 'CWMS1661_MEMBERSHIP_SITE', 'https://warehousemanagementsolutions.com/' );
    cwms1661_define( 'CWMS1661_MEMBERSHIP_ID', null ); // add filter for change membership ID
}
// Inlcudes plugin files
function cwms1661_include_api(){
    $api_dir       = CWMS1661_ABSPATH.'module'.DIRECTORY_SEPARATOR.'api';
    $api_dir_files = scandir( $api_dir );
    if( empty( $api_dir_files ) ){
        return false;
    }
    foreach ( $api_dir_files as $file ) {
        $file_path = $api_dir.DIRECTORY_SEPARATOR.$file;
        if( is_dir( $file_path ) || $file == 'index.php' ){
            continue;
        }
        require_once $file_path;
    }
}
function cwms1661_includes(){
    require_once CWMS1661_ABSPATH . 'includes/functions.php';
    require_once CWMS1661_ABSPATH . 'includes/hooks.php';
    require_once CWMS1661_ABSPATH . 'includes/ajax.php';
    require_once CWMS1661_ABSPATH . 'includes/admin-hooks.php'; 
    require_once CWMS1661_ABSPATH . 'includes/class-field.php';
    require_once CWMS1661_ABSPATH . 'includes/class-scripts.php';
    require_once CWMS1661_ABSPATH . 'includes/class-templater.php';
    require_once CWMS1661_ABSPATH . 'includes/class-post-types.php';
    require_once CWMS1661_ABSPATH . 'includes/class-post-status.php';
    require_once CWMS1661_ABSPATH . 'includes/class-admin-pages.php';
    // Settings
    require_once CWMS1661_ABSPATH . 'module/setting/class-settings.php';
    require_once CWMS1661_ABSPATH . 'module/setting/setting-functions.php';
    // Product
    require_once CWMS1661_ABSPATH . 'module/product/class-product.php';
    require_once CWMS1661_ABSPATH . 'module/product/product-functions.php';
    // Supplier
    require_once CWMS1661_ABSPATH . 'module/supplier/supplier-functions.php';
    require_once CWMS1661_ABSPATH . 'module/supplier/class-supplier.php';
    // User
    require_once CWMS1661_ABSPATH . 'module/user/user-functions.php';
    require_once CWMS1661_ABSPATH . 'module/user/class-user.php';
    // Inbound
    require_once CWMS1661_ABSPATH . 'module/inbound/class-inbound.php';
    require_once CWMS1661_ABSPATH . 'module/inbound/class-po-post-type.php';
    require_once CWMS1661_ABSPATH . 'module/inbound/inbound-functions.php';
    // Sales Order
    require_once CWMS1661_ABSPATH . 'module/sales-order/class-sales-order.php';
    require_once CWMS1661_ABSPATH . 'module/sales-order/class-so-post-type.php';
    require_once CWMS1661_ABSPATH . 'module/sales-order/sales-order-functions.php';
    // Invoice
    require_once CWMS1661_ABSPATH . 'module/invoice/class-invoice.php';
    require_once CWMS1661_ABSPATH . 'module/invoice/class-invoice-post-type.php';
    require_once CWMS1661_ABSPATH . 'module/invoice/invoice-functions.php';
    // Return
    require_once CWMS1661_ABSPATH . 'module/return/class-return.php';
    require_once CWMS1661_ABSPATH . 'module/return/class-return-post-type.php';
    require_once CWMS1661_ABSPATH . 'module/return/return-functions.php';
    // Return to Vendor
    require_once CWMS1661_ABSPATH . 'module/rtv/class-rtv.php';
    require_once CWMS1661_ABSPATH . 'module/rtv/rtv-functions.php';
    // REPORTS ##
    // Receivable
    require_once CWMS1661_ABSPATH . 'module/reports/receivable/class-receivable.php';
    require_once CWMS1661_ABSPATH . 'module/reports/receivable/receivable-functions.php';
    // Customer
    require_once CWMS1661_ABSPATH . 'module/reports/customer/class-customer.php';
    require_once CWMS1661_ABSPATH . 'module/reports/customer/customer-functions.php';
    // Payment
    require_once CWMS1661_ABSPATH . 'module/reports/payment/class-payment.php';
    require_once CWMS1661_ABSPATH . 'module/reports/payment/payment-functions.php';
    // Unit Sold
    require_once CWMS1661_ABSPATH . 'module/reports/unit-sold/class-unit-sold.php';
    require_once CWMS1661_ABSPATH . 'module/reports/unit-sold/unit-sold-functions.php';
    // Gross Profit
    require_once CWMS1661_ABSPATH . 'module/reports/gross-profit/class-gross-profit.php';
    require_once CWMS1661_ABSPATH . 'module/reports/gross-profit/gross-profit-functions.php';
    // Import
    require_once CWMS1661_ABSPATH . 'module/imports/class-imports.php';
    require_once CWMS1661_ABSPATH . 'module/imports/import-functions.php';
    // Print
    require_once CWMS1661_ABSPATH . 'module/print/class-print.php';
    // Plugin installation
    require_once CWMS1661_ABSPATH . 'includes/class-install.php';
    require_once CWMS1661_ABSPATH . 'includes/class-db.php';
    cwms1661_include_api();
}
function cwms116_initilize(){
    cwms1661_define_constants();
    cwms1661_includes();
    // Run Installation
    CWMS_Install::init();
    // Initialize language translation files
    add_action( 'init', 'cwms1661_load_textdomain' );

    register_activation_hook( CWMS1661_PLUGIN_FILE, array('CWMS_DB', 'create' ) );
}