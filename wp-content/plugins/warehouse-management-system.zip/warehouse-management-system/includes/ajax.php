<?php 
defined( 'ABSPATH' ) || exit;
function cwms_get_dashboard_data(){
    $date_range     = (array)$_POST['datesRange'];
    $invoice        = [];
    $sales_order    = [];
    $inbounds       = [];

    // Number of records for each module
    foreach( $date_range as $date ){
        $invoice[]      = cwms1661_get_post_count_by_date( CWMS1661_INVOICE_POST_TYPE, $date );
        $sales_order[]  = cwms1661_get_post_count_by_date( CWMS1661_SO_POST_TYPE, $date );
        $inbounds[]     = cwms1661_get_post_count_by_date( CWMS1661_PO_POST_TYPE, $date );
    }

    // Get the start and end data for the module costing
    $date_start     = array_shift( $date_range );
    $date_end       = array_pop( $date_range );
    $date_end       = $date_end ? $date_end : $date_start;
    $daterange      = array(
        'start' => $date_start,
        'end'   => $date_end
    );

    $inbound_cost       = cwms1661_po_total_cost( $date_start, $date_end );
    $collection_cost    = cwms1661_total_collections( $date_start, $date_end  );
    $receivable_cost    = cwms1661_payable_total_cost( null, $daterange );

    $data = array(
        'inbounds' => array(
            'label'     => sprintf( __( 'Inbound (%d)', 'wpcodigo_wms'), array_sum( $inbounds ) ),
            'data'      => $inbounds,
            'tension'   =>  0.3,
        ),
        'sales_order' => array(
            'label'     => sprintf( __( 'Sales Order (%d)', 'wpcodigo_wms'), array_sum( $sales_order ) ),
            'data'      => $sales_order,
            'tension'   =>  0.3,
        ),
        'invoices' => array(
            'label'     => sprintf( __( 'Invoice (%d)', 'wpcodigo_wms'), array_sum( $invoice ) ),
            'data'      => $invoice,
            'tension'   =>  0.3,
        )
        );
    wp_send_json( array(
        'graph' => $data,
        'totals' => array(
            'inbound'       => cwms1661_format_number( $inbound_cost, 2, ','),
            'collection'    => cwms1661_format_number( $collection_cost, 2, ','),
            'receivable'    => cwms1661_format_number( $receivable_cost, 2, ',')
        ),
        'daterange' => array( $date_start,  $date_end )
    ) );
}
add_action( 'wp_ajax_cwms_get_dashboard_data', 'cwms_get_dashboard_data' );
function cwms_display_membership_notification_callback(){
    $membership_url = CWMS1661_MEMBERSHIP_SITE;
    $membership_id  = add_filter( 'cwms_membership_id', CWMS1661_MEMBERSHIP_ID );
    $response = wp_remote_get( "{$membership_url}wp-json/wms-notification/v1/member/{$membership_id}",
        array(
            'timeout'     => 120,
            'httpversion' => '1.1',
        )
    );

    if ( ! is_array( $response ) || is_wp_error( $response ) ) {
        echo null;
    }

    $body    = (array)json_decode( $response['body'] ); // use the content

    if( !isset( $body['status'] ) || $body['status'] != 'success' || empty($body['memberships']) ){
        echo  null;
    }
    ob_start();
    foreach ( $body['memberships'] as $membership ) {
        $expiry_timestamp = strtotime($membership->enddate);
        ?>
        <div class="alert alert-info">
            <?php printf("Your Warehouse Management Solution <strong>%s membership</strong> is about to expire on <strong>%s at %s</strong>. Please %s", $membership->name, date("F j, Y", $expiry_timestamp), date("H:i", $expiry_timestamp), '<a href="'. $membership_url .'membership-account/" target="_blank">Renew Membership</a>' ) ?>
        </div>
        <?php
    }

    echo ob_get_clean();
    wp_die();
}
add_action( 'wp_ajax_cwms_display_membership_notification', 'cwms_display_membership_notification_callback' );