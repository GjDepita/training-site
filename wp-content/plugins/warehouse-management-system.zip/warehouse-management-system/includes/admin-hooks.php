<?php
defined( 'ABSPATH' ) || exit;
function cwms1661_admin_body_class_callback( $classes ){
    $currentScreen = get_current_screen();
    if( $currentScreen->id != 'toplevel_page_cwms-dashboard' ){
        return $classes;
    }
    $classes .= 'cwms-dashboard';
    return $classes;
}
add_filter( 'admin_body_class', 'cwms1661_admin_body_class_callback' );

function cwms1661_current_screen_callback(){
    $currentScreen = get_current_screen();
    if( $currentScreen->id != 'toplevel_page_cwms-dashboard' ){
        return false;
    }
    ?>
    <!-- Remove the admin sidebar -->
    <script>
        if( jQuery('.cwms-dashboard').length ){
            jQuery('body #adminmenumain').remove();
            jQuery('body #wpadminbar').remove();
        }
    </script>
    <!-- Add style for the admin padding adjustment  -->
    <style>
        html.wp-toolbar{
            padding-top:0 !important;
        }
        .cwms-dashboard #wpwrap #wpcontent,
        .cwms-dashboard #wpwrap #wpfooter{
            margin-left:0px !important;
        }
    </style>
    <?php
}
// add_action( 'admin_footer', 'cwms1661_current_screen_callback' );
function cwms1661_show_admin_bar_callback(){
    return false;
}
add_filter( 'show_admin_bar', 'cwms1661_show_admin_bar_callback' );
function cwms1661_register_query_vars( $vars ) {
	$vars[] = 'cwms-page';
	return $vars;
}
add_action( 'admin_bar_menu', 'cwms1661_admin_bar_item', 500 );
function cwms1661_admin_bar_item ( WP_Admin_Bar $admin_bar ) {
    $args = array(
        'parent' => 'site-name',
        'id'     => 'cwms-view-page',
        'title'  => __('Visit WMS Dashboard', 'wpcargo-frontend-manager'),
        'href'   => cwms1661_dashboard_home(),
        'meta'   => false        
    );
    $admin_bar->add_node( $args );
}
add_filter( 'login_redirect', 'wcms1661_login_redirect_callback', 10, 3 );
function wcms1661_login_redirect_callback( $redirect_to, $request, $user ) {   
    $wcms_roles     = array_keys( cwms1661_dashboard_roles() );
    $wcms_roles[]   = 'administrator';
    $wcms_roles     = apply_filters( 'wcms1661_login_redirect_roles', $wcms_roles );
    if ( isset( $user->roles ) && is_array( $user->roles ) ) {
        if( array_intersect( $wcms_roles , $user->roles ) ) {
            $redirect_to = cwms1661_dashboard_home();
            return $redirect_to;
        }else{
            return get_admin_url();
        }
    }
    return $redirect_to;
}
add_action( 'wp_login_failed', 'wcms1661_login_fail_redirect_callback', 10, 2 );  
function wcms1661_login_fail_redirect_callback( $username, $error ) {
	$referrer       = $_SERVER['HTTP_REFERER'];
	$dashboard_url  = cwms1661_dashboard_home();
    $message        = wp_strip_all_tags( $error->get_error_message() );
	if ( !empty($referrer) && !strstr($referrer,'wp-login') && !strstr($referrer,'wp-admin') && cwms1661_dashboard_page() ) {
		$redirect = apply_filters( 'wcms1661_login_failed_redirect', $dashboard_url. '?login=failed&username='.$username.'&message='.$message, $dashboard_url );
		wp_redirect( $redirect);
		exit;
	}
}
add_action('wcms1661_before_form_login', 'wcms1661_form_login_failed_message');
function wcms1661_form_login_failed_message(){
    if( isset($_GET['message']) && !empty($_GET['message']) ): ?>
        <div class="alert alert-error" style="margin-bottom: 0;"><?php echo urldecode( $_GET['message'] ); ?></div>
        <script>
            window.history.replaceState({}, document.title, '<?php echo cwms1661_dashboard_home().'?'.cwms1661_clean_url_parameter(['message']); ?>' );
        </script>
    <?php endif;
}