<?php
defined( 'ABSPATH' ) || exit;

function cwms1661_nav_active( $nav_slug ){
    return apply_filters('cwms1661_nav_list_'.$nav_slug, false );
}
function cwms1661_subnav_active( $subnav_slug ){
    return apply_filters('cwms1661_subnav_list_'.$subnav_slug, true );
}
// Enable sidebar navigation hooks
function cwms1661_nav_list_active_callback(){
    foreach ( cwms1661_dashboard_menus() as $menu_array ) {
        // menu without subs
        if( !isset( $menu_array['subs'] ) || ! is_array( $menu_array['subs'] ) || empty( $menu_array['subs'] ) ){
            continue;
        }
        add_filter( 'cwms1661_nav_list_'.$menu_array['id'], function() use( $menu_array ) {
            return isset($_GET['cwmspage']) && in_array( $_GET['cwmspage'], array_keys( $menu_array['subs'] ) ) ? true : false;
        } );
        // Sub menu loop
        foreach ( array_keys( $menu_array['subs'] ) as $sub ) {
            add_filter( 'cwms1661_subnav_list_'.$sub, function() use( $sub ) {
                return isset($_GET['cwmspage']) && $_GET['cwmspage'] == $sub ? true : false;
            } );
        }
    }
}
add_action( 'wp_head', 'cwms1661_nav_list_active_callback', 10 );
// membership notification hook
add_action( 'cwms_before_page_content', function(){
    ?><div id="cwms-membership_notification_wrapper" class="col-md-12 col-sm-12 col-xs-12 p-4"></div><?php
});