<?php
defined( 'ABSPATH' ) || exit;

class CWMS_Install{

    public static function init() {
		add_action( 'init', array( __CLASS__, 'setup_post_type' ), 5 );
		add_action( 'init', array( __CLASS__, 'initialize_classes' ), 5 );
		add_action( 'init', array( __CLASS__, 'create_roles' ), 5 );
        register_deactivation_hook( CWMS1661_PLUGIN_FILE, array( __CLASS__, 'delete_roles'));
		add_filter( 'plugin_action_links_' . CWMS1661_PLUGIN_BASENAME, array( __CLASS__, 'plugin_action_links' ) );
		add_filter( 'plugin_row_meta', array( __CLASS__, 'plugin_row_meta' ), 10, 2 );
	}

    public static function setup_post_type(){
        CWMS1661_Post_Types::register_post_types();
        CWMS1661_Post_Types::register_taxonomy();
        CWMS1661_Post_Status::register_post_statuses();
        CWMS1661_PO_Post_Type::register_post_type();
        CWMS1661_SO_POST_TYPE::register_post_type();
        CWMS1661_Invoice_Post_Type::register_post_type();
        CWMS1661_Return_Post_Type::register_post_type();
    }

    public static function initialize_classes(){
        CWMS1661_Admin_Pages::init();
        CWMS1661_Product::init();
        CWMS1661_Supplier::init();
        CWMS1661_User::init();
        CWMS1661_Inbound::init();
        CWMS1661_Sales_Order::init();
        CWMS1661_Invoice::init();
        CWMS1661_Return::init();
        CWMS1661_RTV::init();
        CWMS1661_Receivable::init();
        CWMS1661_Customer::init();
        CWMS1661_Payment::init();
        CWMS1661_UnitSold::init();
        CWMS1661_Gross_Profit::init();
        CWMS1661_Import::init();
        CWMS1661_Print::init();
    }
    /**
	 * Create roles and capabilities.
	 */
	public static function create_roles() {
		global $wp_roles;
		if ( ! class_exists( 'WP_Roles' ) ) {
			return;
		}

		if ( ! isset( $wp_roles ) ) {
			$wp_roles = new WP_Roles(); // @codingStandardsIgnoreLine
		}

        $dashboard_roles = cwms1661_dashboard_roles();

        foreach ( $dashboard_roles as $role_slug => $role_name) {
            add_role(
                $role_slug,
                $role_name,
                array(
                    'read' => true,
                )
            );
        }
    }
    public static function delete_roles(){
        foreach ( array_keys( cwms1661_dashboard_roles() ) as $role ) {
            remove_role($role);
        }
    }

    public static function plugin_action_links( $links ){
        $action_links = array(
			'settings' => '<a href="' . admin_url( 'admin.php?page=cwms-dashboard' ) . '" aria-label="' . esc_attr__( 'View WMS settings', 'wpcodigo_wms' ) . '">' . esc_html__( 'Settings', 'wpcodigo_wms' ) . '</a>',
		);

		return array_merge( $action_links, $links );
    }
    public static function plugin_row_meta( $links, $file ) {
		if ( CWMS1661_PLUGIN_BASENAME !== $file ) {
			return $links;
		}

		$row_meta = array(
			'docs'    => '<a href="' . esc_url( apply_filters( 'cwms_docs_url', 'https://docs.codigo.com/documentation/' ) ) . '" aria-label="' . esc_attr__( 'View WMS documentation', 'wpcodigo_wms' ) . '">' . esc_html__( 'Docs', 'wpcodigo_wms' ) . '</a>',
			'apidocs' => '<a href="' . esc_url( apply_filters( 'cwms_apidocs_url', 'https://docs.codigo.com/apidocs/' ) ) . '" aria-label="' . esc_attr__( 'View WMS API docs', 'wpcodigo_wms' ) . '">' . esc_html__( 'API docs', 'wpcodigo_wms' ) . '</a>'
		);

		return array_merge( $links, $row_meta );
	}
}