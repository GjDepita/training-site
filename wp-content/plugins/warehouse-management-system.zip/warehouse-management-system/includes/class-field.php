<?php
defined( 'ABSPATH' ) || exit;

class CWMS_Field{
    private $field;
    private $value;
    private $placeholder;
    private $required;
    private $attribute;
    public function __construct( $field, $value = '', $attribute = array() )
    {
        $this->field        = $field;
        $this->value        = $value;
        $this->required     = $field['required'];
        $this->placeholder  = array_key_exists( 'placeholder', $field ) ? $field['placeholder'] : '';
        $this->attribute    = $attribute;
    }
    private function not_found(){
        ob_start();
        ?>
        <div class="form-group"><?php printf('Field %s with a type of %s is not yet registered in field generator.', $this->field['label'], $this->field['type']); ?></div><?php
        return ob_get_clean();
    
    $this->closing();}
    private function opening(){
        echo '<div class="form-group '. $this->field['classes'] .'">';
    }
    private function closing(){
        echo '</div>';
    }
    private function label(){
        $required_span = $this->required ? '<span class="required text-danger">*</span>' : '' ;
        echo '<label class="control-label col-md-3 col-sm-3 col-xs-12">'. $this->field['label']. ' ' .$required_span . '</label>';
    }
    private function text(){
        ob_start();
        $required   = $this->required ? 'required' : '';
        $attribute  = is_array( $this->attribute ) ? implode($this->attribute) : $this->attribute;
        $type_class = in_array( $this->field['type'], array( 'date', 'time', 'datetime', 'daterange') ) ? 'cwms-'.$this->field['type'] : '' ;
        $type_attr  = 'text';
        if( $this->field['type'] == 'email' ){
            $type_attr  = 'email';
        }elseif( $this->field['type'] == 'password' ){
            $type_attr  = 'password';
        }
        $this->opening();
        $this->label();

        ?>
        <div class="col-md-9 col-sm-9 col-xs-12">
            <input type="<?php echo $type_attr; ?>" class="form-control <?php echo $type_class; ?>" name="<?php echo $this->field['id']; ?>" placeholder="<?php echo $this->placeholder; ?>" value="<?php echo $this->value; ?>" <?php echo $required; ?> <?php echo $attribute; ?>>
            <?php do_action( 'cwms_after_form_field', $this->field ); ?>
        </div>
        <?php
        $this->closing();
        return ob_get_clean();
    }
    private function email(){
        return $this->text();
    }
    function date(){
        return $this->text();
    }
    function time(){
        return $this->text();
    }
    function datetime(){
        return $this->text();
    }
    function daterange(){
        return $this->text();
    }
    function password(){
        return $this->text();
    }
    private function select(){
        ob_start();
        if( empty($this->field['options']) || !is_array($this->field['options']) ){
            return false;
        }
        $required       = $this->required ? 'required' : '';
        $attribute      = is_array( $this->attribute ) ? implode($this->attribute) : $this->attribute;
        $default_value  = $this->placeholder ? $this->field['placeholder'] : esc_html__('Choose option', 'wpcodigo_wms');
        $this->opening();
        $this->label();
        ?>
        <div class="col-md-9 col-sm-9 col-xs-12">
            <select name="<?php echo $this->field['id']; ?>" class="form-control" <?php echo $required; ?> <?php echo $attribute; ?>>
                <option value=""><?php echo $default_value; ?></option>
                <?php foreach( $this->field['options'] as $option ): ?>
                <option value="<?php echo $option; ?>" <?php selected( $this->value, $option ); ?>><?php echo $option; ?></option>
                <?php endforeach; ?>
            </select>
            <?php do_action( 'cwms_after_form_field', $this->field ); ?>
        </div>
        <?php
        $this->closing();
        return ob_get_clean();
    }
    function textarea(){
        ob_start();
        $required       = $this->required ? 'required' : '';
        $attribute      = is_array( $this->attribute ) ? implode($this->attribute) : $this->attribute;
        $this->opening();
        $this->label();
        ?>
        <div class="col-md-9 col-sm-6 col-xs-12">
            <textarea class="form-control col-md- col-xs-12" name="<?php echo $this->field['id']; ?>" placeholder="<?php echo $this->placeholder; ?>" <?php echo $required; ?> <?php echo $attribute; ?>><?php echo $this->value; ?></textarea>
            <?php do_action( 'cwms_after_form_field', $this->field ); ?>
        </div>     
        <?php
        $this->closing();
        return ob_get_clean();
    }
    function radio(){
        if( empty($this->field['options']) || !is_array($this->field['options']) ){
            return false;
        }
        ob_start();
        $this->opening();
        $this->label();
        ?>
        <div class="col-md-9 col-sm-9 col-xs-12">
            <?php foreach( $this->field['options'] as $option ): ?>
                <div class="<?php echo $this->field['type']; ?>" >
                    <label>
                        <input type="<?php echo $this->field['type']; ?>" name="<?php echo $this->field['id']; ?>" value="<?php echo $option; ?>" <?php checked( $this->value, $option ); ?>> <?php echo $option; ?>
                    </label>
                </div>
            <?php endforeach; ?>
            <?php do_action( 'cwms_after_form_field', $this->field ); ?>
        </div>
        <?php
        $this->closing();
        return ob_get_clean();
    }
    function checkbox(){
        if( empty($this->field['options']) || !is_array($this->field['options']) ){
            return false;
        }
        $selected   = is_array( $this->value ) ? $this->value : array( $this->value );
        ob_start();
        $this->opening();
        $this->label();
        ?>
        <div class="col-md-9 col-sm-9 col-xs-12">
            <?php foreach( $this->field['options'] as $option ): ?>
                <div class="<?php echo $this->field['type']; ?>">
                    <label>
                        <input type="<?php echo $this->field['type']; ?>" name="<?php echo $this->field['id']; ?>[]" value="<?php echo $option; ?>" <?php echo in_array( $option, $selected ) ? 'checked' : ''; ?>> <?php echo $option; ?>
                    </label>
                </div>
            <?php endforeach; ?>
            <?php do_action( 'cwms_after_form_field', $this->field ); ?>
        </div>
        <?php
        $this->closing();
        return ob_get_clean();
    }
    public function html(){
        if( !method_exists($this, $this->field['type']) ){
            return $this->not_found();
        }
        return apply_filters( 'cwms1661_field_html_'.$this->field['id'], $this->{$this->field['type']}(), $this->field, $this->value ) ;
    }
}