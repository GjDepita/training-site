<?php
defined( 'ABSPATH' ) || exit;
function cwms1661_supplier_fields(){
    $headers = array(
        '_company_name' => array(
            'id'        => '_company_name',
            'label'     => __('Company Name', 'wpcodigo_wms' ),
            'type'      => 'text',
            'required'  => true,
            'options'   => array(),
            'classes'   => ''
        ),
        '_name'             => array(
            'id'        => '_name',
            'label'     => __('Contact Person', 'wpcodigo_wms' ),
            'type'      => 'text',
            'required'  => true,
            'options'   => array(),
            'classes'   => ''
        ),
        '_phone'             => array(
            'id'        => '_phone',
            'label'     => __('Phone', 'wpcodigo_wms' ),
            'type'      => 'text',
            'required'  => true,
            'options'   => array(),
            'classes'   => 'wcms-phone'
        ),
        '_email'             => array(
            'id'        => '_email',
            'label'     => __('Email', 'wpcodigo_wms' ),
            'type'      => 'email',
            'required'  => true,
            'options'   => array(),
            'classes'   => ''
        ),
        '_address_1'             => array(
            'id'        => '_address_1',
            'label'     => __('Address 1', 'wpcodigo_wms' ),
            'type'      => 'text',
            'required'  => true,
            'options'   => array(),
            'classes'   => ''
        ),
        '_address_2'    => array(
            'id'        => '_address_2',
            'label'     => __('Address 2', 'wpcodigo_wms' ),
            'type'      => 'text',
            'required'  => false,
            'options'   => array(),
            'classes'   => ''
        ),
        '_city'             => array(
            'id'        => '_city',
            'label'     => __('City', 'wpcodigo_wms' ),
            'type'      => 'text',
            'required'  => true,
            'options'   => array(),
            'classes'   => ''
        ),
        '_state'             => array(
            'id'        => '_state',
            'label'     => __('State / Province / Region', 'wpcodigo_wms' ),
            'type'      => 'text',
            'required'  => true,
            'options'   => array(),
            'classes'   => ''
        ),
        '_country'      => array(
            'id'        => '_country',
            'label'     => __('Country', 'wpcodigo_wms' ),
            'type'      => 'text',
            'required'  => true,
            'options'   => array(),
            'classes'   => ''
        ),
        '_postcode'     => array(
            'id'        => '_postcode',
            'label'     => __('Postcode', 'wpcodigo_wms' ),
            'type'      => 'text',
            'required'  => true,
            'options'   => array(),
            'classes'   => ''
        )
    );
    return apply_filters( 'cwms1661_supplier_fields', $headers );
}
function cwms1661_supplier_table_headers(){
    $metakeys   = ['_company_name', '_name', '_phone', '_email', '_state', '_city' ];
    return apply_filters( 'cwms1661_supplier_table_headers', $metakeys );
}

function cwms1661_can_add_supplier_roles(){
    $assinged_roles     = get_option( 'cwms1661_can_add_supplier_roles', null );
    $assinged_roles[]   = 'administrator';
    return $assinged_roles;
}
function cwms1661_can_add_supplier(){
    if( !is_user_logged_in() ){
        return false;
    }
    $allowed_roles = apply_filters('cwms1661_can_add_supplier_roles', cwms1661_can_add_supplier_roles() );
    return array_intersect( $allowed_roles,  cwms1661_current_user_roles() ) ? true : false ;
}

function cwms1661_can_update_supplier_roles(){
    $assinged_roles     = get_option( 'cwms1661_can_update_supplier_roles', null );
    $assinged_roles[]   = 'administrator';
    return $assinged_roles;
}
function cwms1661_can_update_supplier(){
    if( !is_user_logged_in() ){
        return false;
    }
    $allowed_roles = apply_filters('cwms1661_can_update_supplier_roles', cwms1661_can_update_supplier_roles() );
    return array_intersect( $allowed_roles,  cwms1661_current_user_roles() ) ? true : false ;
}
function cwms1661_can_delete_supplier_roles(){
    $assinged_roles     = get_option( 'cwms1661_can_delete_supplier_roles', null );
    $assinged_roles[]   = 'administrator';
    return $assinged_roles;
}
function cwms1661_can_delete_supplier(){
    if( ! is_user_logged_in() ){
        return false;
    }
    $allowed_roles = apply_filters('cwms1661_can_delete_supplier_roles', cwms1661_can_delete_supplier_roles() );
    return array_intersect( $allowed_roles,  cwms1661_current_user_roles() ) ? true : false ;
}
function cwms1661_supplier_address_html( $supplier_data ){
    $address = '';
    if( !empty( $supplier_data['_address_1'] ) || !empty( $supplier_data['_address_2'] ) ){
        $address .= $supplier_data['_address_1'].' '.$supplier_data['_address_2'].'</br>';
    }
    if( !empty( $supplier_data['_city'] ) || !empty( $supplier_data['_state'] ) ){
        $address .= $supplier_data['_city'].' '.$supplier_data['_state'].'</br>';
    }
    if( !empty( $supplier_data['_postcode'] ) || !empty( $supplier_data['_country'] ) ){
        $address .= $supplier_data['_postcode'].' '.$supplier_data['_country'];
    }
    return $address;
}
function cwms1661_search_supplier( $search ){
    global $wpdb;
    if( !$search ){
        return false;
    }
    $post_type = CWMS1661_SUPPLIER_POST_TYPE;
    $sql = "SELECT post.ID FROM {$wpdb->posts} AS `post`";
    $sql .= " LEFT JOIN {$wpdb->postmeta} AS meta on post.ID = meta.post_id";
    $sql .= " WHERE post.post_status LIKE 'publish' AND post.post_type LIKE '{$post_type}'";
    $sql .= " AND ( post.post_title LIKE %s OR ( meta.meta_key LIKE '_name' AND meta.meta_value LIKE %s ) )";
    $sql .= " GROUP BY post.ID ORDER BY post.post_title";
    $sql = apply_filters( 'cwms1661_search_supplier_sql', $wpdb->prepare( $sql, '%'.$search.'%', '%'.$search.'%' ), $search );
    return $wpdb->get_col( $sql );
}
function cwms1661_get_po_per_supplier( $supplier_id, $post_status = 'cwms-completed' ){
    global $wpdb;
    $sql = "SELECT tblpost.ID FROM {$wpdb->posts} AS tblpost";
    $sql .= " LEFT JOIN {$wpdb->postmeta} AS tblmeta ON tblpost.ID = tblmeta.post_id";
    $sql .= " WHERE tblpost.post_status LIKE %s AND tblpost.post_type LIKE 'cwms_inbound'";
    $sql .= " AND tblmeta.meta_key LIKE '_supplier_id' AND tblmeta.meta_value = %d";
    return $wpdb->get_col( $wpdb->prepare( $sql, $post_status, $supplier_id ) );
}