<?php
defined( 'ABSPATH' ) || exit;
/**
 * Product
 */
class CWMS1661_Supplier {

    public static function init(){
        // Saving Product data
        add_action('wp', array( __CLASS__, 'save') );
        add_action('template_redirect', array( __CLASS__, 'save_redirection') );
        add_action( 'save_post_'.CWMS1661_SUPPLIER_POST_TYPE, array( __CLASS__, 'save_post_meta'), 10, 3 );
        // Ajax handlers
        add_action( 'wp_ajax_cwms_get_suppliers', array(__CLASS__,  'get_data' ) );
        add_action( 'wp_ajax_cwms_delete_supplier', array(__CLASS__,  'delete_data' ) );
        add_action( 'wp_ajax_cwms_bulkdelete_supplier', array(__CLASS__,  'bulk_delete_data' ) );
        add_action( 'wp_ajax_cwms_search_supplier', array(__CLASS__,  'search' ) );
        // Localize Script translations
        add_filter( 'cwms1661_ajax_localize_script_translations', array(__CLASS__,  'script_translations' ) );
        // Product page script - add/remove URL message parameters
        add_action( 'cwms1661_before_supplier_form', array(__CLASS__, 'notification_message'));
        add_action( 'cwms1661_before_supplier_view', array(__CLASS__, 'notification_message'));
        // After page title hook
        add_action('cwms1661_after_page_title_view-supplier', array(__CLASS__, 'all_list_link'));
        add_action('cwms1661_after_page_title_update-supplier', array(__CLASS__, 'add_new_link'));
        add_action('cwms1661_after_page_title_all-suppliers', array(__CLASS__, 'add_new_link'));
        // Menu hooks
        add_filter( 'cwms1661_dashboard_menus', array(__CLASS__, 'menu' ) );
        add_filter( 'cwms1661_dashboard_shortcuts_menu', array(__CLASS__, 'shortcuts' ) );
        add_filter( 'cwms1661_registered_dashboard_pages', array(__CLASS__, 'page' ));
        // Template
        add_filter( 'cwms1661_content_template_view-supplier', array(__CLASS__, 'view_template' ) );
        add_filter( 'cwms1661_content_template_add-supplier', array(__CLASS__, 'add_template' ) );
        add_filter( 'cwms1661_content_template_update-supplier', array(__CLASS__, 'update_template' ) );
        add_filter( 'cwms1661_content_template_all-suppliers', array(__CLASS__, 'all_template' ) );

        // Permissions
        add_filter( 'cwms1661_permissions', array(__CLASS__, 'permissions' ) );
    }
    public static function all_list_link(){
        printf( '<a href="%s" class="btn btn-sm btn-primary">' . __( 'All suppliers', 'wpcodigo_wms' ) . '</a>', cwms1661_dashboard_home().'?cwmspage=all-suppliers' );
    }
    public static function add_new_link(){
        if( !cwms1661_can_add_supplier() ){
            return false;
        }
        printf( '<a href="%s" class="btn btn-sm btn-primary">' . __( 'Add new supplier', 'wpcodigo_wms' ) . '</a>', cwms1661_dashboard_home().'?cwmspage=add-supplier' );
    }
    public static function menu( $menus ){
        $submenu = array(
            'all-suppliers' => esc_html__('All Suppliers', 'wpcodigo_wms')
        );
        if( cwms1661_can_add_supplier() ){
            $submenu['add-supplier'] = esc_html__('Add Supplier', 'wpcodigo_wms');
        }
        $menus[30] = array(
            'id'        => 'suppliers',
            'label'     => esc_html__('Suppliers', 'wpcodigo_wms'),
            'classes'   => 'fa fa-book',
            'subs'      => $submenu
        );
        return $menus;
    }
    public static function shortcuts( $shortcuts ){
        if( !cwms1661_can_add_supplier() ){
            return $shortcuts;
        }
        $shortcuts[40] = array(
            'page-slug' => 'add-supplier',
            'label'     => esc_html__('Add new supplier', 'wpcodigo_wms'),
            'icon'     => 'fa fa-book'
        );
        return $shortcuts;
    }
    public static function page( $pages ){
        $pages['update-supplier']   = esc_html__('Update Supplier', 'wpcodigo_wms');
        $pages['view-supplier']   = esc_html__('Supplier Information', 'wpcodigo_wms');
        return $pages;
    }
    public static function view_template(){
        return apply_filters( "cwms1661_get_template_view-supplier", CWMS1661_ABSPATH.'module/supplier/templates/view-supplier.php' );
    }
    public static function add_template(){
        if( ! cwms1661_can_add_supplier() ){
            return cwms1661_get_template_path('403', 'dashboard');
        }
        return apply_filters( "cwms1661_get_template_add-supplier", CWMS1661_ABSPATH.'module/supplier/templates/add-supplier.php' );
    }
    public static function update_template(){
        if( ! cwms1661_can_update_supplier() ){
            return cwms1661_get_template_path('403', 'dashboard');
        }
        return apply_filters( "cwms1661_get_template_update-supplier", CWMS1661_ABSPATH.'module/supplier/templates/update-supplier.php' );
    }
    public static function all_template(){
        return apply_filters( "cwms1661_get_template_all-suppliers", CWMS1661_ABSPATH.'module/supplier/templates/all-suppliers.php' );
    }
    public static function save(){
        // Do not run if the condition is NOT meet
        if ( ! isset( $_POST['cwms-supplier_form_nonce'] ) 
            || ! wp_verify_nonce( $_POST['cwms-supplier_form_nonce'], 'cwms-supplier_form_action' ) 
        ) {
            return true;
        }

        $company     = '';
        if( isset($_POST['_company_name']) ){
            $company = wp_strip_all_tags( $_POST['_company_name'] );
        }
        $supplier_args = array(
            'post_title'    => $company,
            'post_status'   => 'publish',
            'post_type'     => CWMS1661_SUPPLIER_POST_TYPE
        );
        // Check if add new product
        $supplier_id   = isset($_POST['cwms_supplier_id']) ? (int)$_POST['cwms_supplier_id'] : false;
        if( !$supplier_id ){
            if( ! cwms1661_can_add_supplier() ){
                printf( '<div id="message" class="error"><p>%s</p></div>', __('Permission denied. Please contact admin support', 'wpcodigo_wms') );
                wp_die();
            }
            // Insert the post into the database
            $supplier_id = wp_insert_post( $supplier_args );
        }else{
            if( ! cwms1661_can_update_supplier() ){
                printf( '<div id="message" class="error"><p>%s</p></div>', __('Permission denied. Please contact admin support', 'wpcodigo_wms') );
                wp_die();
            }
            // Update product data
            $supplier_args['ID'] = $supplier_id;
            $supplier_id = wp_update_post( $supplier_args );
        }

        if ( is_wp_error( $supplier_id ) ) {
            $error_string = $supplier_id->get_error_message();
            echo '<div id="message" class="error"><p>' . $error_string . '</p></div>';
            wp_die();
        }
        $subpage = cwms1661_can_update_supplier() ? 'update-supplier' : 'view-supplier' ;
        $_POST['cwms_supplier_redirection'] = array(
            'url'       => cwms1661_dashboard_home(),
            'subpage'   => $subpage,
            'id'        => $supplier_id,
            'message'   => sprintf( __('Supplier %s successfully saved!'), get_the_title($supplier_id) )
        );
    }
    public static function save_post_meta( $post_id, $post, $update ){
        $metakeys  = array_keys( cwms1661_supplier_fields() );
        // Unset Product name and description
        unset($metakeys[0]);
        // Return if METAKEYS is empty
        if( empty($metakeys) ){
            return false;
        }
        foreach ( $metakeys as $metakey ) {
            if( !array_key_exists($metakey, $_POST)){
                continue;
            }
            update_post_meta( $post_id, $metakey, sanitize_text_field( $_POST[$metakey] ) );
        }
    }
    // Save supplier redirection
    public static function save_redirection(){
        if( !isset($_POST['cwms_supplier_redirection']) || !is_array($_POST['cwms_supplier_redirection']) ){
            return false;
        }
        wp_redirect( $_POST['cwms_supplier_redirection']['url'] .'?cwmspage='. $_POST['cwms_supplier_redirection']['subpage'] .'&id='. $_POST['cwms_supplier_redirection']['id'] .'&cwms-message='. urlencode($_POST['cwms_supplier_redirection']['message']) );
        exit;
    }
    public static function notification_message(){
        if( !isset($_GET['cwmspage']) || ( $_GET['cwmspage'] != 'update-supplier' && $_GET['cwmspage'] != 'view-supplier' ) ){
            return false;
        }
        if( !isset($_GET['cwms-message']) || empty($_GET['cwms-message']) ){
            return false;
        }
        printf('<div class="submit-notification_message alert alert-success">%s</div>', urldecode($_GET['cwms-message']));
        ?>        
        <script>
            window.history.replaceState({}, document.title, '<?php echo cwms1661_dashboard_home().'?'.cwms1661_clean_url_parameter(['cwms-message']); ?>' );
            setTimeout(function(){
                jQuery('body').find('.submit-notification_message').remove();
            }, 6000 );
        </script>
        
        <?php
    }
    public static function script_translations( $translations ){
        $translations['supplierTableData'] = array(
            'id'        => 'cwms_dataTable-supplier',
            'delete'    => cwms1661_can_delete_supplier(),
            'headers'   => cwms1661_supplier_table_headers()
        );
        return $translations;
    }
    public static function get_data(){
        $metakeys       = array_keys( cwms1661_supplier_fields() );
        $data           = cwms1661_get_all_data( CWMS1661_SUPPLIER_POST_TYPE, $metakeys, '_company_name' );
        if( $data ){
            $data = array_map( function( $value ){
                $value['update_link']   = cwms1661_dashboard_home().'?cwmspage=update-supplier&id='.$value['ID'];
                $value['view_link']     = cwms1661_dashboard_home().'?cwmspage=view-supplier&id='.$value['ID'];
                $label_url              = esc_url_raw( cwms1661_dashboard_home().'?cwmspage=update-supplier&id='.$value['ID'] );
                $actions = [
                    'edit' => sprintf(
                        '<span class="edit"><a class="cwms-update_supplier text-primary" href="%s">%s</a> ',
                        esc_url_raw( cwms1661_dashboard_home().'?cwmspage=update-supplier&id='.$value['ID'] ),
                        esc_html__('Edit','wpcodigo_wms')
                    ),
                    'delete' => sprintf(
                        '<span class="trash"><a class="cwms-delete_supplier text-danger" href="#">%s</a></span>',
                        esc_html__('Delete','wpcodigo_wms')
                    ),
                    'view'  => sprintf(
                        '<span class="view"><a class="text-primary" href="%s">%s</a></span>',
                        esc_url_raw( cwms1661_dashboard_home().'?cwmspage=view-supplier&id='.$value['ID'] ),
                        esc_html__('View','wpcodigo_wms')
                    )
                ];
                if( !cwms1661_can_delete_supplier( ) ):
                    unset($actions['delete']);
                endif;
                if( !cwms1661_can_update_supplier()  ):
                    unset($actions['edit']);
                    $label_url = esc_url_raw( cwms1661_dashboard_home().'?cwmspage=view-supplier&id='.$value['ID'] );
                endif;
                ob_start();
                ?>
                <strong data-id="<?php echo $value['ID']; ?>"><a href="<?php echo $label_url; ?>"><?php echo $value['_company_name']; ?></a></strong> 
                <div class="row-actions" data-id="<?php echo $value['ID']; ?>">
                    <?php echo implode( ' | ', array_values( $actions ) ) ?>
                </div>
                <?php
                $value['_company_name'] = ob_get_clean();
                return $value;
            }, $data );
        }
        wp_send_json( array( 'data' => $data ) );
    }
    public static function delete_data(){
        if( !cwms1661_can_delete_supplier() ){
            wp_send_json( array(
                'status' => 'error',
                'code'  => 401,
                'message' => esc_html__('Permission denied', 'wpcodigo_wms')
            ));
        }
        $supplier_id = (int) $_POST['id'];
        $result     = wp_trash_post( $supplier_id );
        $code       = 200;
        $message    = esc_html__('Product successfully deleted.', 'wpcodigo_wms');
        do_action('cwms_after_delete_supplier', $supplier_id, $result );
        if( !$result ){
            $code       = 400;
            $message    = esc_html__('Request failed.', 'wpcodigo_wms');
        }
        wp_send_json( array(
            'code'      => $code,
            'message'   => $message,
            'supplier_id' => $supplier_id
        ));
    }
    public function bulk_delete_data(){
        if( !cwms1661_can_delete_supplier() ){
            wp_send_json( array(
                'status' => 'error',
                'code'  => 401,
                'message' => esc_html__('Permission denied', 'wpcodigo_wms')
            ));
        }
        $selected_ids = $_POST['ids'];
        $deleted_ids   = [];
        foreach ($selected_ids as $id ) {
            $deleted_ids[] = wp_trash_post( $id );
        }   
        wp_send_json( 
            array(
                'status' => 'success',
                'code'  => 200,
                'message' => esc_html__('Request successfully completed', 'wpcodigo_wms')
            )
        );
        wp_die();
    }
    public function search(){
        $data    = array( );
        $options = cwms1661_search_supplier( $_GET['q'] );
        if( $options ){
            foreach ( (array)$options as $post_id ) {
                $data[] = cwms1661_get_data( $post_id, array_keys(cwms1661_supplier_fields()), '_company_name' );
            }
        }
        wp_send_json( $data );
        wp_die();
    }

    public static function permissions( $permissions ){
        $permissions[45] = array(
            'label' => esc_html__('Suppliers', 'wpcodigo_wms' ),
			'options' => array(
                'cwms1661_can_add_supplier_roles'         => esc_html__('Add', 'wpcodigo_wms' ), 
                'cwms1661_can_update_supplier_roles'      => esc_html__('Update', 'wpcodigo_wms' ), 
                'cwms1661_can_delete_supplier_roles'      => esc_html__('Delete', 'wpcodigo_wms' )
            )
        );
        return $permissions;
    }
}