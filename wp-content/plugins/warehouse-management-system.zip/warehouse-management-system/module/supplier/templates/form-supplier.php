<div class="col-md-offset-3 col-md-6 col-sm-12">
    <?php do_action('cwms1661_before_supplier_form', $supplier ); ?>
    <form class="form-horizontal form-label-left input_mask" action="" method="POST">
        <?php wp_nonce_field( 'cwms-supplier_form_action', 'cwms-supplier_form_nonce' ); ?>
        <?php if( $supplier != null ): ?>
            <input type="hidden" name="cwms_supplier_id" value="<?php echo (int)$supplier['ID']; ?>">
        <?php endif; ?>
        <?php do_action('cwms1661_before_supplier_form_fields', $supplier ); ?>
        <?php 
        foreach( cwms1661_supplier_fields() as $key => $field ): 
            $value = $supplier != null && array_key_exists( $key, $supplier ) ? $supplier[$key] : '';
            $field = new CWMS_Field( $field, $value );
            echo $field->html();
        endforeach; 
        ?>
        <?php do_action('cwms1661_after_supplier_form_fields', $supplier ); ?>
        <div class="ln_solid"></div>
        <div class="form-group">
            <div class="col-md-9 col-sm-9 col-xs-12 col-md-offset-3">
                <button type="submit" class="btn btn-success"><?php echo esc_html__('Save Supplier', 'wpcodigo_wms' ); ?></button>
            </div>
        </div>
    </form>
    <?php do_action('cwms1661_after_supplier_form', $supplier ); ?>
</div>