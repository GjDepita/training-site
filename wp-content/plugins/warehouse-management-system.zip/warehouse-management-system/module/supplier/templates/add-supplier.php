<?php
    $supplier_id = isset( $_GET['id'] ) ? (int)$_GET['id'] : 0;
    $supplier    = array();
    include_once apply_filters( "cwms1661_get_template_form-supplier", CWMS1661_ABSPATH.'module/supplier/templates/form-supplier.php' );
?>