<?php
    $supplier_id    = isset( $_GET['id'] ) ? (int)$_GET['id'] : 0;
    $metakeys       = array_keys( cwms1661_supplier_fields() );
    $supplier       = cwms1661_get_data($supplier_id, $metakeys, '_company_name' );
?>
<div class="col-md-offset-3 col-md-6 col-sm-12">
    <?php do_action('cwms1661_before_supplier_view', $supplier ); ?>    
    <div class="form-horizontal form-label-left input_mask">
        <?php 
        foreach( cwms1661_supplier_fields() as $key => $field ): 
            $field = new CWMS_Field( $field, $supplier[$key], array('disabled') );
            echo $field->html();
        endforeach; 
        ?>
    </div>
    <?php do_action('cwms1661_after_supplier_view', $supplier ); ?>
</div>