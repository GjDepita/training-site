<div class="table-reponsive">
<table id="cwms_dataTable-supplier" data-type="suppliers" class="wcms1661_dataTable display" style="width:100%">
    <thead>
        <tr>
            <?php do_action( 'cwms1661_supplier_before_table_header' ); ?>
            <th></th>
            <?php foreach( cwms1661_supplier_fields() as $metakey => $field_info ): ?>
                <?php if( !in_array($metakey, cwms1661_supplier_table_headers() ) ) continue; ?>
                <th><?php echo apply_filters('cwms1661_supplier_table_headers_label_'.$metakey , $field_info['label'] ); ?></th>
            <?php endforeach; ?>
            <?php do_action( 'cwms1661_supplier_after_table_header' ); ?>
        </tr>
    </thead>
    <tfoot>
        <tr>
            <?php do_action( 'cwms1661_supplier_before_table_header' ); ?>
            <th></th>
            <?php foreach( cwms1661_supplier_fields() as $metakey => $field_info ): ?>
                <?php if( !in_array($metakey, cwms1661_supplier_table_headers() ) ) continue; ?>
                <th><?php echo apply_filters('cwms1661_supplier_table_headers_label_'.$metakey , $field_info['label'] ); ?></th>
            <?php endforeach; ?>
            <?php do_action( 'cwms1661_supplier_after_table_header' ); ?>
        </tr>
    </tfoot>
</table>
</div>