<?php
    $supplier_id    = isset( $_GET['id'] ) ? (int)$_GET['id'] : 0;
    $metakeys       = array_keys( cwms1661_supplier_fields() );
    $supplier       = cwms1661_get_data($supplier_id, $metakeys, '_company_name' );
    include_once apply_filters( "cwms1661_get_template_form-supplier", CWMS1661_ABSPATH.'module/supplier/templates/form-supplier.php' );
?>