<?php 
defined( 'ABSPATH' ) || exit;

function cwms1661_get_customer_credit_key( $user_id ){
    $credit_key    = CWMS1661_CREDIT_KEY;
    $credit_array  = array(
        'credit_key' => $credit_key,
        'user_id'    => (int)$user_id
    );
    return '_cwms1661_customer_'.md5( json_encode( $credit_array ) );
}
function cwms1661_update_customer_credit( $user_id, $amount = 0 ){
    $credit_key     = cwms1661_get_customer_credit_key( $user_id );
    $current_credit = cwms1661_get_customer_credit( $user_id );
    $amount         = floatval( $amount );
    $new_credit     = bcadd( $current_credit, $amount );
    update_option( $credit_key, $new_credit );
}
function cwms1661_get_customer_credit( $user_id ){
    $credit_key = cwms1661_get_customer_credit_key( $user_id );
    return get_option( $credit_key, 0 );
}
function cwms1661_customers_table_headers(){
    $fields = array(
        '_name'     => __('Name', 'wpcodigo_wms' ),
        '_company'  => __('Company', 'wpcodigo_wms' ),
        '_phone'    => __('Phone', 'wpcodigo_wms' ),
        '_email'    => __('Email', 'wpcodigo_wms' ),
        '_address'  => __('Address', 'wpcodigo_wms' ),
    );
    return apply_filters( 'cwms1661_customers_table_headers', $fields );
}
function cwms1661_customers_invoice_table_headers(){
    $fields = array(
        '_invoice_number'   => __('Invoice No.', 'wpcodigo_wms' ),
        '_date_created'     => __('Date Created', 'wpcodigo_wms' ),
        '_total_amount'     => __('Total Amount', 'wpcodigo_wms' ),
        '_balance'          => __('Balance', 'wpcodigo_wms' ),
        '_payment_status'   => __('Payment Status', 'wpcodigo_wms' ),
        '_action'           => __('Actions', 'wpcodigo_wms' ),
    );
    return apply_filters( 'cwms1661_customers_invoice_table_headers', $fields );
}

function cwms1661_get_all_customers_data( $limit = null, $offset = 0 ){
    global $wpdb;
    $parameter = array( CWMS1661_INVOICE_POST_TYPE );
    $sql = "SELECT `ID` as 'id'";
    $sql .= " FROM {$wpdb->posts} AS tblposts";
    $sql .= " LEFT JOIN {$wpdb->postmeta} AS tblmeta ON  tblposts.ID = tblmeta.post_id";
    $sql .= " WHERE tblposts.post_status LIKE 'cwms-completed' AND tblposts.post_type LIKE %s";
    $sql .= " AND tblmeta.meta_key LIKE '_payment_status' AND tblmeta.meta_value LIKE '_paid' ";
    if( $limit ){
        $sql .= " LIMIT %d OFFSET %d";
        $parameter = array_merge( $parameter, array( $limit, $offset ) );
    }
    $sql     = $wpdb->prepare( $sql, $parameter);
    $results = $wpdb->get_col( apply_filters( 'cwms1661_get_all_customers_data_sql', $sql, $limit, $offset ) );

    if( empty($results) ){
        return false;
    }

    $data = [];
    foreach ($results as $post_id ) {
        $data[] = cwms1661_get_invoice_data( $post_id );
    }
    return $data;
}
function cwms1661_get_customer_invoice_data( $customer_id, $status, $date_range = array(), $limit = null, $offset = 0 ){
    $results        = cwms1661_get_receivables_by_date( $date_range['start'], $date_range['end'], $customer_id, null, $status );
    $data = [];
    foreach ($results as $post_id ) {
        $data[] = cwms1661_get_invoice_data( $post_id );
    }
    return $data;
}

function cwms1661_get_customer_unpaid_invoices( $customer_id, $limit = null, $offset = 0 ){
    global $wpdb;
    $parameter = array( CWMS1661_INVOICE_POST_TYPE, $customer_id );
    $sql = "SELECT tblposts.ID as 'id', tblposts.post_title as 'invoice_number'";
    $sql .= " FROM {$wpdb->posts} AS tblposts";
    $sql .= " LEFT JOIN {$wpdb->postmeta} AS tblmeta ON  tblposts.ID = tblmeta.post_id";
    $sql .= " LEFT JOIN {$wpdb->postmeta} AS tblstatus ON  tblposts.ID = tblstatus.post_id";
    $sql .= " WHERE tblposts.post_status  LIKE 'cwms-completed' AND tblposts.post_type LIKE %s";
    $sql .= " AND tblmeta.meta_key LIKE '_customer_id'  AND tblmeta.meta_value LIKE %d";
    $sql .= " AND tblstatus.meta_key LIKE '_payment_status'  AND tblstatus.meta_value NOT LIKE '_paid'";
    $sql .= " GROUP BY tblposts.ID";
    if( $limit ){
        $sql .= " LIMIT %d OFFSET %d";
        $parameter = array_merge( $parameter, array( $limit, $offset ) );
    }
    $sql     = $wpdb->prepare( $sql, $parameter);
    return $wpdb->get_results( apply_filters( 'cwms1661_get_customer_unpaid_invoices_sql', $sql, $limit, $offset ), ARRAY_A );
}

function cwms1661_get_customer_payments_data( $customer_id, $date_range = array(), $limit = null, $offset = 0 ){
    global $wpdb;
    $parameter          = array( 'cwms-completed', CWMS1661_INVOICE_POST_TYPE, $customer_id );
    $tbl_payments       = $wpdb->prefix.CWMS1661_TBL_PAYMENTS;
    $tbl_paymentinfo    = $wpdb->prefix.CWMS1661_TBL_PAYMENT_INFO;

    // Get payments table columsn
    $tbl_columns   = $wpdb->get_col("DESC {$tbl_payments}", 0);

    $tbl_columns   = array_map( function( $column ) {
        return 'tblpayment.'.$column;
    }, $tbl_columns );
    $tbl_columns[] = 'tblposts.post_title as _po_number';
    $tbl_columns[] = 'tblinfo.created_date as created_date';
    $tbl_columns[] = 'tblinfo.created_by as created_by';
    $tbl_columns[] = 'tblinfo.paid_by as paid_by';
    $tbl_columns[] = 'tblinfo.remarks as remarks';

    $sql = "SELECT ".implode( ', ', $tbl_columns );
    $sql .= " FROM {$tbl_payments} AS tblpayment";
    $sql .= " LEFT JOIN {$wpdb->posts} AS tblposts ON tblpayment.invoice_id = tblposts.ID";
    $sql .= " LEFT JOIN {$wpdb->postmeta} AS tblmeta ON tblpayment.invoice_id = tblmeta.post_id";
    $sql .= " LEFT JOIN {$tbl_paymentinfo} AS tblinfo ON tblpayment.payment_key = tblinfo.payment_key";
    $sql .= " WHERE tblposts.post_status  LIKE %s";
    $sql .= " AND tblposts.post_type LIKE %s";
    $sql .= " AND tblmeta.meta_key LIKE '_customer_id'";
    $sql .= " AND tblmeta.meta_value = %d";

    if( !empty( $date_range ) ){
        $sql .= " AND CAST( tblinfo.created_date AS DATE) BETWEEN %s AND %s";
        $parameter[] = $date_range['start'];
        $parameter[] = $date_range['end'];
    }

    $sql .= " GROUP BY tblpayment.ID ORDER BY tblpayment.ID DESC";

    if( $limit ){
        $sql .= " LIMIT %d OFFSET %d";
        $parameter = array_merge( $parameter, array( $limit, $offset ) );
    }
    $sql     = $wpdb->prepare( $sql, $parameter);

    return $wpdb->get_results( apply_filters( 'cwms1661_get_customer_payments_data_sql', $sql, $date_range, $limit, $offset ), ARRAY_A );
}

function cwms1661_search_customer_cheque( $customer_id, $cheque_number ){
    global $wpdb;
    $parameter          = array( 'cwms-completed', CWMS1661_INVOICE_POST_TYPE, $customer_id, trim($cheque_number) );
    $tbl_payments       = $wpdb->prefix.CWMS1661_TBL_PAYMENTS;
    $tbl_paymentinfo    = $wpdb->prefix.CWMS1661_TBL_PAYMENT_INFO;
    
    $tbl_columns   = $wpdb->get_col("DESC {$tbl_paymentinfo}", 0);
    $tbl_columns   = array_map( function( $column ) {
        return 'tblinfo.'.$column;
    }, $tbl_columns );

    $sql = "SELECT ".implode( ', ', $tbl_columns );
    $sql .= " FROM {$tbl_paymentinfo} AS tblinfo";
    $sql .= " INNER JOIN {$tbl_payments} AS tblpayment ON tblpayment.payment_key = tblinfo.payment_key";
    $sql .= " LEFT JOIN {$wpdb->posts} AS tblposts ON tblpayment.invoice_id = tblposts.ID";
    $sql .= " LEFT JOIN {$wpdb->postmeta} AS tblmeta ON tblpayment.invoice_id = tblmeta.post_id";
    $sql .= " WHERE tblposts.post_status LIKE %s";
    $sql .= " AND tblposts.post_type LIKE %s";
    $sql .= " AND tblmeta.meta_key LIKE '_customer_id'";
    $sql .= " AND tblmeta.meta_value = %d";
    $sql .= " AND tblinfo.payment_type LIKE '_cheque'";
    $sql .= " AND tblinfo.assigned = 0";
    $sql .= " AND tblinfo.status NOT LIKE '_stale'";
    $sql .= " AND tblinfo.cheque_number LIKE %s";
    $sql .= " LIMIT 1";
    $sql = $wpdb->prepare( $sql, $parameter );
    return $wpdb->get_row( $sql, ARRAY_A );
}
function cwms1661_get_customer_payments( $customer_id, $payment_type = '', $date_range = array(), $limit = null, $offset = 0  ){
    global $wpdb;
    $parameter          = array( 'cwms-completed', CWMS1661_INVOICE_POST_TYPE, $customer_id );
    $tbl_payments       = $wpdb->prefix.CWMS1661_TBL_PAYMENTS;
    $tbl_paymentinfo    = $wpdb->prefix.CWMS1661_TBL_PAYMENT_INFO;

    if( !empty( $payment_type ) ){
        $parameter[] = $payment_type;
    }
    // Get payments table columns

    $tbl_columns   = $wpdb->get_col("DESC {$tbl_paymentinfo}", 0);

    $tbl_columns   = array_map( function( $column ) {
        return 'tblinfo.'.$column;
    }, $tbl_columns );
    $tbl_columns[] = 'tblpayment.created_date';

    $sql = "SELECT ".implode( ', ', $tbl_columns );
    $sql .= " FROM {$tbl_payments} AS tblpayment";
    $sql .= " LEFT JOIN {$wpdb->posts} AS tblposts ON tblpayment.invoice_id = tblposts.ID";
    $sql .= " LEFT JOIN {$wpdb->postmeta} AS tblmeta ON tblpayment.invoice_id = tblmeta.post_id";
    $sql .= " INNER JOIN {$tbl_paymentinfo} AS tblinfo ON tblpayment.payment_key = tblinfo.payment_key";
    $sql .= " WHERE tblposts.post_status  LIKE %s";
    $sql .= " AND tblposts.post_type LIKE %s";
    $sql .= " AND tblmeta.meta_key LIKE '_customer_id'";
    $sql .= " AND tblmeta.meta_value = %d";
    $sql .= " AND tblinfo.assigned = 1";
    if( !empty( $payment_type ) ){
        $sql .= " AND tblinfo.payment_type LIKE %s";
    }
    if( !empty( $date_range ) ){
        $sql .= " AND CAST( tblinfo.created_date AS DATE) BETWEEN %s AND %s";
        $parameter[] = $date_range['start'];
        $parameter[] = $date_range['end'];
    }
    $sql .= " ORDER BY tblinfo.created_date DESC";
    if( $limit ){
        $sql .= " LIMIT %d OFFSET %d";
        $parameter = array_merge( $parameter, array( $limit, $offset ) );
    }
    $sql     = $wpdb->prepare( $sql, $parameter);
    return $wpdb->get_results( apply_filters( 'cwms1661_get_customer_payments_sql', $sql, $date_range, $limit, $offset ), ARRAY_A );
}

function cwms1661_get_customer_payment_info( $customer_id, $payment_type = '', $payment_status = '', $date_range = array(), $limit = null, $offset = 0){
    global $wpdb;
    $parameter          = array( 'cwms-completed', CWMS1661_INVOICE_POST_TYPE, $customer_id );
    $tbl_payments       = $wpdb->prefix.CWMS1661_TBL_PAYMENTS;
    $tbl_paymentinfo    = $wpdb->prefix.CWMS1661_TBL_PAYMENT_INFO;
    
    $tbl_columns   = $wpdb->get_col("DESC {$tbl_paymentinfo}", 0);

    $tbl_columns   = array_map( function( $column ) {
        return 'tblinfo.'.$column;
    }, $tbl_columns );

    $sql = "SELECT ".implode( ', ', $tbl_columns );
    $sql .= " FROM {$tbl_paymentinfo} AS tblinfo";
    $sql .= " INNER JOIN {$tbl_payments} AS tblpayment ON tblpayment.payment_key = tblinfo.payment_key";
    $sql .= " LEFT JOIN {$wpdb->posts} AS tblposts ON tblpayment.invoice_id = tblposts.ID";
    $sql .= " LEFT JOIN {$wpdb->postmeta} AS tblmeta ON tblpayment.invoice_id = tblmeta.post_id";
    
    $sql .= " WHERE tblposts.post_status LIKE %s";
    $sql .= " AND tblposts.post_type LIKE %s";
    $sql .= " AND tblmeta.meta_key LIKE '_customer_id'";
    $sql .= " AND tblmeta.meta_value = %d";
    $sql .= " AND tblinfo.assigned = 1";
    if( !empty( $payment_type ) ){
        $sql .= " AND tblinfo.payment_type LIKE %s";
        $parameter[] = $payment_type;
    }
    if( !empty( $payment_status ) ){
        $sql .= " AND tblinfo.status LIKE %s";
        $parameter[] = $payment_status;
    }
    if( !empty( $date_range ) ){
        $sql .= " AND CAST( tblinfo.created_date AS DATE) BETWEEN %s AND %s";
        $parameter[] = $date_range['start'];
        $parameter[] = $date_range['end'];
    }
    $sql .= "GROUP BY tblinfo.ID ORDER BY tblinfo.ID DESC, tblinfo.created_date DESC";
    if( $limit ){
        $sql .= " LIMIT %d OFFSET %d";
        $parameter = array_merge( $parameter, array( $limit, $offset ) );
    }
    $sql     = $wpdb->prepare( $sql, $parameter);
    
    return $wpdb->get_results( apply_filters( 'cwms1661_get_customer_payment_info_sql', $sql, $parameter ), ARRAY_A );
}

function  cwms_get_customer_cheque_payments( $customer_id, $payment_status = array(), $assigned = null, $date_range = array(), $limit = null, $offset = 0 ){
    global $wpdb;
    $parameter          = array( 'cwms-completed', CWMS1661_INVOICE_POST_TYPE, $customer_id );
    $tbl_payments       = $wpdb->prefix.CWMS1661_TBL_PAYMENTS;
    $tbl_paymentinfo    = $wpdb->prefix.CWMS1661_TBL_PAYMENT_INFO;
    
    $tbl_columns   = $wpdb->get_col("DESC {$tbl_paymentinfo}", 0);

    $tbl_columns   = array_map( function( $column ) {
        return 'tblinfo.'.$column;
    }, $tbl_columns );

    $sql = "SELECT ".implode( ', ', $tbl_columns );
    $sql .= " FROM {$tbl_paymentinfo} AS tblinfo";
    $sql .= " INNER JOIN {$tbl_payments} AS tblpayment ON tblpayment.payment_key = tblinfo.payment_key";
    $sql .= " LEFT JOIN {$wpdb->posts} AS tblposts ON tblpayment.invoice_id = tblposts.ID";
    $sql .= " LEFT JOIN {$wpdb->postmeta} AS tblmeta ON tblpayment.invoice_id = tblmeta.post_id";
    
    $sql .= " WHERE tblposts.post_status LIKE %s";
    $sql .= " AND tblposts.post_type LIKE %s";
    $sql .= " AND tblmeta.meta_key LIKE '_customer_id'";
    $sql .= " AND tblmeta.meta_value = %d";
    $sql .= " AND tblinfo.payment_type LIKE '_cheque'";

    if( $assigned !== null ){
        $sql .= " AND tblinfo.assigned = %d";
        $parameter[] = $assigned;
    }

    if( !empty( $payment_status ) && is_array( $payment_status ) ){
        $payment_status = array_map( 'sanitize_text_field', $payment_status );
        $sql .= " AND tblinfo.status IN ('".implode( "','", $payment_status )."')";
    }
    
    if( !empty( $date_range ) ){
        $sql .= " AND CAST( tblinfo.created_date AS DATE) BETWEEN %s AND %s";
        $parameter[] = $date_range['start'];
        $parameter[] = $date_range['end'];
    }
    $sql .= "GROUP BY tblinfo.ID ORDER BY tblinfo.ID DESC, tblinfo.created_date DESC";
    if( $limit ){
        $sql .= " LIMIT %d OFFSET %d";
        $parameter = array_merge( $parameter, array( $limit, $offset ) );
    }
    $sql     = $wpdb->prepare( $sql, $parameter);
    
    return $wpdb->get_results( apply_filters( 'cwms_get_customer_cheque_payments_sql', $sql, $parameter ), ARRAY_A );
}
// Access restriction functions
function cwms1661_can_access_customers(){
    if( cwms1661_can_view_customers() ){
        return true;
    }   
    return false;
}
function cwms1661_can_view_customers_roles(){
    $assinged_roles     = get_option( 'cwms1661_can_view_customers_roles', null );
    if( $assinged_roles === null ){
        $assinged_roles = array( 'cwms_manager' );
    }
    $assinged_roles[]   = 'administrator';
    return $assinged_roles;
}
function cwms1661_can_view_customers(){
    if( !is_user_logged_in() ){
        return false;
    }
    $allowed_roles = apply_filters('cwms1661_can_view_customers_roles', cwms1661_can_view_customers_roles() );
    return array_intersect( $allowed_roles,  cwms1661_current_user_roles() ) ? true : false ;
}