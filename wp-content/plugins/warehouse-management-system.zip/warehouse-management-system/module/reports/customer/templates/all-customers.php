<?php
$table_headers  = cwms1661_customers_table_headers();
?>
<table id="cwms_customerTable" class="wcms1661_dataTable display" style="width:100%">
    <thead>
        <tr>
            <?php do_action( 'cwms1661_customer_before_table_header' ); ?>
            <?php foreach( $table_headers as $metakey => $label ): ?>
                <th><?php echo apply_filters('cwms1661_customers_table_headers_label_'.$metakey , $label ); ?></th>
            <?php endforeach; ?>
            <?php do_action( 'cwms1661_customer_after_table_header' ); ?>
        </tr>
    </thead>
    <tfoot>
        <tr>
            <?php do_action( 'cwms1661_customer_before_table_header' ); ?>
            <?php foreach( $table_headers as $metakey => $label ): ?>
                <th><?php echo apply_filters('cwms1661_customers_table_headers_label_'.$metakey , $label ); ?></th>
            <?php endforeach; ?>
            <?php do_action( 'cwms1661_customer_after_table_header' ); ?>
        </tr>
    </tfoot>
</table>    