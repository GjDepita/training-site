<div role="tabpanel" class="tab-pane fade" id="staled-cheques-tab" aria-labelledby="staled-cheques-tab">
    <div class="filter-section profile_title" style="margin-bottom:18px;">
        <input id="staled_cheques_daterange_filter" type="text" class="form-control form-control-sm" style="width:210px;display:inline-block;" value="" />
    </div>
    <div class="staled_cheques-table-wrapper">
        <table id="cwms_customerAllStaledChequesTable" class="wcms1661_dataTable table table-striped jambo_table" style="width:100%;">
                <thead>
                    <tr>
                        <td><?php echo esc_html('Cheque Number','wpcodigo_wms'); ?></td>
                        <td><?php echo esc_html('Bank Name','wpcodigo_wms'); ?></td>
                        <td><?php echo esc_html('Processed by','wpcodigo_wms'); ?></td>
                        <td><?php echo esc_html('Processed Date','wpcodigo_wms'); ?></td>
                        <td><?php echo esc_html('Paid by','wpcodigo_wms'); ?></td>
                        <td><?php echo esc_html('Amount','wpcodigo_wms'); ?></td>
                    </tr>
                </thead>
        </table>
    </div>
</div>