<form id="cwms-invoices-payment-form" class="row">
    <div class="col-md-6" style="margin-bottom:18px;">
        <label for="payment_type"><?php esc_html_e('Payment Type', 'wpcodigo_wms'); ?></label>
        <select id="payment_type" class="form-control" name="payment_type" required="required">
            <?php foreach ( cwms1661_payment_types() as $key => $value): ?>
                <option value="<?php echo $key; ?>"><?php echo $value; ?></option>
            <?php endforeach; ?>
        </select>
    </div>
    <div class="col-md-6" style="margin-bottom:18px;">
        <label for="payment_amount"><?php esc_html_e('Payment Amount', 'wpcodigo_wms'); ?></label>
        <input type="text" id="payment_amount" class="form-control cmws-currency" name="payment_amount" required="required">
    </div>
    <div id="cwms_cheque-information" class="col-md-12" style="padding:12px; margin-bottom:18px; display:none;">
        <p><strong><?php esc_html_e('Cheque Information', 'wpcodigo_wms'); ?></strong></p>
        <div class="col-md-12 cwms-search_cheque_wrapper" style="margin-bottom:18px;">
            <input type="text" id="cwms-search_cheque" class="form-control cwms-search_cheque" data-action="cwms_search_unassigned_cheque" placeholder="<?php esc_html_e('Search unassigned cheque', 'wpcodigo_wms'); ?>">
        </div>
        <div class="col-md-12" style="margin-bottom:18px;">
            <label for="cheque_number"><?php esc_html_e('Cheque Number', 'wpcodigo_wms'); ?></label>
            <input type="text" id="cheque_number" class="form-control" name="cheque_number">
        </div>
        <div class="col-md-6" style="margin-bottom:18px;">
            <label for="cheque_date"><?php esc_html_e('Date', 'wpcodigo_wms'); ?></label>
            <input type="text" id="cheque_date" class="form-control cwms-date" name="cheque_date">
        </div>
        <div class="col-md-6" style="margin-bottom:18px;">
            <label for="cheque_bank"><?php esc_html_e('Bank Name', 'wpcodigo_wms'); ?></label>
            <input type="text" id="cheque_bank" class="form-control" name="cheque_bank">
        </div>
    </div>
    <div class="col-md-12" style="margin-bottom:18px;">
        <label for="status"><?php esc_html_e('Validation Status', 'wpcodigo_wms'); ?></label>
        <select id="status" name="status" class="form-control" required="required">
            <option value="" disabled><?php esc_html_e('Select option', 'wpcodigo_wms'); ?></option>
            <?php foreach ( cwms1661_payment_validation_status() as $key => $status ): ?>
                <option value="<?php echo esc_attr($key); ?>" <?php selected( '_cleared', $key ); ?> <?php echo $key != '_cleared' ? 'disabled' : '' ; ?>><?php echo esc_html( $status ); ?></option>
            <?php endforeach; ?>
        </select>
    </div>
    <div class="col-md-12" style="margin-bottom:18px;">
        <div class="ln_solid"></div>
        <button id="cwms-payment-submit" class="btn btn-info" type="submit"><?php esc_html_e('Add Payment', 'wpcodigo_wms'); ?></button>
    </div>
</form>