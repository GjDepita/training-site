<div class="col-middle">
    <div class="text-center text-center">
        <h1 class="error-number">404</h1>
        <h2><?php esc_html_e("Sorry no invoices to create payment.", "wpcodigo_wms" ); ?></h2>
    </div>
</div>