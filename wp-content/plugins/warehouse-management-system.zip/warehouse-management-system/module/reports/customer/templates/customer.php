<?php
$user_info      = get_userdata( (int)$_GET['id'] );
$user_data      = cwms1661_get_user_info( $user_info );
$table_headers  = cwms1661_customers_invoice_table_headers();
$unpaid_invoices = cwms1661_get_customer_unpaid_invoices( (int)$_GET['id'] );

$invoice_statuses   = cwms1661_invoice_payment_statuses();
$invoice_statuses['_paid']          = __('Collections', 'wpcodigo_wms');
$invoice_statuses['_receivables']   = __('Receivables', 'wpcodigo_wms');
$invoice_statuses                   = array_reverse($invoice_statuses);

// Payments record
$page       = 1; 
$per_page   = 2 ; 
$offset     =  ($page-1) * $per_page; 
$payables   = cwms1661_payable_total_cost( (int)$user_info->ID );
?>
<div class="row">
    <div class="col-md-12 col-sm-12 col-xs-12">
        <div class="x_panel">
            <div class="x_content">
            <div class="col-md-3 col-sm-3 col-xs-12 profile_left">
                <!-- Current avatar -->
                <!-- <div class="profile_img">
                    <div id="crop-avatar">
                        <img class="img-responsive avatar-view" src="images/picture.jpg" alt="Avatar" title="Change the avatar">
                    </div>
                </div> -->
                <h3><?php echo esc_html( $user_data['display_name'] ); ?></h3>
                <p class="text-muted"><?php echo cwms1661_user_status($user_info->ID); ?></p>
                <ul class="list-unstyled user_data">
                    <li>
                        <i class="fa fa-building user-profile-icon"></i> <?php echo esc_html( $user_data['_company'] ); ?>
                    </li>
                    <li>
                        <i class="fa fa-phone user-profile-icon"></i> <?php echo esc_html( $user_data['_phone'] ); ?>
                    </li>
                    <li>
                        <i class="fa fa-envelope-o user-profile-icon"></i> <?php echo esc_html( $user_data['_email'] ); ?>
                    </li>
                    <li>
                        <i class="fa fa-map-marker user-profile-icon"></i> <?php echo cwms1661_display_address_html( $user_data ); ?>
                    </li>
                </ul>

                <div class="ln_solid"></div>

                <div class="tile_count" style="margin-top: 0;">
                    <div class="tile_stats_count" style="padding: 0; margin: 0;">
                        <span class="count_top"><i class="fa fa-money"></i> <?php esc_html_e('Payable Amount', 'wpcodigo_wms' ); ?></span>
                        <div class="count cwms-total_collection blue" style="font-size: 1.5em; line-height: inherit;"><?php echo cwms1661_format_number( $payables, 2, ','); ?></div>
                    </div>
                </div>

                <?php if( cwms1661_can_create_payment() && !empty( $unpaid_invoices ) ): ?>
                    <div class="tile_count" style="margin-top: 0;">
                        <a href="<?php echo cwms1661_dashboard_home().'?cwmspage=customer&id='.(int)$user_info->ID.'&action=create-payment' ?>" class="btn btn-primary"><?php esc_html_e('Create payment', 'wpcodigo_wms' ); ?></a>
                    </div>
                <?php endif; ?>

                <div class="tile_stats_count" style="padding: 0; margin: 0;">
                    <span class="count_top"><i class="fa fa-money"></i> <?php esc_html_e('Remaining Credit Amount', 'wpcodigo_wms' ); ?></span>
                    <div class="count cwms-total_collection blue" style="font-size: 1.5em; line-height: inherit;"><?php echo cwms1661_format_number( cwms1661_get_customer_credit( $user_info->ID ), 2, ','); ?> <i data-toggle="modal" data-target="#cwms-credit-history-modal" class="fa fa-list cursor-pointer cwms-show_credit_history" title="<?php esc_html_e('Show credit history', 'wpcodigo_wms' ); ?>"></i> </div>
                </div>

            </div>
            <div class="col-md-9 col-sm-9 col-xs-12">

                <div class="profile_title">
                    <div class="col-md-4">
                        <h4><?php echo esc_html( 'Invoice Report', 'wpcodigo_wms' ); ?></h4>
                        <p><?php echo esc_html( 'As of', 'wpcodigo_wms' ); ?> <span class="cwms-customer_report_daterange"></span></p>
                    </div>
                    <div class="col-md-8">
                        <section class="filter-wrapper pull-right" style="margin-right:12px; display:inline-block;">
                            <input id="cmws-customer_daterange" data-id="<?php echo (int)$user_data['ID']; ?>"  type="text" class="form-control" style="width: 210px;" value="" />
                        </section>
                        <section class="filter-wrapper pull-right" style="margin-right:12px; display:inline-block;">
                            <select id="cmws-customer_invoices" data-placeholder="<?php echo esc_html('All Invoices','wpcodigo_wms'); ?>" class="form-control form-control-sm" style="width:180px;margin-right:8px;display:inline-block;">
                                <option value=""><?php echo esc_html('All Invoices','wpcodigo_wms'); ?></option>
                                <?php foreach( $invoice_statuses as $key => $status ): ?>
                                    <option value="<?php echo esc_attr( $key ); ?>" <?php selected( '_receivables', $key); ?>><?php echo esc_html( $status ); ?></option>
                                <?php endforeach; ?>
                            </select>
                        </section>
                        
                    </div>
                </div>

                <!-- start of Invoice table -->
                <div id="cwms_customer_invoiceTable-wrapper" style="padding: 24px 0;">
                    <table id="cwms_customer_invoiceTable" class="wcms1661_dataTable display" style="width:100%;">
                        <thead>
                            <tr>
                                <?php do_action( 'cwms1661_customer_invoice_before_table_header' ); ?>
                                <?php foreach( $table_headers as $metakey => $label ): ?>
                                    <th><?php echo apply_filters('cwms1661_customer_invoice_table_headers_label_'.$metakey , $label ); ?></th>
                                <?php endforeach; ?>
                                <?php do_action( 'cwms1661_customer_invoice_after_table_header' ); ?>
                            </tr>
                        </thead>
                        <tfoot>
                            <tr>
                                <?php do_action( 'cwms1661_customer_invoice_before_table_header' ); ?>
                                <?php foreach( $table_headers as $metakey => $label ): ?>
                                    <th><?php echo apply_filters('cwms1661_customer_invoice_table_headers_label_'.$metakey , $label ); ?></th>
                                <?php endforeach; ?>
                                <?php do_action( 'cwms1661_customer_invoice_after_table_header' ); ?>
                            </tr>
                        </tfoot>
                    </table>    
                </div>
                <!-- end of Invoice table -->

                <div class="" role="tabpanel" data-example-id="togglable-tabs">
                    <ul id="myTab" class="nav nav-tabs bar_tabs" role="tablist">
                        <!-- <li role="presentation" class="active"><a href="#payments-tab" id="home-tab-menu" role="tab" data-toggle="tab" aria-expanded="true"><i class="fa fa-money"></i> <?php //echo esc_html( 'Payments per Invoice', 'wpcodigo_wms' ); ?></a>
                        </li> -->
                        <li role="presentation" class="active"><a href="#all-payments-tab" id="chequepayment-tab-menu" role="tab" data-toggle="tab" aria-expanded="true"><i class="fa fa-list"></i> <?php echo esc_html( 'All Payments', 'wpcodigo_wms' ); ?></a>
                        </li>
                        <li role="presentation"><a href="#unassinged_cheques-tab" id="unassinged_cheques-tab-menu" role="tab" data-toggle="tab" aria-expanded="true"><i class="fa fa-chain-broken"></i> <?php echo esc_html( 'Unassinged Cheques', 'wpcodigo_wms' ); ?></a>
                        </li>
                        <li role="presentation"><a href="#staled-cheques-tab" id="staled-cheques-tab-menu" role="tab" data-toggle="tab" aria-expanded="true"><i class="fa fa-reply-all"></i> <?php echo esc_html( 'Return/Stale Cheques', 'wpcodigo_wms' ); ?></a>
                        </li>
                    </ul>
                    <div id="myTabContent" class="tab-content">
                        <?php //include_once apply_filters( "cwms1661_get_template_customer-payments", CWMS1661_ABSPATH.'module/reports/customer/templates/invoice-payments.php' ); ?>
                        <?php include_once apply_filters( "cwms1661_get_template_customer-all_payments", CWMS1661_ABSPATH.'module/reports/customer/templates/all-payments.php' ); ?>
                        <?php include_once apply_filters( "cwms1661_get_template_customer-unassinged_cheques", CWMS1661_ABSPATH.'module/reports/customer/templates/unassinged_cheques.php' ); ?>
                        <?php include_once apply_filters( "cwms1661_get_template_customer-staled-cheques", CWMS1661_ABSPATH.'module/reports/customer/templates/staled-cheques.php' ); ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Modal Template - Credit history -->
<div id="cwms-credit-history-modal" class="cwms-modal modal fade" tabindex="-1" role="dialog" aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-label="<?php esc_html_e('Close', 'wpcodigo_wms'); ?>"><span aria-hidden="true">×</span>
                    </button>
                    <h4 class="modal-title"><?php esc_html_e('Credit History', 'wpcodigo_wms'); ?></h4>
                </div>
                <div class="modal-body">
                    <div class="credit_history-table-wrapper">
                        <table id="cwms_credit_history-table" class="wcms1661_dataTable table table-striped jambo_table" style="width:100%;">
                            <thead>
                                <tr>
                                    <td><?php echo esc_html('Processed date','wpcodigo_wms'); ?></td>
                                    <td><?php echo esc_html('Processed by','wpcodigo_wms'); ?></td>
                                    <td><?php echo esc_html('Amount','wpcodigo_wms'); ?></td>
                                    <td><?php echo esc_html('Remarks','wpcodigo_wms'); ?></td>
                                </tr>
                            </thead>
                            <tbody></tbody>
                            <tfoot>
                                <tr><td colspan="4" class="text-center"><a id="cwms-showmore_credit_history" href="#"><i class="fa fa-angle-double-down"></i> Show more</a></td></tr>
                            </tfoot>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>