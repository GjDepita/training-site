<div role="tabpanel" class="tab-pane fade active in" id="payments-tab" aria-labelledby="home-tab">
    <div id="cwms-payment-records_wrapper" class="table-responsive">
        <div class="profile_title" style="margin-bottom:18px;">
            <input id="cmws-paymentRecords_daterange" type="text" class="pull-right" style="margin-top: 5px; background: #fff; cursor: pointer; padding: 5px 10px; border: 1px solid #E6E9ED;min-width: 180px;" value="" />
        </div>
        <div class="invoices_payments_table-wrapper">
            <table id="cwms-invoices_payments_table" class="table table-striped jambo_table">
                <thead>
                    <tr>
                        <th><?php echo esc_html('Payment no.','wpcodigo_wms'); ?></th>
                        <th><?php echo esc_html('Invoice no.','wpcodigo_wms'); ?></th>
                        <th><?php echo esc_html('Date','wpcodigo_wms'); ?></th>
                        <th><?php echo esc_html('Created By','wpcodigo_wms'); ?></th>
                        <th><?php echo esc_html('Amount Paid','wpcodigo_wms'); ?></th>
                        <th><?php echo esc_html('Paid By','wpcodigo_wms'); ?></th>
                        <th><?php echo esc_html('Remarks','wpcodigo_wms'); ?></th>
                    </tr>
                </thead>
            </table>
        </div>
    </div>
</div>
