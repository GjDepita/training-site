<div role="tabpanel" class="tab-pane fade active in" id="all-payments-tab" aria-labelledby="all-payments-tab">
    <div class="filter-section profile_title" style="margin-bottom:18px;">
        <select id="payment_type_filter" class="form-control form-control-sm" style="width:fit-content;margin-right:8px;display:inline-block;">
            <option value=""><?php echo esc_html('All Types','wpcodigo_wms'); ?></option>
            <?php foreach( cwms1661_payment_types() as $key => $label ): ?>
                <option value="<?php echo esc_attr( $key ); ?>"><?php echo esc_html( $label ); ?></option>
            <?php endforeach; ?>
        </select>
        <select id="payment_status_filter" class="form-control form-control-sm" style="width:fit-content;margin-right:8px;display:inline-block;">
            <option value=""><?php echo esc_html('All status','wpcodigo_wms'); ?></option>
            <?php foreach( cwms1661_payment_validation_status() as $key => $label ): ?>
                <option value="<?php echo esc_attr( $key ); ?>"><?php echo esc_html( $label ); ?></option>
            <?php endforeach; ?>
        </select>
        <input id="payment_daterange_filter" type="text" class="form-control form-control-sm" style="width:210px;display:inline-block;" value="" />
    </div>
    <div class="all-payment-table-wrapper">
        <table id="cwms_customerAllPaymentsTable" class="wcms1661_dataTable table table-striped jambo_table" style="width:100%;">
                <thead>
                    <tr>
                        <td><?php echo esc_html('Receipt Number','wpcodigo_wms'); ?></td>
                        <td><?php echo esc_html('Payment Type','wpcodigo_wms'); ?></td>
                        <td><?php echo esc_html('Processed by','wpcodigo_wms'); ?></td>
                        <td><?php echo esc_html('Processed Date','wpcodigo_wms'); ?></td>
                        <td><?php echo esc_html('Paid by','wpcodigo_wms'); ?></td>
                        <td><?php echo esc_html('Amount','wpcodigo_wms'); ?></td>
                        <td><?php echo esc_html('Remarks','wpcodigo_wms'); ?></td>
                        <td><?php echo esc_html('Status','wpcodigo_wms'); ?></td>
                        <td><?php echo esc_html('Action','wpcodigo_wms'); ?></td>
                    </tr>
                </thead>
        </table>
    </div>
    <!-- Payment History-->
    <div id="cwms-update-check-payment-modal" class="cwms-modal modal fade" tabindex="-1" role="dialog" aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-label="<?php esc_html_e('Close', 'wpcodigo_wms'); ?>"><span aria-hidden="true">×</span>
                    </button>
                    <h4 class="modal-title"></h4>
                </div>
                <div class="modal-body">
                    <div class="cwms-payment-informations">
                        <h4><?php esc_html_e('Invoices', 'wpcodigo_wms'); ?></h4>
                        <table id="cwms_invoices_table" class="table">
                            <thead>
                                <tr>
                                    <th><?php esc_html_e('Invoice Number', 'wpcodigo_wms'); ?></th>
                                    <th><?php esc_html_e('Amount Paid', 'wpcodigo_wms'); ?></th>
                                    <th><?php esc_html_e('Adjustment', 'wpcodigo_wms'); ?></th>
                                </tr>
                            </thead>
                            <tbody></tbody>
                        </table>
                        <h4><?php esc_html_e('Payments', 'wpcodigo_wms'); ?></h4>
                        <table id="cwms_payments_table" class="table">
                            <thead>
                                <tr>
                                <th><?php esc_html_e('Payment Type', 'wpcodigo_wms'); ?></th>
                                <th><?php esc_html_e('Status', 'wpcodigo_wms'); ?></th>
                                <th><?php esc_html_e('Amount', 'wpcodigo_wms'); ?></th>
                                </tr>
                            </thead>
                            <tbody></tbody>
                        </table>
                    </div>
                    <div class="cwms-payment-payment_details">
                        <p>
                            <label for="collected_date"><?php esc_html_e('Collection Date', 'wpcodigo_wms'); ?></label>
                            <input type="text" id="collected_date" class="form-control" disabled>
                        </p>
                        <p class="select2-100">
                            <label for="agent_name"><?php esc_html_e('Agent', 'wpcodigo_wms'); ?></label><br/>
                            <input type="text" id="agent_name" class="form-control" disabled>
                        </p>
                        <p>
                            <label for="receipt_number"><?php esc_html_e('Receipt Number (PR/CR)', 'wpcodigo_wms'); ?></label>
                            <input type="text" id="receipt_number" class="form-control" disabled>
                        </p>
                        <p>
                            <label for="paid_by"><?php esc_html_e('Paid by', 'wpcodigo_wms'); ?></label>
                            <input type="text" id="paid_by" class="form-control" disabled>
                        </p>
                        <p>
                            <label for="remarks"><?php esc_html_e('Remarks', 'wpcodigo_wms'); ?></label>
                            <textarea type="text" id="remarks" class="form-control" disabled></textarea>
                        </p>
                    </div>
                    <div class="ln_solid"></div>
                    <form class="cwms-payment-form row" method="POST">
                        <?php wp_nonce_field( 'cwms-update_customer_payment_form_action', 'cwms-update_customer_payment_form_nonce' ); ?>
                        <input type="hidden" name="payment_id" value="" />
                        <div class="col-md-6" style="margin-bottom:18px;">
                            <label for="payment_type"><?php esc_html_e('Payment Type', 'wpcodigo_wms'); ?></label>
                            <input type="text" id="payment_type" class="form-control cmws-currency" disabled>
                        </div>
                        <div class="col-md-6" style="margin-bottom:18px;">
                            <label for="payment_amount"><?php esc_html_e('Payment Amount', 'wpcodigo_wms'); ?></label>
                            <input type="text" id="amount" class="form-control cmws-currency" disabled>
                        </div>
                        <div id="cwms_cheque-information" class="col-md-12 d-none" style="padding:12px; margin-bottom:18px;">
                            <p><strong><?php esc_html_e('Cheque Information', 'wpcodigo_wms'); ?></strong></p>
                            <div class="col-md-12" style="margin-bottom:18px;">
                                <label for="cheque_number"><?php esc_html_e('Cheque Numner', 'wpcodigo_wms'); ?></label>
                                <input type="text" id="cheque_number" class="form-control" disabled>
                            </div>
                            <div class="col-md-6" style="margin-bottom:18px;">
                                <label for="cheque_date"><?php esc_html_e('Date', 'wpcodigo_wms'); ?></label>
                                <input type="text" id="cheque_date" class="form-control cwms-date" disabled>
                            </div>
                            <div class="col-md-6" style="margin-bottom:18px;">
                                <label for="cheque_bank"><?php esc_html_e('Bank Name', 'wpcodigo_wms'); ?></label>
                                <input type="text" id="cheque_bank" class="form-control" disabled>
                            </div>
                        </div>
                        <div class="col-md-12" style="margin-bottom:18px;">
                            <label for="status"><?php esc_html_e('Validation Status', 'wpcodigo_wms'); ?></label>
                            <select id="status" name="status" class="form-control" required="required">
                                <option value="" disabled><?php esc_html_e('Select option', 'wpcodigo_wms'); ?></option>
                                <?php foreach ( cwms1661_payment_validation_status() as $key => $status ): ?>
                                    <option value="<?php echo esc_attr($key); ?>"><?php echo esc_html( $status ); ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="col-md-12" style="margin-bottom:18px;">
                            <div class="ln_solid"></div>
                            <button id="cwms-payment-submit" class="btn btn-info" type="submit"><?php esc_html_e('Update Payment', 'wpcodigo_wms'); ?></button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>