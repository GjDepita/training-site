<div class="col-md-12 col-sm-12">
    <?php do_action('cwms1661_before_create_customer_payment_template'); ?>
    <section >
        <h4><?php esc_html_e('Unpaid Invoices', 'wpcodigo_wms'); ?></h4>
        <p><?php esc_html_e('Note: Select invoices to apply payments', 'wpcodigo_wms'); ?></p>
    </section>
    <table id="cwms_unpaidInvoiceTable" class="table">
        <thead>
            <tr>
                <th><?php esc_html_e('Invoice Number', 'wpcodigo_wms'); ?></th>
                <th><?php esc_html_e('Total Amount', 'wpcodigo_wms'); ?></th>
                <th><?php esc_html_e('Total Paid', 'wpcodigo_wms'); ?></th>
                <th><?php esc_html_e('Balance', 'wpcodigo_wms'); ?></th>
                <th><?php esc_html_e('Action', 'wpcodigo_wms'); ?></th>
            </tr>
        </thead>
    </table>
</div>
<div class="col-md-12 col-sm-12" style="margin-top: 38px; background: #F5F7FA;">
    <form id="cwms_customer_payment_form" action="" method="POST">
        <h4><?php esc_html_e('Payment Form', 'wpcodigo_wms'); ?></h4>
        <?php wp_nonce_field( 'cwms-customer_payment_form_action', 'cwms-customer_payment_form_nonce' ); ?>
        <input type="submit" style="display:none !important;" value="<?php esc_html_e('Submit Payment', 'wpcodigo_wms'); ?>">
        <table id="cwms_invoices_list_table" class="table">
            <thead>
                <tr>
                    <th colspan="2"><?php esc_html_e('Invoice Number', 'wpcodigo_wms'); ?></th>
                    <th><?php esc_html_e('Amount Paid', 'wpcodigo_wms'); ?></th>
                    <th><?php esc_html_e('Adjustment', 'wpcodigo_wms'); ?></th>
                    <th><?php esc_html_e('Amount', 'wpcodigo_wms'); ?></th>
                    <th><?php esc_html_e('Balance', 'wpcodigo_wms'); ?></th>
                </tr>
            </thead>
            <tbody>
                <tr class="empty-invoices"><td colspan="5"><?php esc_html_e('Select invoices for payment', 'wpcodigo_wms'); ?></td></tr>
            </tbody>
            <tfoot>
                <tr>
                    <th colspan="5" class="text-right"><?php esc_html_e('Total Balance', 'wpcodigo_wms'); ?></th>
                    <th class="total_balance">0.00</th>
                </tr>
            </tfoot>
        </table>
        <table id="cwms_invoices_payments_table" class="table d-none">
            <thead>
                <tr>
                    <th colspan="4"><a href="#" class="btn btn-sm btn-primary" data-toggle="modal" data-target="#cwms-customer_payment_registry-modal" style="float:right;"><?php esc_html_e('Add Payment', 'wpcodigo_wms'); ?></a></th>
                </tr>
                <tr>
                    <th colspan="2"><?php esc_html_e('Payment Type', 'wpcodigo_wms'); ?></th>
                    <th><?php esc_html_e('Status', 'wpcodigo_wms'); ?></th>
                    <th><?php esc_html_e('Amount', 'wpcodigo_wms'); ?></th>
                </tr>
            </thead>
            <tbody></tbody>
            <tfoot>
                <tr>
                    <th class="text-right" colspan="3"><?php esc_html_e('Total Payment', 'wpcodigo_wms'); ?></th>
                    <th class="payment_total"></th>
                </tr>
                <tr>
                    <th class="text-right" colspan="3"><?php esc_html_e('Paid Amount', 'wpcodigo_wms'); ?></th>
                    <th class="paid_amount"></th>
                </tr>
                <tr>
                    <th class="text-right" colspan="3"><?php esc_html_e('Payment Change', 'wpcodigo_wms'); ?></th>
                    <th class="payment_balance"></th>
                </tr>
                <tr>
                    <th colspan="4">
                        <div class="col-md-4" style="margin-bottom:18px;">
                            <p>
                                <label for="collection_date"><?php esc_html_e('Collection Date', 'wpcodigo_wms'); ?></label>
                                <input type="text" id="collection_date" class="form-control cwms-daterange_date" name="collection_date" readonly required="required">
                            </p>
                            <p class="select2-100">
                                <?php $agents = cwms1661_get_all_users( 'cwms_agent' ); ?>
                                <label for="agent_id"><?php esc_html_e('Agent/Salesman', 'wpcodigo_wms'); ?></label><br/>
                                <select id="agent_id" name="agent_id" data-action="cwms_search_salesman" data-placeholder="<?php echo esc_html('Search Agent/Salesman','wpcodigo_wms'); ?>" class="form-control form-control-sm cwms-select2" required="required">
                                    <option value=""><?php echo esc_html('Search Agent/Salesman','wpcodigo_wms'); ?></option>
                                    <?php foreach( $agents as $agent ): ?>
                                        <option value="<?php echo (int)$agent['ID']; ?>" ><?php echo esc_html( $agent['display_name'] ); ?></option>
                                    <?php endforeach; ?>
                                </select> 
                            </p>
                            <p>
                                <label for="receipt_number"><?php esc_html_e('Receipt Number (PR/CR)', 'wpcodigo_wms'); ?></label>
                                <input type="text" id="receipt_number" class="form-control" name="receipt_number" required="required">
                            </p>
                            <p>
                                <label for="paid_by"><?php esc_html_e('Paid by', 'wpcodigo_wms'); ?></label>
                                <input type="text" id="paid_by" class="form-control" name="paid_by" required="required">
                            </p>
                            <p>
                                <label for="payment_remarks"><?php esc_html_e('Remarks', 'wpcodigo_wms'); ?></label>
                                <textarea type="text" id="payment_remarks" class="form-control" name="payment_remarks" placeholder="<?php esc_html_e('Add remarks here.', 'wpcodigo_wms'); ?>"></textarea>
                            </p>
                        </div>
                    </th>
                </tr>
                <tr>
                    <th colspan="3"><button id="cwms-submit_payment"  type="button" class="btn btn-success"><?php esc_html_e('Submit Payment', 'wpcodigo_wms'); ?></button></th>
                </tr>
            </tfoot>
        </table>
    </form>
    <?php do_action('cwms1661_after_create_customer_payment_template'); ?>
</div>
<!-- Modals -->
<div id="cwms-customer_payment_registry-modal" class="cwms-modal modal fade" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog modal-md">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="<?php esc_html_e('Close', 'wpcodigo_wms'); ?>"><span aria-hidden="true">×</span>
                </button>
                <h4 class="modal-title" id="uploadLogoModalLabel"></h4>
            </div>
            <div class="modal-body">
                <?php include_once cwms1661_get_template_path( 'payment-form', 'reports/customer/templates', true ); ?>
            </div>
        </div>
    </div>
</div>