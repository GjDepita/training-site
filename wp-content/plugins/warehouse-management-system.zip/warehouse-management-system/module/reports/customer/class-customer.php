<?php
defined( 'ABSPATH' ) || exit;
/**
 * Product
 */
class CWMS1661_Customer {
    public static function init(){

        add_action('wp', array(__CLASS__, 'create_payment' ));
        add_action('wp', array(__CLASS__, 'update_payment' ));
        add_action( 'template_redirect', array( __CLASS__, 'save_redirection') );
        add_action( 'cwms1661_before_create_customer_payment_template', array(__CLASS__, 'notification_message' ) );

        add_filter( 'cwms1661_content_template_customers', array(__CLASS__, 'all_customers_template' ) );
        add_filter( 'cwms1661_content_template_customer', array(__CLASS__, 'customer_template' ) );
        // Script translation
        add_filter( 'cwms1661_report_localize_script_translations', array(__CLASS__,  'script_translations' ) );    
        // Ajax handlers
        add_action( 'wp_ajax_cwms_get_all_customers', array(__CLASS__,  'get_all_customers' ) );
        add_action( 'wp_ajax_cwms_get_customer_invoices', array(__CLASS__,  'get_customer_invoices' ) );
        add_action( 'wp_ajax_cwms_get_customer_unpaid_invoices', array(__CLASS__,  'get_customer_unpaid_invoices' ) );
        add_action( 'wp_ajax_cwms_get_customer_payments', array(__CLASS__,  'get_customer_payments' ) );
        add_action( 'wp_ajax_cwms_get_customer_payment_records', array(__CLASS__,  'customer_payment_records' ) );
        add_action( 'wp_ajax_cwms_get_customer_all_payments', array(__CLASS__,  'customer_all_payments' ) );
        add_action( 'wp_ajax_cwms_customer_update_payment_status', array(__CLASS__,  'customer_update_payment_status' ) );
        add_action( 'wp_ajax_cwms_get_customer_credit', array(__CLASS__,  'get_customer_credit' ) );
        add_action( 'wp_ajax_cwms_get_customer_unassigned_cheques', array(__CLASS__,  'get_customer_unassigned_cheques' ) );
        add_action( 'wp_ajax_cwms_get_customer_staled_cheques', array(__CLASS__,  'get_customer_staled_cheques' ) );
        add_action( 'wp_ajax_cwms_get_customer_credit_history', array(__CLASS__,  'get_customer_credit_history' ) );
        add_action( 'wp_ajax_cwms_search_unassigned_cheque', array(__CLASS__,  'search_unassigned_cheque' ) );

        // Permissions
        add_filter( 'cwms1661_permissions', array(__CLASS__, 'permissions' ) );
        // Menus 
        add_filter( 'cwms1661_registered_dashboard_pages', array(__CLASS__, 'page' ));
        add_filter( 'cwms1661_dashboard_report_sub_menu', array(__CLASS__, 'sub_menu' ), 5 );

        if( isset($_GET['action']) && $_GET['action'] == 'create-payment' && cwms1661_can_create_payment() ){
            add_filter( 'cwms1661_registered_dashboard_pages', function( $pages ){
                $user_name          = cwms1661_user_fullname( (int)$_GET['id'], 'cwms_customer' );
                $company_name       = get_user_meta( (int)$_GET['id'], '_company', true );
                $pages['customer']  =  sprintf( '<span style="font-size: .6em;">%s :</span> <span class="text-primary"><a href="%s">%s</a> <span style="font-size: .6em; color:#c5c5c5;text-transform: initial;">(%s)</span></span>', __('Payment for', 'wpcodigo_wms'), cwms1661_dashboard_home().'?cwmspage=customer&id='.(int)$_GET['id'], $company_name, $user_name );
                return $pages;
            });
        }      
        // Print
        add_filter( 'cwms1661_print_html_body_customer-invoice', array(__CLASS__, 'print' ), 10, 2 );
    }

    public static function create_payment(){
        if ( ! isset( $_REQUEST['cwms-customer_payment_form_nonce'] ) 
            || ! wp_verify_nonce( $_REQUEST['cwms-customer_payment_form_nonce'], 'cwms-customer_payment_form_action' ) 
        ) {
            return false;
        } 
        if( ! cwms1661_can_create_payment() ){
            printf( '<div id="message" class="error"><p>%s</p></div>', __('Permission denied. Please contact admin support', 'wpcodigo_wms') );
            wp_die();
        }

        $_REQUEST['time']   = time();
        $string             = urldecode( http_build_query( $_REQUEST ) );    
        $payment_key        = md5( $string );
        $created_by         = cwms1661_user_fullname( get_current_user_id() );
        $customer_id        = (int)$_REQUEST['id'];
        $agent_id           = (int)$_REQUEST['agent_id'];
        $customer_name      = cwms1661_user_fullname( $customer_id );
        $receipt_number     = sanitize_text_field( $_REQUEST['receipt_number'] );
        $paid_by            = sanitize_text_field( $_REQUEST['paid_by'] );
        $remarks            = sanitize_textarea_field( $_REQUEST['payment_remarks'] );
        $collected_date     = sanitize_textarea_field( $_REQUEST['collection_date'] );

        // Saved Invoices
        $invoice_ids        = [];
        $total_amount_paid  = 0;
        $total_payments     = 0;

        // Add payment to each invoices
        if( isset( $_REQUEST['payment_invoices'] ) && is_array( $_REQUEST['payment_invoices'] ) ){
            foreach ( $_REQUEST['payment_invoices'] as $invoice ) {
                $invoice_id   = (int)$invoice['id'];
                // Create invoice payment
                $payment_data = array(
                    'payment_key'   => $payment_key,
                    'invoice_id'    => $invoice_id,
                    'amount_paid'   => floatval( $invoice['amount_paid'] ),
                    'adjustment'    => floatval( $invoice['adjustment'] ),
                );              
                $payment_id = cwms_insert_payment( $payment_data );
                if( is_wp_error( $payment_id ) ){
                    continue;
                }         
                $total_amount_paid += floatval( $invoice['amount_paid'] );
                // Check the invoice if balance is Zero change the payment status into paid
                $invoice_payment_data = [];
                cwms1661_get_invoice_cost( $invoice_payment_data, $invoice_id );
                $payment_status  = $invoice_payment_data['_balance'] == 0 ? '_paid' : '_initial' ;
                cwms1661_set_invoice_status( $invoice_id, $payment_status );
                $invoice_ids[] = $invoice_id;

            }
        }

        // Save all payments created in table
        if( isset( $_REQUEST['payments'] ) && is_array( $_REQUEST['payments'] ) && !empty( $invoice_ids ) ){
            // Loop array of payments
            foreach ( $_REQUEST['payments'] as $payment ) {
                $payment_type   = sanitize_text_field( $payment['payment_type'] );
                $amount         = floatval( $payment['payment_amount'] );
                $cheque_number  = sanitize_text_field( $payment['cheque_number'] );
                $cheque_date    = sanitize_text_field( $payment['cheque_date'] );
                $cheque_bank    = sanitize_text_field( $payment['cheque_bank'] );
                $status         = sanitize_text_field( $payment['status'] );
                $payment_info   = array(
                    'receipt_number' => $receipt_number,
                    'payment_key'   => $payment_key,
                    'created_by'    => $created_by,
                    'collected_date' => $collected_date,
                    'agent_id'      => $agent_id,
                    'customer_id'   => $customer_id,
                    'paid_by'       => $paid_by,
                    'payment_type'  => $payment_type,
                    'amount'        => $amount,
                    'cheque_number' => $cheque_number,
                    'cheque_date'   => $cheque_date,
                    'cheque_bank'   => $cheque_bank,
                    'remarks'       => $remarks,
                    'status'        => $status
                );

                // Check is check payment is unassigned
                // set to assign
                $is_unassinged      = cwms1661_search_customer_cheque( $customer_id, $cheque_number );
                $_payment_process    = null;
                if( $is_unassinged ){
                    $payment_info['assigned'] = 1;
                    $_payment_process = cwms_update_payment_info( $is_unassinged['ID'], $payment_info );
                }else{
                    $_payment_process = cwms_insert_payment_info( $payment_info );
                }
                // Make sure that the payment process has no error
                if( $_payment_process ){
                    $total_payments += $amount;
                    // if the payment type is Credit, deduct the amount to user current credit
                    if( $payment_type == '_credit' ){
                        $credit_deduction_amount = floatval( $amount ) * -1;
                        cwms1661_update_customer_credit( (int)$_REQUEST['id'], $credit_deduction_amount );
                        // Add Credit History here
                        $credit_deduction_remarks   = sprintf( __( '%s is deducted to credit from Credit payment.', 'wpcodigo_wms'), $credit_deduction_amount );
                        $credit_deduction_history   = array(
                            'amount'        => $amount,
                            'customer_id'   => $customer_id,
                            'payment_key'   => null,
                            'created_by'    => $created_by,
                            'remarks'       => $credit_deduction_remarks,
                        );
                        cwms1661_add_credit_history( $credit_deduction_history );
                    }
                }
            }
        }

        // Add to credit when payment amount exceed to amount paid to invoices
        // Get total amount paid for invoices
        $payment_credit = $total_payments - $total_amount_paid;
        if( $payment_credit > 0 ){
            cwms1661_update_customer_credit( (int)$_REQUEST['id'], floatval( $payment_credit ) );
            // Add Credit History here
            $remarks   = sprintf( __( '%s credit added from new payments for %s', 'wpcodigo_wms'), cwms1661_format_number( $payment_credit, 2, ',' ), $customer_name );
            $credit_history = array(
                'amount'        => $payment_credit,
                'customer_id'   => $customer_id,
                'payment_key'   => $payment_key,
                'created_by'    => $created_by,
                'remarks'       => $remarks,
            );
            cwms1661_add_credit_history( $credit_history );
        }

        $unpaid_invoices = cwms1661_get_customer_unpaid_invoices( $customer_id );
        $redirection     = array(
            'cwmspage'  => 'customer',
            'id'        => (int)$_REQUEST['id'],
            'action'    => 'create-payment',
            'cwms-message'   => __('Payment successfully paid!', 'wpcodigo_wms')
        );
        if( empty( $unpaid_invoices ) ){
            unset( $redirection['action'] );
        }
        $_POST['cwms_customer_payment_redirection'] = $redirection;
    }

    public static function update_payment(){

        if ( ! isset( $_POST['cwms-update_customer_payment_form_nonce'] ) 
            || ! wp_verify_nonce( $_POST['cwms-update_customer_payment_form_nonce'], 'cwms-update_customer_payment_form_action' ) 
        ) {
            return false;
        } 
        if( ! cwms1661_can_create_payment() ){
            printf( '<div id="message" class="error"><p>%s</p></div>', __('Permission denied. Please contact admin support', 'wpcodigo_wms') );
            wp_die();
        }

        $assigned       = true;
        $customer_id    = (int)$_REQUEST['id'];
        $payment_id     = isset($_REQUEST['payment_id']) ? (int)$_REQUEST['payment_id'] : false;
        $status         = isset($_REQUEST['status']) ? sanitize_text_field( $_REQUEST['status'] ) : '';
        $payment_data   = cwms1661_get_payment_info( (int)$payment_id );
        $updated_by     = cwms1661_user_fullname( get_current_user_id() );
        
        if( ! $payment_data || ! array_key_exists( $status, cwms1661_payment_validation_status() ) ){
            printf( '<div id="message" class="error"><p>%s</p></div>', __('Permission denied. Please contact admin support', 'wpcodigo_wms') );
            wp_die();
        }  

        $payment_key    = $payment_data['payment_key'];
        $payments       = $payment_data['payments'];
        $payment_info   = $payment_data['payment_info'];
        // Remove the selected payment for update
        $found_key      = array_search( $payment_id, array_column( $payment_info, 'ID'));
        $selected_payment = $payment_info[$found_key];
        unset( $payment_info[$found_key] );

        $remarks      = sprintf( __( 'Cheque payment # %s is set from %s to %s.', 'wpcodigo_wms'), $selected_payment['cheque_number'], cwms1661_payment_validation_status()[$selected_payment['status']], cwms1661_payment_validation_status()[$status] );

        /* Check if status is "Stale"
         * TRUE - Set  all the invoices payments to status to 0 meaning the payments created is cancelled
         * Set the check payment to un assigned
         * Set the cash to CREDIT
        */
        $payment_history = array(
            'payment_id'    => $payment_id,
            'updated_by'    => $updated_by,
            'remarks'       => $remarks
        ); 

        // Update payment info status        
        if( $status == '_stale' ){
            $assigned = false; 
            cwms_update_payment_info_status( $payment_id, $status, $assigned );
            cwms1661_add_payment_history( $payment_history );

            // Update affected invoices and payments
            // Cancelled all invoices payments
            foreach( $payments as $invoice_payment ){
                
                // Get the invoice costing
                $curr_payment       = floatval( $invoice_payment['amount_paid'] ) + floatval( $invoice_payment['adjustment'] );
                $total_paid         = cwms_get_invoice_payments_total( $invoice_payment['invoice_id'] );
                $total_paid_adj     = floatval( $total_paid ) - floatval( $curr_payment );
                $invoice_status     = '_unpaid';
                if( $total_paid_adj > 0 ){
                    $invoice_status  = '_initial';
                }
                // Change invoice status
                cwms1661_set_invoice_status( $invoice_payment['invoice_id'], $invoice_status );
                // Cancel invoice payment
                cwms_cancel_invoice_payment( $invoice_payment['ID'] );

            }
            // Un assigned all Cheques and att to credit if cat payment
            foreach( $payment_info as $pay_info ){
                cwms_update_payment_info_status( $pay_info['ID'], $pay_info['status'], $assigned );
                // Add Check History here
                $payment_history['payment_id'] = $pay_info['ID'];
                cwms1661_add_payment_history( $payment_history );

                // Add cash payment to user Customer Credit
                if( $pay_info['payment_type'] == '_cash' || $pay_info['payment_type'] == '_credit' ){
                    $payment_type   = cwms1661_payment_types()[$pay_info['payment_type']];
                    $amount         = floatval($pay_info['amount']);
                    cwms1661_update_customer_credit( (int)$_REQUEST['id'], $amount );
                    // Add Credit History here
                    $_remarks   = $remarks.' '.sprintf( __( '%s is added to credit from %s payment.', 'wpcodigo_wms'), $amount, $payment_type );
                    $credit_history = array(
                        'amount'        => $amount,
                        'customer_id'   => $customer_id,
                        'payment_key'   => null,
                        'created_by'    => $updated_by,
                        'remarks'       => $_remarks,
                    );
                    cwms1661_add_credit_history( $credit_history );
                }
            }

            // Check if there is Credit during the payment 
            // Get the credit amount in the credit history using the payment key
            $credit_amount = cwms1661_get_credit_amount( $payment_key );
            if( $credit_amount ){
                $credit_amount  = floatval( $credit_amount ) * -1;
                $_remarks       = $remarks.' '.sprintf( __( '%s is deducted to credit, deducted amount is from credit added during payment.', 'wpcodigo_wms'), $credit_amount );
                $credit_history = array(
                    'amount'        => $credit_amount,
                    'customer_id'   => $customer_id,
                    'payment_key'   => null,
                    'created_by'    => $updated_by,
                    'remarks'       => $_remarks,
                );
                cwms1661_update_customer_credit( (int)$_REQUEST['id'], $credit_amount );
                cwms1661_add_credit_history( $credit_history );
            }
        
        }else{
            cwms_update_payment_info_status( $payment_id, $status, $assigned );
            cwms1661_add_payment_history( $payment_history );
        }

        $unpaid_invoices = cwms1661_get_customer_unpaid_invoices( $customer_id );
        $redirection     = array(
            'cwmspage'  => 'customer',
            'id'        => (int)$_REQUEST['id'],
            'action'    => 'create-payment',
            'cwms-message'   => __('Payment successfully paid!', 'wpcodigo_wms')
        );
        if( empty( $unpaid_invoices ) ){
            unset( $redirection['action'] );
        }
        $_POST['cwms_customer_payment_redirection'] = $redirection;
    }

    public static function all_customers_template(){
        if( ! cwms1661_can_view_customers() ){
            return cwms1661_get_template_path('403', 'dashboard');
        }
        return apply_filters( "cwms1661_get_template_all-customers", CWMS1661_ABSPATH.'module/reports/customer/templates/all-customers.php' );
    }
    public static function customer_template(){
        if( ! cwms1661_can_view_customers() || ! isset( $_GET['id'] ) || ! (int)$_GET['id'] ){
            return cwms1661_get_template_path('403', 'dashboard');
        }
        $user_info = cwms1661_user_fullname( (int)$_GET['id'], 'cwms_customer' );
        if( ! $user_info ){
            return cwms1661_get_template_path('403', 'dashboard');
        }
        if( isset($_GET['action']) && $_GET['action'] == 'create-payment' && cwms1661_can_create_payment() ){
            $unpaid_invoices = cwms1661_get_customer_unpaid_invoices( (int)$_GET['id'] );
            if( !empty( $unpaid_invoices ) ){
                return apply_filters( "cwms1661_get_template_customer-create-payment", CWMS1661_ABSPATH.'module/reports/customer/templates/create-payment.php' );
            }
            return apply_filters( "cwms1661_get_template_customer-nocreate-payment", CWMS1661_ABSPATH.'module/reports/customer/templates/nocreate-payment.php' );            
        }
        return apply_filters( "cwms1661_get_template_customer", CWMS1661_ABSPATH.'module/reports/customer/templates/customer.php' );
    }

    public static function script_translations( $translations ){
        $customerID  = isset( $_GET['cwmspage'] ) && $_GET['cwmspage'] == 'customer' && isset( $_GET['id'] ) ? $_GET['id'] : null;

        $translations['customerTableData'] = array(
            'id'                => 'cwms_customerTable',
            'drpID'             => 'cmws-customer_daterange',
            'custInvTableID'    => 'cwms_customer_invoiceTable',
            'headers'           => array_keys( cwms1661_customers_table_headers() ),
            'custInvTableHeaders' => array_keys( cwms1661_customers_invoice_table_headers() ),
            'paymentNo'         => __( 'Payment no.', 'wpcodigo_wms'),
            'invoiceNo'         => __( 'Invoice no.', 'wpcodigo_wms'),
            'createdBy'         => __( 'Created by', 'wpcodigo_wms'),
            'customerID'        => $customerID,
            'unpaidInvTableID'  => 'cwms_unpaidInvoiceTable',
            'allCustPaymentTableID' => 'cwms_customerAllPaymentsTable',
            'createPaymentForm' => 'cwms_customer_payment_form',
            'paymentTypes'      => cwms1661_payment_types(),
            'paymentValidations'=> cwms1661_payment_validation_status(),
        );
        return $translations;
    }

    public static function get_all_customers(){
        $data       = cwms1661_get_all_users( array( 'cwms_customer' ), null );
        if( $data ){
            $data = array_map( function( $value ) {
                $user_id     = (int)$value['ID'];
                $label_url   = esc_url_raw( cwms1661_dashboard_home().'?cwmspage=customer&id='.$user_id );
                $actions = [
                    'edit' => sprintf(
                        '<span class="edit"><a class="cwms-update_user text-primary" href="%s">%s</a> ',
                        esc_url_raw( cwms1661_dashboard_home().'?cwmspage=update-user&id='.$value['ID'] ),
                        esc_html__('Edit','wpcodigo_wms')
                    ),
                    'report'  => sprintf(
                        '<span class="view"><a class="text-primary" href="%s">%s</a></span>',
                        esc_url_raw( cwms1661_dashboard_home().'?cwmspage=customer&id='.$value['ID'] ),
                        esc_html__('View Report','wpcodigo_wms')
                    )
                ];
                ob_start();
                ?>
                    <strong data-id="<?php echo esc_attr($value['display_name']); ?>"><a href="<?php echo $label_url; ?>"><?php echo esc_html($value['display_name']); ?></a></strong>  
                    <br/><span class="text-muted"><?php echo cwms1661_user_status($user_id); ?></span>
                    <div class="row-actions" data-id="<?php echo $value['ID']; ?>">
                        <?php echo implode( ' | ', array_values( $actions ) ) ?>
                    </div>
                <?php
                $value['_name']     = ob_get_clean();
                $value['_address']  = cwms1661_display_address_html( $value );
                return $value;
            }, $data );
        }
        wp_send_json( array( 'data' => $data ) );
    }

    public static function get_customer_invoices(){
        $customet_id    = (int)$_GET['id'];
        $date_start     = sanitize_text_field( $_GET['start'] );
        $date_end       = sanitize_text_field( $_GET['end'] );
        $status         = sanitize_text_field( $_GET['status'] );
        $date_range     = array(
            'start' => $date_start,
            'end'   => $date_end
        );
        $data           = cwms1661_get_customer_invoice_data( $customet_id, $status, $date_range );
        if( $data ){
            $data = array_map( function( $value ) {
                $view_link      = cwms1661_dashboard_home().'?cwmspage=view-invoice&id=' . $value['ID'];
                $actions        = array(
                    sprintf( '<a href="%s" class="downloadPDF" data-id="%s" data-type="customer-invoice"><i class="fa fa-2x fa-file-pdf-o" title="%s" style="margin-right:12px;"></i></a>', '#', $value['ID'], __('Download PDF', 'wpcodigo_wms') )
                );
                ob_start();
                ?>
                    <strong data-id="<?php echo $value['ID']; ?>">
                        <a href="<?php echo esc_url($view_link); ?>"><?php echo esc_html($value['_invoice_number']); ?></a>
                    </strong> 
                <?php
                $value['_invoice_number']  = ob_get_clean();
                $value['_action']          = implode(" ", $actions);
                $value['_payment_status']  =  $value['_payment_status'] ? $value['_payment_status'] : __('Unpaid', 'wpcodigo_wms');
                return $value;
            }, $data );
        }
        wp_send_json( array( 'data' => $data ) );
    }

    public static function get_customer_unpaid_invoices(){
        $invoices = cwms1661_get_customer_unpaid_invoices( (int)$_GET['id'] );
        $data = [];
        if( $invoices ){
            $data = array_map( function( $invoice ){
                $total_amount       = cwms1661_get_invoice_total_amount( $invoice['id']);
                $total_paid         = cwms_get_invoice_payments_total( $invoice['id']);
                $balance            = floatval( $total_amount  ) - floatval( $total_paid );
                $invoice['total_amount'] = cwms1661_format_number($total_amount);
                $invoice['total_paid']   = cwms1661_format_number($total_paid);
                $invoice['balance']      = cwms1661_format_number($balance);
                $invoice['action']       = sprintf( '<i class="fa fa-2x fa-plus-circle text-success cursor-pointer addtopayment-invoices" title="%s" data-invoice="%s"></i>', __('Add to payment invoices', 'wpcodigo_wms'), htmlspecialchars(json_encode($invoice), ENT_QUOTES, 'UTF-8') );
                return $invoice;
            }, $invoices );
        }
        wp_send_json( array( 'data' => $data ) );
    }

    public static function get_customer_payments(){
        $customer_id    = (int)$_GET['id'];
        $curr_page      = sanitize_text_field( $_GET['currPage'] );
        $per_page       = sanitize_text_field( $_GET['perPage'] );
        $offset         =  ($curr_page-1) * $per_page; 
        $payments       = cwms1661_get_customer_payments_data( $customer_id, array(), $per_page, $offset );
        $payments        = array_map( function( $data ){
            $data['payment_no']         = str_pad( $data['ID'], 6, "0", STR_PAD_LEFT );
            $data['created_date']       = date( cwms1661_datetime_format(), strtotime( $data['created_date'] ) );
            return $data;
        }, $payments );
        wp_send_json( $payments );
    }
    public static function customer_payment_records(){
        $customer_id    = (int)$_GET['id'];
        $date_start     = sanitize_text_field( $_GET['start'] );
        $date_end       = sanitize_text_field( $_GET['end'] );
        $date_range     = array(
            'start' => $date_start,
            'end'   => $date_end
        );
        $payments       = cwms1661_get_customer_payments_data( $customer_id, $date_range );
        $payments        = array_map( function( $data ){
            $data['payment_no']         = str_pad( $data['ID'], 6, "0", STR_PAD_LEFT );
            $data['created_date']       = date( cwms1661_datetime_format(), strtotime( $data['created_date'] ) );
            return $data;
        }, $payments );
        wp_send_json( array( 'data' => $payments ) );
    }

    public static function customer_all_payments(){
        $customer_id    = (int)$_GET['id'];
        $date_start     = sanitize_text_field( $_GET['start'] );
        $date_end       = sanitize_text_field( $_GET['end'] );
        $status         = sanitize_text_field( $_GET['status'] );
        $type           = sanitize_text_field( $_GET['type'] );

        $date_range     = array(
            'start' => $date_start,
            'end'   => $date_end
        );

        $payments = cwms1661_get_customer_payment_info( $customer_id, $type, $status, $date_range );

        $payments = array_map( function( $data ){
            $class_icon             = $data['payment_type'] == "_cash" ? 'money' : 'barcode' ;
            $type_key               = $data['payment_type'];
            $status_key             = $data['status'];
            $data['payment_type']   = cwms1661_payment_types()[$type_key];
            $data['status']         = cwms1661_payment_validation_status()[$status_key];
            $data['actions']        = sprintf('<span data-toggle="modal" data-target="#cwms-update-check-payment-modal" class="fa fa-2x fa-%s cwms-customer_update_payment_status cursor-pointer" data-id="%d" data-prcr="%s" data-ptype="%s" data-ktype="%s" data-amount="%s" title="%s"></span>', $class_icon, $data['ID'], $data['receipt_number'], $data['payment_type'], $type_key, cwms1661_format_number( $data['amount'], 2, ',' ), __( 'Update payment status', 'wpcodigo_wms') );

            $data['receipt_number']   = sprintf(
                '<span data-toggle="modal" data-target="#cwms-update-check-payment-modal" class="cwms-customer_update_payment_status cursor-pointer" data-id="%d" data-prcr="%s" data-ptype="%s" data-ktype="%s" data-amount="%s" title="%s">%s</span>', $data['ID'], $data['receipt_number'], $data['payment_type'], $type_key, cwms1661_format_number( $data['amount'], 2, ',' ), __( 'Update payment status', 'wpcodigo_wms'), $data['receipt_number'] );
            return $data;
        }, $payments );

        wp_send_json( array( 'data' => $payments ) );

    }

    public static function customer_update_payment_status(){
        $payment_id     = (int)$_POST['paymentID'];
        $payment_info   = cwms1661_get_payment_info( $payment_id );
        $data           = [];
        if( !$payment_info ){
            $data['status']     = 'error';
            $data['message']    = __('Sorry cannot find payment information, please reload the page and try again.','wpcodigo_wms');
            wp_send_json( $data  );
        }

        $data['status']         = 'success';
        $data['message']        = __('Payment information found','wpcodigo_wms');
        $data['data']           = $payment_info;
        wp_send_json( $data  );
    }

    public static function get_customer_credit(){
        $customerID     = (int)$_POST['customerID'];
        wp_send_json( cwms1661_get_customer_credit( $customerID )  );
    }

    public static function get_customer_unassigned_cheques(){
        $customerID     = (int)$_GET['id'];
        $date_start     = sanitize_text_field( $_GET['start'] );
        $date_end       = sanitize_text_field( $_GET['end'] );
        $date_range     = array(
            'start' => $date_start,
            'end'   => $date_end
        );

        $payment_statuses = cwms1661_payment_validation_status();
        unset( $payment_statuses['_stale'] );
        $payment_status = array_keys( $payment_statuses );
        $data = cwms_get_customer_cheque_payments( $customerID, $payment_status, false, $date_range );
        if( !empty( $data ) ){
            $data = array_map( function( $payment ) use($payment_statuses) {
                $payment['status'] = $payment_statuses[ $payment['status'] ];
                return $payment;
            }, $data );
        }
        wp_send_json( array( 'data' => $data ) );
    }

    public static function search_unassigned_cheque(){
        global $wpdb;
        $search_string      = sanitize_text_field( trim( $_GET['q'] ) );
        $customer_id        = (int)$_GET['custID'];
        $parameter          = array( 'cwms-completed', CWMS1661_INVOICE_POST_TYPE, $customer_id, '%'. $search_string . '%' );
        $tbl_payments       = $wpdb->prefix.CWMS1661_TBL_PAYMENTS;
        $tbl_paymentinfo    = $wpdb->prefix.CWMS1661_TBL_PAYMENT_INFO;
        
        $tbl_columns   = $wpdb->get_col("DESC {$tbl_paymentinfo}", 0);
        $tbl_columns   = array_map( function( $column ) {
            return 'tblinfo.'.$column;
        }, $tbl_columns );

        $sql = "SELECT ".implode( ', ', $tbl_columns );
        $sql .= " FROM {$tbl_paymentinfo} AS tblinfo";
        $sql .= " INNER JOIN {$tbl_payments} AS tblpayment ON tblpayment.payment_key = tblinfo.payment_key";
        $sql .= " LEFT JOIN {$wpdb->posts} AS tblposts ON tblpayment.invoice_id = tblposts.ID";
        $sql .= " LEFT JOIN {$wpdb->postmeta} AS tblmeta ON tblpayment.invoice_id = tblmeta.post_id";
        $sql .= " WHERE tblposts.post_status LIKE %s";
        $sql .= " AND tblposts.post_type LIKE %s";
        $sql .= " AND tblmeta.meta_key LIKE '_customer_id'";
        $sql .= " AND tblmeta.meta_value = %d";
        $sql .= " AND tblinfo.payment_type LIKE '_cheque'";
        $sql .= " AND tblinfo.assigned = 0";
        $sql .= " AND tblinfo.status NOT LIKE '_stale'";
        $sql .= " AND tblinfo.cheque_number LIKE %s";

        $sql = $wpdb->prepare( $sql, $parameter );
        $checques       =  $wpdb->get_results( $sql, ARRAY_A );
        wp_send_json( $checques ); 
    }

    public static function get_customer_staled_cheques(){
        $customerID     = (int)$_GET['id'];
        $date_start     = sanitize_text_field( $_GET['start'] );
        $date_end       = sanitize_text_field( $_GET['end'] );
        $date_range     = array(
            'start' => $date_start,
            'end'   => $date_end
        );
        $payment_status = array( '_stale' );
        $data = cwms_get_customer_cheque_payments( $customerID, $payment_status, false, $date_range );
        wp_send_json( array( 'data' => $data ) );
    }

    public static function get_customer_credit_history(){
        $customer_id    = (int)$_POST['id'];
        $curr_page      = (int)$_POST['currPage'];
        $per_page       = (int)$_POST['perPage'];
        $offset         =  ($curr_page-1) * $per_page; 
        $credit_history  = cwms1661_get_credit_history( $customer_id, array(), $per_page, $offset );
        $credit_history  = array_map( function( $data ){
            $data['created_date']       = date( cwms1661_datetime_format(), strtotime( $data['created_date'] ) );
            return $data;
        }, $credit_history );
        wp_send_json( $credit_history );
    }

    public static function permissions( $permissions ){
        $permissions[60] = array(
            'label' => esc_html__('Customer Report', 'wpcodigo_wms' ),
			'options' => array(
                'cwms1661_can_view_customers_roles' => esc_html__('View', 'wpcodigo_wms' )
            )
        );
        return $permissions;
    }

    public static function page( $pages ){
        $pages['customer'] = esc_html__('Customer Report', 'wpcodigo_wms');
        return $pages;
    }

    public static function save_redirection(){
        if( !isset($_POST['cwms_customer_payment_redirection']) || !is_array($_POST['cwms_customer_payment_redirection']) ){
            return false;
        }
        wp_redirect( cwms1661_dashboard_home().'?'.http_build_query( $_POST['cwms_customer_payment_redirection'] ) );
        exit;
    }
    public static function notification_message(){
        if( !isset($_GET['cwmspage']) ){
            return false;
        }
        if( !isset($_GET['cwms-message']) || empty($_GET['cwms-message']) ){
            return false;
        }
        printf('<div class="submit-notification_message alert alert-success">%s</div>', urldecode($_GET['cwms-message']));
        $clear_parameter = ['cwms-message'];
        ?>        
        <script>
            window.history.replaceState({}, document.title, '<?php echo cwms1661_dashboard_home().'?'.cwms1661_clean_url_parameter($clear_parameter); ?>' );
            setTimeout(function(){
                jQuery('body').find('.submit-notification_message').remove();
            }, 6000 );
        </script>
        
        <?php
    }

    public static function  sub_menu( $sub_menus ){
        if( cwms1661_can_access_customers() ){
            $sub_menus['customers'] = esc_html__('Customers', 'wpcodigo_wms');
        }
        return $sub_menus;
    }
    public static function print( $file_path,  $print_id ){
        if( !(int)$print_id  ){
            return $file_path;
        }
        return apply_filters( "cwms1661_customer_invoice_print_template", CWMS1661_ABSPATH.'module/invoice/templates/print-invoice.php' );
    }
}