<?php 
    $general_settings   = cwms1661_get_general_settings(); 
?>
<div style="text-align:center; margin-bottom:12px;">
    <?php if($general_settings['_company_logo']):  ?>
        <img src="<?php echo $general_settings['_company_logo']; ?>" alt="<?php echo $general_settings['_company_name']; ?>" width="210">
    <?php else: ?>
        <h1 ><?php echo $general_settings['_company_name']; ?></h1>
    <?php endif; ?>
    <div style="margin-top:18px;">
        <span class="owner text-uppercase"><?php echo $general_settings['_owner']; ?> - PROP.</span></br>
        <span class="company-address"><?php echo $general_settings['_address']; ?></span><br/>
        <span class="company-address"><?php esc_html_e('VAT TIN', 'wpcodigo_wms'); ?>: <?php echo $general_settings['_vat_tin']; ?></span><br/>
        <?php esc_html_e('Phone', 'wpcodigo_wms'); ?>: <?php echo $general_settings['_phone']; ?>
    </div>
</div>
<div id="cwms1661_grossprofit-calculator-wrapper" class="row" style="margin-top:38px;">     
    <div class="x_panel tile" style="min-height:320px;">

        <section class="x_title" style="margin-bottom:36px; text-align:center;">
            <h4><?php echo esc_html('PROFIT AND LOSS STATEMENT', 'wpcodigo_wms'); ?><br/><?php printf( sanitize_text_field( $_POST['dateRange'] ) ); ?></h4>
        </section>

        <table >
            <tr>
                <td style="width:50%">
                    <h5><?php echo esc_html('REVENUE', 'wpcodigo_wms'); ?></h5>
                    <table class="bordered">
                        <tr>
                            <th><?php echo esc_html('Sales Revenue', 'wpcodigo_wms'); ?></th>
                            <td class="text-right w-130"><?php printf( to_cwms1661_currency( $_POST['revenueAmount'] ) ); ?></td>
                        </tr>
                        <tr>
                            <th><?php echo esc_html('Other Revenue', 'wpcodigo_wms'); ?></th>
                            <td class="text-right w-130"><?php printf( to_cwms1661_currency( $_POST['otherRevenueAmount'] ) ); ?></td>
                        </tr>
                        <tr>
                            <?php $total_revenue = floatval( $_POST['revenueAmount'] ) + floatval(  $_POST['otherRevenueAmount'] ); ?>
                            <th class="bg-fill"><?php echo esc_html('GROSS REVENUE', 'wpcodigo_wms'); ?></th>
                            <td class="__total_revenue bg-fill text-right w-130"><?php printf( to_cwms1661_currency( $total_revenue ) ); ?></td>
                        </tr>
                    </table>
                    <h5><?php echo esc_html('COST OF GOODS SOLD', 'wpcodigo_wms'); ?></h5>
                    <table id="cwms1661_grossprofit-cogs-table" class="bordered">
                        <tr>
                            <th><?php echo esc_html('COGS', 'wpcodigo_wms'); ?></th>
                            <td class="text-right w-130"><?php printf( to_cwms1661_currency( $_POST['cogsAmount'] ) ); ?></td>
                        </tr>
                        <tr>
                            <th class="bg-fill"><?php echo esc_html('TOTAL COGS', 'wpcodigo_wms'); ?></th>
                            <td class="text-right bg-fill w-130"><?php printf( to_cwms1661_currency( $_POST['cogsAmount'] ) ); ?></td>
                        </tr>
                    </table>
                    <h5 class="text-right"><?php echo esc_html('GROSS PROFIT', 'wpcodigo_wms'); ?></h5>
                    <table class="table">
                        <tr>
                            <?php $gross_profit = floatval( $total_revenue ) - floatval($_POST['cogsAmount']); ?>
                            <th class="text-right border-none"><?php echo esc_html('Gross Revenue minus COGS', 'wpcodigo_wms'); ?></th>
                            <td class="__gross_profit bg-fill bordered text-right w-130"><?php printf( to_cwms1661_currency( $gross_profit ) ); ?></td>
                        </tr>
                    </table>
                </td>
                <td style="width:50%">
                    <h5><?php echo esc_html('EXPENSES', 'wpcodigo_wms'); ?></h5>
                    <table id="cwms1661_grossprofit-expenses-table" class="bordered">
                        <?php $total_expenses = 0; ?>
                        <?php foreach( (array)$_POST['expensesData'] as $expense ): ?>
                            <?php $total_expenses += floatval($expense['amount']); ?>
                            <tr>
                                <th><?php echo sanitize_text_field( $expense['label'] ); ?></th>
                                <td class="text-right w-130"><?php echo to_cwms1661_currency( $expense['amount'] ); ?></td>
                            </tr>
                        <?php endforeach; ?>
                        <tr>
                            <th class="bg-fill"><?php echo esc_html('TOTAL EXPENSES', 'wpcodigo_wms'); ?></th>
                            <td class="__total_expense bg-fill text-right w-130"><?php echo to_cwms1661_currency( $total_expenses ); ?></td>
                        </tr>
                    </table>

                    <h5 class="text-right"><?php echo esc_html('NET INCOME', 'wpcodigo_wms'); ?></h5>
                    <table id="cwms1661_grossprofit-netincome-table" class="cwms1661_grossprofit_calctbl table">
                        <tr>
                            <?php $net_income = floatval($gross_profit) - floatval( $total_expenses ); ?>
                            <th class="text-right border-none"><?php echo esc_html('Gross Profit minus Espense', 'wpcodigo_wms'); ?></th>
                            <td class="__net_income bg-fill text-right bordered w-130"><?php echo to_cwms1661_currency( $net_income ); ?></td>
                        </tr>
                    </table>
                </td>
            </tr>
        </table>
    </div>
    <div style="margin-top: 38px;">
        <h5><?php echo esc_html('INVOICES', 'wpcodigo_wms'); ?></h5>
        <table class="bordered">
            <thead>
                <tr>
                    <?php foreach ( array_values( cwms1661_grossprofit_table_headers() ) as $label ): ?>
                        <th class="bg-fill"><?php echo sanitize_text_field( $label ); ?></th>
                    <?php endforeach; ?>
                </tr>
            </thead>
            <tbody>
                <?php
                $_totals = [];
                foreach ( array_keys( cwms1661_grossprofit_table_headers() ) as $_key) {
                    $_totals[ $_key ] = 0;
                }
                ?>
                <?php foreach ( (array)$_POST['records']  as $invoice ): ?>
                    <tr>
                        <?php foreach( $invoice as $_key => $_data ): ?>
                            <?php 
                                $value = $_key == '_invoice_number' ? sanitize_text_field($_data) : to_cwms1661_currency( $_data ); 
                                $_totals[$_key] += $_key == '_invoice_number' ? 0 : $_data;
                            ?>
                            <td><?php echo $value; ?></td>
                        <?php endforeach; ?>
                    </tr>
                <?php endforeach; ?>
            </tbody>
            <tfoot>
                <tr>
                    <?php foreach ( array_keys( cwms1661_grossprofit_table_headers() ) as $_key ): ?>
                        <?php $label =  $_key == '_invoice_number' ? __('TOTALS','wpcodigo_wms') : to_cwms1661_currency( $_totals[$_key] );  ?>
                        <th class="bg-fill"><?php echo sanitize_text_field( $label ); ?></th>
                    <?php endforeach; ?>
                </tr>
            </tfoot>
        </table>
    </div>
</div>