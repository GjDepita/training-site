<div id="cwms1661_grossprofit-calculator-wrapper" class="row" style="margin-top:38px;">     
    <div class="x_panel tile" style="min-height:320px;">

        <section class="x_title">
            <h4><?php echo esc_html('PROFIT AND LOSS STATEMENT', 'wpcodigo_wms'); ?> <?php printf( '%s <span class="gross-profit_daterange_header" ></span>', esc_html('as of', 'wpcodigo_wms' ) ); ?> <a href="#" class="btn btn-sm btn-primary cwms-download-profitloss-statement" style="float:right"> <i class="fa fa-file-pdf-o" title="<?php echo esc_html('Download', 'wpcodigo_wms'); ?>" style="margin-right:8px;"></i> <?php echo esc_html('Download', 'wpcodigo_wms'); ?></a></h4>
                
        </section>

        <section class="col-xs-12 col-sm-6 col-md-6">
            <h5><?php echo esc_html('REVENUE', 'wpcodigo_wms'); ?></h5>
            <table id="cwms1661_grossprofit-revenue-table" class="cwms1661_grossprofit_calctbl table table-bordered">
                <tr id="__sales_revenue">
                    <th><?php echo esc_html('Sales Revenue', 'wpcodigo_wms'); ?></th>
                    <td class="calc_amount __sales_revenue_data text-right" data-amount="0">0.00</td>
                </tr>
                <tr id="__other_revenue">
                    <th><?php echo esc_html('Other Revenue', 'wpcodigo_wms'); ?></th>
                    <td class="calc_amount __other_revenue_data text-right w-input" data-amount="0">
                        <input id="__other_revenue_field" type="text" class="form-control cmws-currency" placeholder="0.00">
                    </td>
                </tr>
                <tr>
                    <th class="bg-fill"><?php echo esc_html('GROSS REVENUE', 'wpcodigo_wms'); ?></th>
                    <td class="__total_revenue bg-fill text-right">0.00</td>
                </tr>
            </table>
            <h5><?php echo esc_html('COST OF GOODS SOLD', 'wpcodigo_wms'); ?></h5>
            <table id="cwms1661_grossprofit-cogs-table" class="cwms1661_grossprofit_calctbl table table-bordered">
                <tr id="__cogs">
                    <th><?php echo esc_html('COGS', 'wpcodigo_wms'); ?></th>
                    <td class="calc_amount __cogs_data text-right" data-amount="0">0.00</td>
                </tr>
                <tr>
                    <th class="bg-fill"><?php echo esc_html('TOTAL COGS', 'wpcodigo_wms'); ?></th>
                    <td class="__total_cogs bg-fill text-right">0.00</td>
                </tr>
            </table>
            <h5 class="text-right"><?php echo esc_html('GROSS PROFIT', 'wpcodigo_wms'); ?></h5>
            <table id="cwms1661_grossprofit-table" class="cwms1661_grossprofit_calctbl table">
                <tr>
                    <th class="text-right border-none"><?php echo esc_html('Gross Revenue minus COGS', 'wpcodigo_wms'); ?></th>
                    <td class="__gross_profit bg-fill bordered text-right">0.00</td>
                </tr>
            </table>
        </section>
        <section class="col-xs-12 col-sm-6 col-md-6">
            <h5><?php echo esc_html('EXPENSES', 'wpcodigo_wms'); ?></h5>
            <table id="cwms1661_grossprofit-expenses-table" class="cwms1661_grossprofit_calctbl table table-bordered">
                <tr id="__wages_benefits">
                    <th><?php echo esc_html('Wages and Benefits', 'wpcodigo_wms'); ?></th>
                    <td class="calc_amount __wages_benefits_data text-right w-input" data-amount="0">
                        <input id="__wages_benefits_data_field" type="text" class="form-control cmws-currency" placeholder="0.00">
                    </td>
                </tr>
                <tr id="__rent_mortage">
                    <th><?php echo esc_html('Rent / Mortage', 'wpcodigo_wms'); ?></th>
                    <td class="calc_amount __rent_mortage text-right w-input" data-amount="0">
                        <input id="__rent_mortage_field" type="text" class="form-control cmws-currency" placeholder="0.00">
                    </td>
                </tr>
                <tr id="__utilities">
                    <th><?php echo esc_html('Utilities', 'wpcodigo_wms'); ?></th>
                    <td class="calc_amount __utilities text-right w-input" data-amount="0">
                        <input id="__utilities_field" type="text" class="form-control cmws-currency" placeholder="0.00">
                    </td>
                </tr>
                <tr id="__office_supplies">
                    <th><?php echo esc_html('Office Supplies', 'wpcodigo_wms'); ?></th>
                    <td class="calc_amount __office_supplies text-right w-input" data-amount="0">
                        <input id="__office_supplies_field" type="text" class="form-control cmws-currency" placeholder="0.00">
                    </td>
                </tr>
                <tr id="__taxes">
                    <th><?php echo esc_html('Taxes', 'wpcodigo_wms'); ?></th>
                    <td class="calc_amount __taxes text-right w-input" data-amount="0">
                        <input id="__taxes_field" type="text" class="form-control cmws-currency" placeholder="0.00">
                    </td>
                </tr>
                <tr id="__other_expenses">
                    <th><?php echo esc_html('Other Expenses', 'wpcodigo_wms'); ?></th>
                    <td class="calc_amount __other_expenses text-right w-input" data-amount="0">
                        <input id="__other_expenses_field" type="text" class="form-control cmws-currency" placeholder="0.00">
                    </td>
                </tr>
                <tr>
                    <th class="bg-fill"><?php echo esc_html('TOTAL EXPENSES', 'wpcodigo_wms'); ?></th>
                    <td class="__total_expense bg-fill text-right">0.00</td>
                </tr>
            </table>

            <h5 class="text-right"><?php echo esc_html('NET INCOME', 'wpcodigo_wms'); ?></h5>
            <table id="cwms1661_grossprofit-netincome-table" class="cwms1661_grossprofit_calctbl table">
                <tr>
                    <th class="text-right border-none"><?php echo esc_html('Gross Profit minus Espense', 'wpcodigo_wms'); ?></th>
                    <td class="__net_income bg-fill text-right bordered">0.00</td>
                </tr>
            </table>
        </section>
    </div>
</div>