<?php
    $table_headers = cwms1661_grossprofit_table_headers();
?>
<div class="filter-section profile_title" style="margin-bottom:18px; flex-direction:row; justify-content:space-between; align-content: center;
">
    <section class="filter-wrapper" style="margin-left:12px;">
        <input id="gross-profit_daterange_filter" type="text" class="form-control form-control-sm" style="width:210px;display:inline-block;" value="" />
    </section>
    <section class="filter-wrapper" style="margin-right:12px;">
        <p style="margin:0;"><?php printf( '%s <span class="gross-profit_daterange_header" ></span>', esc_html('Report as of', 'wpcodigo_wms' ) ); ?></p>
    </section>
</div>
<h4><?php echo esc_html('Invoices', 'wpcodigo_wms' ); ?></h4>
<div id="cwms1661_grossprofit-content-wrapper" style="min-height: 180px;">
    <table id="cwms_grossProfitInvoiceTable" class="wcms1661_dataTable display" style="width:100%">
        <thead>
            <tr>
                <?php foreach( $table_headers as $metakey => $label ): ?>
                    <th><?php echo apply_filters('cwms1661_grossprofit_table_headers_label_'.$metakey , $label ); ?></th>
                <?php endforeach; ?>
            </tr>
        </thead>
        <tfoot>
            <tr>
                <?php foreach( $table_headers as $metakey => $label ): ?>
                    <?php $placeholder = $metakey != '_invoice_number' ? '0.00' : '' ; ?> 
                    <th class="<?php echo esc_attr($metakey); ?>"><?php echo $placeholder; ?></th>
                <?php endforeach; ?>
            </tr>
        </tfoot>
    </table> 
    <?php include_once CWMS1661_ABSPATH.'module/reports/gross-profit/templates/calculator.php' ?>
</div>