<?php
defined( 'ABSPATH' ) || exit;
/**
 * Payment
 */
require_once CWMS1661_ABSPATH . 'lib/dompdf/vendor/autoload.php';

use Dompdf\Dompdf;
use Dompdf\Options;

class CWMS1661_Gross_Profit {

    private static $template_dir = CWMS1661_ABSPATH.'module/reports/gross-profit/templates/';

    public static function init(){

        if( ! can_access_cwms1661_gross_profit() ){
            return false;
        }

        add_filter( 'cwms1661_content_template_gross-profit', array(__CLASS__, 'all_templates' ) );

        // Menus 
        add_filter( 'cwms1661_registered_dashboard_pages', array(__CLASS__, 'page' ));
        add_filter( 'cwms1661_dashboard_report_sub_menu', array(__CLASS__, 'sub_menu' ), 99 );

        // Ajax handler
        add_action( 'wp_ajax_cwms_get_grossprofit_records', array(__CLASS__,  'get_records' ) );
        add_action( 'wp_ajax_cwms_download_grossprofit_statement', array(__CLASS__,  'download' ) );

        // Script translation
        add_filter( 'cwms1661_report_localize_script_translations', array(__CLASS__,  'script_translations' ) );

    }

    public static function all_templates(){
        if( ! can_access_cwms1661_gross_profit() ){
            return cwms1661_get_template_path('403', 'dashboard');
        }
        return apply_filters( "cwms1661_get_template_gross-profit", self::$template_dir. 'gross-profit.php' );
    }

    public static function page( $pages ){
        if( ! can_access_cwms1661_gross_profit() ){
            return $pages;
        }
        $pages['gross-profit_report'] = esc_html__('Gross Profit Report', 'wpcodigo_wms');
        return $pages;
    }

    public static function  sub_menu( $sub_menus ){
        if( ! can_access_cwms1661_gross_profit() ){
            return $sub_menus;
        }
        $sub_menus['gross-profit'] = esc_html__('Gross Profit-loss', 'wpcodigo_wms');
        return $sub_menus;
    }

    public static function get_records(){
        $datesRange = (array)$_POST['datesRange'];
        // Get all invoices with the give date range
        // Make sure that the invoice status is completed
        $invoices = cwms1661_grossprofit_invoices( array_values( $datesRange ) );
        $records  = [];
        if( !empty( $invoices ) ){
            foreach ($invoices as $invoice ) {

                $data = [];
                cwms1661_get_invoice_cost( $data, $invoice['ID'] );

                $_cost_price      = 0;
                $_retail_price    = 0;
                $_discount        = 0;

                foreach( $data['_products'] as $product ){
                    $qty              = floatval( $product['qty_delivered'] );
                    $_cost_price      += $qty * floatval( $product['cost_price'] );
                    $_retail_price    += $qty * floatval( $product['retail_price'] );
                    $_discount        += $qty * floatval( $product['discount_amount'] );
                }

                $gross_profit  = array(
                    '_invoice_number'       => $invoice['_invoice_number'],
                    '_cost_price'           => $_cost_price,
                    '_retail_price'         => $_retail_price,
                    '_discount'             => $_discount,
                    '_cod_discount'         => $data['_cod_discount'],
                    '_tax'                  => $data['_tax'],
                    '_others'               => $data['_others'],
                    '_total_amount'         => $data['_total_amount'],
                );

                $records[] = apply_filters( 'cwms1661_grossprofit_data', $gross_profit, $invoice );

            }
        }
        wp_send_json( array(
            'data' => $records,
            'datesRange' => $datesRange
        ) );
    }

    public static function download(){
        
        
        $directory    = CWMS1661_ABSPATH.'module/print/storage/';
        // Check if directory exist
        if( !is_dir( $directory ) ){
            mkdir( $directory );
        }

        // Clean directory before adding new file
        foreach( glob($directory.'*.pdf') as $pdf_file){
            unlink($pdf_file);
        }
        $pdf_title 	    = 'profit-loss-statement-'.sanitize_text_field( $_POST['dateRange'] );	
        // instantiate and use the dompdf class
        $options 		= new Options();
        $options->setDpi( 160 );
        $options->set('isRemoteEnabled', true);
        $dompdf 		= new Dompdf( $options );
        $dompdf->setPaper( CWMS1661_PDF_PAPER_SIZE, 'portrait');
        $dompdf->loadHtml( self::print_statment( $_POST ), 'UTF-8' );
        $dompdf->render();
        self::pdf_marker( $dompdf );

        $output = $dompdf->output();
        $data_info = array();
        if( file_put_contents( $directory.$pdf_title.'.pdf', $output) ){
            $data_info = array(
                'file_url' => CWMS1661_PLUGIN_URL.'module/print/storage/'.$pdf_title.'.pdf',
                'file_name' => $pdf_title
            );  
        }
        wp_send_json( $data_info );
    }

    public static function pdf_marker( $dompdf ){

        $font_family    = apply_filters( 'cwms1661_pdf_pagination_font_family', 'Helvetica' );
        $font_type      = apply_filters( 'cwms1661_pdf_pagination_font_type', 'normal' );
        $x              = apply_filters( 'cwms1661_pdf_pagination_x_axis', 4 );
        $y              = apply_filters( 'cwms1661_pdf_pagination_y_axis', 4 );
        $text           = sprintf( __( 'Printed by: %s', 'wpcodigo_wms' ), cwms1661_user_fullname( get_current_user_id() ) );
        $font           = $dompdf->getFontMetrics()->get_font($font_family, $font_type);   
        $size           = apply_filters( 'cwms1661_pdf_pagination_font_size', 8 );    
        $color          = array(0,0,0);
        $word_space     = 0.0;
        $char_space     = 0.0;
        $angle          = 0.0;
        $dompdf->getCanvas()->page_text(
            $x, $y, $text, $font, $size, $color, $word_space, $char_space, $angle
        );

    }

    public static function print_statment( $data ){
        ob_start();
        self::header( $data );
        self::body( $data );
        self::footer( $data );
        return ob_get_clean();
    }
    public static function header( $data ){
        include_once cwms1661_get_template_path( 'print_header', 'reports/gross-profit/templates/', true );
    }
    public static function body( $data ){
        $file_path = cwms1661_get_template_path( 'print_body', 'reports/gross-profit/templates/', true );
        include_once apply_filters( 'cwms1661_gross_profit_statement_print_html_body', $file_path, $data);
    }
    public static function footer( $data ){
        include_once cwms1661_get_template_path( 'print_footer', 'reports/gross-profit/templates/', true );
    }

    public static function script_translations( $translations ){
        $translations['grossProfitTable'] = array(
            'tblInvoiceID'  => 'cwms_grossProfitInvoiceTable',
            'tblPOID'       => 'cwms_grossProfitPOTable',
            'headers'       => array_keys( cwms1661_grossprofit_table_headers() ),
            'errorMessage'  => __('Sorry cannot process request, no record to process.', 'wpcodigo_wms')
        );
        return $translations;
    }
}