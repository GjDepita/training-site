<?php 
defined( 'ABSPATH' ) || exit;

function cwms1661_grossprofit_table_headers(){
    $fields = array(
        '_invoice_number'       => __('Invoice No.', 'wpcodigo_wms' ),
        '_cost_price'           => __('Cost Amount', 'wpcodigo_wms' ),
        '_retail_price'         => __('Retail Amount', 'wpcodigo_wms' ),
        '_discount'             => __('Discount', 'wpcodigo_wms' ),
        '_cod_discount'         => __('COD Discount', 'wpcodigo_wms' ),
        '_tax'                  => __('Tax', 'wpcodigo_wms' ),
        '_others'               => __('Others', 'wpcodigo_wms' ),
        '_total_amount'         => __('Total Amount', 'wpcodigo_wms' ),
    );
    return apply_filters( 'cwms1661_grossprofit_table_headers', $fields );
}
function cwms1661_grossprofit_invoices( $daterange, $page = null, $limit = 12 ){
    global $wpdb;
    $parameter = array( 'cwms-completed', CWMS1661_INVOICE_POST_TYPE );
    $parameter = array_merge( $parameter, array_values( $daterange ) );
    $sql = "SELECT `ID`, `post_title` AS '_invoice_number'";
    $sql .= " FROM {$wpdb->posts}";
    $sql .= " WHERE `post_status` LIKE %s AND `post_type` LIKE %s";
    $sql .= " AND CAST( `post_date` as date) between %s and %s";
    if( $page ){
        $offset = ($page - 1) * $limit;
        $sql .= " LIMIT %d OFFSET %d";
        $parameter = array_merge( $parameter, array( $limit, $offset ) );
    }
    $sql    .= " ORDER BY `post_date` DESC";
    $sql     = $wpdb->prepare( $sql, $parameter);
    return  $wpdb->get_results( apply_filters( 'cwms1661_grossprofit_invoices_sql', $sql, $daterange, $page, $limit ), ARRAY_A );
}