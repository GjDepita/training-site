<?php 
    $general_settings   = cwms1661_get_general_settings(); 
?>
<div style="text-align:center; margin-bottom:12px;">
    <?php if($general_settings['_company_logo']):  ?>
        <img src="<?php echo $general_settings['_company_logo']; ?>" alt="<?php echo $general_settings['_company_name']; ?>" width="210">
    <?php else: ?>
        <h1 ><?php echo $general_settings['_company_name']; ?></h1>
    <?php endif; ?>
    <div style="margin-top:18px;">
        <span class="owner text-uppercase"><?php echo $general_settings['_owner']; ?> - PROP.</span></br>
        <span class="company-address"><?php echo $general_settings['_address']; ?></span><br/>
        <span class="company-address"><?php esc_html_e('VAT TIN', 'wpcodigo_wms'); ?>: <?php echo $general_settings['_vat_tin']; ?></span><br/>
        <?php esc_html_e('Phone', 'wpcodigo_wms'); ?>: <?php echo $general_settings['_phone']; ?>
    </div>
</div>
<div id="title" style="text-align:center; margin-bottom:12px;">
    <h2 style="maring-bottom:0;"><?php printf(__('SUMMARY OF COLLECTION REPORT %s', 'wpcodigo_wms'), strftime( '%Y', strtotime( $data['report_date'] ) ) ); ?></h2>
    <p><?php printf( __('As of %s', 'wpcodigo_wms'), strftime( '%B %d, %Y', strtotime( $data['report_date'] ) ) ); ?></p>
</div>
<div id="content">
        <table class="bordered header-black min-space">
            <thead>
                <tr>
                    <th class="text-left"><?php esc_html_e('Salesman', 'wpcodigo_wms'); ?></th>
                    <?php foreach( $data['tbl_column_headers'] as $month ): ?>
                        <th><?php echo esc_html( $month ); ?></th>
                    <?php endforeach; ?>
                    <th class="text-right"><?php esc_html_e('Salesman Total', 'wpcodigo_wms'); ?></th>
                </tr>
            </thead>
            <tbody>
                <?php foreach( $data['salesmen'] as $salesman ): ?>
                    <?php 
                        $total_collection = 0; 
                        $can_calculate    = true;
                        $acc_sales        = 0;
                    ?>
                    <tr>
                        <td><?php echo esc_html( $salesman->display_name ); ?></td>
                        <?php foreach( $data['records'] as $record ): ?>
                            <?php 
                                $monthly_collection = $record['salesmen_records'][$salesman->ID]['amount'];
                                $total_collection += $monthly_collection; 
                                $acc_sales        += $monthly_collection; 
                                // Stop accumulated cost when meet the last date of query
                                if( !$can_calculate ){
                                    $acc_sales   = 0;
                                }
                                if( $record['status'] ){
                                    $can_calculate = false;
                                }
                            ?>
                            <td><?php echo cwms1661_format_number( $acc_sales, 2, ',' ); ?></td>
                        <?php endforeach; ?>
                        <td class="text-right"><?php echo cwms1661_format_number( $total_collection, 2, ',' ); ?></td>
                    </tr>
                    <?php $month_collections[] = $total_collection; ?>
                <?php endforeach; ?>
            </tbody>
            <tfoot>
                <tr>
                    <th class="text-left"><?php esc_html_e('Monthly Total', 'wpcodigo_wms'); ?></th>
                    <?php $yearly_total = 0; ?>
                    <?php foreach( $data['records'] as $record ): ?>
                        <?php 
                           $total_monthly_collection = array_reduce( $record['salesmen_records'], function( $carry, $item ){
                                $carry += $item['amount'];
                                return $carry;
                           }, 0 );
                           $yearly_total += $total_monthly_collection;
                        ?>
                        <th class="text-left" ><?php echo cwms1661_format_number( $total_monthly_collection, 2, ',' ); ?></th>
                    <?php endforeach; ?>
                    <th class="text-right" ><?php echo cwms1661_format_number( $yearly_total, 2, ',' ); ?></th>
                </tr>
            </tfoot>
        </table>
</div>