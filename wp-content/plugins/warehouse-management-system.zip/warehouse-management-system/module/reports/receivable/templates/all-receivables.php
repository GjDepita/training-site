<?php 
    $table_headers      = cwms1661_receivable_table_headers(); 
    $invoice_statuses   = cwms1661_invoice_payment_statuses();
    $invoice_statuses['_paid']          = __('Collections', 'wpcodigo_wms');
    $invoice_statuses['_receivables']   = __('Receivables', 'wpcodigo_wms');
    $invoice_statuses                   = array_reverse($invoice_statuses);

    $area_states        = cwms1661_get_user_area('state');
    $area_cities        = cwms1661_get_user_area('city');
?>
<div class="filter-section profile_title" style="margin-bottom:18px;">
    <section class="filter-wrapper" style="margin-right:12px;">
        <select id="receivable_salesman_filter" data-action="cwms_search_salesman" data-placeholder="<?php echo esc_html('All Salesman','wpcodigo_wms'); ?>" class="form-control form-control-sm" style="width:180px;margin-right:8px;display:inline-block;">
            <option value=""><?php echo esc_html('All Salesman','wpcodigo_wms'); ?></option>
        </select> 
    </section>
    <section class="filter-wrapper" style="margin-right:12px;">
        <select id="receivable_customer_filter" data-action="cwms_search_customer" data-placeholder="<?php echo esc_html('All Customer','wpcodigo_wms'); ?>" class="form-control form-control-sm" style="width:180px;margin-right:8px;display:inline-block;">
            <option value=""><?php echo esc_html('All Customer','wpcodigo_wms'); ?></option>
        </select>
    </section>
    <section class="filter-wrapper" style="margin-right:12px;">
        <select id="receivable_invoice_filter" data-placeholder="<?php echo esc_html('All Invoices','wpcodigo_wms'); ?>" class="form-control form-control-sm" style="width:180px;margin-right:8px;display:inline-block;">
            <option value=""><?php echo esc_html('All Invoices','wpcodigo_wms'); ?></option>
            <?php foreach( $invoice_statuses as $key => $status ): ?>
                <option value="<?php echo esc_attr( $key ); ?>"><?php echo esc_html( $status ); ?></option>
            <?php endforeach; ?>
        </select>
    </section>
    <?php if( $area_cities ): ?>
        <section class="filter-wrapper" style="margin-right:12px;">
            <select id="receivable_city_filter" data-placeholder="<?php echo esc_html('All Cities','wpcodigo_wms'); ?>" class="form-control form-control-sm" style="width:180px;margin-right:8px;display:inline-block;">
                <option value=""><?php echo esc_html('All Cities','wpcodigo_wms'); ?></option>
                <?php foreach( $area_cities as $city ): ?>
                    <option value="<?php echo esc_attr( $city ); ?>"><?php echo esc_html( $city ); ?></option>
                <?php endforeach; ?>
            </select>
        </section>
    <?php endif; ?>
    <?php if( $area_states ): ?>
        <section class="filter-wrapper" style="margin-right:12px;">
            <select id="receivable_state_filter" data-placeholder="<?php echo esc_html('All States','wpcodigo_wms'); ?>" class="form-control form-control-sm" style="width:180px;margin-right:8px;display:inline-block;">
                <option value=""><?php echo esc_html('All States','wpcodigo_wms'); ?></option>
                <?php foreach( $area_states as $state ): ?>
                    <option value="<?php echo esc_attr( $state ); ?>"><?php echo esc_html( $state ); ?></option>
                <?php endforeach; ?>
            </select>
        </section>
    <?php endif; ?>
    <section class="filter-wrapper" style="margin-right:12px;">
        <input id="receivable_daterange_filter" type="text" class="form-control form-control-sm" style="width:210px;display:inline-block;" value="" />
    </section>
</div>

<table id="cwms_receivableTable" class="wcms1661_dataTable table-responsive display" style="width:100%">
    <thead>
        <tr>
            <?php foreach( $table_headers as $metakey => $label ): ?>
                <th><?php echo apply_filters('cwms1661_receivable_table_headers_label_'.$metakey , $label ); ?></th>
            <?php endforeach; ?>
        </tr>
    </thead>
    <tfoot>
        <tr>
            <?php foreach( $table_headers as $metakey => $label ): ?>
                <th><?php echo apply_filters('cwms1661_receivable_table_headers_label_'.$metakey , $label ); ?></th>
            <?php endforeach; ?>
        </tr>
    </tfoot>
</table>    
<div id="receivable_table_report" class="text-center">
    <p><?php echo esc_html('Date','wpcodigo_wms'); ?>: <strong><span class="receivable_daterange"></span></strong></p>
    <p><?php echo esc_html('Customer','wpcodigo_wms'); ?>: <strong><span class="receivable_customer"></span></strong></p>
    <p><?php echo esc_html('Salesman','wpcodigo_wms'); ?>: <strong><span class="receivable_salesman"></span></strong></p>
    <p><?php echo esc_html('City','wpcodigo_wms'); ?>: <strong><span class="receivable_city"></span></strong></p>
    <p><?php echo esc_html('State','wpcodigo_wms'); ?>: <strong><span class="receivable_state"></span></strong></p>
    <p><?php echo esc_html('Status','wpcodigo_wms'); ?>: <strong><span class="receivable_status"></span></strong></p>
    <h4><?php echo esc_html('Total Amount','wpcodigo_wms'); ?>: <span class="receivable_total_amount">0.00</span></h4>
    <h4><?php echo esc_html('Total Balance','wpcodigo_wms'); ?>: <span class="receivable_total_balance">0.00</span></h4>
</div>