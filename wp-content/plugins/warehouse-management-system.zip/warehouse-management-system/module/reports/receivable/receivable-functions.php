<?php 
defined( 'ABSPATH' ) || exit;

function cwms1661_receivable_table_headers(){

    $fields = array(
        '_invoice_number'   => __('Invoice #', 'wpcodigo_wms' ),
        '_dr_no'            => __('DR #.', 'wpcodigo_wms' ),
        '_date_created'     => __('Date Created', 'wpcodigo_wms' ),
        '_customer_company' => __('Company Name', 'wpcodigo_wms' ),
        '_salesman'         => __('Salesman', 'wpcodigo_wms' ),
        '_total_amount_cur' => __('Amount', 'wpcodigo_wms' ),
        '_balance_cur'      => __('Balance', 'wpcodigo_wms' ),
        '_terms'            => __('Terms', 'wpcodigo_wms' ),
        '_dr_age'           => __('Age of DR', 'wpcodigo_wms' ),
        '_payment_status'   => __('Status', 'wpcodigo_wms' ),
    );

    return apply_filters( 'cwms1661_receivable_table_headers', $fields );
}
function cwms1661_get_receivables_by_date( $date_start, $date_end, $customer_id = null, $agent_id = null, $status = null, $city = null, $state = null ){
    global $wpdb;

    $parameter = [ CWMS1661_INVOICE_POST_TYPE ];
    $sql = "SELECT `ID` as 'id'";
    $sql .= " FROM {$wpdb->posts} AS tblposts";
    
    if( $status ){
        $sql .= " LEFT JOIN {$wpdb->postmeta} AS tblstatus ON  tblposts.ID = tblstatus.post_id";
    }
    if( $customer_id ){
        $sql .= " LEFT JOIN {$wpdb->postmeta} AS tblcustomer ON  tblposts.ID = tblcustomer.post_id";
    }
    if( $agent_id ){
        $sql .= " LEFT JOIN {$wpdb->postmeta} AS tblagent ON  tblposts.ID = tblagent.post_id";
    }
    if( $city ){
        $sql .= " LEFT JOIN {$wpdb->postmeta} AS tblcity ON  tblposts.ID = tblcity.post_id";
    }
    if( $state ){
        $sql .= " LEFT JOIN {$wpdb->postmeta} AS tblstate ON  tblposts.ID = tblstate.post_id";
    }

    $sql .= " WHERE tblposts.post_status LIKE 'cwms-completed' AND tblposts.post_type LIKE %s";

    if( $date_start && $date_end ){
        $sql .= " AND CAST( tblposts.post_date AS DATE) BETWEEN %s AND %s";
        $parameter[] = $date_start;
        $parameter[] = $date_end;
    }
    
    if( $status ){
        $payment_keys = array_keys( cwms1661_invoice_payment_statuses() );
        if( in_array( $status, $payment_keys ) ){
            $sql .= " AND tblstatus.meta_key LIKE '_payment_status' AND tblstatus.meta_value LIKE %s";
            $parameter[] = sanitize_text_field($status);
        }else{
            $sql .= " AND tblstatus.meta_key LIKE '_payment_status' AND tblstatus.meta_value NOT LIKE '_paid'";
        }
    }
    if( $customer_id ){
        $sql .= " AND tblcustomer.meta_key LIKE '_customer_id' AND tblcustomer.meta_value = %d";
        $parameter[] = (int)$customer_id;
    }
    if( $agent_id ){
        $sql .= " AND tblagent.meta_key LIKE '_assigned_agent' AND tblagent.meta_value = %d";
        $parameter[] = (int)$agent_id;
    }
    if( $city ){
        $sql .= " AND tblcity.meta_key LIKE '_city' AND tblcity.meta_value = %s";
        $parameter[] = sanitize_text_field($city);
    }
    if( $state ){
        $sql .= " AND tblstate.meta_key LIKE '_state' AND tblstate.meta_value = %s";
        $parameter[] = sanitize_text_field($state);
    }
    $sql = $wpdb->prepare( $sql, $parameter);
    return $wpdb->get_col( apply_filters( 'cwms1661_get_receivables_by_date_sql', $sql, $parameter ) );
}


function cwms1661_get_all_receivable_data( $limit = null, $offset = 0 ){
    global $wpdb;
    $parameter = array( CWMS1661_INVOICE_POST_TYPE );
    $sql = "SELECT `ID` as 'id'";
    $sql .= " FROM {$wpdb->posts} AS tblposts";
    $sql .= " LEFT JOIN {$wpdb->postmeta} AS tblmeta ON  tblposts.ID = tblmeta.post_id";
    $sql .= " WHERE tblposts.post_status LIKE 'cwms-completed' AND tblposts.post_type LIKE %s";
    $sql .= " AND tblmeta.meta_key LIKE '_payment_status' AND tblmeta.meta_value != '_paid' ";
    if( $limit ){
        $sql .= " LIMIT %d OFFSET %d";
        $parameter = array_merge( $parameter, array( $limit, $offset ) );
    }
    $sql     = $wpdb->prepare( $sql, $parameter);
    $results = $wpdb->get_col( apply_filters( 'cwms1661_get_all_receivable_data_sql', $sql, $limit, $offset ) );

    if( empty($results) ){
        return false;
    }

    $data = [];
    foreach ($results as $post_id ) {
        $data[] = cwms1661_get_invoice_data( $post_id );
    }
    return $data;
}

// Access restriction functions
function cwms1661_can_access_receivables(){
    if(
        cwms1661_can_view_receivables() 
        || cwms1661_can_create_payment()
    ){
        return true;
    }
    return false;
}
function cwms1661_can_view_receivables_roles(){
    $assinged_roles     = get_option( 'cwms1661_can_view_receivables_roles', null );
    if( $assinged_roles === null ){
        $assinged_roles = array( 'cwms_manager', 'cwms_encoder', 'cwms_agent' );
    }
    $assinged_roles[]   = 'administrator';
    return $assinged_roles;
}
function cwms1661_can_view_receivables(){
    if( !is_user_logged_in() ){
        return false;
    }
    $allowed_roles = apply_filters('cwms1661_can_view_receivables_roles', cwms1661_can_view_receivables_roles() );
    return array_intersect( $allowed_roles,  cwms1661_current_user_roles() ) ? true : false ;
}