<?php
defined( 'ABSPATH' ) || exit;
/**
 * Product
 */
require_once CWMS1661_ABSPATH . 'lib/dompdf/vendor/autoload.php';

use Dompdf\Dompdf;
use Dompdf\Options;

class CWMS1661_Receivable {
    public static function init(){
        // Templates
        add_filter( 'cwms1661_content_template_receivables', array(__CLASS__, 'all_receivables_template' ) );
        // Script translation
        add_filter( 'cwms1661_report_localize_script_translations', array(__CLASS__,  'script_translations' ) );        
        // Ajax handlers
        add_action( 'wp_ajax_cwms_get_all_receivables', array(__CLASS__,  'get_all_receivables' ) );
        add_action( 'wp_ajax_cwms_get_invoice_summary_collection', array(__CLASS__,  'get_summary_collection' ) );
        // Page
        add_filter( 'cwms1661_registered_dashboard_pages', array(__CLASS__, 'page' ));
        // Permissions
        add_filter( 'cwms1661_permissions', array(__CLASS__, 'permissions' ) );
        // Menus 
        add_filter( 'cwms1661_dashboard_report_sub_menu', array(__CLASS__, 'sub_menu' ), 10 );
        // Print
        add_filter( 'cwms1661_print_html_body_receivable-invoice', array(__CLASS__, 'print' ), 10, 2 );
    }

    public static function get_all_receivables(){
        $current_date   = date( 'Y-m-d', current_time( 'timestamp', 0 ) );
        $customer_id    = (int)$_GET['customer'];
        $agent_id       = (int)$_GET['salesman'];
        $status         = sanitize_text_field( $_GET['invstat'] );
        $city           = sanitize_text_field( $_GET['city'] );
        $state          = sanitize_text_field( $_GET['state'] );
        $date_start     = sanitize_text_field( $_GET['start'] );
        $date_end       = sanitize_text_field( $_GET['end'] );
        $results        = cwms1661_get_receivables_by_date( $date_start, $date_end, $customer_id, $agent_id, $status, $city, $state );
        $data = [];
        if( $results ){
            foreach ($results as $post_id ) {
                $data[] = cwms1661_get_invoice_data( $post_id );
            }
            
            $data = array_map( function( $value ) use( $current_date ) {
                $current_date   = $value['_date_fully_paid'] ? $value['_date_fully_paid'] : $current_date;
                $date_diff      = cwms1661_date_diff( $current_date, $value['_date_created']);
                $label_url      = esc_url_raw( cwms1661_dashboard_home().'?cwmspage=view-invoice&id='.$value['ID'] );
                $dr_aged        = ! $value['_terms'] || $value['_terms'] < $date_diff;
                $dr_age_class   = $dr_aged ? 'text-danger' : '' ;
                ob_start();
                ?> <strong data-id="<?php echo $value['ID']; ?>"> <a href="<?php echo $label_url; ?>"><?php echo $value['_invoice_number']; ?></a> </strong>  <?php
                $value['_invoice_number']   = ob_get_clean();
                $value['_dr_age']           = $value['_terms'] ? sprintf( '<span class="%s">%d %s</span>', $dr_age_class, $date_diff, __('Days') ) : '';
                $value['_aged']             = $dr_aged;
                $value['_salesman']         = $value['_assigned_agent_name'];
                $value['_total_amount_cur'] = cwms1661_format_number( $value['_total_amount'], 2, ',' );
                $value['_balance_cur']      = cwms1661_format_number( $value['_balance'], 2, ',' );
                $value['_terms']            = cwms1661_term_options()[$value['_terms']];
                return $value;
            }, $data );
        }
        wp_send_json( array( 'data' => $data ) );
    }

    public static function get_summary_collection(){
        $dateRange      = (array)$_POST['dateRange'];
        $customer_id    = (int)$_POST['customerID'];
        $agent_id       = (int)$_POST['salesmanID'];
        $status         = sanitize_text_field( $_POST['invoiceStatus'] );

        $salesmen      = array();
        if( $agent_id ){
            $salesmen[] = get_userdata( $agent_id );
        }else{
            $salesmen = get_users( array( 'role__in' => 'cwms_agent' ) );
        }

        // Loop the daterange
        $dates              = $dateRange['dates'];
        $report_date        = $dateRange['end'];
        $tbl_column_headers = array_map( function( $value ){
            return $value['month'];
        }, $dates );

        $accumulated_data = array(
            'customer_id'   => $customer_id,
            'agent_id'      => $agent_id,
            'status'        => $status,
        );
        $records    = [];
        $can_query  = true;
        foreach( $dates as $date ){
            // Get date total amount
            $date_status    = $date['status'];
            $date_start     = $date['start'];
            $date_end       = $status ? $report_date : $date['end'] ;
            
            $salesmen_records      = [];
            // Loop data for each salesman
            foreach ( $salesmen as $salesman ) {
                $monthly_cost    = 0;
                $invoices        = cwms1661_get_receivables_by_date( $date_start, $date_end, $customer_id, $salesman->ID, $status );
                foreach ($invoices as $invoice_id ) {
                    $data = [];
                    cwms1661_get_invoice_cost( $data, $invoice_id );
                    $monthly_cost += floatval( $data['_total_amount'] );
                }
                $salesmen_records[$salesman->ID] = array(
                    'name'      => $salesman->display_name,
                    'amount'    => $monthly_cost,
                    'invoices' => $invoices
                );
            }
            $date['salesmen_records'] = $salesmen_records;
            $date['date_end'] = $date_end;
            $records[] = $date;
            if( $date_status ){
                $can_query = false;
            }
        }
        $accumulated_data['records']                = $records;
        $accumulated_data['salesmen']               = $salesmen;
        $accumulated_data['tbl_column_headers']     = $tbl_column_headers;
        $accumulated_data['report_date']            = $report_date;
        // wp_send_json( $accumulated_data );
        
        $directory    = CWMS1661_ABSPATH.'module/print/storage/';
        // Check if directory exist
        if( !is_dir( $directory ) ){
            mkdir( $directory );
        }

        // Clean directory before adding new file
        foreach( glob($directory.'*.pdf') as $pdf_file){
            unlink($pdf_file);
        }
        $pdf_title 	    = 'accumulated-collection-'.time();	
        // instantiate and use the dompdf class
        $options 		= new Options();
        $options->setDpi( 160 );
        $options->set('isRemoteEnabled', true);
        $dompdf 		= new Dompdf( $options );
        $dompdf->setPaper( CWMS1661_PDF_PAPER_SIZE, 'landscape');
        $dompdf->loadHtml( self::print_accumulated( $accumulated_data ), 'UTF-8' );
        $dompdf->render();
        self::pdf_marker( $dompdf );

        $output = $dompdf->output();
        $data_info = array();
        if( file_put_contents( $directory.$pdf_title.'.pdf', $output) ){
            $data_info = array(
                'file_url' => CWMS1661_PLUGIN_URL.'module/print/storage/'.$pdf_title.'.pdf',
                'file_name' => $pdf_title
            );  
        }
        wp_send_json( $data_info );
        
    }

    public static function page( $pages ){
        $pages['create-payment']  = esc_html__('Invoice Information', 'wpcodigo_wms');
        return $pages;
    }
    public static function all_receivables_template(){
        if( ! cwms1661_can_view_receivables() ){
            return cwms1661_get_template_path('403', 'dashboard');
        }
        return apply_filters( "cwms1661_get_template_all-receivables", CWMS1661_ABSPATH.'module/reports/receivable/templates/all-receivables.php' );
    }
    public static function script_translations( $translations ){
        $translations['receivebleTableData'] = array(
            'id'        => 'cwms_receivableTable',
            'headers'   => array_keys( cwms1661_receivable_table_headers() ),
            'paymentTypes' => cwms1661_payment_types()
        );
        return $translations;
    }

    public static function permissions( $permissions ){
        $permissions[80] = array(
            'label' => esc_html__('Invoice Report', 'wpcodigo_wms' ),
			'options' => array(
                'cwms1661_can_view_receivables_roles' => esc_html__('View', 'wpcodigo_wms' )
            )
        );
        return $permissions;
    }

    public static function  sub_menu( $sub_menus ){
        if( cwms1661_can_access_receivables() ){
            $sub_menus['receivables'] = esc_html__('Invoices', 'wpcodigo_wms');
        }
        return $sub_menus;
    }
    public static function print( $file_path,  $print_id ){
        if( !(int)$print_id  ){
            return $file_path;
        }
        return apply_filters( "cwms1661_receivable_invoice_print_template", CWMS1661_ABSPATH.'module/reports/receivable/templates/print.php' );
    }
    public static function pdf_marker( $dompdf ){

        $font_family    = apply_filters( 'cwms1661_pdf_pagination_font_family', 'Helvetica' );
        $font_type      = apply_filters( 'cwms1661_pdf_pagination_font_type', 'normal' );
        $x              = apply_filters( 'cwms1661_pdf_pagination_x_axis', 4 );
        $y              = apply_filters( 'cwms1661_pdf_pagination_y_axis', 4 );
        $text           = sprintf( __( 'Printed by: %s', 'wpcodigo_wms' ), cwms1661_user_fullname( get_current_user_id() ) );
        $font           = $dompdf->getFontMetrics()->get_font($font_family, $font_type);   
        $size           = apply_filters( 'cwms1661_pdf_pagination_font_size', 8 );    
        $color          = array(0,0,0);
        $word_space     = 0.0;
        $char_space     = 0.0;
        $angle          = 0.0;
        $dompdf->getCanvas()->page_text(
            $x, $y, $text, $font, $size, $color, $word_space, $char_space, $angle
        );

    }
    public static function print_accumulated( $data ){
        ob_start();
        self::header( $data );
        self::body( $data );
        self::footer( $data );
        return ob_get_clean();
    }
    public static function header( $data ){
        include_once cwms1661_get_template_path( 'print_acc_header', 'reports/receivable/templates/', true );
    }
    public static function body( $data ){
        $file_path = cwms1661_get_template_path( 'print_acc_body', 'reports/receivable/templates/', true );
        include_once apply_filters( 'cwms1661_accumulated_collection_print_html_body', $file_path, $data);
    }
    public static function footer( $data ){
        include_once cwms1661_get_template_path( 'print_acc_footer', 'reports/receivable/templates/', true );
    }
}