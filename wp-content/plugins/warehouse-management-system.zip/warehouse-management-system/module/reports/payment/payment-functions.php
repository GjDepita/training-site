<?php
defined( 'ABSPATH' ) || exit;

// Permissions #####
function cwms1661_can_view_payment_reports_roles(){
    $assinged_roles     = get_option( 'cwms1661_can_view_payment_reports_roles', null );
    if( $assinged_roles === null ){
        $assinged_roles = array( 'cwms_manager' );
    }
    $assinged_roles[]   = 'administrator';
    return $assinged_roles;
}
function cwms1661_can_view_payment_reports(){
    if( !is_user_logged_in() ){
        return false;
    }
    $allowed_roles = apply_filters('cwms1661_can_view_payment_reports_roles', cwms1661_can_view_payment_reports_roles() );
    return array_intersect( $allowed_roles,  cwms1661_current_user_roles() ) ? true : false ;
}
function cwms1661_can_update_payment_status_roles(){
    $assinged_roles     = get_option( 'cwms1661_can_update_payment_status_roles', null );
    if( $assinged_roles === null ){
        $assinged_roles = array( 'cwms_manager' );
    }
    $assinged_roles[]   = 'administrator';
    return $assinged_roles;
}
function cwms1661_can_update_payment_status(){
    if( !is_user_logged_in() ){
        return false;
    }
    $allowed_roles = apply_filters('cwms1661_can_update_payment_status_roles', cwms1661_can_update_payment_status_roles() );
    return array_intersect( $allowed_roles,  cwms1661_current_user_roles() ) ? true : false ;
}
function cwms1661_can_create_payment_roles(){
    $assinged_roles     = get_option( 'cwms1661_can_create_payment_roles', null );
    if( $assinged_roles === null ){
        $assinged_roles = array( 'cwms_manager' );
    }
    $assinged_roles[]   = 'administrator';
    return $assinged_roles;
}
function cwms1661_can_create_payment(){
    if( !is_user_logged_in() ){
        return false;
    }
    $allowed_roles = apply_filters('cwms1661_can_create_payment_roles', cwms1661_can_create_payment_roles() );
    return array_intersect( $allowed_roles,  cwms1661_current_user_roles() ) ? true : false ;
}
function cwms1661_can_access_payment_reports(){
    if(
        cwms1661_can_view_payment_reports() ){
        return true;
    }
    return false;
}
// Function helpers
function cwms1661_payments_table_headers(){
    $fields = array(
        'receipt_number' => __('PR/CR', 'wpcodigo_wms'),
        'payment_type'  => __('Payment Type', 'wpcodigo_wms'),
        'cheque_number' => __('Cheque Number', 'wpcodigo_wms'),
        'cheque_date'   => __('Cheque Date', 'wpcodigo_wms'),
        'cheque_bank'   => __('Cheque Bank', 'wpcodigo_wms'),
        'created_by'    => __('Processed by', 'wpcodigo_wms'),
        'collected_date'  => __('Collected Date', 'wpcodigo_wms'),
        'salesman_name'  => __('Salesman', 'wpcodigo_wms'),
        'customer_name' => __('Customer Name', 'wpcodigo_wms'),
        'paid_by'       => __('Paid by', 'wpcodigo_wms'),
        'amount'        => __('Amount', 'wpcodigo_wms'),
        'remarks'       => __('Remarks', 'wpcodigo_wms'),
        'status'        => __('Status', 'wpcodigo_wms'),
        'assigned'      => __('Assigned', 'wpcodigo_wms')
    );
    return apply_filters( 'cwms1661_payments_table_headers', $fields );
}
function cwms1661_current_validation_status_filter(){
    if( isset($_GET['status']) 
        && in_array( urldecode($_GET['status']), array_keys( cwms1661_payment_validation_status() ) ) 
        && urldecode($_GET['status']) != '_received' ){
            return urldecode($_GET['status']);
    }
    return '_received';
}
function cwms1661_total_collections( $dateStart, $dateEnd  ){
    global $wpdb;
    $payment_table = $wpdb->prefix.CWMS1661_TBL_PAYMENT_INFO;
    return $wpdb->get_var ( $wpdb->prepare( "SELECT SUM(`amount`) FROM {$payment_table} WHERE CAST( `created_date` as date) between %s and %s AND `status` NOT LIKE '_stale'", $dateStart, $dateEnd ) );
}
function is_cwms1661_invoice_payable( $invoice_id ){
    global $wpdb;
    $sql = "SELECT `ID` as 'id'";
    $sql .= " FROM {$wpdb->posts} AS tblposts";
    $sql .= " LEFT JOIN {$wpdb->postmeta} AS tblmeta ON  tblposts.ID = tblmeta.post_id";
    $sql .= " WHERE tblposts.post_status LIKE 'cwms-completed' AND tblposts.post_type LIKE %s AND tblposts.ID = %d";
    $sql .= " AND tblmeta.meta_key LIKE '_payment_status' AND tblmeta.meta_value != '_paid' ";
    $sql = $wpdb->prepare( $sql, CWMS1661_INVOICE_POST_TYPE, $invoice_id );
    return $wpdb->get_var( apply_filters( 'is_cwms1661_invoice_payable_sql', $sql, $invoice_id ) );
}

function cwms1661_invoice_payables( $customer_id = null, $daterange = array() ){
    global $wpdb;
    $customer_id    = (int)$customer_id;
    $parameter      = [ CWMS1661_INVOICE_POST_TYPE ];
    $sql = "SELECT tblposts.ID";
    $sql .= " FROM {$wpdb->posts} AS tblposts";
    $sql .= " INNER JOIN {$wpdb->postmeta} AS tblmeta ON tblposts.ID = tblmeta.post_id";
    if( $customer_id ){
        $sql .= " INNER JOIN {$wpdb->postmeta} AS tblcustomer ON  tblposts.ID = tblcustomer.post_id";
    }
    $sql .= " WHERE tblposts.post_status LIKE 'cwms-completed' AND tblposts.post_type LIKE %s";
    if( !empty( $daterange ) ){
        $sql .= " AND CAST( tblposts.post_date as date) between %s and %s";
        $parameter = array_merge( $parameter, array_values( $daterange  ) );
    }
    if( $customer_id ){
        $sql .= " AND tblcustomer.meta_key LIKE '_customer_id' AND tblcustomer.meta_value = %d";
        $parameter[] = (int)$customer_id;
    }
    $sql .= " AND tblmeta.meta_key LIKE '_payment_status' AND tblmeta.meta_value NOT LIKE '_paid'";
    $sql .= " GROUP BY tblposts.ID";
    $sql = $wpdb->prepare( $sql, $parameter);
    return $wpdb->get_col( apply_filters( 'cwms1661_invoice_payables_sql', $sql, $parameter ) );
}

function cwms1661_payable_total_cost( $customer_id = null, $daterange = array() ){
    $payables = cwms1661_invoice_payables( $customer_id, $daterange );
    if( empty( $payables ) ){
        return 0;
    }
    return array_reduce( $payables, function( $carry, $item ){
        $data = array();
        cwms1661_get_invoice_cost( $data, $item );
        $carry +=  floatval( $data['_balance'] );
        return $carry;
    }, 0 );
}

function cwms1661_all_payments( $agent_id = null, $customer_id = null, $payment_type = '', $payment_status = '', $assigned = 'all', $date_range = array(), $limit = null, $offset = 0){
    global $wpdb;
    $parameter          = array( 1 );
    $tbl_paymentinfo    = $wpdb->prefix.CWMS1661_TBL_PAYMENT_INFO;

    $sql = "SELECT *";
    $sql .= " FROM {$tbl_paymentinfo} AS tblinfo";
    $sql .= " WHERE 1 = %d";

    if( $agent_id ){
        $sql .= " AND tblinfo.agent_id = %d";
        $parameter[] = $agent_id;
    }

    if( $customer_id ){
        $sql .= " AND tblinfo.customer_id = %d";
        $parameter[] = $customer_id;
    }

    if( $assigned !== 'all' ){
        $sql .= " AND tblinfo.assigned = %d";
        $parameter[] = (int)$assigned;
    }
    
    if( !empty( $payment_type ) ){
        $sql .= " AND tblinfo.payment_type LIKE %s";
        $parameter[] = $payment_type;
    }
    if( !empty( $payment_status ) ){
        $sql .= " AND tblinfo.status LIKE %s";
        $parameter[] = $payment_status;
    }
    if( !empty( $date_range ) ){
        $sql .= " AND CAST( tblinfo.collected_date AS DATE) BETWEEN %s AND %s";
        $parameter[] = $date_range['start'];
        $parameter[] = $date_range['end'];
    }
    $sql .= " ORDER BY tblinfo.collected_date DESC, tblinfo.ID ASC";
    if( $limit ){
        $sql .= " LIMIT %d OFFSET %d";
        $parameter = array_merge( $parameter, array( $limit, $offset ) );
    }

    $sql     = $wpdb->prepare( $sql, $parameter); 

    return $wpdb->get_results( apply_filters( 'cwms1661_all_payments_sql', $sql, $parameter ), ARRAY_A );
}

function cwms1661_get_payment( $payment_id ){
    global $wpdb;
    $tableName = $wpdb->prefix . CWMS1661_TBL_PAYMENTS;
    $sql = $wpdb->prepare( "SELECT * FROM {$tableName} WHERE `ID` = %d", $payment_id );
    $sql = apply_filters( 'cwms1661_get_payment', $sql, $payment_id );
    return $wpdb->get_row(  $sql, ARRAY_A );
}
function cwms1661_get_payment_info_by_key( $payment_key ){
    global $wpdb;
    $payments       = $wpdb->prefix.CWMS1661_TBL_PAYMENTS;
    $payment_info   = $wpdb->prefix.CWMS1661_TBL_PAYMENT_INFO;
    // get the payment key
    if( !$payment_key ){
        return false;
    }
    // get all payment info using the payment key
    $data_info     = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$payment_info} WHERE `payment_key` LIKE %s", $payment_key ), ARRAY_A  );
    // get all the payments using the payment key
    $tbl_columns   = $wpdb->get_col("DESC {$payments}", 0);
    $tbl_columns   = array_map( function( $column ) {
        return 'tblpayments.'.$column;
    }, $tbl_columns );
    $tbl_columns[]  = 'tblposts.post_title as invoice_number';
    $sql            = "SELECT ".implode( ', ', $tbl_columns );
    $sql            .= " FROM {$payments} AS tblpayments";
    $sql            .= " INNER JOIN {$wpdb->posts} AS tblposts ON tblpayments.invoice_id = tblposts.ID";
    $sql            .= " WHERE `payment_key` LIKE %s";

    $payments       = $wpdb->get_results( $wpdb->prepare( $sql, $payment_key ), ARRAY_A  );
    // extract all payment and payment info data
    $additional_info = array(
        'receipt_number'    => $data_info[0]['receipt_number'],
        'agent_id'          => $data_info[0]['agent_id'],
        'agent_name'        => cwms1661_user_fullname( $data_info[0]['agent_id'] ),
        'customer_id'       => $data_info[0]['customer_id'],
        'customer_name'     => cwms1661_user_fullname( $data_info[0]['customer_id'] ),
        'collected_date'    => $data_info[0]['collected_date'],
        'paid_by'           => $data_info[0]['paid_by'],
        'remarks'           => $data_info[0]['remarks'],
    );

    return array(
        'payment_key'   => $payment_key,
        'payments'      => $payments,
        'payment_info'  => $data_info,
        'additional_info'  => $additional_info
    );
}

function cwms1661_get_payment_info( $payment_id ){
    global $wpdb;
    $payment_info   = $wpdb->prefix.CWMS1661_TBL_PAYMENT_INFO;
    // get the payment key
    $payment_key = $wpdb->get_var( $wpdb->prepare( "SELECT `payment_key` FROM {$payment_info} WHERE `ID` = %d", $payment_id )  );
    if( !$payment_key ){
        return false;
    }
    return cwms1661_get_payment_info_by_key( $payment_key );
}
function cwms1661_get_payment_count( $status ){
    global $wpdb;
    $tableName = $wpdb->prefix . CWMS1661_TBL_PAYMENTS;
    $sql = $wpdb->prepare( "SELECT COUNT(*) FROM {$tableName} WHERE `status` LIKE %s", $status );
    $sql = apply_filters( 'cwms1661_get_payment_count_sql', $sql, $status );
    return $wpdb->get_var(  $sql );
}
function cwms1661_add_payment_history( $data ){
    global $wpdb;
    $table          = $wpdb->prefix.CWMS1661_TBL_PAYMENT_HISTORY;
    $wpdb->insert( $table,
        $data,
        array( '%d', '%s', '%s' )
    );
}
function cwms1661_get_payment_history( $payment_id, $limit = null, $offset = 0  ){
    global $wpdb;
    $parameter  = array( $payment_id );
    $table_name = $wpdb->prefix.CWMS1661_TBL_PAYMENT_HISTORY;
    $sql = "SELECT * FROM {$table_name} WHERE `payment_id` = %d ORDER BY `id` DESC";
    if( $limit ){
        $sql .= " LIMIT %d OFFSET %d";
        $parameter = array_merge( $parameter, array( $limit, $offset ) );
    }
    return $wpdb->get_results( $wpdb->prepare( $sql, $parameter ), ARRAY_A );
}
function cwms_get_invoice_payments( $invoice_id ){
    global $wpdb;
    $table  = $wpdb->prefix.CWMS1661_TBL_PAYMENTS;
    $sql    = "SELECT * FROM {$table} WHERE `invoice_id` = %d ORDER BY `created_date` DESC";
    return $wpdb->get_results( $wpdb->prepare($sql, $invoice_id), ARRAY_A );
}

function cwms_get_invoice_payments_total( $invoice_id ){
    global $wpdb;
    $table  = $wpdb->prefix.CWMS1661_TBL_PAYMENTS;
    $sql    = "SELECT SUM(amount_paid + adjustment) FROM {$table} WHERE `invoice_id` = %d AND `status` = 1";
    $amount = $wpdb->get_var( $wpdb->prepare($sql, $invoice_id) );
    return floatval( $amount );
}
function cwms_cancel_invoice_payment( $payment_id ){
    global $wpdb;
    $table          = $wpdb->prefix.CWMS1661_TBL_PAYMENTS;
    return $wpdb->update($table,
        array( 'status' => 0 ), array( 'ID' => $payment_id ),
        array( '%d' ), array( '%d' )
    );
}
function cwms_insert_payment( $data ){
    global $wpdb;
    $table          = $wpdb->prefix.CWMS1661_TBL_PAYMENTS;
    $inserted_row   = $wpdb->insert($table,
        $data,
        array( '%s', '%d', '%f', '%f', '%s' )
    );
    if( !$inserted_row ){
        return false;
    }
    return $wpdb->insert_id;
}
function cwms_update_payment_info_status( $payment_id, $status, $assigned = true ){
    global $wpdb;
    $table = $wpdb->prefix.CWMS1661_TBL_PAYMENT_INFO;
    return $wpdb->update($table,
        array( 'status' => $status, 'assigned' => $assigned ),
        array( 'ID' => $payment_id ),
        array( '%s', '%d' ),
        array( '%d' )
    );
}
function cwms_insert_payment_info( $data ){
    global $wpdb;
    $table          = $wpdb->prefix.CWMS1661_TBL_PAYMENT_INFO;
    $inserted_row   = $wpdb->insert($table,
        $data,
        array( '%s', '%s', '%s', '%s', '%d', '%d', '%s', '%s', '%f', '%s', '%s', '%s', '%s', '%s' )
    );
    if( !$inserted_row ){
        return false;
    }
    return $wpdb->insert_id;
}
function cwms_update_payment_info( $id, $data ){
    global $wpdb;
    $table          = $wpdb->prefix.CWMS1661_TBL_PAYMENT_INFO;
    return $wpdb->update($table,
        $data,
        array( 'ID' => $id ),
        array( '%s', '%s', '%s', '%s', '%d', '%d', '%s', '%s', '%f', '%s', '%s', '%s', '%s', '%s' ),
        array( '%d' )
    );
}
// Credit function helpers
function cwms1661_get_credit_amount( $payment_key ){
    global $wpdb;
    $table          = $wpdb->prefix.CWMS1661_TBL_CREDIT_HISTORY;
    return $wpdb->get_var( $wpdb->prepare( "SELECT `amount` FROM {$table} WHERE `payment_key` LIKE %s", $payment_key ) );
}

function cwms1661_add_credit_history( $data ){
    global $wpdb;
    $table          = $wpdb->prefix.CWMS1661_TBL_CREDIT_HISTORY;
    $wpdb->insert( $table,
        $data,
        array( '%f', '%d', '%s', '%s', '%s', '%s' )
    );
}
function cwms1661_get_credit_history( $customer_id, $daterange = array(), $limit = null, $offset = 0 ){
    global $wpdb;
    $parameter = array( $customer_id );
    $table  = $wpdb->prefix.CWMS1661_TBL_CREDIT_HISTORY;
    $sql    = "SELECT * FROM {$table} WHERE `customer_id` LIKE %d";
    if( !empty( $daterange ) ){
        $sql .= " AND CAST( `created_date` as date) between %s and %s";
        $parameter = array_merge( $parameter, array_values( $daterange  ) );
    }
    $sql .= " ORDER BY `ID` DESC";
    if( $limit ){
        $sql .= " LIMIT %d OFFSET %d";
        $parameter = array_merge( $parameter, array( $limit, $offset ) );
    } 
    $sql     = $wpdb->prepare( $sql, $parameter);
    return $wpdb->get_results( apply_filters( 'cwms1661_get_customer_payments_data_sql', $sql, $daterange, $limit, $offset ), ARRAY_A );
}