<?php
defined( 'ABSPATH' ) || exit;
/**
 * Payment
 */
require_once CWMS1661_ABSPATH . 'lib/dompdf/vendor/autoload.php';

use Dompdf\Dompdf;
use Dompdf\Options;

class CWMS1661_Payment {

    public static function init(){
        add_filter( 'cwms1661_content_template_payments', array(__CLASS__, 'all_payments_template' ) );

        // Menus 
        add_filter( 'cwms1661_registered_dashboard_pages', array(__CLASS__, 'page' ));
        add_filter( 'cwms1661_dashboard_report_sub_menu', array(__CLASS__, 'sub_menu' ), 5 );

         // Ajax handlers
        add_action( 'wp_ajax_cwms_get_all_payments', array(__CLASS__,  'get_all_payments' ) );
        add_action( 'wp_ajax_cwms_get_payment_summary_collection', array(__CLASS__,  'get_summary_collection' ) );
        
         // Permissions
        add_filter( 'cwms1661_permissions', array(__CLASS__, 'permissions' ) );

         // Script translation
         add_filter( 'cwms1661_ajax_localize_script_translations', array(__CLASS__,  'script_translations' ) );
    }

    public static function all_payments_template(){
        if( ! cwms1661_can_view_payment_reports() ){
            return cwms1661_get_template_path('403', 'dashboard');
        }
        return apply_filters( "cwms1661_get_template_all-payments", CWMS1661_ABSPATH.'module/reports/payment/templates/all-payments.php' );
    }

    public static function page( $pages ){
        $pages['payments_report'] = esc_html__('Payments Report', 'wpcodigo_wms');
        return $pages;
    }

    public static function  sub_menu( $sub_menus ){
        if( cwms1661_can_view_payment_reports() ){
            $sub_menus['payments'] = esc_html__('Payments', 'wpcodigo_wms');
        }
        return $sub_menus;
    }

    public static function get_all_payments(){
        $customer_id    = (int)$_GET['customer_id'];
        $agent_id       = (int)$_GET['agent_id'];
        $date_start     = sanitize_text_field( $_GET['start'] );
        $date_end       = sanitize_text_field( $_GET['end'] );
        $status         = sanitize_text_field( $_GET['status'] );
        $type           = sanitize_text_field( $_GET['type'] );
        $assignment     = sanitize_text_field( $_GET['assignment'] ) != 'all' ? (int)$_GET['assignment'] : 'all';

        $date_range     = array(
            'start' => $date_start,
            'end'   => $date_end
        );

        $payments = cwms1661_all_payments( $agent_id, $customer_id, $type, $status, $assignment, $date_range );

        $payments = array_map( function( $data ){
            $type_key               = $data['payment_type'];
            $status_key             = $data['status'];
            $data['cheque_date']    = '0000-00-00' != $data['cheque_date'] ? $data['cheque_date'] : '';
            $data['customer_name']  = (int)$data['customer_id'] ? cwms1661_user_fullname( (int)$data['customer_id'] ) : '' ;
            $data['salesman_name']  = (int)$data['agent_id'] ? cwms1661_user_fullname( (int)$data['agent_id'] ) : '' ;
            $data['payment_type']   = cwms1661_payment_types()[$type_key];
            $data['status']         = cwms1661_payment_validation_status()[$status_key];
            $data['assigned']       = (int)$data['assigned'] ? '<i class="fa fa-check text-success" title="Assinged"></i> <span class="d-none">'.esc_html('Assigned','wpcodigo_wms').'</span>' : '<i class="fa fa-chain-broken text-danger" title="Unassinged"></i> <span class="d-none">'.esc_html('Unassinged','wpcodigo_wms').'</span>';
            return $data;
        }, $payments );

        wp_send_json( array( 'data' => $payments ) );
    }

    public static function get_summary_collection(){
        $dateRange      = (array)$_POST['dateRange'];
        $customer_id    = (int)$_POST['customerID'];
        $agent_id       = (int)$_POST['salesmanID'];
        $payment_type   = sanitize_text_field( $_POST['paymentType'] );
        $payment_status = sanitize_text_field( $_POST['paymentStatus'] );

        $salesmen      = array();
        if( $agent_id ){
            $salesmen[] = get_userdata( $agent_id );
        }else{
            $salesmen = get_users( array( 'role__in' => 'cwms_agent' ) );
        }

        // Loop the daterange
        $dates              = $dateRange['dates'];
        $report_date        = $dateRange['end'];
        $tbl_column_headers = array_map( function( $value ){
            return $value['month'];
        }, $dates );

        $accumulated_data = array(
            'customer_id'   => $customer_id,
            'agent_id'      => $agent_id,
            'payment_type'  => $payment_type,
            'payment_status' => $payment_status,
        );
        $records    = [];
        $can_query  = true;

        $post_dated_payments = array();

        foreach( $dates as $date ){
            // Get date total amount
            $date_status    = $date['status'];
            $date_start     = $date['start'];
            $date_month     = $date['month'];
            $date_end       = $date_status ? $report_date : $date['end'] ;
            $date_range     = array(
                'start' => $date_start,
                'end'   => $date_end
            );
            
            $salesmen_records      = [];
    
            // Loop data for each salesman
            foreach ( $salesmen as $salesman ) {
    
                $monthly_cost   = 0;
                $payments       = array();
    
                if( $can_query ){
                    $payments        = cwms1661_all_payments( $salesman->ID, $customer_id, $payment_type, $payment_status, 1, $date_range );
    
                    // Check if theres posted date for the current month
                    if( array_key_exists($salesman->ID, $post_dated_payments) ){
                        $monthly_cost += array_reduce( $post_dated_payments[$salesman->ID], function( $carry, $payment ) use( $date_month ) {
                            $_amount = 0;
                            if( $date_month == $payment['month'] ){
                                $_amount = floatval( $payment['amount'] );
                            }
                            $carry += $_amount;
                            return $carry;
                        }, 0 );
                    }
    
                    // Assign collection to cheque_date when the cheque_date is ahead of the collected_date
    
                    if( $payments && !empty( $payments ) ){
                        foreach ($payments as $payment ) {
                            $cheque_mth_name    = date( 'F', strtotime( $payment['cheque_date']) );
                            $cheque_month       = date( 'Y-m', strtotime( $payment['cheque_date']) );
                            $collected_month    = date( 'Y-m', strtotime( $payment['collected_date'] ) );
    
                            // If not Check payment add to monthly cost
                            if( '_cheque' != $payment['payment_type'] ){
                                $monthly_cost += floatval( $payment['amount'] );
                                continue;
                            }
    
                            // Checking base on the  collection date and cheque date by month                    
                            if( $cheque_month <= $collected_month ){
                                $monthly_cost += floatval( $payment['amount'] );
                                continue;
                            }
    
                            // Postdated payments
                            // Check if saleman has postdate payment            
                            if( array_key_exists( $salesman->ID, $post_dated_payments ) ){
                                $post_dated_payments[$salesman->ID][] = array(
                                    'month' => $cheque_mth_name,
                                    'amount' => $payment['amount']
                                );
                            }else{
                                $post_dated_payments[$salesman->ID] = array( array(
                                    'month' => $cheque_mth_name,
                                    'amount' => $payment['amount']
                                ) );
                            }
                        }
                    }
    
                }
    
                $salesmen_records[$salesman->ID] = array(
                    'name'      => $salesman->display_name,
                    'amount'    => $monthly_cost,
                    'payments'  => $payments
                );
            }
            $date['salesmen_records'] = $salesmen_records;
            $date['date_end'] = $date_end;
            $records[] = $date;
            if( $date_status ){
                $can_query = false;
            }
        }

        $accumulated_data['records']                = $records;
        $accumulated_data['postdated_payments']     = $post_dated_payments;
        $accumulated_data['salesmen']               = $salesmen;
        $accumulated_data['tbl_column_headers']     = $tbl_column_headers;
        $accumulated_data['report_date']            = $report_date;
        // wp_send_json( $accumulated_data );
        
        $directory    = CWMS1661_ABSPATH.'module/print/storage/';
        // Check if directory exist
        if( !is_dir( $directory ) ){
            mkdir( $directory );
        }

        // Clean directory before adding new file
        foreach( glob($directory.'*.pdf') as $pdf_file){
            unlink($pdf_file);
        }
        $pdf_title 	    = 'accumulated-collection-'.time();	
        // instantiate and use the dompdf class
        $options 		= new Options();
        $options->setDpi( 160 );
        $options->set('isRemoteEnabled', true);
        $dompdf 		= new Dompdf( $options );
        $dompdf->setPaper( CWMS1661_PDF_PAPER_SIZE, 'landscape');
        $dompdf->loadHtml( self::print_accumulated( $accumulated_data ), 'UTF-8' );
        $dompdf->render();
        self::pdf_marker( $dompdf );

        $output = $dompdf->output();
        $data_info = array();
        if( file_put_contents( $directory.$pdf_title.'.pdf', $output) ){
            $data_info = array(
                'file_url' => CWMS1661_PLUGIN_URL.'module/print/storage/'.$pdf_title.'.pdf',
                'file_name' => $pdf_title
            );  
        }
        wp_send_json( $data_info );
    }

    public static function pdf_marker( $dompdf ){

        $font_family    = apply_filters( 'cwms1661_pdf_pagination_font_family', 'Helvetica' );
        $font_type      = apply_filters( 'cwms1661_pdf_pagination_font_type', 'normal' );
        $x              = apply_filters( 'cwms1661_pdf_pagination_x_axis', 4 );
        $y              = apply_filters( 'cwms1661_pdf_pagination_y_axis', 4 );
        $text           = sprintf( __( 'Printed by: %s', 'wpcodigo_wms' ), cwms1661_user_fullname( get_current_user_id() ) );
        $font           = $dompdf->getFontMetrics()->get_font($font_family, $font_type);   
        $size           = apply_filters( 'cwms1661_pdf_pagination_font_size', 8 );    
        $color          = array(0,0,0);
        $word_space     = 0.0;
        $char_space     = 0.0;
        $angle          = 0.0;
        $dompdf->getCanvas()->page_text(
            $x, $y, $text, $font, $size, $color, $word_space, $char_space, $angle
        );

    }

    public static function print_accumulated( $data ){
        ob_start();
        self::header( $data );
        self::body( $data );
        self::footer( $data );
        return ob_get_clean();
    }
    public static function header( $data ){
        include_once cwms1661_get_template_path( 'print_acc_header', 'reports/payment/templates/', true );
    }
    public static function body( $data ){
        $file_path = cwms1661_get_template_path( 'print_acc_body', 'reports/payment/templates/', true );
        include_once apply_filters( 'cwms1661_payment_accumulated_collection_print_html_body', $file_path, $data);
    }
    public static function footer( $data ){
        include_once cwms1661_get_template_path( 'print_acc_footer', 'reports/payment/templates/', true );
    }

    public static function permissions( $permissions ){
        $permissions[70] = array(
            'label' =>  __('Payment Report', 'wpcodigo_wms' ),
			'options' => array(
                'cwms1661_can_view_payment_reports_roles' => __('View', 'wpcodigo_wms' ),
                'cwms1661_can_create_payment_roles'       => __('Create', 'wpcodigo_wms' ),
            )
        );
        return $permissions;
    }

    public static function script_translations( $translations ){
        $translations['paymentsTable'] = array(
            'id'        => 'cwms_paymentsTable',
            'reportLabel' => __('Payment Reports', 'wpcodigo_wms' ),
            'headers'   => array_keys( cwms1661_payments_table_headers() ),
            'status'    => cwms1661_current_validation_status_filter()
        );
        return $translations;
    }
}