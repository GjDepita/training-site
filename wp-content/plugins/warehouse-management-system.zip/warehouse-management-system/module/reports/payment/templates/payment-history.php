<div id="cwms-payment-history_wrapper" class="table-responsive">
    <div class="profile_title">
        <div class="col-md-6">
            <h4><?php echo esc_html('Payment Update History','wpcodigo_wms'); ?></h4>
        </div>
    </div>
    <table id="cwms-payment-history_table" class="table table-striped jambo_table">
        <thead>
            <tr class="headings">
                <th><?php echo esc_html('Date Updated','wpcodigo_wms'); ?></th>
                <th><?php echo esc_html('Updated by','wpcodigo_wms'); ?></th>
                <th><?php echo esc_html('Remarks','wpcodigo_wms'); ?></th>
            </tr>
        </thead>
        <tbody></tbody>
        <tfoot></tfoot>
    </table>
</div>
