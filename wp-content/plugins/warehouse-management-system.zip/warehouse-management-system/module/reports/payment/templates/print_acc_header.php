<!DOCTYPE html>
<html <?php language_attributes(); ?>>
    <head>
        <title>WMS by Codigo</title>
        <meta charset="<?php bloginfo( 'charset' ); ?>">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
        <style>
            *{
                font-family: system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, 'Open Sans', 'Helvetica Neue', sans-serif;
                margin:0;
                padding:0;
                font-size: 18px;
            }
            *, *:before, *:after { box-sizing: border-box; }
            body{ padding: 26px; }
            table{ width: 100%; border-spacing: 0; border-collapse: collapse;}
            table td{ vertical-align: top; padding:8px;}
            table.bordered, table.bordered td, table.bordered th, .bordered{ border: 1px solid #525659; }
            table .no-border, table .no-border td, table .no-border th{ border: none !important; }
            table.min-space td, table.min-space th{ padding: 8px 12px; }
            table.header-black tr th { background-color: #323639; color:#fff; }
            table.header-black tfoot tr th { background-color: #eee; color:#000; }
            table.font-small thead tr th { font-size: .9em; }
            table.font-small tbody tr td { font-size: .8em; }
            .border-top{ border-top: 1px solid #000;}
            .border-bottom{ border-bottom: 1px solid #000;}
            .bordered{ border: 1px solid #000;}
            .lead { margin-bottom: 20px; font-size: 1.6em; }
            .text-left{ text-align: left; }
            .text-right{ text-align: right; }
            .text-center{ text-align: center; }
            .text-uppercase{ text-transform: uppercase; }
            .text-underline{ border-bottom: 1px solid #000; }
            div.text-underline{padding-bottom:8px;}
            h1{ font-size: 32px;}
            h2{ font-size: 26px;}
        </style>
    </head>
    <body>