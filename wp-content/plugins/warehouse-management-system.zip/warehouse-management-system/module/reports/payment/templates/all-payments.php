<?php $table_headers  = cwms1661_payments_table_headers(); ?>
<div class="filter-section profile_title" style="margin-bottom:18px;">
    <section class="filter-wrapper" style="margin-right:12px;">
        <select id="allpayment_salesman_filter" data-action="cwms_search_salesman" data-placeholder="<?php echo esc_html('All Salesman','wpcodigo_wms'); ?>" class="form-control form-control-sm" style="width:180px;margin-right:8px;display:inline-block;">
            <option value=""><?php echo esc_html('All Salesman','wpcodigo_wms'); ?></option>
        </select> 
    </section>
    <section class="filter-wrapper" style="margin-right:12px;">
        <select id="allpayment_customer_filter" data-action="cwms_search_customer" data-placeholder="<?php echo esc_html('All Customer','wpcodigo_wms'); ?>" class="form-control form-control-sm" style="width:180px;margin-right:8px;display:inline-block;">
            <option value=""><?php echo esc_html('All Customer','wpcodigo_wms'); ?></option>
        </select>
    </section>
    <section class="filter-wrapper" style="margin-right:12px;">
        <select id="allpayment_type_filter" class="form-control form-control-sm" data-placeholder="<?php echo esc_html('All Payment Type','wpcodigo_wms'); ?>" style="width:fit-content;margin-right:8px;display:inline-block;">
            <option value=""><?php echo esc_html('All Types','wpcodigo_wms'); ?></option>
            <?php foreach( cwms1661_payment_types() as $key => $label ): ?>
                <option value="<?php echo esc_attr( $key ); ?>"><?php echo esc_html( $label ); ?></option>
            <?php endforeach; ?>
        </select>
    </section>
    <section class="filter-wrapper" style="margin-right:12px;">
        <select id="allpayment_status_filter" class="form-control form-control-sm" data-placeholder="<?php echo esc_html('All Payment Status','wpcodigo_wms'); ?>" style="width:fit-content;margin-right:8px;display:inline-block;">
            <option value=""><?php echo esc_html('All status','wpcodigo_wms'); ?></option>
            <?php foreach( cwms1661_payment_validation_status() as $key => $label ): ?>
                <option value="<?php echo esc_attr( $key ); ?>"><?php echo esc_html( $label ); ?></option>
            <?php endforeach; ?>
        </select>
    </section>
    <section class="filter-wrapper" style="margin-right:12px;">
        <select id="allpayment_assigned_filter" class="form-control form-control-sm" data-placeholder="<?php echo esc_html('All Assigned/Unassigned Payment','wpcodigo_wms'); ?>" style="width:fit-content;margin-right:8px;display:inline-block;">
            <option value=""><?php echo esc_html('Assigned / Unassigned','wpcodigo_wms'); ?></option>
            <option value="1"><?php echo esc_html('Assigned','wpcodigo_wms'); ?></option>
            <option value="0"><?php echo esc_html('Unassigned','wpcodigo_wms'); ?></option>
        </select>
    </section>
    <section class="filter-wrapper" style="margin-right:12px;">
        <input id="allpayment_daterange_filter" type="text" class="form-control form-control-sm" style="width:210px;display:inline-block;" value="" />
    </section>
</div>
<table id="cwms_paymentsTable" class="wcms1661_dataTable display responsive" width="100%">
    <thead>
        <tr>
            <?php foreach( $table_headers as $metakey => $label ): ?>
                <th><?php echo apply_filters('cwms1661_payments_table_headers_label_'.$metakey , $label ); ?></th>
            <?php endforeach; ?>
        </tr>
    </thead>
    <tfoot>
        <tr>
            <?php foreach( $table_headers as $metakey => $label ): ?>
                <th><?php echo apply_filters('cwms1661_payments_table_headers_label_'.$metakey , $label ); ?></th>
            <?php endforeach; ?>
        </tr>
    </tfoot>
</table>   