<?php 
    $table_headers = cwms1661_unitsold_table_headers(); 
    $area_states   = cwms1661_get_user_area('state');
    $area_cities   = cwms1661_get_user_area('city');
?>
<div class="filter-section profile_title" style="margin-bottom:18px;">
    <section class="filter-wrapper" style="margin-right:12px;">
        <select id="unitsold_product_filter" data-action="cwms_product_options" data-placeholder="<?php echo esc_html('All Products','wpcodigo_wms'); ?>" class="form-control form-control-sm" style="width:180px;margin-right:8px;display:inline-block;">
            <option value=""><?php echo esc_html('All Products','wpcodigo_wms'); ?></option>
        </select> 
    </section>
    <section class="filter-wrapper" style="margin-right:12px;">
        <select id="unitsold_salesman_filter" data-action="cwms_search_salesman" data-placeholder="<?php echo esc_html('All Salesman','wpcodigo_wms'); ?>" class="form-control form-control-sm" style="width:180px;margin-right:8px;display:inline-block;">
            <option value=""><?php echo esc_html('All Salesman','wpcodigo_wms'); ?></option>
        </select> 
    </section>
    <section class="filter-wrapper" style="margin-right:12px;">
        <select id="unitsold_customer_filter" data-action="cwms_search_customer" data-placeholder="<?php echo esc_html('All Customer','wpcodigo_wms'); ?>" class="form-control form-control-sm" style="width:180px;margin-right:8px;display:inline-block;">
            <option value=""><?php echo esc_html('All Customer','wpcodigo_wms'); ?></option>
        </select>
    </section>
    <?php if( $area_cities ): ?>
        <section class="filter-wrapper" style="margin-right:12px;">
            <select id="unitsold_city_filter" data-placeholder="<?php echo esc_html('All Cities','wpcodigo_wms'); ?>" class="form-control form-control-sm" style="width:180px;margin-right:8px;display:inline-block;">
                <option value=""><?php echo esc_html('All Cities','wpcodigo_wms'); ?></option>
                <?php foreach( $area_cities as $city ): ?>
                    <option value="<?php echo esc_attr( $city ); ?>"><?php echo esc_html( $city ); ?></option>
                <?php endforeach; ?>
            </select>
        </section>
    <?php endif; ?>
    <?php if( $area_states ): ?>
        <section class="filter-wrapper" style="margin-right:12px;">
            <select id="unitsold_state_filter" data-placeholder="<?php echo esc_html('All States','wpcodigo_wms'); ?>" class="form-control form-control-sm" style="width:180px;margin-right:8px;display:inline-block;">
                <option value=""><?php echo esc_html('All States','wpcodigo_wms'); ?></option>
                <?php foreach( $area_states as $state ): ?>
                    <option value="<?php echo esc_attr( $state ); ?>"><?php echo esc_html( $state ); ?></option>
                <?php endforeach; ?>
            </select>
        </section>
    <?php endif; ?>
    <section class="filter-wrapper" style="margin-right:12px;">
        <input id="unitsold_daterange_filter" type="text" class="form-control form-control-sm" style="width:210px;display:inline-block;" value="" />
    </section>
</div>
<table id="cwms_unitSoldTable" class="wcms1661_dataTable display" style="width:100%">
    <thead>
        <tr>
            <?php do_action( 'cwms1661_customer_before_table_header' ); ?>
            <?php foreach( $table_headers as $metakey => $label ): ?>
                <th><?php echo apply_filters('cwms1661_unit_sold_table_headers_label_'.$metakey , $label ); ?></th>
            <?php endforeach; ?>
            <?php do_action( 'cwms1661_customer_after_table_header' ); ?>
        </tr>
    </thead>
    <tfoot>
        <tr>
            <?php do_action( 'cwms1661_customer_before_table_header' ); ?>
            <?php foreach( $table_headers as $metakey => $label ): ?>
                <th><?php echo apply_filters('cwms1661_unit_sold_table_headers_label_'.$metakey , $label ); ?></th>
            <?php endforeach; ?>
            <?php do_action( 'cwms1661_customer_after_table_header' ); ?>
        </tr>
    </tfoot>
</table>
<div id="unit_sold_table_report" class="text-center">
    <p><?php echo esc_html('Date','wpcodigo_wms'); ?>: <strong><span class="unit_sold_daterange"></span></strong></p>
    <p><?php echo esc_html('Product','wpcodigo_wms'); ?>: <strong><span class="unit_sold_product"></span></strong></p>
    <p><?php echo esc_html('Customer','wpcodigo_wms'); ?>: <strong><span class="unit_sold_customer"></span></strong></p>
    <p><?php echo esc_html('Salesman','wpcodigo_wms'); ?>: <strong><span class="unit_sold_salesman"></span></strong></p>
    <p><?php echo esc_html('City','wpcodigo_wms'); ?>: <strong><span class="unit_sold_city"></span></strong></p>
    <p><?php echo esc_html('State','wpcodigo_wms'); ?>: <strong><span class="unit_sold_state"></span></strong></p>
    <h4><?php echo esc_html('Total Qty. Sold','wpcodigo_wms'); ?>: <span class="unit_sold_total_qty">0.00</span></h4>
    <h4><?php echo esc_html('Total Amount Sold','wpcodigo_wms'); ?>: <span class="unit_sold_total_amount">0.00</span></h4>
</div>