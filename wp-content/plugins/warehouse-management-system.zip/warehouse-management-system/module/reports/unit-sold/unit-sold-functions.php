<?php
defined( 'ABSPATH' ) || exit;

function cwms1661_unitsold_table_headers(){
    $headers = array(
        'name'              => __('Product Name', 'wpcodigo_wms' ),
        'upc'               => __('SKU', 'wpcodigo_wms' ),
        '_qty'              => __('Remaining QTY.', 'wpcodigo_wms' ),
        'total_delivered'   => __('Unit Sold', 'wpcodigo_wms' ),
        'total_sales'       => __('Total', 'wpcodigo_wms' ),
    );
    return apply_filters( 'cwms1661_unitsold_table_headers', $headers );
}

function cwms1661_get_unitsold( $product_id = null, $agent_id = null, $customer_id = null, $city = null, $state = null, $date_range = array(), $limit = null, $offset = 0 ){
    global $wpdb;
    $tbl_product    = $wpdb->prefix.CWMS1661_TB_PRODUCTS;
    $parameter      = [CWMS1661_INVOICE_POST_TYPE];
    $sql  = "SELECT tblproduct.ID, tblproduct.product_id, tblproduct.name, tblproduct.upc, SUM( tblproduct.qty_delivered ) AS total_delivered, SUM( tblproduct.discount_amount ) AS total_disc_amount, SUM( ( tblproduct.qty_delivered * tblproduct.retail_price ) - tblproduct.discount_amount ) AS  total_sales";
    $sql .= " FROM {$tbl_product} AS tblproduct";
    $sql .= " LEFT JOIN {$wpdb->posts} AS tblinvoice ON tblinvoice.ID = tblproduct.trans_id";
    if( $customer_id ){
        $sql .= " LEFT JOIN {$wpdb->postmeta} AS tblcustomer ON tblcustomer.post_id = tblproduct.trans_id";
    } 
    if( $agent_id ){
        $sql .= " LEFT JOIN {$wpdb->postmeta} AS tblsalesman ON tblsalesman.post_id = tblproduct.trans_id";
    }
    if( $city ){
        $sql .= " LEFT JOIN {$wpdb->postmeta} AS tblcity ON  tblcity.post_id = tblproduct.trans_id";
    }
    if( $state ){
        $sql .= " LEFT JOIN {$wpdb->postmeta} AS tblstate ON  tblstate.post_id = tblproduct.trans_id";
    }
    $sql .= " WHERE tblinvoice.post_type LIKE %s";

    if( !empty( $date_range ) ){
        $sql .= " AND CAST( tblinvoice.post_date AS DATE) BETWEEN %s AND %s";
        $parameter[] = $date_range['start'];
        $parameter[] = $date_range['end'];
    }

    if( $product_id ){
        $sql .= " AND tblproduct.product_id = %d";
        $parameter[] = $product_id;
    }
    if( $agent_id ){
        $sql .= " AND tblsalesman.meta_key LIKE '_assigned_agent' AND tblsalesman.meta_value = %d";
        $parameter[] = $agent_id;
    }

    if( $customer_id ){
        $sql .= " AND tblcustomer.meta_key LIKE '_customer_id' AND tblcustomer.meta_value = %d";
        $parameter[] = $customer_id;
    }

    if( $city ){
        $sql .= " AND tblcity.meta_key LIKE '_city' AND tblcity.meta_value = %s";
        $parameter[] = sanitize_text_field($city);
    }
    if( $state ){
        $sql .= " AND tblstate.meta_key LIKE '_state' AND tblstate.meta_value = %s";
        $parameter[] = sanitize_text_field($state);
    }

    $sql .= " GROUP BY tblproduct.product_id";

    if( $limit ){
        $sql .= " LIMIT %d OFFSET %d";
        $parameter = array_merge( $parameter, array( $limit, $offset ) );
    }

    $sql =  $wpdb->prepare( $sql, $parameter );
    return $wpdb->get_results( $sql, ARRAY_A );
}

// Permission
function cwms1661_can_view_unitsold_reports_roles(){
    $assinged_roles     = get_option( 'cwms1661_can_view_unitsold_reports_roles', null );
    if( $assinged_roles === null ){
        $assinged_roles = array( 'cwms_manager' );
    }
    $assinged_roles[]   = 'administrator';
    return $assinged_roles;
}
function cwms1661_can_view_unitsold_reports(){
    if( !is_user_logged_in() ){
        return false;
    }
    $allowed_roles = apply_filters('cwms1661_can_view_unitsold_reports_roles', cwms1661_can_view_unitsold_reports_roles() );
    return array_intersect( $allowed_roles,  cwms1661_current_user_roles() ) ? true : false ;
}