<?php
defined( 'ABSPATH' ) || exit;
/**
 * Product
 */
class CWMS1661_UnitSold {

    public static function init(){
        add_filter( 'cwms1661_content_template_unit-sold', array(__CLASS__, 'all_unit_sold_template' ) );

        // Menus 
        add_filter( 'cwms1661_registered_dashboard_pages', array(__CLASS__, 'page' ));
        add_filter( 'cwms1661_dashboard_report_sub_menu', array(__CLASS__, 'sub_menu' ), 5 );
        add_filter( 'cwms1661_nav_list_reports', array(__CLASS__,  'nav_active' ), 10 );

         // Ajax handlers
        add_action( 'wp_ajax_cwms_get_all_unit_sold', array(__CLASS__,  'get_all_unit_sold' ) );
        
         // Permissions
        add_filter( 'cwms1661_permissions', array(__CLASS__, 'permissions' ) );

         // Script translation
         add_filter( 'cwms1661_report_localize_script_translations', array(__CLASS__,  'script_translations' ) );
    }

    public static function all_unit_sold_template(){
        if( ! cwms1661_can_view_payment_reports() ){
            return cwms1661_get_template_path('403', 'dashboard');
        }
        return apply_filters( "cwms1661_get_template_all-unit-sold", CWMS1661_ABSPATH.'module/reports/unit-sold/templates/all-unit-sold.php' );
    }

    public static function page( $pages ){
        $pages['unit_sold_report'] = esc_html__('Unit Sold Report', 'wpcodigo_wms');
        return $pages;
    }

    public static function  sub_menu( $sub_menus ){
        if( cwms1661_can_view_unitsold_reports() ){
            $sub_menus['unit-sold'] = esc_html__('Unit Sold', 'wpcodigo_wms');
        }
        return $sub_menus;
    }
    public static function nav_active( ){
        return isset( $_GET['cwmspage'] ) && $_GET['cwmspage'] == 'unit-sold' ? true : false;
    }

    public static function get_all_unit_sold(){
        $product_id     = (int)$_GET['product'];
        $agent_id       = (int)$_GET['salesman'];
        $customer_id    = (int)$_GET['customer'];
        $city           = sanitize_text_field( $_GET['city'] );
        $state          = sanitize_text_field( $_GET['state'] );
        $date_start     = sanitize_text_field( $_GET['start'] );
        $date_end       = sanitize_text_field( $_GET['end'] );

        $date_range = array(
            'start' =>  $date_start,
            'end'   => $date_end
        );
        $unitsold = cwms1661_get_unitsold( $product_id, $agent_id, $customer_id, $city, $state, $date_range );
        if( $unitsold ){
            $unitsold = array_map( function( $product ){
                $product['_qty']            = get_post_meta( $product['product_id'], '_qty', true);
                $product['_total_sales']    = $product['total_sales'];
                $product['total_sales']     = cwms1661_format_number( $product['total_sales'], 2, ',');
                return $product;
            }, $unitsold );
        }
        wp_send_json( array( 'data' => $unitsold ) );
    }

    public static function permissions( $permissions ){
        $permissions[90] = array(
            'label' =>  __('Unit Sold Report', 'wpcodigo_wms' ),
			'options' => array(
                'cwms1661_can_view_unitsold_reports_roles' => __('View', 'wpcodigo_wms' )
            )
        );
        return $permissions;
    }

    public static function script_translations( $translations ){
        $translations['unitSoldTable'] = array(
            'id'            => 'cwms_unitSoldTable',
            'reportLabel'   => __('Unit Sold Reports', 'wpcodigo_wms' ),
            'headers'       => array_keys( cwms1661_unitsold_table_headers() )
        );
        return $translations;
    }
}