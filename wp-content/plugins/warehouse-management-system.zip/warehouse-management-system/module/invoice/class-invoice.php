<?php
defined( 'ABSPATH' ) || exit;
/**
 * Invoice
 */

class CWMS1661_Invoice {

    public static function init(){
        // Saving PO data
        add_action( 'wp', array( __CLASS__, 'create_invoice'), 99, 1 );
        add_action( 'wp', array( __CLASS__, 'update_invoice'), 99, 1 );
        add_action( 'save_post_'.CWMS1661_INVOICE_POST_TYPE, array( __CLASS__, 'save_invoice_post_meta'), 10, 3 );

        // cwms1661_after_so_update_status
        add_action('template_redirect', array( __CLASS__, 'save_redirection') );

        // Ajax handlers
        add_action( 'wp_ajax_cwms_get_all_invoice', array(__CLASS__,  'get_all_invoices' ) );
        add_action( 'wp_ajax_cwms_delete_invoice', array(__CLASS__,  'invoice_delete' ) );
        add_action( 'wp_ajax_cwms_invoice_bulk_action', array(__CLASS__, 'invoice_bulk_action' ) );
        add_action( 'wp_ajax_cwms_search_so_invoice', array(__CLASS__,  'search_invoice_so' ) );
        add_action( 'wp_ajax_cwms_check_invoice_dr', array(__CLASS__,  'check_invoice_dr' ) );

        // Menu hooks
        add_filter( 'cwms1661_dashboard_menus', array(__CLASS__, 'menu' ) );
        add_filter( 'cwms1661_registered_dashboard_pages', array(__CLASS__, 'page' ));

         // After page title hook
        add_action('cwms1661_after_page_title_receive-invoice', array(__CLASS__, 'all_list_link'));
        add_action('cwms1661_after_page_title_view-invoice', array(__CLASS__, 'all_list_link'));

        // Script translation
        add_filter( 'cwms1661_ajax_localize_script_translations', array(__CLASS__,  'script_translations' ) );

        // Template
        add_filter( 'cwms1661_content_template_invoices', array(__CLASS__, 'all_invoice_template' ) );
        add_filter( 'cwms1661_content_template_create-invoice', array(__CLASS__, 'create_invoice_template' ) );
        add_filter( 'cwms1661_content_template_view-invoice', array(__CLASS__, 'view_invoice_template' ) );
        add_filter( 'cwms1661_content_template_update-invoice', array(__CLASS__, 'update_invoice_template' ) );
        add_action( 'cwms1661_before_invoice_form', array(__CLASS__, 'notification_message' ) );
        add_action( 'cwms1661_before_view_invoice_template', array(__CLASS__, 'notification_message' ) );
        add_action( 'cwms_before_page-invoices', array(__CLASS__, 'page_navigation' ) );

        // Permissions
        add_filter( 'cwms1661_permissions', array(__CLASS__, 'permissions' ) );
        
        // Print
        add_filter( 'cwms1661_print_html_body_invoice', array(__CLASS__, 'print_invoice' ), 10, 2 );
        add_filter( 'cwms1661_print_html_body_consignment', array(__CLASS__, 'print_consignment' ), 10, 2 );
        add_filter( 'cwms1661_print_html_body_delivery', array(__CLASS__, 'print_delivery' ), 10, 2 );
    }
    public static function all_list_link(){
        printf( '<a href="%s" class="btn btn-sm btn-primary">' . __( 'All Invoices', 'wpcodigo_wms' ) . '</a>', cwms1661_dashboard_home().'?cwmspage=invoices' );
    }
    public static function menu( $menus ){

        if( !cwms1661_can_access_invoice() ){
            return $menus;
        }
        $subs   = array(
            'invoices' => esc_html__('All Invoice', 'wpcodigo_wms'),
            'create-invoice' => esc_html__('Create Invoice', 'wpcodigo_wms')
        );
        if( !cwms1661_can_create_invoice() ){
            unset( $subs['create-invoice'] );
        }
        $menus[20] = array(
            'id'   => 'invoices',
            'label' => esc_html__('Invoices', 'wpcodigo_wms'),
            'classes' => 'fa fa-truck',
            'subs'  => $subs
        );
        return $menus;
    }
    public static function page( $pages ){
        $pages['invoices']           = esc_html__('All Invoices', 'wpcodigo_wms');
        $pages['view-invoice']       = esc_html__('Invoice details', 'wpcodigo_wms');
        $pages['create-invoice']     = esc_html__('Create Invoice', 'wpcodigo_wms');
        $pages['update-invoice']     = esc_html__('Update Invoice', 'wpcodigo_wms');
        return $pages;
    }
    public static function all_invoice_template(){
        if( ! cwms1661_can_view_invoice() ){
            return cwms1661_get_template_path('403', 'dashboard');
        }
        return apply_filters( "cwms1661_get_template_all-invoice", CWMS1661_ABSPATH.'module/invoice/templates/all-invoice.php' );
    }
    public static function create_invoice_template(){
        if( ! cwms1661_can_create_invoice() ){
            return cwms1661_get_template_path('403', 'dashboard');
        }
        return apply_filters( "cwms1661_get_template_create-invoice", CWMS1661_ABSPATH.'module/invoice/templates/create-invoice.php' );
    }
    public static function view_invoice_template(){
        if( ! cwms1661_can_view_invoice() 
            || !isset($_GET['id']) 
            || !is_cwms1661_invoice($_GET['id']) ){
            return cwms1661_get_template_path('403', 'dashboard');
        }
        return apply_filters( "cwms1661_get_template_view-invoice", CWMS1661_ABSPATH.'module/invoice/templates/view-invoice.php' );
    }
    public static function update_invoice_template(){
        if( ! cwms1661_can_update_invoice() 
            || !isset($_GET['id']) 
            || !is_cwms1661_invoice($_GET['id'] )
            || is_cwms1661_invoice($_GET['id'], array('cwms-completed') ) ){
            return cwms1661_get_template_path('403', 'dashboard');
        }
        return apply_filters( "cwms1661_get_template_update-invoice", CWMS1661_ABSPATH.'module/invoice/templates/update-invoice.php' );
    }
    public static function page_navigation(){
        include_once apply_filters( "cwms1661_get_template_all-invoice-navigation", CWMS1661_ABSPATH.'module/invoice/templates/navigation.php' );
    }
    public static function script_translations( $translations ){
        $empty_repeater = isset( $_GET['cwmspage'] ) && urldecode( $_GET['cwmspage'] ) == 'create-invoice' ? true : false;
        $translations['invoiceTableData'] = array(
            'id'        => 'cwms_invoiceTable',
            'delete'    => cwms1661_can_delete_product(),
            'headers'   => array_keys( cwms1661_invoice_table_headers() ),
            'status'    => cwms1661_current_status_filter(),
            'emptyRepeater' => $empty_repeater 
        );
        return $translations;
    }
    public static function save_invoice(){
        if ( ! isset( $_POST['cwms-invoice_form_nonce'] ) 
            || ! wp_verify_nonce( $_POST['cwms-invoice_form_nonce'], 'cwms-invoice_form_action' ) 
        ) {
            return false;
        } 
        $invoice_id     = isset($_GET['id']) ? (int)$_GET['id'] : false;
        if( ! $invoice_id 
            || ! is_cwms1661_invoice( $invoice_id ) 
            || ! cwms1661_can_update_invoice() 
            || ! in_array( get_post_status( $invoice_id ), cwms1661_edited_statuses() ) ){
            $_POST['cwms_invoice_redirection'] = array(
                'url'       => cwms1661_dashboard_home(),
                'subpage'   => 'update-invoice',
                'id'        => 0,
                'message'   => __('Permission denied. Please contact admin support', 'wpcodigo_wms')
            );
            return false;
        }

        $invoice_number = get_the_title( $invoice_id );
        // Updating invoice data
        if( isset($_POST['remarks']) ){
            update_post_meta( $invoice_id, '_remarks', sanitize_textarea_field( $_POST['remarks'] ) );
        }
        if( isset($_POST['cod_discount']) ){
            update_post_meta( $invoice_id, '_cod_discount', floatval($_POST['cod_discount']) );
        }
        if( isset($_POST['tax']) ){
            update_post_meta( $invoice_id, '_tax', floatval($_POST['tax']) );
        }
        if( isset($_POST['others']) ){
            update_post_meta( $invoice_id, '_others', floatval($_POST['others']) );
        }

        // Updating products
        $products         = cwms1661_get_invoice_product_data( $invoice_id );

        $_POST['cwms_invoice_redirection'] = array(
            'url'       => cwms1661_dashboard_home(),
            'subpage'   => 'update-invoice',
            'id'        => $invoice_id,
            'message'   => sprintf( __('Invoice number # %s successfully updated', 'wpcodigo_wms'), $invoice_number )
        );
        return false;

    }
    public static function create_invoice( ){
        if ( ! isset( $_POST['cwms-create-invoice_form_nonce'] ) 
            || ! wp_verify_nonce( $_POST['cwms-create-invoice_form_nonce'], 'cwms-create-invoice_form_action' ) 
        ) {
            return false;
        }

        if ( ! cwms1661_can_create_invoice( ) ) {
            echo '<div id="message" class="error"><p>' . __('Permission denied. Please contact admin support.', 'wpcodigo_wms') . '</p></div>';
            wp_die();
        }
        
        $invoice_id      = isset( $_GET['id'] ) && (int)$_GET['id'] ? (int)$_GET['id'] : false ;
        $invoice_number  = isset( $_POST['_invoice_number'] ) && !empty( $_POST['_invoice_number'] ) ? trim($_POST['_invoice_number']) : cwms1661_generate_invoice_number() ;
        $invoice_date    = isset( $_POST['_invoice_date'] ) && !empty( $_POST['_invoice_date'] ) ? trim($_POST['_invoice_date']) : false ;

        if(cwms1661_dr_senquence_enable()){
            $invoice_number = cwms1661_generate_invoice_number();
        }

        $invoice_args    = array(
            'post_title'    => wp_strip_all_tags( $invoice_number ),
            'post_status'   => 'cwms-for-approval',
            'post_type'     => CWMS1661_INVOICE_POST_TYPE
        );
        if( $invoice_date ){
            $invoice_args['post_date'] = strftime( '%Y-%m-%d %X', strtotime( $invoice_date ) );
        }
        $invoice_id = wp_insert_post( $invoice_args );
        if ( is_wp_error( $invoice_id ) ) {
            echo '<div id="message" class="error"><p>' . $invoice_id->get_error_message() . '</p></div>';
            wp_die();
        }

        // Set sales order type to Completed  for Reserve
        if( isset( $_POST['_so_id'] ) 
            && is_cwms1661_so( (int)$_POST['_so_id'] ) ){
                wp_update_post( array( 'ID' => (int)$_POST['_so_id'], 'post_status' => 'cwms-completed' ) );

                // Update SO product data
                $products           = maybe_unserialize( get_post_meta( (int)$_POST['_so_id'], '_products', true  ) );
                $invoice_products   = isset( $_POST['cwms_invoice_products'] ) ? (array)$_POST['cwms_invoice_products'] : array();

                if( !empty($products) && is_array($products) && !empty( $invoice_products ) ){
                    $new_products = array_map( function( $item  ) use( $invoice_products ) {
                        if( array_key_exists( 'applied', $item ) && $item['applied'] ){
                            return $item;
                        }
                        $found_key          = array_search( $item['id'], array_column($invoice_products, 'product_id'));
                        $applied            = $found_key !== false ? true : false;
                        $item['applied']    = $applied;
                        return $item;
                    }, $products );
                    // Update the SO products for applie markings
                    update_post_meta( $_POST['_so_id'], '_products', $new_products );
                }
        }

        $_POST['cwms_invoice_redirection'] = array(
            'url'       => cwms1661_dashboard_home(),
            'subpage'   => 'create-invoice',
            'id'        => $invoice_id,
            'message'   => sprintf( __('Invoice number # %s successfully saved', 'wpcodigo_wms'), $invoice_number )
        );
        return false;
    }
    public static function update_invoice(){
        if ( ! isset( $_POST['cwms-update_invoice_form_nonce'] ) 
            || ! wp_verify_nonce( $_POST['cwms-update_invoice_form_nonce'], 'cwms-update_invoice_form_action' ) 
        ) {
            return false;
        }

        if( ! isset( $_POST['cwms_invoice_id'] ) 
            || ! (int)$_POST['cwms_invoice_id']
            || ! cwms1661_can_update_invoice()
            || ! is_cwms1661_invoice( (int) $_POST['cwms_invoice_id'] )
            ){
            echo '<div id="message" class="error"><p>' . __('Permission denied. Please contact admin support', 'wpcodigo_wms') . '</p></div>';
            wp_die();
        }
        $invoice_date       = isset( $_POST['_invoice_date'] ) && !empty( $_POST['_invoice_date'] ) ? trim($_POST['_invoice_date']) : false ;
        $invoice_status     = isset( $_POST['_invoice_status'] ) && array_key_exists( $_POST['_invoice_status'], cwms1661_invoice_bulk_actions() ) ? trim($_POST['_invoice_status']) : false ;
        $invoice_args       = array(
            'ID'           => (int) $_POST['cwms_invoice_id'],
            'post_date'    => strftime( '%Y-%m-%d %X', strtotime( $invoice_date ) )
        );
        if( $invoice_status ){
            $invoice_args['post_status'] = $invoice_status;
        }
        $invoice_id = wp_update_post( $invoice_args );
        if ( is_wp_error( $invoice_id ) ) {
            echo '<div id="message" class="error"><p>' . $invoice_id->get_error_message() . '</p></div>';
            wp_die();
        }
        $invoice_number = get_the_title( $invoice_id );
        $subpage        = $invoice_status && $invoice_status == 'cwms-completed' ? 'view-invoice' :  'update-invoice' ;
        $_POST['cwms_invoice_redirection'] = array(
            'url'       => cwms1661_dashboard_home(),
            'subpage'   => $subpage,
            'id'        => $invoice_id,
            'message'   => sprintf( __('Invoice number # %s successfully saved', 'wpcodigo_wms'), $invoice_number )
        );
        return false;
    }
    public static function save_invoice_post_meta( $invoice_id, $post, $update ){
        $user_id        = get_current_user_id();
        // Saving invoice post meta
        if( isset($_POST['_customer_id']) && (int)$_POST['_customer_id'] ){
            $user_info = get_userdata( (int)$_POST['_customer_id'] );
            update_post_meta( $invoice_id, '_customer_id', $user_info->ID );
            update_post_meta( $invoice_id, '_customer_details', cwms1661_get_user_info( $user_info ) );
            update_post_meta( $invoice_id, '_state', get_user_meta( $user_info->ID, '_state', true ) );
            update_post_meta( $invoice_id, '_city', get_user_meta( $user_info->ID, '_city', true ) );
        }

        // Saving Invoice DR logic
        if( !$update && cwms1661_dr_senquence_enable() ){
            $latest_dr_no  = cwms1661_generate_invoice_dr();
            update_post_meta( $invoice_id, '_dr_no', $latest_dr_no );
            cwms1661_dr_update_senquence_number( $latest_dr_no );
        }elseif( !cwms1661_dr_senquence_enable() && isset($_POST['_invoice_dr_no']) ){
            update_post_meta( $invoice_id, '_dr_no', sanitize_textarea_field( $_POST['_invoice_dr_no'] ) );
        }

        if( isset($_POST['remarks']) ){
            update_post_meta( $invoice_id, '_remarks', sanitize_textarea_field( $_POST['remarks'] ) );
        }
        if( isset($_POST['terms']) ){
            update_post_meta( $invoice_id, '_terms', sanitize_textarea_field( $_POST['terms'] ) );
        }
        if( isset($_POST['cod_discount']) ){
            update_post_meta( $invoice_id, '_cod_discount', floatval($_POST['cod_discount']) );
        }
        if( isset($_POST['tax']) ){
            update_post_meta( $invoice_id, '_tax', floatval($_POST['tax']) );
        }
        if( isset($_POST['others']) ){
            update_post_meta( $invoice_id, '_others', floatval($_POST['others']) );
        }
        if( isset($_POST['_assigned_agent']) ){
            update_post_meta( $invoice_id, '_assigned_agent', (int)$_POST['_assigned_agent'] ) ;
        }
        if( isset($_POST['_assigned_whseman']) ){
            update_post_meta( $invoice_id, '_assigned_whseman', (int)$_POST['_assigned_whseman'] ) ;
        }

        update_post_meta( $invoice_id, '_updated_by', cwms1661_user_fullname( $user_id ) );
        update_post_meta( $invoice_id, '_updated_on', date( 'Y-m-d H:i:s', current_time( 'timestamp', 0 ) ) );

        // Saving product data
        if( isset( $_POST['cwms_invoice_products'] ) && is_array( $_POST['cwms_invoice_products'] ) ){
            $products   = $_POST['cwms_invoice_products'];

            // Prepare products for processing
            array_walk($products, function( &$product, $key ) use( $invoice_id ) {
                // $discAmount                 = cwms1661_calculate_discount( $product, 'qty_delivered' );
                $product['discount_amount'] = 0;
                $product['trans_id']        = $invoice_id;
                $product['ID']              = null;
            });

            if( $post->post_status == 'cwms-completed' ){
                $remarks    = sprintf( esc_html__( 'Complete invoice order # %s', 'wpcodigo_wms' ), $post->post_title );
                foreach ( $products as $product ) {
                    // Deduct product quantity in stock
                    $deducted_qty       = floatval($product['qty_delivered']) * -1;
                    $product_history_id = cwms1661_update_product_qty( $product['product_id'], $deducted_qty, $invoice_id, $post->post_title, $remarks );                                
                    if( ! $product_history_id ){
                        continue;
                    }
                    // Add product to invoice
                    cwms1661_assign_product( $invoice_id, $product, 'cwms_invoice' );
                    // Delete invoice product meta
                    delete_post_meta( $invoice_id, '_products' );
                }
                update_post_meta( $invoice_id, '_payment_status', '_unpaid' );
            }else{
                update_post_meta( $invoice_id, '_products', $products );
            }
        }
    }
    // Save supplier redirection
    public static function save_redirection(){
        if( !isset($_POST['cwms_invoice_redirection']) || !is_array($_POST['cwms_invoice_redirection']) ){
            return false;
        }
        wp_redirect( $_POST['cwms_invoice_redirection']['url'] .'?cwmspage='. $_POST['cwms_invoice_redirection']['subpage'] .'&id='. $_POST['cwms_invoice_redirection']['id'] .'&cwms-message='. urlencode($_POST['cwms_invoice_redirection']['message']) );
        exit;
    }
    public static function notification_message(){
        if( !isset($_GET['cwmspage']) ){
            return false;
        }
        if( !isset($_GET['cwms-message']) || empty($_GET['cwms-message']) ){
            return false;
        }
        printf('<div class="submit-notification_message alert alert-success">%s</div>', urldecode($_GET['cwms-message']));
        ?>        
        <script>
            window.history.replaceState({}, document.title, '<?php echo cwms1661_dashboard_home().'?'.cwms1661_clean_url_parameter(['cwms-message']); ?>' );
            setTimeout(function(){
                jQuery('body').find('.submit-notification_message').remove();
            }, 6000 );
        </script>
        
        <?php
    }
    // AJAX
    public static function get_all_invoices(){
        $post_status    = sanitize_text_field( $_GET['status'] );
        $data           = cwms1661_get_all_invoice_data( array(  $post_status ) );
        $can_update     = cwms1661_can_update_invoice();
        if( $data ){
            $data = array_map( function( $value ) use($can_update, $post_status) {

                $action_links = [
                    'edit' => sprintf(
                        '<span class="edit"><a class="cwms-update_so text-primary" href="%s">%s</a> ',
                        esc_url_raw( cwms1661_dashboard_home().'?cwmspage=update-invoice&id='.$value['ID'] ),
                        esc_html__('Edit','wpcodigo_wms')
                    ),
                    'view'  => sprintf(
                        '<span class="view"><a class="text-primary" href="%s">%s</a></span>',
                        esc_url_raw( cwms1661_dashboard_home().'?cwmspage=view-invoice&id='.$value['ID'] ),
                        esc_html__('View','wpcodigo_wms')
                    )
                ];
                if( ! $can_update || $post_status == 'cwms-completed' ){
                    $action_links = [];
                }

                $label_url  = esc_url_raw( cwms1661_dashboard_home().'?cwmspage=view-invoice&id='.$value['ID'] );
                $actions    = sprintf( '<a href="%s" class="downloadPDF" data-id="%s" data-type="invoice"><i class="fa fa-2x fa-list-alt" title="%s" style="margin-right:12px;"></i></a>', '#', $value['ID'], __('Download Charge Sales Invoice', 'wpcodigo_wms') );
                $actions    .= sprintf( '<a href="%s" class="downloadPDF" data-id="%s" data-type="consignment"><i class="fa fa-2x fa-list" title="%s" style="margin-right:12px;"></i></a>', '#', $value['ID'], __('Download Consignment Receipt', 'wpcodigo_wms') );
                $actions    .= sprintf( '<a href="%s" class="downloadPDF" data-id="%s" data-type="delivery"><i class="fa fa-2x fa-truck" title="%s" style="margin-right:12px;"></i></a>', '#', $value['ID'], __('Download Delivery Receipt', 'wpcodigo_wms') );
                ob_start();
                ?>
                <strong data-id="<?php echo $value['ID']; ?>">
                    <a href="<?php echo $label_url; ?>"><?php echo $value['_invoice_number']; ?></a>
                </strong> 
                <?php if( !empty($action_links) ): ?>
                    <div class="row-actions" data-id="<?php echo $value['ID']; ?>">
                        <?php echo implode( ' | ', array_values( $action_links ) ) ?>
                    </div>
                <?php endif; ?>
                <?php
                $value['_invoice_number'] = ob_get_clean();
                $value['_total_amount'] = cwms1661_format_number( $value['_total_amount'], 2, ',' );
                $value['_actions']  = $actions;
                return $value;
            }, $data );
        }
        wp_send_json( array( 'data' => $data ) );
    }

    public static function invoice_bulk_action(){
        $invoice_ids    = $_POST['invoiceIds'];
        $action         = $_POST['actionType'];
        $statuses       = array_keys( cwms1661_invoice_bulk_actions() );  
        if( !in_array( $action, $statuses ) 
            || ( $action == 'cwms-delete' && ! cwms1661_can_delete_invoice() ) 
            || ( $action != 'cwms-delete' && ! cwms1661_can_update_invoice() )
            ){
            wp_send_json( array(
                'status' => 'error',
                'message' => __('Request error, permission denied!', 'wpcodigo_wms')
            ) );
        }

          // Checked if there is complete status in the ID list
        $has_error = array_filter( array_map( function( $id ){
            return get_post_status( (int)$id ) == 'cwms-completed' || get_post_type( (int)$id ) != CWMS1661_INVOICE_POST_TYPE;
        },  $invoice_ids) );

        if( !empty( $has_error ) ){
            wp_send_json( array(
                'status' => 'error',
                'message' => __('One request permission denied. please reloaded the page and try again.', 'wpcodigo_wms')
            ) );
        }

        // Delete PO
        foreach ( $invoice_ids as $id ) {
            if( 'cwms-completed' ==  $action ){
                // Update Product Qty and History
                $invoice_number = get_the_title( $id );
                $remarks        = sprintf( __('Complete invoice order # %s', 'wpcodigo_wms'), $invoice_number );
                $product_data   = cwms1661_get_invoice_product_data( $id );

                if( !empty( $product_data ) ){
                    foreach ( $product_data as $product ) {
                        if( empty( $product ) ){
                            continue;
                        }

                        $deducted_qty       = floatval($product['qty_delivered']) * -1;
                        $product_history_id = cwms1661_update_product_qty( $product['product_id'], $deducted_qty, $id, $invoice_number, $remarks );                                
                        if( ! $product_history_id ){
                            continue;
                        }
                        // Add product to invoice
                        cwms1661_assign_product( $id, $product, 'cwms_invoice' );
                        // Delete invoice product meta
                        delete_post_meta( $id, '_products' );   
                    }
                }
            }
            
            // Update Invoice Status
            $update_post = wp_update_post( array( 'ID' => (int)$id, 'post_status' => $action ) );
            if( is_wp_error( $update_post ) ){
                wp_send_json( array(
                    'status' => 'error',
                    'message' => $update_post->get_error_message()
                ) );
                break;
            }
            // Setup Payment Status when status is completed
            if( $action == 'cwms-completed' ){
                update_post_meta( (int)$id, '_payment_status', '_unpaid' );
            }
        } 

        wp_send_json( array( 
            'status' => 'success',
            'message' => __('Request completed', 'wpcodigo_wms')
        ));
        wp_die();
    }

    public static function search_invoice_so(){
        $options    = cwms1661_search_so( $_GET['q'], array('cwms-processing', 'cwms-approved', 'cwms-completed', 'cwms-reserve') );
        $data       = [];
        if( !empty( $options ) ){
            foreach ($options as $po_id ) {
                $data[] = cwms1661_get_so_data( $po_id );
            }
        }
        wp_send_json( array(
            'drno'  => cwms1661_generate_invoice_dr(),
            'invno' => cwms1661_generate_invoice_number(),
            'data'  => $data
        ) );
        wp_die();
    }

    public static function check_invoice_dr(){
        $dr_no      = sanitize_text_field( $_POST['drNo'] );
        $invoice_id = cwms1661_search_invoice_dr( $dr_no );
        $results    = array(
            'status' => 'success',
            'message' => sprintf( __('DR No. %s is OK to use.', 'wpcodigo_wms'),  $dr_no )
        );
        if( $invoice_id ){
            $results    = array(
                'status' => 'error',
                'message' => sprintf( __('DR No. %s is already used in Invoice # %s.', 'wpcodigo_wms'), $dr_no, get_the_title( $invoice_id  ) )
            );
        }
        wp_send_json( $results );
        wp_die();
    }

    public static function invoice_delete(){
        $pos_id    = (int)$_POST['invoiceID'];
        if( get_post_status( $pos_id ) != 'cwms-for-approval' 
            || get_post_type( $pos_id ) != CWMS1661_INVOICE_POST_TYPE 
            || ! cwms1661_can_delete_so() ){
            wp_send_json( array(
                'status'    => 'error',
                'code'      => 401,
                'message'   => __('Request error, permission denied!', 'wpcodigo_wms')
            ) );
        }
        wp_trash_post( $pos_id );
        wp_send_json( array( 
            'status'    => 'success',
            'code'      => 200,
            'message'   => __('Request completed', 'wpcodigo_wms')
        ));
        wp_die();
    }

    public static function permissions( $permissions ){
        $permissions[40] = array(
            'label' => esc_html__('Invoices', 'wpcodigo_wms' ),
			'options' => array(
                'cwms1661_can_view_invoice_roles'           => esc_html__('View', 'wpcodigo_wms' ), 
                'cwms1661_can_create_invoice_roles'         => esc_html__('Add', 'wpcodigo_wms' ), 
                'cwms1661_can_update_invoice_roles'         => esc_html__('Update', 'wpcodigo_wms' ), 
                // 'cwms1661_can_cancel_invoice_status_roles'  => esc_html__('Cancel', 'wpcodigo_wms' ),
                // 'cwms1661_can_delete_invoice_roles'         => esc_html__('Delete', 'wpcodigo_wms' )
            )
        );
        return $permissions;
    }

    public static function print_invoice( $file_path, $print_id ){
        if( !(int)$print_id  ){
            return $file_path;
        }
        return apply_filters( "cwms1661_invoice_print_template", CWMS1661_ABSPATH.'module/invoice/templates/print-invoice.php' );
    }
    public static function print_consignment( $file_path, $print_id ){
        if( !(int)$print_id  ){
            return $file_path;
        }
        return apply_filters( "cwms1661_consignment_print_template", CWMS1661_ABSPATH.'module/invoice/templates/print-consignment.php' );
    }
    public static function print_delivery( $file_path, $print_id ){
        if( !(int)$print_id  ){
            return $file_path;
        }
        return apply_filters( "cwms1661_delivery_print_template", CWMS1661_ABSPATH.'module/invoice/templates/print-delivery.php' );
    }
}