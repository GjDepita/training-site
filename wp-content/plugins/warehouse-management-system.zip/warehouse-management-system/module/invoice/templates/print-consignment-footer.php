<tr>
    <td colspan="4" style="text-align: justify;padding-right:120px; padding-left:0;">
        All accounts overdue will be charge 12% interest per annum plus 25% on said amount for attorney’s fees and cost of collection. The parties expressly submit themselves to the jurisdiction of the court of Iloilo City in any legal actions arising out of this transaction without in any way attempting to divert in an other court of courts. A charge of 10% will be made on all returned goods at customer’s request to cover handling expenses. 
    </td>
    <td colspan="3" style="vertical-align: bottom;text-align: justify;">
        Received form NEXUS TRADING the above describe articles in good order and condition.
    </td>
</tr>
<tr>
    <td colspan="4">&nbsp;</td>
    <td colspan="3" style="vertical-align:bottom;padding-bottom:2px;">
        <div style="border-bottom: 1px solid #000;margin-top:90px;">
            <span style="border-bottom: 6px solid white;"><?php esc_html_e('BY', 'wpcodigo_wms'); ?>: </span> 
            &nbsp;
        </div>  
    </td>
</tr>
<tr>
    <td colspan="4">&nbsp;</td>
    <td colspan="3" class="text-center" style="padding-top:2px;">
        <p style="font-size:1.2em;"><?php esc_html_e("INVOICE TO FOLLOW", 'wpcodigo_wms'); ?> (NT)</p>
    </td>
</tr>