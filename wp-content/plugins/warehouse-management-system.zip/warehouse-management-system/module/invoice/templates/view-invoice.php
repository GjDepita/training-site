<?php
$invoice            = cwms1661_get_invoice_data( (int)$_GET['id'] );
$general_settings   = cwms1661_get_general_settings();
$invoice_number     = $invoice['title'];
$current_date       = $invoice['_date_created'];
$products           = $invoice['_products'];
?>
<div class="col-md-offset-1 col-md-10 col-sm-12">
    <?php do_action('cwms1661_before_view_invoice_template', $invoice ); ?>
    <!-- Header -->
    <section id="po-header-section" class="row" style="margin-bottom:18px;">
        <div class="col-md-6 col-sm-12">
            <?php if($general_settings['_company_logo']):  ?>
                <img src="<?php echo $general_settings['_company_logo']; ?>" alt="<?php echo $general_settings['_company_name']; ?>" width="210">
            <?php endif; ?>
        </div>
        <div class="col-md-6 col-sm-12 text-right">
            <h1><?php esc_html_e('INVOICE ORDER', 'wpcodigo_wms'); ?></h1>
            <?php esc_html_e('DATE', 'wpcodigo_wms'); ?>: <?php echo $current_date; ?><br/>            
            <span class="cwms-invoice_number"><?php esc_html_e('Invoice', 'wpcodigo_wms'); ?>#: <?php echo $invoice_number; ?></span></br>
            <span class="cwms-invoice_dr_no"><?php esc_html_e('DR', 'wpcodigo_wms'); ?>#: <?php echo $invoice['_dr_no']; ?></span></br>
            <strong><?php echo $invoice['_status']; ?></strong>
            <?php if( $invoice['_payment_status'] && $invoice['_status_key'] == 'cwms-completed' ): ?>
                </br><?php esc_html_e('Payment', 'wpcodigo_wms'); ?>: <strong><?php echo $invoice['_payment_status']; ?></strong>
            <?php endif; ?>
        </div>
    </section>
    <!-- Vendors Information -->
    <section id="customer-info-section" class="row" style="margin-bottom:18px;">
        <div class="col-md-6 col-sm-12">
            <h3 class="info-header bg-header"><?php esc_html_e('From', ''); ?></h3>
            <span class="contact-name"><?php echo $general_settings['_company_name']; ?></span></br>
            <span class="company-address"><?php echo nl2br( $general_settings['_address'] ); ?></span><br/>
            <?php echo $general_settings['_phone']; ?>
        </div>
        <div class="col-md-6 col-sm-12">
            <h3 class="info-header bg-header"><?php esc_html_e('Customer', 'wpcodigo_wms'); ?></h3>
            <div id="cwms-customer-details">
                <?php if( (int)$invoice['_customer_id'] ): ?>
                    <strong><?php echo $invoice['_customer_company']; ?></strong><br/>
                    <span class="contact-name"><?php echo $invoice['_customer']; ?></span><br/>
                    <?php echo cwms1661_display_address_html( $invoice['_customer_details'] ); ?><br/>
                    <?php echo $invoice['_customer_details']['_phone']; ?><br/>
                    <?php echo $invoice['_customer_details']['_email']; ?>
                <?php endif; ?>
            </div>
        </div>
    </section>
    <section id="product-info" class="table-responsive cwms_invoice_items">
        <table id="cwms-poitems-table" class="table table-sm table-hover">
            <thead>
                <tr>
                    <th><?php esc_html_e('SKU', 'wpcodigo_wms'); ?></th>
                    <th><?php esc_html_e('Name', 'wpcodigo_wms'); ?></th>
                    <th class="cwms-input-header"><?php esc_html_e('Order Qty', 'wpcodigo_wms'); ?></th>
                    <th class="cwms-input-header"><?php esc_html_e('Delivered Qty', 'wpcodigo_wms'); ?></th>
                    <th class="cwms-input-header"><?php esc_html_e('Unit', 'wpcodigo_wms'); ?></th>
                    <th class="cwms-input-header"><?php esc_html_e('Retail Price', 'wpcodigo_wms'); ?></th>
                    <th class="cwms-input-header"><?php esc_html_e('Discount(s)', 'wpcodigo_wms'); ?></th>
                    <th class="cwms-input-header text-right"><?php esc_html_e('Total', 'wpcodigo_wms'); ?></th>
                </tr>
            </thead>
            <tbody >
                <?php foreach ( $products as $product ): ?>
                    <tr >
                        <td class="col-upc"><?php echo esc_html( $product['upc'] ); ?></td>
                        <td class="col-name"><?php echo esc_html( $product['name'] ); ?></td>
                        <td class="col-qty"><?php echo floatval( $product['qty_ordered'] ); ?></td>
                        <td class="col-qty"><?php echo floatval( $product['qty_delivered'] ); ?></td>
                        <td class="col-qty"><?php echo esc_html( $product['unit'] ); ?></td>
                        <td class="col-unit_price"><?php echo cwms1661_format_number( $product['retail_price'], 2, ',' ); ?></td>
                        <td class="col-discount"><?php echo esc_html( $product['discount'] ); ?></td>
                        <td class="col-total text-right"><?php echo cwms1661_format_number( $product['total'], 2, ',' ); ?></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </section>
    <div class="row" id="amount-breakdown">
        <!-- Remarks column -->
        <div class="col-xs-6">
            <p class="lead"><?php esc_html_e('Remarks', 'wpcodigo_wms'); ?>:</p>
            <textarea name="remarks" rows="6" style="width:100%;margin-bottom:20px;" placeholder="<?php esc_html_e('Add remarks here.', 'wpcodigo_wms'); ?>" disabled><?php echo $invoice['_remarks'] ; ?></textarea>
            <p class="lead"><?php esc_html_e('Terms', 'wpcodigo_wms'); ?>: <?php echo esc_html( cwms1661_term_options()[$invoice['_terms']] ) ; ?></p>
        </div>
        <!-- /.col -->
        <div class="col-xs-6">
            <p class="lead"><?php esc_html_e('Amount Due', 'wpcodigo_wms'); ?></p>
            <div class="table-responsive">
                <table id="cwms-amountdue-table" class="table">
                    <tbody>
                    <tr>
                        <th style="width:50%" class="text-right"><?php esc_html_e('SubTotal', 'wpcodigo_wms'); ?>:</th>
                        <td class="amount_due_subtotal text-right"><?php echo cwms1661_format_number($invoice['_sub_total'], 2, ',' ) ; ?></td>
                    </tr>
                    <tr>
                        <th style="width:50%" class="text-right"><?php esc_html_e('COD Discount', 'wpcodigo_wms'); ?>:</th>
                        <td class="amount_cod_discount text-right"><?php echo cwms1661_format_number( $invoice['_cod_discount'], 2, ',' ) ; ?></td>
                    </tr>
                    <tr>
                        <th class="text-right"><?php esc_html_e('Tax', 'wpcodigo_wms'); ?>:</th>
                        <td class="amount_due_tax text-right"><?php echo cwms1661_format_number( $invoice['_tax'], 2, ',' ) ; ?></td>
                    </tr>
                    <tr>
                        <th class="text-right"><?php esc_html_e('Others', 'wpcodigo_wms'); ?>:</th>
                        <td class="amount_due_others text-right"><?php echo cwms1661_format_number( $invoice['_others'], 2, ',' ) ; ?></td>
                    </tr>
                    <tr>
                        <th class="text-right"><?php esc_html_e('Total', 'wpcodigo_wms'); ?>:</th>
                        <td class="amount_due_total text-right"><?php echo cwms1661_format_number( $invoice['_total_amount'], 2, ',' ) ; ?></td>
                    </tr>
                    </tbody>
                </table>
            </div>
        </div>
        <!-- /.col -->
    </div>
    <div class="ln_solid"></div>
    <section id="action-section">
        <div class="col-md-6 form-group">
            <strong><?php esc_html_e('Date'); ?>: </strong> <?php echo $invoice['_date_created']; ?><br/>
            <strong><?php esc_html_e('Prepared by'); ?>:</strong> <?php echo $invoice['_created_by']; ?> 
        </div>
        <div class="col-md-6 text-right">
         <?php esc_html_e('Salesman', 'wpcodigo_wms'); ?> : <strong><?php echo $invoice['_assigned_agent_name']; ?> </strong></br>
         <?php esc_html_e('Checked By', 'wpcodigo_wms'); ?> : <strong><?php echo $invoice['_assigned_whseman_name']; ?> </strong>
        </div>
    </section>
    <?php do_action('cwms1661_after_view_invoice_template', $invoice ); ?>
</div>