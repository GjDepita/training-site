<?php
    $invoice            = cwms1661_get_invoice_data( (int)$_GET['id'] );
    $general_settings   = cwms1661_get_general_settings();
    $invoice_number     = $invoice['title'];
    $current_date       = $invoice['_date_created'];
    include_once apply_filters( "cwms1661_get_template_form-invoice", CWMS1661_ABSPATH.'module/invoice/templates/form-invoice.php' );
?>