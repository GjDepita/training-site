<tr>
    <td rowspan="2" colspan="4" class="text-uppercase" style="vertical-align:bottom;">
        <div style="border-bottom: 1px solid #000; font-size:28px;">
            <span style="border-bottom: 6px solid white;"><?php esc_html_e('Consign to', 'wpcodigo_wms'); ?>:</span> 
            <?php echo esc_html( $invoice['_customer_company'] ); ?>
        </div>
    </td>
    <td colspan="3">
        <div style="border-bottom: 1px solid #000;vertical-align:top;">
            <span style="border-bottom: 6px solid white;"><?php esc_html_e('Date', 'wpcodigo_wms'); ?>:</span> 
            <?php echo esc_html( $current_date ); ?>
        </div>
    </td>
</tr>
<tr>
    <td colspan="3">
        <div style="border-bottom: 1px solid #000;">
            <span style="border-bottom: 6px solid white;"><?php esc_html_e('Terms', 'wpcodigo_wms'); ?>:</span> 
            <?php echo cwms1661_term_options()[$invoice['_terms']]; ?>
        </div>
    </td>
</tr>
<tr>
    <td rowspan="2" colspan="4" class="text-uppercase" style="vertical-align:bottom;padding:4px;">
        <div style="border-bottom: 1px solid #000;">
            <span style="border-bottom: 6px solid white;"><?php esc_html_e('Address', 'wpcodigo_wms'); ?>:</span> 
            <?php echo esc_html( $customer_address ); ?>
        </div>   
    </td>
    <td colspan="3" style="padding:4px;">
        <div style="border-bottom: 1px solid #000;">
            <span style="border-bottom: 6px solid white;"><?php esc_html_e('Salesman', 'wpcodigo_wms'); ?>:</span> 
            <?php echo esc_html( $invoice['_assigned_agent_name'] ); ?>
        </div> 
    </td>
</tr>
<tr>
    <td colspan="3">
        <div style="border-bottom: 1px solid #000;vertical-align:top;">
            <span style="border-bottom: 6px solid white;"><?php esc_html_e('Checked By', 'wpcodigo_wms'); ?>:</span> 
            <?php echo esc_html( $invoice['_assigned_whseman_name'] ); ?>
        </div>
    </td>
</tr>
<tr>
    <td colspan="2" class="text-uppercase" style="padding:4px;">
        <div >
            <span style="border-bottom: 6px solid white;"><?php esc_html_e('Delivery Instructions', 'wpcodigo_wms'); ?>: </span> 
        </div>  
    </td>
    <td colspan="2" class="text-uppercase" style="padding:4px; border-bottom:1px solid #000;">
        <div >
            <?php echo esc_html( $invoice['_remarks'] ); ?>
            <div style="padding:24px 0;width:100%;"></div>
        </div>  
    </td>
    <td colspan="3" style="padding:4px;">
        <div style="border-bottom: 1px solid #000;">
            <span style="border-bottom: 6px solid white;"><?php esc_html_e('P.O NO.', 'wpcodigo_wms'); ?>:</span> 
            &nbsp;
        </div>  
    </td>
</tr>