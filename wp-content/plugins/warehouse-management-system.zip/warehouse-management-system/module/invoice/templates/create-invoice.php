<?php  
    $general_settings   = cwms1661_get_general_settings(); 
    $invoice_number     = cwms1661_generate_invoice_number();
    $current_date       = date( cwms1661_datetime_format(), current_time( 'timestamp', 0 ) );
?>
<section id="cwms-search_so_action_wrapper" class="col-md-12">
    <select id="cwms-search_so" class="cwms-select2-search form-control form-control-sm" data-action="cwms_search_so_invoice" style="width: 280px;" aria-placeholder="<?php esc_html_e('Search SO Number', 'wpcodigo_wms'); ?>">
        <option value=""><?php esc_html_e('Search SO number', 'wpcodigo_wms'); ?></option>
    </select>
</section>
<section id="cwms-notification_action_wrapper" class="col-md-12" style="margin-top:36px;">
    <?php do_action( 'cwms1661_before_invoice_form' ); ?>
</section>
<section id="cwms-search_so_result_wrapper" class="col-md-12" style="margin-top: 36px; position: relative; min-height: 180px;">
    <div class="so-details_placeholder">
        <span style="margin: 12px 0; font-style: italic; font-size: 1.2em;"><?php esc_html_e('Search SO number to create invoice.', 'wpcodigo_wms'); ?></span><br/>
        <span class="text-danger" style="margin: 12px 0; font-style: italic;"><?php esc_html_e('Note: Only Sales order with Approved and Processing status are allowed to generate invoice.', 'wpcodigo_wms'); ?></span>
    </div>
</section>
<div id="cwms-so_invoicing_form_wrapper" class="col-md-offset-1 col-md-10 col-sm-12 d-none">
    <form id="cwms-invoicing_so_form" class="form-horizontal form-label-left input_mask" action="" method="POST">
        <?php wp_nonce_field( 'cwms-create-invoice_form_action', 'cwms-create-invoice_form_nonce' ); ?>
        <input type="hidden" name="_assigned_agent" value="" />
        <input type="hidden" name="_assigned_whseman" value="" />
        <input type="submit" style="display:none !important;" value="<?php esc_html_e('Create Invoice Order', 'wpcodigo_wms'); ?>">
        <!-- Header -->
        <section id="po-header-section" class="row" style="margin-bottom:18px;">
            <div class="col-md-6 col-sm-12">
                <?php if($general_settings['_company_logo']):  ?>
                    <img src="<?php echo $general_settings['_company_logo']; ?>" alt="<?php echo $general_settings['_company_name']; ?>" width="210">
                <?php endif; ?>
            </div>
            <div class="col-md-6 col-sm-12 text-right">
                <h1><?php esc_html_e('INVOICE ORDER', 'wpcodigo_wms'); ?></h1>
                <span class="cwms-invoice_date"><?php esc_html_e('DATE', 'wpcodigo_wms'); ?>: <input type="text" name="_invoice_date"  class="cwms-datetime-12hrs" value="<?php echo $current_date; ?>" style="border: 1px solid #dcdcdc;padding-right: 6px;text-align: right;margin-bottom: 4px;" required /></span><br/>
                <?php if( !cwms1661_dr_senquence_enable() ): ?>
                    <span class="cwms-invoice_dr_no"><?php esc_html_e('DR #', 'wpcodigo_wms'); ?>: <input type="text" name="_invoice_dr_no"  value="" style="border: 1px solid #dcdcdc;padding-right: 6px;text-align: right; margin-bottom: 4px;" required /></span></br>
                <?php endif; ?>
                <span class="cwms-invoice_number"><?php esc_html_e('Invoice', 'wpcodigo_wms'); ?>#: <span class="_invoice_number"><?php echo $invoice_number; ?></span></span>
                <input type="hidden" name="_invoice_number" value="<?php echo $invoice_number; ?>" />
                <input type="hidden" name="_so_id" value="" />
            </div>
        </section>
        <!-- Vendors Information -->
        <section id="customer-info-section" class="row" style="margin-bottom:18px;">
            <div class="col-md-6 col-sm-12">
                <h3 class="info-header bg-header"><?php esc_html_e('From', ''); ?></h3>
                <span class="contact-name"><?php echo $general_settings['_company_name']; ?></span></br>
                <span class="company-address"><?php echo nl2br( $general_settings['_address'] ); ?></span><br/>
                <?php echo $general_settings['_phone']; ?>
            </div>
            <div class="col-md-6 col-sm-12">
                <h3 class="info-header bg-header"><?php esc_html_e('Customer', 'wpcodigo_wms'); ?></h3>
                <div id="cwms-customer-details">
                    <!-- Dynamic data here -->
                </div>
            </div>
        </section>
        <section id="product-info" class="table-responsive cwms_invoice_items">
            <p class="text-danger" style="margin: 12px 0; font-style: italic; font-size: 1.2em;"><?php esc_html_e('Note: In adding multiple discount please add comma (,) to separate each discount. For pecentage add (%) at the end Ex. 5%', 'wpcodigo_wms'); ?></p>
            <table id="cwms-invoicing-soitems-table" class="table table-sm table-hover">
                <thead>
                    <tr>
                        <th colspan="2"><?php esc_html_e('SKU', 'wpcodigo_wms'); ?></th>
                        <th><?php esc_html_e('Name', 'wpcodigo_wms'); ?></th>
                        <th class="cwms-input-header"><?php esc_html_e('Order Qty', 'wpcodigo_wms'); ?></th>
                        <th class="cwms-input-header"><?php esc_html_e('Delivered Qty', 'wpcodigo_wms'); ?></th>
                        <th class="cwms-input-header"><?php esc_html_e('Unit', 'wpcodigo_wms'); ?></th>
                        <th class="cwms-input-header"><?php esc_html_e('Retail Price', 'wpcodigo_wms'); ?></th>
                        <th class="cwms-input-header"><?php esc_html_e('Discount(s)', 'wpcodigo_wms'); ?></th>
                        <th class="cwms-input-header"><?php esc_html_e('Total', 'wpcodigo_wms'); ?></th>
                    </tr>
                </thead>
                <tbody data-repeater-list="cwms_invoice_products">
                </tbody>
            </table>
        </section>
        <div class="row" id="amount-breakdown">
            <!-- Remarks column -->
            <div class="col-xs-6">
                <p class="lead"><?php esc_html_e('Remarks', 'wpcodigo_wms'); ?>:</p>
                <textarea class="form-control form-control-sm" name="remarks" rows="6" style="width:100%; margin-bottom:20px;" placeholder="<?php esc_html_e('Add remarks here.', 'wpcodigo_wms'); ?>"><!-- Dynamic data --></textarea>
                <p class="lead"><?php esc_html_e('Terms', 'wpcodigo_wms'); ?>:</p>
                <select id="cwms-search_terms" class="form-control form-control-sm" style="width: 280px; display: inline-block;" name="terms" required >
                    <option value=""><?php esc_html_e('Select Term', 'wpcodigo_wms'); ?></option>
                    <?php foreach( cwms1661_term_options() as $term_key => $term_value ): ?>
                        <option value="<?php echo (int)$term_key; ?>"><?php echo esc_html( $term_value ); ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <!-- /.col -->
            <div class="col-xs-6">
                <p class="lead"><?php esc_html_e('Amount Due', 'wpcodigo_wms'); ?></p>
                <div class="table-responsive">
                    <table id="cwms-amountdue-table" class="table">
                        <tbody>
                        <tr>
                            <th style="width:50%"><?php esc_html_e('SubTotal', 'wpcodigo_wms'); ?>:</th>
                            <td class="amount_due_subtotal">0.00</td>
                        </tr>
                        <tr>
                            <th><?php esc_html_e('COD Discount', 'wpcodigo_wms'); ?>:</th>
                            <td class="amount_cod_discount">
                                <input type="text" class="cmws-currency cwms-calculate" name="cod_discount" value="0.00" />
                            </td>
                        </tr>
                        <tr>
                            <th><?php esc_html_e('Tax', 'wpcodigo_wms'); ?>:</th>
                            <td class="amount_due_tax">
                                <input type="text" class="cmws-currency cwms-calculate" name="tax" value="0.00" />
                            </td>
                        </tr>
                        <tr>
                            <th><?php esc_html_e('Others', 'wpcodigo_wms'); ?>:</th>
                            <td class="amount_due_others">
                                <input type="text" class="cmws-currency cwms-calculate" name="others" value="0.00" />
                            </td>
                        </tr>
                        <tr>
                            <th><?php esc_html_e('Total', 'wpcodigo_wms'); ?>:</th>
                            <td class="amount_due_total">0.00</td>
                        </tr>
                        </tbody>
                    </table>
                </div>
            </div>
            <!-- /.col -->
            </div>
        <div class="ln_solid"></div>
        <section id="action-section">
            <div class="col-md-6 form-group">
                <?php esc_html_e('Salesman', 'wpcodigo_wms'); ?> : <strong><span class="_assigned_agent_name"></span></strong><br/>
                <?php esc_html_e('Checked By', 'wpcodigo_wms'); ?> : <strong><span class="_assigned_whseman_name"></span></strong>
            </div>
            <div class="col-md-6 text-right">
                <input id="cmws-submit-form_invoice" type="button" class="btn btn-md btn-success" value="<?php echo __('Create Invoice Order', 'wpcodigo_wms'); ?>">
            </div>
        </section>
    </form>
</div>