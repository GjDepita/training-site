<?php
$invoice            = cwms1661_get_invoice_data( (int)$print_id );
$general_settings   = cwms1661_get_general_settings();
$invoice_number     = $invoice['title'];
// $current_date       = $invoice['_date_created'];
$current_date       = cwms1661_current_date();
$customer_details   = $invoice['_customer_details'];
$customer_address   = '';
if( !empty( $customer_details['_address_1'] ) || !empty( $customer_details['_address_2'] ) ){
    $customer_address .= $customer_details['_address_1'].' '.$customer_details['_address_2'].', ';
}
if( !empty( $customer_details['_city'] ) || !empty( $customer_details['_state'] ) ){
    $customer_address .= $customer_details['_city'].' '.$customer_details['_state'].', ';
}
if( !empty( $customer_details['_postcode'] ) || !empty( $customer_details['_country'] ) ){
    $customer_address .= $customer_details['_postcode'].', '.$customer_details['_country'];
}
$products           = cwms1661_remove_zero_product( $invoice['_products'] );
$record_limit       = 24;
$chucked_products   = array_chunk( $products, $record_limit );
$page_total         = count( $chucked_products );

require_once 'print-consignment-templates.php';
?>
<style>
    table tr.products-row td{
        padding:5px 4px !important;
    }
</style>
<?php $chunk_counter = 1; ?>
<?php foreach ($chucked_products as $products ): ?>
    <?php echo $chunk_counter > 1 ? '<div style="page-break-after:right;"></div>' : ''; ?>
    <table>
        <?php echo $tbl_spacer; ?>
        <?php include 'print-consignment-header.php' ?>
        <?php include 'print-consignment-details.php' ?>
        <tr><td colspan="7">&nbsp;</td></tr>
        <?php echo $tbl_product_header; ?>
        <?php foreach ($products as $product): ?>
            <tr class="products-row">
                <td class="bordered col-qty_delivered text-center"><<?php echo floatval( $product['qty_delivered'] ); ?></td>
                <td class="bordered col-unit text-center"><?php echo esc_html( $product['unit'] ); ?></td>
                <td colspan="2" class="bordered col-name"><?php echo cwms_trim_chars( $product['name'] ); ?></td>
                <td class="bordered col-retail_price text-right"><?php echo cwms1661_format_number( $product['retail_price'], 2, ',' ); ?></td>
                <td class="bordered col-discount text-center"><?php echo esc_html( $product['discount'] ); ?></td>
                <td class="bordered col-total text-right"><?php echo cwms1661_format_number( $product['total'], 2, ',' ); ?></td>
            </tr>
        <?php endforeach; ?>

        <?php $row_space =  $record_limit - count($products); ?>
        <?php for ($i=0; $i < $row_space; $i++): ?>
            <?php echo $tbl_product_spacer; ?>
        <?php endfor; ?>
        <?php if( $chunk_counter == $page_total ): ?>
            <?php include 'print-consignment-footer.php'; ?>
        <?php endif; ?>
        <?php if( $chunk_counter >= 1 && $page_total > 1 ): ?>
            <tr><td colspan="7" class=" text-center"><?php printf( esc_html('*** Page %d/%d ***','wpcodigo_wms'), $chunk_counter, $page_total ); ?></td></tr>
        <?php endif; ?>
    </table>
    <?php $chunk_counter++; ?>
<?php endforeach; ?>  