<tr>
    <td colspan="4">
        <?php if($general_settings['_company_logo']):  ?>
            <img src="<?php echo $general_settings['_company_logo']; ?>" alt="<?php echo $general_settings['_company_name']; ?>" width="180">
        <?php endif; ?>
        <h1 ><?php echo $general_settings['_company_name']; ?></h1>
        <span class="company-address"><?php echo $general_settings['_address']; ?></span><br/>
        <span class="company-tin"><?php esc_html_e('VAT TIN', 'wpcodigo_wms'); ?>: <?php echo $general_settings['_vat_tin']; ?></span><br/>
        <span><?php esc_html_e('Phone', 'wpcodigo_wms'); ?>: <?php echo $general_settings['_phone']; ?></span>
    </td>
    <td rowspan="2" colspan="3">
        <div style="border-bottom: 1px solid #000;">
            <h1><span style="border-bottom: 6px solid white;"><?php esc_html_e('NO. ', 'wpcodigo_wms'); ?>:</span> 
            <?php echo esc_html( $invoice['_dr_no'] ); ?></h1>
        </div>
    </td>
</tr>
<tr>
    <td colspan="4">
        <h1 style="width: fit-content; display: inline-block; font-size:18px"><?php esc_html_e('CONSIGNMENT RECEIPT', 'wpcodigo_wms'); ?></h1>
    </td>
</tr>