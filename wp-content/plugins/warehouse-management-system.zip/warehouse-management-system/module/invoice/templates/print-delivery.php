<?php
$invoice            = cwms1661_get_invoice_data( (int)$print_id );
$general_settings   = cwms1661_get_general_settings();
$invoice_number     = $invoice['title'];
// $current_date       = $invoice['_date_created'];
$current_date       = cwms1661_current_date();
$customer_details   = $invoice['_customer_details'];
$customer_address   = '';
if( !empty( $customer_details['_address_1'] ) || !empty( $customer_details['_address_2'] ) ){
    $customer_address .= $customer_details['_address_1'].' '.$customer_details['_address_2'].', ';
}
if( !empty( $customer_details['_city'] ) || !empty( $customer_details['_state'] ) ){
    $customer_address .= $customer_details['_city'].' '.$customer_details['_state'].', ';
}
if( !empty( $customer_details['_postcode'] ) || !empty( $customer_details['_country'] ) ){
    $customer_address .= $customer_details['_postcode'].', '.$customer_details['_country'];
}
$products           = cwms1661_remove_zero_product( $invoice['_products'] );
?>
<table>
    <tr class="no-border">
        <td style="width:12%"></td>
        <td style="width:10%"></td>
        <td style="width:22%"></td>
        <td style="width:22%"></td>
        <td style="width:12%"></td>
        <td style="width:10%"></td>
        <td style="width:12%"></td>
    </tr>
    <tr>
        <td rowspan="3" colspan="5">
            <?php if($general_settings['_company_logo']):  ?>
                <img src="<?php echo $general_settings['_company_logo']; ?>" alt="<?php echo $general_settings['_company_name']; ?>" width="180">
            <?php endif; ?>
            <h1 ><?php echo $general_settings['_company_name']; ?></h1>
            <span class="owner text-uppercase"><?php echo $general_settings['_owner']; ?> - PROP.</span></br>
            <span class="company-address"><?php echo $general_settings['_address']; ?></span><br/>
            <span class="company-address"><?php esc_html_e('VAT TIN', 'wpcodigo_wms'); ?>: <?php echo $general_settings['_vat_tin']; ?></span><br/>
            <?php esc_html_e('Phone', 'wpcodigo_wms'); ?>: <?php echo $general_settings['_phone']; ?><br/>
        </td>
        <td colspan="2">
            <div style="border-bottom: 1px solid #000;">
                <h1><span style="border-bottom: 6px solid white;"><?php esc_html_e('NO. ', 'wpcodigo_wms'); ?>:</span> 
                <?php echo esc_html( $invoice['_dr_no'] ); ?></h1>
            </div>
        </td>
    </tr>
    <tr>
        <td colspan="2">
            <div style="border-bottom: 1px solid #000;vertical-align:top;">
                <span style="border-bottom: 6px solid white;"><?php esc_html_e('Date', 'wpcodigo_wms'); ?>:</span> 
                <?php echo $current_date; ?>
            </div>
        </td>
    </tr>
    <tr>
        <td colspan="2">
            <div style="border-bottom: 1px solid #000;vertical-align:top;">
                <span style="border-bottom: 6px solid white;"><?php esc_html_e('TIN', 'wpcodigo_wms'); ?>:</span> 
                &nbsp;
            </div>
        </td>
    </tr>
    <tr>
        <td colspan="7" style="padding-left:0;padding-bottom:12px;">
            <h1 class="border-bottom" style="padding:6px; width: fit-content; display: inline-block;"><?php esc_html_e('DELIVERY RECEIPT', 'wpcodigo_wms'); ?></h1>
        </td>
    </tr>
    <tr>
        <td colspan="4" class="text-uppercase" style="padding:4px;">
            <div style="border-bottom: 1px solid #000; font-size:28px;">
                <span style="border-bottom: 6px solid white;"><?php esc_html_e('Deliver to', 'wpcodigo_wms'); ?>:</span> 
                <?php echo esc_html( $invoice['_customer_company'] ); ?>
            </div>
        </td>
        <td colspan="3" style="padding:4px;">
            <div style="border-bottom: 1px solid #000;">
                <span style="border-bottom: 6px solid white;"><?php esc_html_e('Terms', 'wpcodigo_wms'); ?>:</span> 
                <?php echo cwms1661_term_options()[$invoice['_terms']]; ?>
            </div>
        </td>
    </tr>
    <tr>
        <td colspan="4" class="text-uppercase" style="padding:4px;">
            <div style="border-bottom: 1px solid #000;">
                <span style="border-bottom: 6px solid white;"><?php esc_html_e('Bus. Name/Style', 'wpcodigo_wms'); ?>:</span> 
                &nbsp;
            </div>
        </td>
        <td colspan="3" style="padding:4px;">
            <div style="border-bottom: 1px solid #000;">
                <span style="border-bottom: 6px solid white;"><?php esc_html_e('Salesman', 'wpcodigo_wms'); ?>:</span> 
                <?php echo esc_html( $invoice['_assigned_agent_name'] ); ?>
            </div>
        </td>
    </tr>
    <tr>
        <td colspan="4" class="text-uppercase" style="vertical-align:top;padding:4px;">
            <div style="border-bottom: 1px solid #000;">
                <span style="border-bottom: 6px solid white;"><?php esc_html_e('Address', 'wpcodigo_wms'); ?>:</span> 
                <?php echo esc_html( $customer_address ); ?>
            </div>   
        </td>
        <td colspan="3" style="padding:4px;">
            <div style="border-bottom: 1px solid #000;">
                <span style="border-bottom: 6px solid white;"><?php esc_html_e('Checked by', 'wpcodigo_wms'); ?>: </span> 
                <?php echo esc_html( $invoice['_assigned_whseman_name'] ); ?>
            </div>    
        </td>
    </tr>
    <tr>
        <td colspan="2" class="text-uppercase" style="padding:4px;">
            <div >
                <span style="border-bottom: 6px solid white;"><?php esc_html_e('Delivery Instructions', 'wpcodigo_wms'); ?>: </span> 
            </div>  
        </td>
        <td colspan="2" class="text-uppercase" style="padding:4px; border-bottom:1px solid #000;">
            <div >
                <?php echo esc_html( $invoice['_remarks'] ); ?>
                <div style="padding:24px 0;width:100%;"></div>
            </div>  
        </td>
        <td colspan="3" style="padding:4px;">
         <div style="border-bottom: 1px solid #000;">
                <span style="border-bottom: 6px solid white;"><?php esc_html_e('P.O NO.', 'wpcodigo_wms'); ?>:</span> 
                &nbsp;
            </div>  
        </td>
    </tr>
    <tr><td colspan="7">&nbsp;</td></tr>
    <tr>
        <th class="text-center text-uppercase border-top bordered"><?php echo esc_html( 'Quantity', 'wpcodigo_wms'); ?></th>
        <th class="text-center text-uppercase border-top bordered"><?php echo esc_html( 'Unit', 'wpcodigo_wms'); ?></th>
        <th colspan="2" class="text-center text-uppercase border-top bordered"><?php echo esc_html( 'Articles', 'wpcodigo_wms'); ?></th>
        <th class="text-center text-uppercase border-top bordered"><?php echo esc_html( 'Unit Price', 'wpcodigo_wms'); ?></th>
        <th class="text-center text-uppercase border-top bordered"><?php echo esc_html( 'Disc.', 'wpcodigo_wms'); ?></th>
        <th class="text-center text-uppercase border-top bordered"><?php echo esc_html( 'Amount', 'wpcodigo_wms'); ?></th>
    </tr>
    <?php foreach ($products as $product): ?>
        <tr >
            <td class="bordered col-qty_delivered text-center"><<?php echo floatval( $product['qty_delivered'] ); ?></td>
            <td class="bordered col-unit text-center"><?php echo esc_html( $product['unit'] ); ?></td>
            <td colspan="2" class="bordered col-name"><?php echo cwms_trim_chars( $product['name'] ); ?></td>
            <td class="bordered col-retail_price text-right"><?php echo cwms1661_format_number( $product['retail_price'], 2, ',' ); ?></td>
            <td class="bordered col-discount text-center"><?php echo $product['discount']; ?></td>
            <td class="bordered col-total text-right"><?php echo cwms1661_format_number( $product['total'], 2, ',' ); ?></td>
        </tr>
    <?php endforeach; ?>
    <!-- Spacer -->
    <?php $row_space =  cwms1661_product_limit() - count($products); ?>
    <?php for ($i=0; $i < $row_space; $i++): ?>
        <tr>
            <th class="bordered" style="padding:4px;">&nbsp;</th>
            <th class="bordered">&nbsp;</th>
            <th colspan="2" class="bordered">&nbsp;</th>
            <th class="bordered">&nbsp;</th>
            <th class="bordered">&nbsp;</th>
            <th class="bordered">&nbsp;</th>
        </tr>
    <?php endfor; ?>
    <tr>
        <td class="bordered">&nbsp;</td>
        <td class="bordered">&nbsp;</td>
        <td colspan="2" class="bordered">&nbsp;</td>
        <td colspan="2" class="bordered text-uppercase text-right"><?php esc_html_e('Total', 'wpcodigo_wms'); ?>:</td>
        <td class="bordered text-right"><?php echo cwms1661_format_number( $invoice['_sub_total'], 2, ',' ); ?></td>
    </tr>
    <tr>
        <td colspan="4" style="text-align: justify;padding-right:120px; padding-left:0;">
            All accounts overdue will be charge 12% interest per annum plus 25% on said amount for attorney’s fees and cost of collection. The parties expressly submit themselves to the jurisdiction of the court of Iloilo City in any legal actions arising out of this transaction without in any way attempting to divert in an other court of courts. A charge of 10% will be made on all returned goods at customer’s request to cover handling expenses. 
        </td>
        <td colspan="3" style="vertical-align: bottom;text-align: justify;">
            Received form NEXUS TRADING the above describe articles in good order and condition.
        </td>
    </tr>
    <tr>
        <td colspan="4">&nbsp;</td>
        <td colspan="3" style="vertical-align:bottom;padding-bottom:2px;">
            <div style="border-bottom: 1px solid #000;margin-top:90px;">
                <span style="border-bottom: 6px solid white;"><?php esc_html_e('BY', 'wpcodigo_wms'); ?>: </span> 
               &nbsp;
            </div>  
        </td>
    </tr>
    <tr>
        <td colspan="4">&nbsp;</td>
        <td colspan="3" class="text-center" style="padding-top:2px;">
            <p style="font-size:1.2em;"><?php esc_html_e("INVOICE TO FOLLOW", 'wpcodigo_wms'); ?> (NT)</p>
        </td>
    </tr>
</table>