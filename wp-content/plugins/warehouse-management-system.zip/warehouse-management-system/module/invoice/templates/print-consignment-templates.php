<?php
ob_start();
?>
    <tr class="no-border">
        <td style="width:12%"></td>
        <td style="width:10%"></td>
        <td style="width:22%"></td>
        <td style="width:22%"></td>
        <td style="width:12%"></td>
        <td style="width:10%"></td>
        <td style="width:12%"></td>
    </tr>
<?php
$tbl_spacer = ob_get_clean();

ob_start();
?>
    <tr>
        <th class="text-center text-uppercase border-top bordered"><?php echo esc_html( 'Quantity', 'wpcodigo_wms'); ?></th>
        <th class="text-center text-uppercase border-top bordered"><?php echo esc_html( 'Unit', 'wpcodigo_wms'); ?></th>
        <th colspan="2" class="text-center text-uppercase border-top bordered"><?php echo esc_html( 'Articles', 'wpcodigo_wms'); ?></th>
        <th class="text-center text-uppercase border-top bordered"><?php echo esc_html( 'Unit Price', 'wpcodigo_wms'); ?></th>
        <th class="text-center text-uppercase border-top bordered"><?php echo esc_html( 'Disc.', 'wpcodigo_wms'); ?></th>
        <th class="text-center text-uppercase border-top bordered"><?php echo esc_html( 'Amount', 'wpcodigo_wms'); ?></th>
    </tr>
<?php
$tbl_product_header = ob_get_clean();

ob_start();
?>
    <tr>
        <th class="bordered" style="padding:4px;">&nbsp;</th>
        <th class="bordered">&nbsp;</th>
        <th colspan="2" class="bordered">&nbsp;</th>
        <th class="bordered">&nbsp;</th>
        <th class="bordered">&nbsp;</th>
        <th class="bordered">&nbsp;</th>
    </tr>
<?php
$tbl_product_spacer = ob_get_clean();

ob_start();
?>
    <tr>
        <td class="bordered">&nbsp;</td>
        <td class="bordered">&nbsp;</td>
        <td colspan="2" class="bordered">&nbsp;</td>
        <td colspan="2" class="bordered text-uppercase text-right"><?php esc_html_e('Total', 'wpcodigo_wms'); ?>:</td>
        <td class="bordered text-right"><?php echo cwms1661_format_number( $invoice['_sub_total'], 2, ',' ); ?></td>
    </tr>
<?php
$product_total = ob_get_clean();