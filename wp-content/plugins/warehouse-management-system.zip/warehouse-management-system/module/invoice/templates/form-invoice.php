<div id="cwms-so_invoicing_form_wrapper" class="col-md-offset-1 col-md-10 col-sm-12">
    <?php do_action('cwms1661_before_invoice_form', $invoice ); ?>
    <form id="cwms-invoice_form" class="form-horizontal form-label-left input_mask" action="" method="POST">
        <?php wp_nonce_field( 'cwms-update_invoice_form_action', 'cwms-update_invoice_form_nonce' ); ?>
        <input type="hidden" name="cwms_invoice_id" value="<?php echo (int)$invoice['ID']; ?>">
        <input type="submit" style="display:none !important;" value="<?php esc_html_e('Update Invoice Order', 'wpcodigo_wms'); ?>">
        <!-- Header -->
        <section id="po-header-section" class="row" style="margin-bottom:18px;">
            <div class="col-md-6 col-sm-12">
                <?php if($general_settings['_company_logo']):  ?>
                    <img src="<?php echo $general_settings['_company_logo']; ?>" alt="<?php echo $general_settings['_company_name']; ?>" width="210">
                <?php endif; ?>
            </div>
            <div class="col-md-6 col-sm-12 text-right">
                <h1><?php esc_html_e('INVOICE ORDER', 'wpcodigo_wms'); ?></h1>                
                <span class="cwms-invoice_date"><?php esc_html_e('DATE', 'wpcodigo_wms'); ?>: <input type="text" name="_invoice_date"  class="cwms-datetime-12hrs" value="<?php echo $invoice['_date_created']; ?>" style="border: 1px solid #dcdcdc;padding-right: 6px;text-align: right;margin-bottom: 4px;" required /></span><br/>
                <span class="cwms-invoice_dr_no"><?php esc_html_e('DR #', 'wpcodigo_wms'); ?>: <input type="text" name="_invoice_dr_no"  value="<?php echo $invoice['_dr_no']; ?>" style="border: 1px solid #dcdcdc;padding-right: 6px;text-align: right; margin-bottom: 4px;" <?php echo cwms1661_dr_senquence_enable() ? 'disabled' : '' ; ?> required /></span></br>
                <span class="cwms-invoice_number"><?php esc_html_e('Invoice', 'wpcodigo_wms'); ?>#: <?php echo $invoice_number; ?></span>
            </div>
        </section>
        <!-- Vendors Information -->
        <section id="customer-info-section" class="row" style="margin-bottom:18px;">
            <div class="col-md-6 col-sm-12">
                <h3 class="info-header bg-header"><?php esc_html_e('From', ''); ?></h3>
                <span class="contact-name"><?php echo $general_settings['_company_name']; ?></span></br>
                <span class="company-address"><?php echo nl2br( $general_settings['_address'] ); ?></span><br/>
                <?php echo $general_settings['_phone']; ?>
            </div>
            <div class="col-md-6 col-sm-12">
                <h3 class="info-header bg-header"><?php esc_html_e('Customer', 'wpcodigo_wms'); ?></h3>
                <div id="cwms-customer-details">
                    <?php if( (int)$invoice['_customer_id'] ): ?>
                        <strong><?php echo $invoice['_customer_company']; ?></strong><br/>
                        <span class="contact-name"><?php echo $invoice['_customer']; ?></span><br/>
                        <?php echo cwms1661_display_address_html( $invoice['_customer_details'] ); ?><br/>
                        <?php echo $invoice['_customer_details']['_phone']; ?><br/>
                        <?php echo $invoice['_customer_details']['_email']; ?>
                    <?php endif; ?>
                </div>
            </div>
        </section>
        <section id="product-info" class="table-responsive cwms_invoice_items">
            <div id="table-select-action">
                <select id="cwms-search_product" class="cwms-select2-search form-control form-control-sm" data-action="cwms_product_options" style="width: 280px;float:right;" aria-placeholder="<?php esc_html_e('Search Product', 'wpcodigo_wms'); ?>">
                    <option value=""><?php esc_html_e('Search Product', 'wpcodigo_wms'); ?></option>
                </select>
                <button data-repeater-create type="button" class="btn btn-sm btn-primary" style="height: 34px;" disabled><?php esc_html_e('Add Item', 'wpcodigo_wms'); ?></button>
            </div>
            <p class="text-danger" style="margin: 12px 0; font-style: italic; font-size: 1.2em;"><?php esc_html_e('Note: In adding multiple discount please add comma (,) to separate each discount.', 'wpcodigo_wms'); ?></p>
            <table id="cwms-poitems-table" class="table table-sm table-hover">
                <thead>
                    <tr>
                        <th colspan="2"><?php esc_html_e('SKU', 'wpcodigo_wms'); ?></th>
                        <th><?php esc_html_e('Name', 'wpcodigo_wms'); ?></th>
                        <th class="cwms-input-header"><?php esc_html_e('Order Qty', 'wpcodigo_wms'); ?></th>
                        <th class="cwms-input-header"><?php esc_html_e('Delivered Qty', 'wpcodigo_wms'); ?></th>
                        <th class="cwms-input-header"><?php esc_html_e('Unit', 'wpcodigo_wms'); ?></th>
                        <th class="cwms-input-header"><?php esc_html_e('Retail Price', 'wpcodigo_wms'); ?></th>
                        <th class="cwms-input-header"><?php esc_html_e('Discount(s)', 'wpcodigo_wms'); ?></th>
                        <th class="cwms-input-header"><?php esc_html_e('Total', 'wpcodigo_wms'); ?></th>
                    </tr>
                </thead>
                <tbody data-repeater-list="cwms_invoice_products">
                    <?php foreach ($invoice['_products'] as $product): ?>
                        <tr data-repeater-item>
                            <td class="col-delete" style="width:24px;">
                                <i data-repeater-delete class="fa fa-trash text-danger"></i>
                                <input type="hidden" data-name="id" name="id" value="<?php echo (int)$product['ID']; ?>">
                                <input type="hidden" data-name="product_id" name="product_id" value="<?php echo (int)$product['product_id']; ?>">
                                <input type="hidden" data-name="upc" name="upc" value="<?php echo esc_html( $product['upc'] ); ?>">
                                <input type="hidden" data-name="unit" name="unit" value="<?php echo esc_html( $product['unit'] ); ?>">
                                <input type="hidden" data-name="name" name="name" value="<?php echo esc_html( $product['name'] ); ?>">
                                <input type="hidden" data-name="cost_price" name="cost_price" value="<?php echo floatval( $product['cost_price'] ); ?>">
                                <input type="hidden" data-name="qty" name="qty_ordered" value="<?php echo floatval( $product['qty_ordered'] ); ?>" />
                            </td>
                            <td class="col-upc">
                                <?php echo $product['upc']; ?>
                            </td>
                            <td class="col-name"><?php echo esc_html( $product['name'] ); ?></td>
                            <td class="col-qty"><?php echo floatval( $product['qty_ordered'] ); ?></td>
                            <td class="col-qty_delivered"><input type="text" class="cmws-number cwms-calculate" data-name="qty_delivered" name="qty_delivered" value="<?php echo floatval( $product['qty_delivered'] ); ?>" /> </td>
                            <td class="col-unit"><?php echo esc_html( $product['unit'] ); ?></td>
                            <td class="col-unit_price"><input type="text" class="cmws-number cwms-calculate" data-name="retail_price" name="retail_price" value="<?php echo floatval( $product['retail_price']); ?>" /></td>
                            <td class="col-discount"><input type="text" class="cmws-discount cwms-calculate" data-name="discount" name="discount" value="<?php echo $product['discount']; ?>" /></td>
                            <td class="col-total"><?php echo cwms1661_format_number( $product['total'] ); ?></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </section>
        <div class="row" id="amount-breakdown">
            <!-- Remarks column -->
            <div class="col-xs-6">
                <p class="lead"><?php esc_html_e('Remarks', 'wpcodigo_wms'); ?>:</p>
                <textarea name="remarks" rows="6" style="width:100%;" placeholder="<?php esc_html_e('Add remarks here.', 'wpcodigo_wms'); ?>"><?php echo $invoice['_remarks'] ; ?></textarea>
                <p class="lead" style="margin-top:28px"><?php esc_html_e('Terms', 'wpcodigo_wms'); ?>:</p>
                <select id="cwms-search_terms" class="form-control form-control-sm" style="width: 280px; display: inline-block;" name="terms" required >
                    <option value=""><?php esc_html_e('Select Term', 'wpcodigo_wms'); ?></option>
                    <?php foreach( cwms1661_term_options() as $term_key => $term_value ): ?>
                        <option value="<?php echo (int)$term_key; ?>" <?php selected( $invoice['_terms'], (int)$term_key ); ?>><?php echo esc_html( $term_value ); ?></option>
                    <?php endforeach; ?>
                </select>
                <p class="lead" style="margin-top:28px"><?php esc_html_e('Invoice Status', 'wpcodigo_wms'); ?>:</p>
                <select id="cwms-search_terms" class="form-control form-control-sm" style="width: 280px; display: inline-block;" name="_invoice_status" required >
                    <option value=""><?php esc_html_e('Select Status', 'wpcodigo_wms'); ?></option>
                    <?php foreach( cwms1661_invoice_bulk_actions() as $status_key => $status_value ): ?>
                        <option value="<?php echo $status_key; ?>" <?php selected( $invoice['_status_key'], $status_key ); ?>><?php echo esc_html( $status_value ); ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <!-- /.col -->
            <div class="col-xs-6">
                <p class="lead"><?php esc_html_e('Amount Due', 'wpcodigo_wms'); ?></p>
                <div class="table-responsive">
                    <table id="cwms-amountdue-table" class="table">
                        <tbody>
                        <tr>
                            <th style="width:50%"><?php esc_html_e('SubTotal', 'wpcodigo_wms'); ?>:</th>
                            <td class="amount_due_subtotal"><?php echo cwms1661_format_number($invoice['_sub_total']) ; ?></td>
                        </tr>
                        <tr>
                            <th><?php esc_html_e('COD Discount', 'wpcodigo_wms'); ?>:</th>
                            <td class="amount_cod_discount">
                                <input type="text" class="cmws-currency cwms-calculate" name="cod_discount" value="<?php echo cwms1661_format_number( $invoice['_cod_discount'] ) ; ?>" />
                            </td>
                        </tr>
                        <tr>
                            <th><?php esc_html_e('Tax', 'wpcodigo_wms'); ?>:</th>
                            <td class="amount_due_tax">
                                <input type="text" class="cmws-currency cwms-calculate" name="tax" value="<?php echo cwms1661_format_number( $invoice['_tax'] ) ; ?>" />
                            </td>
                        </tr>
                        <tr>
                            <th><?php esc_html_e('Others', 'wpcodigo_wms'); ?>:</th>
                            <td class="amount_due_others">
                                <input type="text" class="cmws-currency cwms-calculate" name="others" value="<?php echo cwms1661_format_number( $invoice['_others'] ) ; ?>" />
                            </td>
                        </tr>
                        <tr>
                            <th><?php esc_html_e('Total', 'wpcodigo_wms'); ?>:</th>
                            <td class="amount_due_total"><?php echo cwms1661_format_number( $invoice['_total_amount'] ) ; ?></td>
                        </tr>
                        </tbody>
                    </table>
                </div>
            </div>
            <!-- /.col -->
            </div>
        <div class="ln_solid"></div>
        <section id="action-section">
            <div class="col-md-6 form-group">
                <?php esc_html_e('Salesman', 'wpcodigo_wms'); ?> : <strong><span class="_assigned_agent_name"><?php echo esc_html( $invoice['_assigned_agent_name'] ); ?></span></strong><br/>
                <?php esc_html_e('Checked By', 'wpcodigo_wms'); ?> : <strong><span class="_assigned_whseman_name"><?php echo esc_html( $invoice['_assigned_whseman_name'] ); ?></span></strong>
            </div>
            <div class="col-md-6 text-right">
                <input id="cmws-submit-form_invoice" type="button" class="btn btn-md btn-success" value="<?php echo __('Update Invoice Order', 'wpcodigo_wms') ; ?>">
            </div>
        </section>
    </form>
    <?php do_action('cwms1661_after_invoice_form', $invoice ); ?>
</div>