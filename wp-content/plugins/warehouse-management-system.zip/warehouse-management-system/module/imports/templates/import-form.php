<div class="row" style="min-height: 50vh;">
    <section id="cwms-import-form_wrapper" class="col-md-4 col-sm-4 col-xs-12">
        <form method="post" enctype="multipart/form-data" id="cwms-import-form" class="form-horizontal">
          <input type="hidden" name="action" value="cwms-<?php echo esc_attr( sanitize_title( $_GET['cwmspage'] ) ); ?>">
          <input type="hidden" name="security" value="<?php echo wp_create_nonce( "cwms-import-nonce" ); ?>">
            <div class="col-md-6 col-sm-6 col-xs-12 form-group">
                <label id="cwms-file_upload_label" for="cwms-file_upload"><b><?php echo esc_html('CSV File upload', ''); ?></b></label>
                <input type="file" class="form-control-file" name="cwms-import_file" id="cwms-file_upload" accept=".csv" required >
            </div>  
            <div class="col-md-6 col-sm-6 col-xs-12 form-group">
                <input type="submit" class="btn btn-primary" value="Submit">
            </div>
        </form>
        <div class="ln_solid"></div>
        <div class="col-xs-12">
            <p><?php echo esc_html('Notes','wpcodigo_wms'); ?>:</p>
            <ol>
                <li><?php echo esc_html('First row of imported csv is ignored as it is assumed that it will be a header row.', 'wpcodigo_wms'); ?></li>
                <li><?php echo esc_html('Download template for correct file data arrangement.', 'wpcodigo_wms'); ?> <a href="#" id="cwms-download_csv_template" class="btn btn-success btn-xs" data-type="cwms-<?php echo esc_attr( sanitize_title( $_GET['cwmspage'] ) ); ?>"><?php echo esc_html('Download CSV template','') ?></a></li>
                <li class="text-danger"><?php echo esc_html('Make sure that you upload the correct CSV file.', 'wpcodigo_wms'); ?></li>
            </ol>
        </div>
    </section>
    <section id="cwms-import-result_wrapper" class="col-md-8 col-sm-8 col-xs-12" style="display:none;">
        <div id="cwms-progress-report">
            <h4><?php echo esc_html('Please do not refresh the page while import is in progress', 'wpcodigo_wms' ); ?></h4>
            <div id="cwms-progress_bar"><div class="progress-indicator"></div></div>
            <div class="info"></div>
        </div>
    </section>
</div>