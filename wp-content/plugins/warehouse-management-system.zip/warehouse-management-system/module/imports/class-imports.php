<?php
defined( 'ABSPATH' ) || exit;
/**
 * Product
 */
class CWMS1661_Import {

    public static function init(){
        // Scripts 
        add_action( 'wp_enqueue_scripts', array( __CLASS__, 'scripts' ) );
        add_filter( 'cwms1661_registered_scripts', array( __CLASS__, 'registered_scripts' ) );
        // Menu hooks
        add_filter( 'cwms1661_dashboard_menus', array(__CLASS__, 'menu' ) );
        
        // Template
        add_filter( 'cwms1661_content_template_import-products', array(__CLASS__, 'product_template' ) );
        add_filter( 'cwms1661_content_template_import-suppliers', array(__CLASS__, 'supplier_template' ) );
        add_filter( 'cwms1661_content_template_import-users', array(__CLASS__, 'user_template' ) );

        // AJAX
        add_action( 'wp_ajax_cwms-import-products', array(__CLASS__, 'import_products') );
        add_action( 'wp_ajax_cwms-import-suppliers', array(__CLASS__, 'import_suppliers') );
        add_action( 'wp_ajax_cwms-import-users', array(__CLASS__, 'import_users') );
    }

    public static function scripts(){
        $import_pages = array_keys( cwms1661_import_submenus() );
        if( !isset($_GET['cwmspage']) || !in_array( $_GET['cwmspage'] , $import_pages ) ){
            return false;
        }
        // wp_enqueue_script( 'cwms1661-papaparse-script', CWMS1661_PLUGIN_URL.'assets/js/papaparse.min.js' , array(), CWMS1661_VERSION, true );
        wp_enqueue_script( 'cwms1661-import-script', CWMS1661_PLUGIN_URL.'assets/js/import.js' , array('cwms1661-papaparse-script'), CWMS1661_VERSION, true );
        $product_fields     = cwms1661_product_fields( true );
        $supplier_fields    = cwms1661_supplier_fields();
        $user_fields        = cwms1661_user_fields();

        wp_localize_script( 'cwms1661-import-script', 'cwmsImportAjaxHandler', array(
            'ajaxurl'           => admin_url( 'admin-ajax.php' ),
            'processedLabel'    => __('Processed', 'wpcodigo_wms'),
            'processComplete'   => __('All records have been processed', 'wpcodigo_wms'),
            'uploadLabel'       => __('CSV File upload', 'wpcodigo_wms' ),
            'productHeaders'    => cwms1661_get_csv_headers( $product_fields ),
            'supplierHeaders'   => cwms1661_get_csv_headers( $supplier_fields ),
            'userHeaders'       => cwms1661_get_csv_headers( $user_fields )
        ) );
    }
    public static function registered_scripts( $scripts ){
        $import_pages = array_keys( cwms1661_import_submenus() );
        if( !isset($_GET['cwmspage']) || !in_array( $_GET['cwmspage'] , $import_pages ) ){
            return $scripts;
        }
        // $scripts[] = 'cwms1661-papaparse-script';
        $scripts[] = 'cwms1661-import-script';
        return $scripts;
    }

    public static function menu( $menus ){
        if( !cwms1661_can_access_po() ){
            return $menus;
        }
        $menus[100] = array(
            'id'        => 'imports',
            'label'     => esc_html__('Imports', 'wpcodigo_wms'),
            'classes'   => 'fa fa-cloud-upload',
            'subs'      => cwms1661_import_submenus()
        );
        return $menus;
    }
    // Page template
    public static function product_template(){
        if( ! cwms1661_can_import_products() ){
            return cwms1661_get_template_path('403', 'dashboard');
        }
        return apply_filters( "cwms1661_get_template_import-products", CWMS1661_ABSPATH.'module/imports/templates/import-form.php' );
    }
    public static function supplier_template(){
        if( ! cwms1661_can_import_suppliers() ){
            return cwms1661_get_template_path('403', 'dashboard');
        }
        return apply_filters( "cwms1661_get_template_import-suppliers", CWMS1661_ABSPATH.'module/imports/templates/import-form.php' );
    }
    public static function user_template(){
        if( ! cwms1661_can_import_users() ){
            return cwms1661_get_template_path('403', 'dashboard');
        }
        return apply_filters( "cwms1661_get_template_import-users", CWMS1661_ABSPATH.'module/imports/templates/import-form.php' );
    }

    // Process Import
    function import_products(){
        if ( ! check_ajax_referer( 'cwms-import-nonce', 'security' ) ) {
          wp_send_json( array(
            'status' => 'error',    
            'message' => __('Error nonce, please reload the page ang try again.', 'wpcodigo_wms')
          ) );
        }   

        $taxonomies      = cwms1661_product_all_categories();
        $product_fields  = cwms1661_product_fields( true );
        $opt_category    = $taxonomies;
        $opt_subcategory = $taxonomies;
        $metakeys        = array_keys( $product_fields );

        $records            = $_POST["records"];
        $parent_term_ids    = [];
        $processed_data     = [];
  
        if( count($records) > 0 ){
            foreach( $records as $record ){
                $record = array_values( $record );
                // Process records
                $product_name = sanitize_text_field( $record[0] );
                $product_desc = sanitize_text_field( $record[2] );
                unset( $record[0] );
                unset( $record[2] );
                
                // Check if product exists 
                $product_id         = is_cwms1661_post_exist( $product_name, CWMS1661_PRODUCT_POST_TYPE );
                $upc_key            = cwms1661_get_array_pocket('_upc', $metakeys );
                $has_duplicate_sku  = cwms1661_has_duplicate_sku( $product_name, $record[$upc_key] );

                if( $has_duplicate_sku ){
                    $processed_data[] = array(
                        'status' => 'error',
                        'name' => $product_name,
                        'message' => sprintf( __( 'Product "%s" has the same SKU with %s. Import Failed.', 'wpcodigo_wms' ), $product_name, '"'.implode('", "', $has_duplicate_sku).'"' )
                    );
                    continue;
                }

                $product_args   = array(
                    'post_title'    => $product_name,
                    'post_content'  => $product_desc,
                    'post_status'   => 'publish',
                    'post_type'     => CWMS1661_PRODUCT_POST_TYPE
                );

                if( ! $product_id  ){
                    $product_id = wp_insert_post( $product_args );
                }else{
                    $product_args['ID'] = $product_id;
                    $product_id = wp_update_post( $product_args );
                }

                if ( is_wp_error( $product_id ) ) {
                    $processed_data[] = array(
                        'status'    => 'error',
                        'name'      => $product_name,
                        'message'   => $product_name . " Import Failed. " . $product_id->get_error_message()
                    );
                    continue;
                }

                // compile processed data
                $processed_data[] = array(
                    'status'    => 'success',
                    'name'      => $product_name
                );

                // Save post meta
                $parent_catID   = false;
                $term_ids       = array();
                foreach ( $record as $key => $meta_value ){

                    if( !array_key_exists( $key, $metakeys)){
                        continue;
                    }

                    $meta_value = sanitize_text_field($meta_value);
                    
                    // Check if it is Qty field and update the existing product QTY
                    if( $metakeys[$key] == "_qty" ){
                        $meta_value = floatval( $meta_value );
                        cwms1661_update_product_qty( $product_id, $meta_value, 'cwms-import', '000000', __('Added from import', 'wpcodigo_wms') );
                        continue;
                    }

                    // Update Category
                    if( $metakeys[$key] == "_category" && !empty($meta_value) ){     
                        // Check if category already in the system
                        // If not create new category else save the category
                        $cat_id = false;
                        if( in_array( $meta_value, $opt_category ) ){
                            $cat_id         = array_search ( $meta_value, $opt_category );
                            $term_ids[]     = $cat_id;
                            $parent_catID   = $cat_id;
                        }else{
                            // Create new term and set product term
                            $_cat_id = wp_insert_term( $meta_value, CWMS1661_PRODUCT_TAXONOMY );
                            if( !is_wp_error( $_cat_id ) ){
                                // Add new term to options
                                $cat_id = $_cat_id['term_id'];
                                $opt_category[$cat_id]  = $meta_value; 
                                $term_ids[]    = $cat_id;
                                $parent_catID  = $cat_id;
                            }
                        }
                        update_post_meta( $product_id, '_category', $cat_id );
                        continue;
                    }

                    // Update subcategory
                    if( $metakeys[$key] == "_sub_category" && !empty($meta_value) ){
                        // Check if category already in the system
                        // If not create new category else save the category
                        $subcat_id = false;
                        if( in_array( $meta_value, $opt_subcategory ) ){
                            $subcat_id      = array_search ( $meta_value, $opt_subcategory );       
                            $term_ids[]     = $subcat_id;            
                        }else{
                            // Create new term and set product term
                            $_subcat_id = wp_insert_term( $meta_value, CWMS1661_PRODUCT_TAXONOMY, array( 'parent' => $parent_catID ) );
                            if( !is_wp_error( $_subcat_id ) ){
                                // Add  new term to options
                                $subcat_id = $_subcat_id['term_id'];
                                $opt_subcategory[$subcat_id] = $meta_value;  
                                $term_ids[]     = $subcat_id;                
                            }
                        }
                        update_post_meta( $product_id, '_sub_category', $subcat_id );
                        continue;
                    }
                    
                    update_post_meta( $product_id, $metakeys[$key], $meta_value );
                }
                $parent_term_ids[] = $term_ids;
                // Set up product category
                wp_set_post_terms( $product_id, $term_ids, CWMS1661_PRODUCT_TAXONOMY );
            }
        }
  
        wp_send_json( $processed_data );

    }
    function import_suppliers(){
        if (  !check_ajax_referer( 'cwms-import-nonce', 'security' ) ) {
          wp_send_json( array(
            'status' => 'error',
            'message' => __('Permission denied nonce failed error.', 'wpcodigo_wms')
          ) );
        }   

        $metakeys       = array_keys( cwms1661_supplier_fields() );
        $records        = $_POST["records"];

        if( count($records) > 0 ){
  
          foreach( $records as $record ){
            $record = array_values( $record );
            // Process records
            $supplier_name = sanitize_text_field( $record[0] );
            unset( $record[0] );
            
            // Check if supplier exists 
            $supplier_id     = is_cwms1661_post_exist( $supplier_name, CWMS1661_SUPPLIER_POST_TYPE );
            $supplier_args   = array(
                'post_title'    => $supplier_name,
                'post_status'   => 'publish',
                'post_type'     => CWMS1661_SUPPLIER_POST_TYPE
            );

            if( ! $supplier_id  ){
                $supplier_id = wp_insert_post( $supplier_args );
            }else{
                $supplier_args['ID'] = $supplier_id;
                $supplier_id = wp_update_post( $supplier_args );
            }

            if ( is_wp_error( $supplier_id ) ) {
                continue;
            }

            // Save post meta
            foreach ( $record as $key => $meta_value ){
                update_post_meta( $supplier_id, $metakeys[$key], sanitize_text_field( $meta_value ) );
            }

          }

        }
  
        wp_send_json( $records );

    }
    function import_users(){
        if (  !check_ajax_referer( 'cwms-import-nonce', 'security' ) ) {
          wp_send_json( array(
            'status' => 'error',
            'message' => __('Permission denied nonce failed error.', 'wpcodigo_wms')
          ) );
        }   
        
        $metakeys   = array_keys( cwms1661_user_fields() );
        $records    = $_POST["records"];  
  
        if(count($records) > 0){
  
          foreach( $records as $record ){
            $record = array_values( $record );

            // Process records
            $password   = wp_generate_password( 12, false );
            $first_name = sanitize_text_field( $record[0] );
            $last_name  = sanitize_text_field( $record[1] );
            $email      = sanitize_text_field( $record[4] );
            $display_name = $first_name.' '.$last_name;

            // Make sure that email is valid
            if ( ! filter_var($email, FILTER_VALIDATE_EMAIL) ) {
                $email  = sanitize_title( $display_name ).'@no-email.com';
            }

            $role       = 'cwms_customer';
            unset( $record[0] );
            unset( $record[1] );
            unset( $record[4] );

            $userdata       = array(
                'user_login'    => $email,
                'user_email'    => $email,
                'first_name'    => $first_name,
                'last_name'     => $last_name,
                'role'          => $role,
                'user_pass'     => $password,
                'display_name'  => $display_name
            );

            $user_id = email_exists( $email );
            // Check if the submission either add or update
            if( $user_id ){
                $userdata['ID'] =  $user_id;
                unset( $userdata['user_login'] );
                unset( $userdata['user_email'] );
                $user_id        = wp_update_user( $userdata );
            }else{
                $user_id        = wp_insert_user( $userdata );
            }

            if ( is_wp_error( $user_id ) ) {
                continue;
            }

            foreach ( $record as $key => $meta_value ){
                update_user_meta( $user_id, $metakeys[$key], sanitize_text_field( $meta_value ) );
            }

          }

        }
  
        wp_send_json( $records );

    }
}