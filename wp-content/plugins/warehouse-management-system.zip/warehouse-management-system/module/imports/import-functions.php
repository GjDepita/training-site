<?php 
defined( 'ABSPATH' ) || exit;

function cwms1661_import_submenus(){
    $submenus = array(
        'import-products'   => esc_html__('Products', 'wpcodigo_wms'),
        'import-suppliers'  => esc_html__('Suppliers', 'wpcodigo_wms'),
        'import-users'      => esc_html__('Users', 'wpcodigo_wms'),
    );
    return apply_filters( 'cwms1661_import_submenus', $submenus );
}

function cwms1661_get_csv_headers( $fields ){
    $headers = array_map( function( $value ){
        return $value['label'];
    }, $fields );
    $headers = array_values( $headers );
    $header_data = [];
    foreach( $headers as $header ){
        $header_data[ $header ] = '';
    }
    return $header_data;
}

// Permission
function cwms1661_can_import_products_roles(){
    $assinged_roles     = get_option( 'cwms1661_can_import_products_roles', null );
    if( $assinged_roles === null ){
        $assinged_roles = array( 'cwms_manager' );
    }
    $assinged_roles[]   = 'administrator';
    return $assinged_roles;
}
function cwms1661_can_import_products(){
    if( !is_user_logged_in() ){
        return false;
    }
    $allowed_roles = apply_filters('cwms1661_can_import_products_roles', cwms1661_can_import_products_roles() );
    return array_intersect( $allowed_roles,  cwms1661_current_user_roles() ) ? true : false ;
}
function cwms1661_can_import_suppliers_roles(){
    $assinged_roles     = get_option( 'cwms1661_can_import_suppliers_roles', null );
    if( $assinged_roles === null ){
        $assinged_roles = array( 'cwms_manager' );
    }
    $assinged_roles[]   = 'administrator';
    return $assinged_roles;
}
function cwms1661_can_import_suppliers(){
    if( !is_user_logged_in() ){
        return false;
    }
    $allowed_roles = apply_filters('cwms1661_can_import_suppliers_roles', cwms1661_can_import_suppliers_roles() );
    return array_intersect( $allowed_roles,  cwms1661_current_user_roles() ) ? true : false ;
}
function cwms1661_can_import_users_roles(){
    $assinged_roles     = get_option( 'cwms1661_can_import_users_roles', null );
    if( $assinged_roles === null ){
        $assinged_roles = array( 'cwms_manager' );
    }
    $assinged_roles[]   = 'administrator';
    return $assinged_roles;
}
function cwms1661_can_import_users(){
    if( !is_user_logged_in() ){
        return false;
    }
    $allowed_roles = apply_filters('cwms1661_can_import_users_roles', cwms1661_can_import_users_roles() );
    return array_intersect( $allowed_roles,  cwms1661_current_user_roles() ) ? true : false ;
}