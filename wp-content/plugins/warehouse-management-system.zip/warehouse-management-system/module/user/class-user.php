<?php
defined( 'ABSPATH' ) || exit;
/**
 * Product
 */
class CWMS1661_User {

    public static function init(){
        // Saving Product data
        add_action('wp', array( __CLASS__, 'save') );
        add_action('wp', array( __CLASS__, 'save_profile') );
        add_action('template_redirect', array( __CLASS__, 'save_redirection') );
        // Ajax handlers
        add_action( 'wp_ajax_cwms_get_users', array(__CLASS__, 'get_users' ) );
        add_action( 'wp_ajax_cwms_delete_user', array(__CLASS__, 'delete_user' ) );
        add_action( 'wp_ajax_cwms_bulkdelete_users', array(__CLASS__, 'bulk_delete_users' ) );
        add_action( 'wp_ajax_cwms_search_customer', array(__CLASS__, 'search_customer' ) );
        add_action( 'wp_ajax_cwms_search_active_customer', array(__CLASS__, 'search_active_customer' ) );
        add_action( 'wp_ajax_cwms_search_salesman', array(__CLASS__, 'search_salesman' ) );
        // Localize Script translations
        add_filter( 'cwms1661_ajax_localize_script_translations', array(__CLASS__,  'script_translations' ) );
        // Product page script - add/remove URL message parameters
        add_action( 'cwms1661_before_user_form', array(__CLASS__, 'notification_message'));
        add_action( 'cwms1661_before_update_profile_form', array(__CLASS__, 'notification_message'));
        // After page title hook
        add_action('cwms1661_after_page_title_update-user', array(__CLASS__, 'add_new_link'));
        add_action('cwms1661_after_page_title_all-users', array(__CLASS__, 'add_new_link'));
        add_action('cwms1661_after_page_title_view-user', array(__CLASS__, 'all_users_link'));
        // Menu hooks
        add_filter( 'cwms1661_dashboard_menus', array(__CLASS__, 'menu' ) );
        add_filter( 'cwms1661_registered_dashboard_pages', array(__CLASS__, 'page' ));
        // Template
        add_filter( 'cwms1661_content_template_edit-profile', array(__CLASS__, 'edit_profile_template' ) );
        add_filter( 'cwms1661_content_template_view-user', array(__CLASS__, 'view_template' ) );
        add_filter( 'cwms1661_content_template_add-user', array(__CLASS__, 'add_template' ) );
        add_filter( 'cwms1661_content_template_update-user', array(__CLASS__, 'update_template' ) );
        add_filter( 'cwms1661_content_template_all-users', array(__CLASS__, 'all_template' ) );

        // Password fields
        add_action( 'cwms1661_after_user_form_fields', array(__CLASS__, 'password_fields' ), 10, 1 );
        add_action( 'cwms1661_after_update_profile_form_fields', array(__CLASS__, 'password_fields' ), 10, 1 );
        add_action( 'cwms_after_form_field', array(__CLASS__, 'password_toggle_icon' ) );

        // Permissions
        add_filter( 'cwms1661_permissions', array(__CLASS__, 'permissions' ) );
    }
    public static function add_new_link(){
        if( !cwms1661_can_add_user() ){
            return false;
        }
        printf( '<a href="%s" class="btn btn-sm btn-primary">' . __( 'Add new User', 'wpcodigo_wms' ) . '</a>', cwms1661_dashboard_home().'?cwmspage=add-user' );
    }
    public static function all_users_link(){
        printf( '<a href="%s" class="btn btn-sm btn-primary">' . __( 'All Users', 'wpcodigo_wms' ) . '</a>', cwms1661_dashboard_home().'?cwmspage=all-users' );
    }
    public static function menu( $menus ){
        if( !cwms1661_can_view_users() ) {
            return $menus;
        }
        $subs = array(
            'all-users' => esc_html__('All Users', 'wpcodigo_wms'),
            'add-user' => esc_html__('Add User', 'wpcodigo_wms')
        );
        if( !cwms1661_can_add_user() ){
            unset($subs['add-user']);
        }
        $menus[35] = array(
            'id'   => 'users',
            'label' => esc_html__('Users', 'wpcodigo_wms'),
            'classes' => 'fa fa-users',
            'subs'  => $subs
        );
        return $menus;
    }
    public static function page( $pages ){
        $pages['update-user']   = esc_html__('Update User', 'wpcodigo_wms');
        $pages['edit-profile']   = esc_html__('Edit Profile', 'wpcodigo_wms');
        $pages['view-user']     = esc_html__('User Information', 'wpcodigo_wms');
        return $pages;
    }
    public static function edit_profile_template(){
        return apply_filters( "cwms1661_get_template_edit-profile", CWMS1661_ABSPATH.'module/user/templates/edit-profile.php' );
    }
    public static function view_template(){
        if( !isset($_GET['id']) || !(int)$_GET['id'] ){
            return cwms1661_get_template_path('404', 'dashboard');
        }
        if( ! cwms1661_can_view_users() && (int)$_GET['id'] !== get_current_user_id() ){
            return cwms1661_get_template_path('403', 'dashboard');
        }
        return apply_filters( "cwms1661_get_template_view-user", CWMS1661_ABSPATH.'module/user/templates/view-user.php' );
    }
    public static function add_template(){
        if( ! cwms1661_can_add_user() ){
            return cwms1661_get_template_path('403', 'dashboard');
        }
        return apply_filters( "cwms1661_get_template_add-user", CWMS1661_ABSPATH.'module/user/templates/add-user.php' );
    }
    public static function update_template(){
        // Check if the current user allowed to update the user role
        $user_id = isset( $_GET['id'] ) ? (int)$_GET['id'] : 0;
        $user    = get_userdata( $user_id );
        if( ! cwms1661_can_update_user() || !$user ){
            return cwms1661_get_template_path('403', 'dashboard');
        }
        // make sure that the non admin user can update only the access roles
        if( !is_cwms1661_admin() && !array_intersect( $user->roles, cwms1661_non_admin_access_user_roles() ) ){
            return cwms1661_get_template_path('403', 'dashboard');
        }
        return apply_filters( "cwms1661_get_template_update-user", CWMS1661_ABSPATH.'module/user/templates/update-user.php' );
    }
    public static function all_template(){
        if( ! cwms1661_can_view_users() ){
            return cwms1661_get_template_path('403', 'dashboard');
        }
        return apply_filters( "cwms1661_get_template_all-users", CWMS1661_ABSPATH.'module/user/templates/all-users.php' );
    }
    public static function password_fields( $user ){
        // Not allowed in the add new user - non admin user
        $required = ! $user ? true : false;
        $password_fields = array(
            '_password'             => array(
                'id'        => '_password',
                'label'     => __('Password', 'wpcodigo_wms' ),
                'type'      => 'password',
                'required'  =>  $required,
                'options'   => array(),
                'classes'   => 'cwms-password-field'
            ),
            '_cpassword'             => array(
                'id'        => '_cpassword',
                'label'     => __('Confirm password', 'wpcodigo_wms' ),
                'type'      => 'password',
                'required'  =>  $required,
                'options'   => array(),
                'classes'   => 'cwms-password-field'
            )
        );
        include_once apply_filters( "cwms1661_get_template_password-fields", CWMS1661_ABSPATH.'module/user/templates/password-fields.php' );
    }
    public static function password_toggle_icon( $field ){
        if( !( $field['id'] == '_password' || $field['id'] == '_cpassword' ) ){
            return;
        }
        ?>
            <i class="fa fa-2x fa-eye cwms-password-toggle" style="
            margin: 0;
            position: absolute;
            top: 50%;
            right: 6px;
            -ms-transform: translate(-50%, -50%);
            transform: translate(-50%, -50%);
            cursor: pointer;
        "></i>
        <?php

    }
    public static function save(){
        // Do not run if the condition is NOT meet
        if ( ! isset( $_POST['cwms-user_form_nonce'] ) 
            || ! wp_verify_nonce( $_POST['cwms-user_form_nonce'], 'cwms-user_form_action' ) 
        ) {
            return true;
        }

        $email          = isset( $_POST['_email'] ) ? sanitize_text_field( $_POST['_email'] ) : '';
        $first_name      = isset( $_POST['_firstname'] ) ? sanitize_text_field( $_POST['_firstname'] )  : '';
        $last_name      = isset( $_POST['_lastname'] ) ? sanitize_text_field( $_POST['_lastname'] )  : '';
        $role           = isset( $_POST['_cwms_roles'] ) ? sanitize_text_field( $_POST['_cwms_roles'] )  : 'cwms_customer';
        $user_id        = isset( $_GET['id']) ? (int)$_GET['id'] : false;
        $allowed_roles     = array_keys( cwms1661_dashboard_roles() );

        if( !is_cwms1661_admin() ){
            $allowed_roles = cwms1661_non_admin_access_user_roles();
        }

        if( ! in_array( strtolower($role), $allowed_roles ) || !cwms1661_can_add_user() ){
            printf( '<div id="message" class="error"><p>%s</p></div>', __('Permission denied. Please contact admin support', 'wpcodigo_wms') );
            wp_die();   
        }

        // Unset data from post with the with the insert user rtequirements
        unset( $_POST['_email'] );
        unset( $_POST['_firsname'] );
        unset( $_POST['_lastname'] );
        unset( $_POST['_cwms_roles'] );

        $userdata       = array(
            'user_login'    => $email,
            'user_email'    => $email,
            'first_name'    => $first_name,
            'last_name'     => $last_name,
            'role'          => $role,
            'display_name'  => $first_name.' '.$last_name
        );

        if( isset( $_POST['_password'] ) && !empty( trim( $_POST['_password'] ) )  ){
            $userdata['user_pass'] = trim( $_POST['_password'] );
        }elseif( !$user_id ){
            // If new user Password is required
            // If form is hacked and removed the password form force to generate password
            $userdata['user_pass'] = wp_generate_password( 12, false );
        }

        $userdata   = apply_filters( 'cwms1611_create_user_args', $userdata );

        // Check if the submission either add or update
        if( $user_id ){
            $userdata['ID'] =  $user_id;
            unset( $userdata['user_login'] );
            unset( $userdata['user_email'] );
            $user_id        = wp_update_user( $userdata );
        }else{
            $user_id        = wp_insert_user( $userdata );
        }
        
        if( is_wp_error( $user_id ) ){
            $error_string = $user_id->get_error_message();
            echo '<div id="message" class="error"><p>' . $error_string . '</p></div>';
            wp_die();
        }
        // Saving User Status ( Active, Inactive )
        if( isset( $_POST['_cwms_user_status'] ) && !(int)$_POST['_cwms_user_status'] ){
            update_user_meta( $user_id, '_cwms_inactive', 1 );
        }else{
            delete_user_meta( $user_id, '_cwms_inactive' );
        }

        // Saving use meta
        foreach ( cwms1661_user_fields() as $key => $field ) {
            if( !array_key_exists($key, $_POST) ){
                continue;
            }
            $value = is_array( $_POST[$key] ) ? (array)$_POST[$key] : sanitize_text_field( $_POST[$key] );
            update_user_meta( $user_id, $key, $value );
        }
        $user_info = get_userdata($user_id);
        $_POST['cwms_user_redirection'] = array(
            'cwmspage'      => 'update-user',
            'id'            => $user_info->ID,
            'cwms-message'  => sprintf( __('User %s successfully saved!'), $user_info->display_name )
        );

    }
    public static function save_profile(){
        // Do not run if the condition is NOT meet
        if ( ! isset( $_POST['cwms-update_profile_form_nonce'] ) 
            || ! wp_verify_nonce( $_POST['cwms-update_profile_form_nonce'], 'cwms-update_profile_form_action' ) 
        ) {
            return true;
        }

        $first_name      = isset( $_POST['_firstname'] ) ? sanitize_text_field( $_POST['_firstname'] )  : '';
        $last_name      = isset( $_POST['_lastname'] ) ? sanitize_text_field( $_POST['_lastname'] )  : '';
        $user_id        = get_current_user_id();

        // Unset data from post with the with the insert user rtequirements
        unset( $_POST['_email'] );
        unset( $_POST['_firsname'] );
        unset( $_POST['_lastname'] );
        unset( $_POST['_cwms_roles'] );

        $userdata       = array(
            'first_name'     => $first_name,
            'last_name'     => $last_name,
            'display_name'  => $first_name.' '.$last_name
        );

        if( isset( $_POST['_password'] ) && !empty( trim( $_POST['_password'] ) )  ){
            $userdata['user_pass'] = trim( $_POST['_password'] );
        }

        $userdata   = apply_filters( 'cwms1611_save_profile_args', $userdata );

        // Check if the submission either add or update
        $userdata['ID'] =  $user_id;
        $user_id        = wp_update_user( $userdata );

        if( is_wp_error( $user_id ) ){
            $error_string = $user_id->get_error_message();
            echo '<div id="message" class="error"><p>' . $error_string . '</p></div>';
            wp_die();
        }

        // Saving use meta
        foreach ( cwms1661_user_fields() as $key => $field ) {
            if( !array_key_exists($key, $_POST) ){
                continue;
            }
            $value = is_array( $_POST[$key] ) ? (array)$_POST[$key] : sanitize_text_field( $_POST[$key] );
            update_user_meta( $user_id, $key, $value );
        }
        $user_info = get_userdata($user_id);
        $_POST['cwms_user_redirection'] = array(
            'cwmspage'   => 'edit-profile',
            'cwms-message'   => sprintf( __('Profile %s successfully saved!'), $user_info->display_name )
        );

    }
    // Save supplier redirection
    public static function save_redirection(){
        if( !isset($_POST['cwms_user_redirection']) || !is_array($_POST['cwms_user_redirection']) ){
            return false;
        }
        wp_redirect( cwms1661_dashboard_home().'?'.http_build_query( $_POST['cwms_user_redirection'] ) );
        exit;
    }
    public static function notification_message(){
        if( !isset($_GET['cwmspage']) || ! ( $_GET['cwmspage'] != 'update-user' || $_GET['cwmspage'] != 'edit-profile' ) ){
            return false;
        }
        if( !isset($_GET['cwms-message']) || empty($_GET['cwms-message']) ){
            return false;
        }
        printf('<div class="alert alert-success">%s</div>', stripslashes( urldecode($_GET['cwms-message']) ));
        ?>        
        <script>
            window.history.replaceState({}, document.title, '<?php echo cwms1661_dashboard_home().'?'.cwms1661_clean_url_parameter(['cwms-message']); ?>' );
        </script>
        
        <?php
    }
    public static function script_translations( $translations ){
        $translations['userTableData'] = array(
            'id'        => 'cwms_dataTable-user',
            'delete'    => current_user_can( 'delete_users' ),
            'headers'   => cwms1661_user_table_headers(),
            'downloadHeaders' => cwms1661_user_download_headers()
        );
        return $translations;
    }
    public static function get_users(){
        global $wp_roles;
        $role_type = sanitize_text_field( $_GET['role'] );
        $roles     = empty( $role_type ) || $role_type == 'all' || $role_type == 'cwms_inactive_account' ? array() : array( $role_type );
        $can_delete_user = cwms1661_can_delete_user();
        
        // if non admin user only allowed user roles can be access
        if( !is_cwms1661_admin() ){
            $access_user_roles = cwms1661_non_admin_access_user_roles();
            // $roles = empty( $role_type ) || ! in_array( $role_type, $access_user_roles ) ? $access_user_roles : array( $role_type ) ;
            if( ! ( empty( $role_type ) || $role_type == 'all' || $role_type == 'cwms_inactive_account' )
                || ! in_array( $role_type, $access_user_roles ) ){
                $roles = cwms1661_non_admin_access_user_roles();
            }else{
                $roles = array( $role_type );
            }
        }

        $active_user = $role_type == 'cwms_inactive_account' ? false : true;

        $data      = cwms1661_get_all_users( $roles, $active_user );
        
        if( $data ){
            $data = array_map( function( $value ) use( $wp_roles, $can_delete_user ) {

                $roles_label    = array_map( function( $role ) use( $wp_roles ) {
                    return $wp_roles->roles[ $role ]['name'];
                }, $value['roles'] );

                $value['roles']       = implode(',', $roles_label);
                $value['update_link'] = cwms1661_dashboard_home().'?cwmspage=update-user&id='.$value['ID'];
                $value['view_link']   = cwms1661_dashboard_home().'?cwmspage=view-user&id='.$value['ID'];
                $label_url = esc_url_raw( cwms1661_dashboard_home().'?cwmspage=update-user&id='.$value['ID'] );
                $actions = [
                    'edit' => sprintf(
                        '<span class="edit"><a class="cwms-update_user text-primary" href="%s">%s</a> ',
                        esc_url_raw( cwms1661_dashboard_home().'?cwmspage=update-user&id='.$value['ID'] ),
                        esc_html__('Edit','wpcodigo_wms')
                    ),
                    'delete' => sprintf(
                        '<span class="trash"><a class="cwms-delete_user text-danger" href="#">%s</a></span>',
                        esc_html__('Delete','wpcodigo_wms')
                    ),
                    'view'  => sprintf(
                        '<span class="view"><a class="text-primary" href="%s">%s</a></span>',
                        esc_url_raw( cwms1661_dashboard_home().'?cwmspage=view-user&id='.$value['ID'] ),
                        esc_html__('View','wpcodigo_wms')
                    )
                ];

                // Remove the delete options if user not allowed to delete user
                if( ( ! $can_delete_user || $value['ID'] == 1 ) || $value['ID'] == get_current_user_id() ):
                    unset($actions['delete']);
                endif;

                if( ( $value['ID'] == 1 && get_current_user_id() !== 1 ) || !cwms1661_can_update_user()  ):
                    unset($actions['edit']);
                    $label_url = esc_url_raw( cwms1661_dashboard_home().'?cwmspage=view-user&id='.$value['ID'] );
                endif;

                ob_start();
                ?>
                <strong data-id="<?php echo $value['ID']; ?>"><a href="<?php echo $label_url; ?>"><?php echo $value['username']; ?></a></strong>          
                    <div class="row-actions" data-id="<?php echo $value['ID']; ?>">
                        <?php echo implode( ' | ', array_values( $actions ) ) ?>
                    </div>
                <?php
                $string = ob_get_clean();
                $value['username'] = $string;
                return $value;
            }, $data );
        }
        wp_send_json( array( 'data' => $data ) );
    }
    public static function delete_user(){
        $user_id = isset( $_POST['id']) ? (int) $_POST['id'] : null;
        $user    = get_userdata( $user_id );

        if( ! cwms1661_can_delete_user() || !$user || in_array('administrator', $user->roles ) ){
            wp_send_json( array(
                'status' => 'error',
                'code'  => 401,
                'message' => esc_html__('Sorry cannot process your request, permission denied', 'wpcodigo_wms')
            ));
        }

        // Check if the current user has access to the selected user roles
        if( !is_cwms1661_admin() && !array_intersect( $user->roles, cwms1661_non_admin_access_user_roles() ) ){
            wp_send_json( array(
                'status' => 'error',
                'code'  => 401,
                'message' => esc_html__('Sorry cannot process your request, permission denied', 'wpcodigo_wms')
            ));
        }
        update_user_meta( $user->ID, '_cwms_inactive', true );
        $code       = 200;
        $message    = esc_html__('User successfully deleted.', 'wpcodigo_wms');
        do_action('cwms_after_delete_user', $user->ID );
        wp_send_json( array(
            'code'      => $code,
            'message'   => $message,
            'user_id' => $user->ID
        ));
    }
    public static function bulk_delete_users(){
        if( !current_user_can( 'delete_users' ) ){
            wp_send_json( array(
                'status' => 'error',
                'code'  => 401,
                'message' => esc_html__('Sorry cannot process your request, permission denied', 'wpcodigo_wms')
            ));
        }
        require_once( ABSPATH.'wp-admin/includes/user.php' );
        $selected_ids   = $_POST['ids'];
        $return         = array(
            'status' => 'success',
            'code'  => 200,
            'message' => esc_html__('Request successfully completed', 'wpcodigo_wms')
        );
        
        foreach ($selected_ids as $id ) {
            $user_id = (int)$id;
            if( !$user_id  || $user_id == 1 ){
                continue;
            }
            $user_info = get_userdata( $user_id );
            update_user_meta( $user_info->ID, '_cwms_inactive', true );
        }   
        wp_send_json($return);
        wp_die();
    }
    public static function search_customer(){
        $search_string  = esc_attr( trim( $_GET['q'] ) );
        $customers      = cwms1661_search_user( $search_string, 'cwms_customer' );
        $options        = array();
        if( !empty( $customers ) ){
            foreach ($customers as $customer ) {
                $options[] = array_map( 'wp_specialchars_decode', cwms1661_get_user_info( $customer ) );
            }
        }
        wp_send_json( $options ); 
    }
    public static function search_active_customer(){
        $search_string  = esc_attr( trim( $_GET['q'] ) );
        $customers      = cwms1661_search_user( $search_string, 'cwms_customer', true );
        $options        = array();
        if( !empty( $customers ) ){
            foreach ($customers as $customer ) {
                $options[] = array_map( 'wp_specialchars_decode', cwms1661_get_user_info( $customer ) );
            }
        }
        wp_send_json( $options ); 
    }
    public static function search_salesman(){
        $search_string  = esc_attr( trim( $_GET['q'] ) );
        $options        = array();
        $customers      = get_users( array( 
            'role'              => array( 'cwms_agent' ),
            'search'            => "*{$search_string}*",
	        'search_columns'    => array( 'user_login', 'user_email', 'user_nicename', 'display_name' )
        ) );
        if( !empty( $customers ) ){
            foreach ($customers as $customer ) {
                $options[] = cwms1661_get_user_info( $customer );
            }
        }
        wp_send_json( $options ); 
    }

    public static function permissions( $permissions ){
        $permissions[60] = array(
            'label' => esc_html__('Users', 'wpcodigo_wms' ),
			'options' => array(
                'cwms1661_can_add_user_roles'     => esc_html__('Add', 'wpcodigo_wms' ), 
                'cwms1661_can_update_user_roles'  => esc_html__('Edit', 'wpcodigo_wms' ),
                'cwms1661_can_delete_user_roles'  => esc_html__('Delete', 'wpcodigo_wms' )
            )
        );
        return $permissions;
    }
}