<?php
defined( 'ABSPATH' ) || exit;
function cwms1661_user_fields(){
    $headers = array(
        '_company'             => array(
            'id'        => '_company',
            'label'     => __('Company Name', 'wpcodigo_wms' ),
            'type'      => 'text',
            'required'  => false,
            'options'   => array(),
            'classes'   => ''
        ),
        '_firstname'             => array(
            'id'        => '_firstname',
            'label'     => __('First Name', 'wpcodigo_wms' ),
            'type'      => 'text',
            'required'  => true,
            'options'   => array(),
            'classes'   => ''
        ),
        '_lastname'             => array(
            'id'        => '_lastname',
            'label'     => __('Last Name', 'wpcodigo_wms' ),
            'type'      => 'text',
            'required'  => true,
            'options'   => array(),
            'classes'   => ''
        ),
        '_middlename'             => array(
            'id'        => '_middlename',
            'label'     => __('Middle Name', 'wpcodigo_wms' ),
            'type'      => 'text',
            'required'  => false,
            'options'   => array(),
            'classes'   => ''
        ),
        '_phone'             => array(
            'id'        => '_phone',
            'label'     => __('Phone', 'wpcodigo_wms' ),
            'type'      => 'text',
            'required'  => true,
            'options'   => array(),
            'classes'   => 'wcms-phone'
        ),
        '_email'             => array(
            'id'        => '_email',
            'label'     => __('Email', 'wpcodigo_wms' ),
            'type'      => 'email',
            'required'  => true,
            'options'   => array(),
            'classes'   => ''
        ),
        '_address_1'             => array(
            'id'        => '_address_1',
            'label'     => __('Address 1', 'wpcodigo_wms' ),
            'type'      => 'text',
            'required'  => true,
            'options'   => array(),
            'classes'   => ''
        ),
        '_address_2'    => array(
            'id'        => '_address_2',
            'label'     => __('Address 2', 'wpcodigo_wms' ),
            'type'      => 'text',
            'required'  => false,
            'options'   => array(),
            'classes'   => ''
        ),
        '_city'             => array(
            'id'        => '_city',
            'label'     => __('City', 'wpcodigo_wms' ),
            'type'      => 'text',
            'required'  => true,
            'options'   => array(),
            'classes'   => ''
        ),
        '_state'             => array(
            'id'        => '_state',
            'label'     => __('State / Province / Region', 'wpcodigo_wms' ),
            'type'      => 'text',
            'required'  => true,
            'options'   => array(),
            'classes'   => ''
        ),
        '_country'      => array(
            'id'        => '_country',
            'label'     => __('Country', 'wpcodigo_wms' ),
            'type'      => 'text',
            'required'  => true,
            'options'   => array(),
            'classes'   => ''
        ),
        '_postcode'     => array(
            'id'        => '_postcode',
            'label'     => __('Postcode', 'wpcodigo_wms' ),
            'type'      => 'text',
            'required'  => true,
            'options'   => array(),
            'classes'   => ''
        )
    );
    return apply_filters( 'cwms1661_user_fields', $headers );
}
function cwms1661_user_table_default_headers(){
    return ['username', 'display_name', '_company'];
}
function cwms1661_user_status( $user_id ){
    $inactive = get_user_meta( $user_id, '_cwms_inactive', true );
    return $inactive ? __('Inactive', 'wpcodigo_wms' ) : __('Active', 'wpcodigo_wms' );
}
function cwms1661_non_admin_access_user_roles(){
    return apply_filters( 'cwms1661_non_admin_access_user_roles', array_keys( cwms1661_dashboard_roles() ) );
}
function cwms1661_user_table_headers(){
    $metakeys   = ['_phone', '_email', '_state', 'roles'];
    $metakeys   = apply_filters( 'cwms1661_user_table_headers', $metakeys );
    return array_merge( cwms1661_user_table_default_headers(), $metakeys );
}
function cwms1661_user_download_headers(){
    $headers_key = cwms1661_user_table_headers();
    $headers     = [];
    foreach ($headers_key as $key) {
        $user_fields = cwms1661_user_fields();
        $key_label = ucfirst( implode( ' ', array_filter( explode("_", $key ) ) ) );
        $label = array_key_exists( $key, $user_fields ) ? $user_fields[$key]['label']  : $key_label ;
        $headers[ $key ] = $label;
    }
    return $headers;
}
function cwms1661_get_user_info( $user ){
    $user_fields =  array_merge( cwms1661_user_table_default_headers() ,array_keys( cwms1661_user_fields() ) );
    // Unset fields which are already in the user Object
    $data       = [ 'ID' => $user->ID,  'roles' => $user->roles ];
    if( in_array( '_firstname', $user_fields) ){
        $data['_firstname'] = $user->first_name;
        if (($key = array_search( '_firstname', $user_fields)) !== false) {
            unset($user_fields[$key]);
        }
    }
    if( in_array( '_lastname', $user_fields) ){
        $data['_lastname'] = $user->last_name;
        if (($key = array_search( '_lastname', $user_fields)) !== false) {
            unset($user_fields[$key]);
        }
    }
    if( in_array( 'display_name', $user_fields) ){
        $data['display_name'] = $user->display_name;
        if (($key = array_search( 'display_name', $user_fields)) !== false) {
            unset($user_fields[$key]);
        }
    }
    if( in_array( 'username', $user_fields) ){
        $data['username'] = $user->user_login;
        if (($key = array_search( 'username', $user_fields)) !== false) {
            unset($user_fields[$key]);
        }
    }
    
    if( in_array( '_email', $user_fields) ){
        $data['_email'] = $user->user_email;
        if (($key = array_search( '_email', $user_fields)) !== false) {
            unset($user_fields[$key]);
        }
    }
    if( ! empty($user_fields) ){
        foreach( $user_fields as $metakey ){
            $value = get_user_meta( $user->ID, $metakey, true );
            $data[ $metakey ] = $value;
        }
    }
    return apply_filters('cwms1661_get_user_info', $data, $user, $user_fields );
}
function cwms1661_get_all_users( $user_roles = array(), $active = true ){
    if( empty( $user_roles ) ){
        $user_roles     = array_keys( cwms1661_dashboard_roles() );
        $user_roles[]   = 'administrator';
    }  

    $args = array(
        'role__in'      => $user_roles,
        'meta_key'      => '_cwms_inactive',
        'meta_compare'  => 'NOT EXISTS'
    );

    if( $active === false ){
        $args['meta_value']     =  true;
        $args['meta_compare']   =  '=';
    }elseif( $active === null ){
        unset( $args['meta_key'] );
        unset( $args['meta_compare'] );
    }

    $users =  get_users( $args );
    if( empty( $users ) ){
        return false;
    }
    $data = [];
    foreach ( $users as $user ) {
        $data[] = cwms1661_get_user_info( $user );
    }
    return $data;
}

function cwms1661_search_user( $search_string, $role = '', $active = null ){
    global $wpdb;
    $search_arr     = [];
    for ($i=0; $i < 6 ; $i++) { 
        $search_arr[] = '%'.$search_string.'%';
    }

    $sql = "SELECT tbluser.ID";
    $sql .= " FROM {$wpdb->users} AS tbluser";
    $sql .= " LEFT JOIN {$wpdb->usermeta} AS tblcap ON tblcap.user_id = tbluser.ID";
    $sql .= " LEFT JOIN {$wpdb->usermeta} AS tblcom ON tblcom.user_id = tbluser.ID";

    if( $active !== null ){
        $sql .= " LEFT JOIN {$wpdb->usermeta} AS tblatc ON ( tbluser.ID = tblatc.user_id AND tblatc.meta_key = '_cwms_inactive' )";
    }

    $sql .= " WHERE 1=1 AND";

    if( $active === false ){
        $sql .= " ( tblatc.user_id IS NOT NULL ) AND ";
    }elseif( $active === true ){
        $sql .= " ( tblatc.user_id IS NULL ) AND ";
    }

    $sql .= " ( tbluser.user_login LIKE %s";
    $sql .= " OR tbluser.user_login LIKE %s";
    $sql .= " OR tbluser.user_email LIKE %s";
    $sql .= " OR tbluser.user_nicename LIKE %s";
    $sql .= " OR tbluser.display_name LIKE %s";
    $sql .= " OR ( tblcom.meta_key LIKE '_company' AND tblcom.meta_value LIKE %s ) )";
    if( ! empty( $role ) ){
        $sql .= " AND ( tblcap.meta_key LIKE 'wp_capabilities' AND tblcap.meta_value LIKE %s )";
        $search_arr[] = '%:"'.$role.'";%';
    }
    $sql .= " GROUP BY tbluser.ID";
    $results =  $wpdb->get_col( $wpdb->prepare( $sql, $search_arr ) );

    return array_map( function( $user_id ){
        return get_userdata( $user_id );
    }, $results );
}

function cwms1661_get_user_area( $area ){
    global $wpdb;
    $sql = "SELECT tblmeta.meta_value FROM {$wpdb->users} AS tbluser LEFT JOIN {$wpdb->usermeta} AS tblmeta ON tblmeta.user_id = tbluser.ID WHERE tblmeta.meta_key LIKE %s AND tblmeta.meta_value <> ''";
    $area_list =  $wpdb->get_col( $wpdb->prepare( $sql, '_'.$area ) );
    return  $area_list ? array_unique( $area_list ) : null;
}
function cwms1661_can_view_users(){
    if( ! ( cwms1661_can_add_user() || cwms1661_can_update_user() || cwms1661_can_delete_user() ) ){
        return false;
    }
    return true;
}
function cwms1661_can_add_user_roles(){
    $assinged_roles     = get_option( 'cwms1661_can_add_user_roles', null );
    if( $assinged_roles === null || !is_array($assinged_roles) ){
        $assinged_roles = array( );
    }
    $assinged_roles     = apply_filters('cwms1661_can_add_user_roles', $assinged_roles );
    $assinged_roles[]   = 'administrator';
    return $assinged_roles;
}
function cwms1661_can_add_user(){
    if( !is_user_logged_in() ){
        return false;
    }
    return array_intersect( cwms1661_can_add_user_roles(),  cwms1661_current_user_roles() ) ? true : false ;
}
function cwms1661_can_update_user_roles(){
    $assinged_roles     = get_option( 'cwms1661_can_update_user_roles', null );
    if( $assinged_roles === null || !is_array($assinged_roles) ){
        $assinged_roles = array( );
    }
    $assinged_roles     = apply_filters('cwms1661_can_update_user_roles', $assinged_roles );
    $assinged_roles[]   = 'administrator';
    return $assinged_roles;
}
function cwms1661_can_update_user(){
    if( !is_user_logged_in() ){
        return false;
    }
    return array_intersect( cwms1661_can_update_user_roles(),  cwms1661_current_user_roles() ) ? true : false ;
}
function cwms1661_can_delete_user_roles(){
    $assinged_roles     = get_option( 'cwms1661_can_delete_user_roles', null );
    if( $assinged_roles === null || !is_array($assinged_roles) ){
        $assinged_roles = array( );
    }
    $assinged_roles = apply_filters('cwms1661_can_delete_user_roles', $assinged_roles );
    $assinged_roles[]   = 'administrator';
    return $assinged_roles;
}
function cwms1661_can_delete_user(){
    if( ! is_user_logged_in() ){
        return false;
    }
    return array_intersect( cwms1661_can_delete_user_roles(),  cwms1661_current_user_roles() ) ? true : false ;
}
