<?php
    $user_id = isset( $_GET['id'] ) ? (int)$_GET['id'] : 0;
    $user    = cwms1661_get_user_info( get_userdata($user_id) );
?>
<div class="col-md-offset-3 col-md-6 col-sm-12">
    <div class="form-horizontal form-label-left input_mask">
        <?php 
        foreach( cwms1661_user_fields() as $key => $field ): 
            $field      = new CWMS_Field( $field, $user[$key], array('disabled') );
            echo $field->html();
        endforeach; 
        ?>
    </div>
</div>