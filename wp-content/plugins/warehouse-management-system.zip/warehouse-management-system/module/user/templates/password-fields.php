<div class="ln_solid"></div>
<div class="form-group ">
    <label class="control-label col-md-3 col-sm-3 col-xs-12"><?php echo esc_html( 'Note', 'wpcodigo_wms'); ?>:</label>        
    <div class="col-md-9 col-sm-9 col-xs-12">
        <p style="padding-top: 8px;"><?php echo sprintf( esc_html( 'Password Accepted characters (%s)', 'wpcodigo_wms'), 'a-zA-Z0-9!~@#$%^&*' ); ?></p>
    </div>
</div>
<div class="cwms-password-message_wrapper"></div>
<?php
    foreach( $password_fields as $key => $field ): 
        $field      = new CWMS_Field( $field, '', array('autocomplete="new-password"') );
        echo $field->html();
    endforeach; 
?>