<?php
    global $wp_roles;
    $cwms_roles = array_keys( cwms1661_dashboard_roles() );
    array_unshift( $cwms_roles, 'administrator' );
    // Display roles option based on the non admin access roles
    if( !is_cwms1661_admin() ){
        $cwms_roles = cwms1661_non_admin_access_user_roles();
    }
?>
<!-- Filter -->
<?php if( count($cwms_roles) > 1 ): ?>
    <div class="filter-section" style="margin-bottom:18px;">
        <section class="filter-wrapper" style="margin-right:12px;">
            <select id="alluser_role_filter" data-action="cwms_search_user_role" data-placeholder="<?php echo esc_html('All Roles','wpcodigo_wms'); ?>" class="form-control form-control-sm" style="width:180px;margin-right:8px;display:inline-block;">
                <option value=""><?php echo esc_html('All Roles','wpcodigo_wms'); ?></option>
                <?php foreach( $wp_roles->role_names as $role_key => $role_label ): ?>
                    <?php
                    if( ! in_array( $role_key, $cwms_roles ) ){
                        continue;
                    }
                    ?>
                    <option value="<?php echo esc_html( $role_key ); ?>"><?php echo esc_html( $role_label ); ?></option>
                <?php endforeach; ?>
                <option value="cwms_inactive_account"><?php echo esc_html('Inactive Accounts','wpcodigo_wms'); ?></option>
            </select> 
        </section>
    </div>
<?php endif; ?>
<!-- Table data list -->
<div class="table-reponsive" style="min-height: 180px;">
    <table id="cwms_dataTable-user" data-type="users" class="wcms1661_dataTable display" style="width:100%">
        <thead>
            <tr>
                <?php do_action( 'cwms1661_user_before_table_header' ); ?>
                <th></th>
                <th><?php esc_html_e('Username','wpcodigo_wms'); ?></th>
                <th><?php esc_html_e('Display Name','wpcodigo_wms'); ?></th>
                <?php foreach( cwms1661_user_fields() as $metakey => $field_info ): ?>
                    <?php if( !in_array($metakey, cwms1661_user_table_headers() ) ) continue; ?>
                    <th><?php echo apply_filters('cwms1661_user_table_headers_label_'.$metakey , $field_info['label'] ); ?></th>
                <?php endforeach; ?>
                <th><?php esc_html_e('Role','wpcodigo_wms'); ?></th>
                <?php do_action( 'cwms1661_user_after_table_header' ); ?>
            </tr>
        </thead>
        <tfoot>
            <tr>
                <?php do_action( 'cwms1661_user_before_table_header' ); ?>
                <th></th>
                <th><?php esc_html_e('Username','wpcodigo_wms'); ?></th>
                <th><?php esc_html_e('Display Name','wpcodigo_wms'); ?></th>
                <?php foreach( cwms1661_user_fields() as $metakey => $field_info ): ?>
                    <?php if( !in_array($metakey, cwms1661_user_table_headers() ) ) continue; ?>
                    <th><?php echo apply_filters('cwms1661_user_table_headers_label_'.$metakey , $field_info['label'] ); ?></th>
                <?php endforeach; ?>
                <th><?php esc_html_e('Role','wpcodigo_wms'); ?></th>
                <?php do_action( 'cwms1661_user_after_table_header' ); ?>
            </tr>
        </tfoot>
    </table>
</div>