<div class="col-md-offset-3 col-md-6 col-sm-12">
    <?php do_action('cwms1661_before_user_form', $user ); ?>
    <form class="form-horizontal form-label-left input_mask" action="" method="POST">
        <?php wp_nonce_field( 'cwms-user_form_action', 'cwms-user_form_nonce' ); ?>
        <?php do_action('cwms1661_before_user_form_fields', $user ); ?>
        <?php if( count($roles) > 1 ): ?>
            <div class="form-group _cwms_roles">
                <label class="control-label col-md-3 col-sm-3 col-xs-12"><?php esc_html_e('User Role','wpcodigo_wms'); ?> <span class="required text-danger">*</span></label>
                <div class="col-md-9 col-sm-9 col-xs-12">
                    <select name="_cwms_roles" class="form-control" required>
                        <option value=""><?php esc_html_e('Select Role','wpcodigo_wms'); ?></option>
                        <?php foreach( $roles as $key => $label ): ?>
                            <?php
                                $current_role = $user ? $user['roles'] : array();
                            ?>
                            <option value="<?php echo $key; ?>" <?php echo $user && in_array( $key, $current_role ) ? 'selected' : '' ; ?>><?php echo $label; ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
            </div>
        <?php endif; ?>
        <?php 
        if( $user ):
            $cwms_inactive   = get_user_meta( $user['ID'], '_cwms_inactive', true );
            $cwms_inactive   = $cwms_inactive ? 0 : 1 ;
            $user_status_opt = [ 1 => __('Active', 'wpcodigo_wms' ), 0 => __('Inactive', 'wpcodigo_wms' )]
            ?>
            <div class="form-group _cwms_user_status">
                <label class="control-label col-md-3 col-sm-3 col-xs-12">
                    <?php echo esc_html('User Status', 'wpcodigo_wms' ) ?><span class="required text-danger">*</span>
                </label>
                <div class="col-md-9 col-sm-9 col-xs-12">
                    <select name="_cwms_user_status" class="form-control" required>
                        <?php foreach( $user_status_opt as $opt_key => $opt_label ): ?>
                        <option value="<?php echo $opt_key; ?>" <?php selected( $cwms_inactive, $opt_key ); ?>><?php echo $opt_label; ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
            </div>
            <?php
        endif;
        foreach( cwms1661_user_fields() as $key => $field ): 
            $attribute  = $key == '_email' && $user ? array('disabled') : array();
            $value      = $user != null && array_key_exists( $key, $user ) ? $user[$key] : '';
            $field      = new CWMS_Field( $field, $value, $attribute );
            echo $field->html();
        endforeach; 
        ?>
        <?php do_action('cwms1661_after_user_form_fields', $user ); ?>
        <div class="ln_solid"></div>
        <div class="form-group">
            <div class="col-md-9 col-sm-9 col-xs-12 col-md-offset-3">
                <button type="submit" class="btn btn-success"><?php echo esc_html__('Save user', 'wpcodigo_wms' ); ?></button>
            </div>
        </div>
    </form>
    <?php do_action('cwms1661_after_user_form', $user ); ?>
</div>