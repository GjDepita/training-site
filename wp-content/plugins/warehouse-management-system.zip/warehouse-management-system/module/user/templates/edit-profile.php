<?php
    $user_id = get_current_user_id();
    $user    = cwms1661_get_user_info( get_userdata($user_id) );
?>
<div class="col-md-offset-3 col-md-6 col-sm-12">
    <?php do_action('cwms1661_before_update_profile_form', $user ); ?>
    <form class="form-horizontal form-label-left input_mask" action="" method="POST">
        <?php wp_nonce_field( 'cwms-update_profile_form_action', 'cwms-update_profile_form_nonce' ); ?>
        <?php do_action('cwms1661_before_update_profile_form_fields', $user ); ?>
        <?php 
        foreach( cwms1661_user_fields() as $key => $field ): 
            $attribute  = $key == '_email' && $user ? array('disabled') : array();
            $value      = $user != null && array_key_exists( $key, $user ) ? $user[$key] : '';
            $field      = new CWMS_Field( $field, $value, $attribute );
            echo $field->html();
        endforeach; 
        ?>
        <?php do_action('cwms1661_after_update_profile_form_fields', $user ); ?>
        <div class="ln_solid"></div>
        <div class="form-group">
            <div class="col-md-9 col-sm-9 col-xs-12 col-md-offset-3">
                <button type="submit" class="btn btn-success"><?php echo esc_html__('Save user', 'wpcodigo_wms' ); ?></button>
            </div>
        </div>
    </form>
    <?php do_action('cwms1661_after_update_profile_form', $user ); ?>
</div>