<?php
    $user_id = isset( $_GET['id'] ) ? (int)$_GET['id'] : 0;
    $user    = cwms1661_get_user_info( get_userdata($user_id) );
    $roles   = cwms1661_dashboard_roles(); 
    $access_user_roles = cwms1661_non_admin_access_user_roles();
     // Display roles option based on the non admin access roles'
    if( !is_cwms1661_admin() && !empty( $access_user_roles ) ){
        foreach( $roles as $_rkey => $_rlabel ){
            if( in_array( $_rkey, $access_user_roles ) ){
                continue;
            }
            unset( $roles[$_rkey] );
        }
    }
    include_once apply_filters( "cwms1661_get_template_form-user", CWMS1661_ABSPATH.'module/user/templates/form-user.php' );
?>