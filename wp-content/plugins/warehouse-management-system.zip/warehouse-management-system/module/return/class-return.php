<?php
defined( 'ABSPATH' ) || exit;
/**
 * Invoice
 */

class CWMS1661_Return {
    public static function init(){

        // Saving
        add_action( 'wp', array( __CLASS__, 'create_return_invoice'), 99, 1 );
        add_action( 'save_post_'.CWMS1661_RETURN_POST_TYPE, array( __CLASS__, 'save_return_invoice_post_meta'), 10, 3 );

        // Menu hooks
        add_filter( 'cwms1661_dashboard_menus', array(__CLASS__, 'menu' ) );
        add_filter( 'cwms1661_registered_dashboard_pages', array(__CLASS__, 'page' ));

        // Script translation
        add_filter( 'cwms1661_ajax_localize_script_translations', array(__CLASS__,  'script_translations' ) );

        // Page Template
        add_filter( 'cwms1661_content_template_returns', array(__CLASS__, 'all_return_template' ) );
        add_filter( 'cwms1661_content_template_view-return', array(__CLASS__, 'view_return_template' ) );
        add_filter( 'cwms1661_content_template_receive-returns', array(__CLASS__, 'receive_returns_template' ) );
        add_action( 'cwms1661_before_return_form', array(__CLASS__, 'notification_message' ) );

        // After page title
        add_action('cwms1661_after_page_title_returns', array(__CLASS__, 'create_return_link'));
        add_action('cwms1661_after_page_title_view-return', array(__CLASS__, 'all_list_link'));

        // Redirection
        add_action('template_redirect', array( __CLASS__, 'save_redirection') );

        // Ajax handlers
        add_action( 'wp_ajax_cwms_search_return_invoice', array(__CLASS__,  'search_return_invoice' ) );
        add_action( 'wp_ajax_cwms_get_all_returns', array(__CLASS__,  'get_all_returns' ) );

        // Permissions
        add_filter( 'cwms1661_permissions', array(__CLASS__, 'permissions' ) );

        // Print
        add_filter( 'cwms1661_print_html_body_return-invoice', array(__CLASS__, 'print' ), 10, 2 );
    }

    // Menu Callbacks
    public static function menu( $menus ){
        if( !cwms1661_can_access_returns() ){
            return $menus;
        }

        $menus[25] = array(
            'id'   => 'returns',
            'label' => esc_html__('Returns', 'wpcodigo_wms'),
            'classes' => 'fa fa-repeat',
            'subs'  => array(
                'returns' => esc_html__('All Returns', 'wpcodigo_wms'),
                'receive-returns' => esc_html__('Receive Returns', 'wpcodigo_wms')
            )
        );
        return $menus;
    }
    public static function page( $pages ){
        $pages['returns']           = esc_html__('All Returns', 'wpcodigo_wms');
        $pages['view-return']       = esc_html__('Return details', 'wpcodigo_wms');
        return $pages;
    }

    // Page template callback
    public static function all_return_template(){
        if( ! cwms1661_can_view_returns() ){
            return cwms1661_get_template_path('403', 'dashboard');
        }
        return apply_filters( "cwms1661_get_template_all-returns", CWMS1661_ABSPATH.'module/return/templates/all-returns.php' );
    }
    public static function view_return_template(){
        if( ! cwms1661_can_view_returns() || !isset( $_GET['id'] ) || get_post_type( (int)$_GET['id'] ) != CWMS1661_RETURN_POST_TYPE ){
            return cwms1661_get_template_path('403', 'dashboard');
        }
        return apply_filters( "cwms1661_get_template_view-return", CWMS1661_ABSPATH.'module/return/templates/view-return.php' );
    }
    public static function receive_returns_template(){
        if( ! cwms1661_can_receive_returns() ){
            return cwms1661_get_template_path('403', 'dashboard');
        }
        return apply_filters( "cwms1661_get_template_receive-returns", CWMS1661_ABSPATH.'module/return/templates/receive-returns.php' );
    }

    // After page title Callback
    public static function all_list_link(){
        printf( '<a href="%s" class="btn btn-sm btn-primary">' . __( 'All Returns', 'wpcodigo_wms' ) . '</a>', cwms1661_dashboard_home().'?cwmspage=returns' );
    }
    public static function create_return_link(){
        printf( '<a href="%s" class="btn btn-sm btn-primary">' . __( 'Receive Return', 'wpcodigo_wms' ) . '</a>', cwms1661_dashboard_home().'?cwmspage=receive-returns' );
    }


    // Script Translation callback
    public static function script_translations( $translations ){
        $remark_options = cwms1661_return_remarks();
        array_unshift($remark_options, __('Select remarks', 'wpcodigo_wms'),);

        $translations['returnInvoiceTable'] = array(
            'id'        => 'cwms_returnsInvoiceTable',
            'headers'   => array_keys( cwms1661_return_invoice_table_headers() ),
            'remark_options'   => $remark_options,
        );
        return $translations;
    }

    // Saving Callback
    public static function create_return_invoice( ){
        if ( ! isset( $_POST['cwms-create-return_invoice_form_nonce'] ) 
            || ! wp_verify_nonce( $_POST['cwms-create-return_invoice_form_nonce'], 'cwms-create-return_invoice_form_action' ) 
        ) {
            return false;
        }

        $invoice_id = isset( $_POST['_invoice_id'] ) ? (int)$_POST['_invoice_id'] : null ;

        // Make sure all requeirement are meet before proceed to returns
        if( ! $invoice_id || ! is_cwms1661_invoice( $invoice_id, array('cwms-completed' ) ) || ! cwms1661_can_receive_returns() ){
            echo '<div id="message" class="error"><p>' . esc_html__('Cannot process your request. Something went wrong with the submitted data. try another transaction') . '</p></div>';
            wp_die();
        }

        $return_invoice_number  = isset( $_POST['_invoice_return_no'] ) && !empty( $_POST['_invoice_return_no'] ) ? trim($_POST['_invoice_return_no']) : cwms1661_generate_return_invoice_number() ;
        $return_invoice_date    = isset( $_POST['_invoice_date'] ) && !empty( $_POST['_invoice_date'] ) ? trim($_POST['_invoice_date']) : false ;

        $return_invoice_args    = array(
            'post_title'    => wp_strip_all_tags( $return_invoice_number ),
            'post_status'   => 'cwms-completed',
            'post_type'     => CWMS1661_RETURN_POST_TYPE
        );
        if( $return_invoice_date ){
            $return_invoice_args['post_date'] = strftime( '%Y-%m-%d %X', strtotime( $return_invoice_date ) );
        }
        $return_invoice_id = wp_insert_post( $return_invoice_args );
        if ( is_wp_error( $return_invoice_id ) ) {
            echo '<div id="message" class="error"><p>' . $return_invoice_id->get_error_message() . '</p></div>';
            wp_die();
        }

        $_POST['cwms_return_invoice_redirection'] = array(
            'url'       => cwms1661_dashboard_home(),
            'subpage'   => 'receive-returns',
            'id'        => $return_invoice_id,
            'message'   => sprintf( __('Return invoice number # %s successfully saved', 'wpcodigo_wms'), $return_invoice_number )
        );
        return false;
    }
    public static function save_return_invoice_post_meta( $post_id, $post, $update ){

        $invoice_id = isset( $_POST['_invoice_id'] ) ? (int)$_POST['_invoice_id'] : null ;
        if( ! $invoice_id || ! is_cwms1661_invoice( $invoice_id, array('cwms-completed' ) ) || ! cwms1661_can_receive_returns() ){
            return false;
        }

        $user_id            = get_current_user_id();
        $created_by         = cwms1661_user_fullname( $user_id );
        $invoice_data       = cwms1661_get_invoice_data( $invoice_id );
        $return_number      = $post->post_title;
        $pullout_no         = isset( $_POST['_pullout_no'] ) ? sanitize_text_field( $_POST['_pullout_no'] ) : '' ;

        // Saving invoice post meta
        if( (int)$invoice_data['_customer_id'] ){
            $user_info = get_userdata( (int)$invoice_data['_customer_id'] );
            update_post_meta( $post_id, '_customer_id', $user_info->ID );
            update_post_meta( $post_id, '_customer_details', cwms1661_get_user_info( $user_info ) );
        }

        if( isset($invoice_data['_assigned_agent']) ){
            update_post_meta( $post_id, '_assigned_agent', (int)$invoice_data['_assigned_agent'] ) ;
        }

        update_post_meta( $post_id, '_created_by', $created_by );
        update_post_meta( $post_id, '_invoice_id', $invoice_id );
        update_post_meta( $post_id, '_pullout_no', $pullout_no );

        // Saving product data
        $returned_products    = (array)$_POST['cwms_invoice_products'];
        $invoice_products     = $invoice_data['_products'];

        $mapped_products = [];
        foreach ( $invoice_products as $key => $product ) {
            // Only include products with returned Qty
            if( $returned_products[$key]['qty_returned'] <= 0 ){
                continue;
            }
            $_remark = cwms1661_return_remarks()[$returned_products[$key]['remarks']];
            $remarks = sprintf( esc_html__( 'Return products from Invoice # %s with Return # %s with "%s" remarks.', 'wpcodigo_wms' ), $invoice_data['_invoice_number'], $return_number, $_remark );

            $product['discount_amount'] = 0;
            $product['qty_returned']    = $returned_products[$key]['qty_returned'];
            $product['total']           = floatval( $returned_products[$key]['qty_returned'] ) * floatval( $product['retail_price'] );
            $product['remarks']         = $_remark;
            $mapped_products[]          = $product;

            $return_remark_key = $returned_products[$key]['remarks'];
            /*
             * Note: If the return items is damage remarks
             *       instead for return the qty to the items put the item into RTV items
             */
            if( $return_remark_key == 'dmg' ){
                $product['pullout_no']   = $pullout_no;
                $product['return_id']   = $post_id;
                $product['invoice_id']  = $invoice_id;
                $product['created_by']  = $created_by;
                cwms1661_add_rtv_item( $product );
            }else{
                cwms1661_update_product_qty( $product['product_id'], $product['qty_returned'], $post_id, $return_number, $remarks );    
            }
        }
        update_post_meta( $post_id, '_products', $mapped_products );

    }
    // Save redirection
    public static function save_redirection(){
        if( !isset($_POST['cwms_return_invoice_redirection']) || !is_array($_POST['cwms_return_invoice_redirection']) ){
            return false;
        }
        wp_redirect( $_POST['cwms_return_invoice_redirection']['url'] .'?cwmspage='. $_POST['cwms_return_invoice_redirection']['subpage'] .'&id='. $_POST['cwms_return_invoice_redirection']['id'] .'&cwms-message='. urlencode($_POST['cwms_return_invoice_redirection']['message']) );
        exit;
    }
    public static function notification_message(){
        if( !isset($_GET['cwmspage']) ){
            return false;
        }
        if( !isset($_GET['cwms-message']) || empty($_GET['cwms-message']) ){
            return false;
        }
        printf('<div class="submit-notification_message alert alert-success">%s</div>', urldecode($_GET['cwms-message']));
        ?>        
        <script>
            window.history.replaceState({}, document.title, '<?php echo cwms1661_dashboard_home().'?'.cwms1661_clean_url_parameter(['cwms-message']); ?>' );
            setTimeout(function(){
                jQuery('body').find('.submit-notification_message').remove();
            }, 6000 );
        </script>
        
        <?php
    }
    // AJAX Callback
    public static function search_return_invoice(){
        $options    = cwms1661_search_invoice( $_GET['q'], array('cwms-completed') );
        $data       = [];
        if( !empty( $options ) ){
            foreach ($options as $po_id ) {
                $data[] = cwms1661_get_invoice_data( $po_id );
            }
        }
        wp_send_json( $data );
        wp_die();
    }
    public static function get_all_returns(){
        $data           = [];
        $returns_ids    = cwms1661_get_all_returns_data( );
        if( $returns_ids ){
            foreach ($returns_ids as $id ) {
                $label_url          = esc_url_raw( cwms1661_dashboard_home().'?cwmspage=view-return&id='.$id );
                $return_no          = get_the_title( $id );
                $invoice_id         = get_post_meta( $id, '_invoice_id', true );
                $pullout_no         = get_post_meta( $id, '_pullout_no', true );
                $invoice_no         = (int)$invoice_id ? get_the_title( (int)$invoice_id ) : ''; 
                $customer_details   = maybe_unserialize( get_post_meta( $id, '_customer_details', true ) );
                $customer_name      = !empty( $customer_details ) && is_array( $customer_details ) ? $customer_details['display_name'] : '' ;
                $date_created       = get_the_date(cwms1661_datetime_format(), $id );

                $data[]             = array(
                    '_pullout_no'               => $pullout_no,
                    '_return_invoice_number'    => sprintf( '<strong data-id="%d"><a href="%s">%s</a></strong>', $id, $label_url, $return_no ),
                    '_invoice_number'           => $invoice_no,
                    '_dr_no'                    => get_post_meta( $id, '_dr_no', true ),
                    '_customer'                 => $customer_name,
                    '_created_by'               => cwms1661_user_fullname( get_post_field('post_author', $id) ),
                    '_date_created'             => $date_created,
                    '_download'                 => sprintf( '<a href="%s" class="downloadPDF" data-id="%d" data-type="return-invoice"><i class="fa fa-2x fa-file-pdf-o" title="%s" style="margin-right:12px;"></i></a>', '#', $id, __('Download PDF', 'wpcodigo_wms') ),
                );
            }
        }
        wp_send_json( array( 'data' => $data ) );
    }

    // Permission Callback
    public static function permissions( $permissions ){
        $permissions[100] = array(
            'label' => esc_html__('Returns', 'wpcodigo_wms' ),
			'options' => array(
                'cwms1661_can_view_returns_roles'          => esc_html__('View', 'wpcodigo_wms' ), 
                'cwms1661_can_receive_returns_roles'       => esc_html__('Create', 'wpcodigo_wms' )
            )
        );
        return $permissions;
    }

    // Print callback
    public static function print( $file_path, $print_id ){
        if( !(int)$print_id  ){
            return $file_path;
        }
        return apply_filters( "cwms1661_return_invoice_print_template", CWMS1661_ABSPATH.'module/return/templates/print.php' );
    }
}