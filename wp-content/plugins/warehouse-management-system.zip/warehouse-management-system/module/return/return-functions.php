<?php 
defined( 'ABSPATH' ) || exit;
// Permissions #####
function cwms1661_can_view_returns_roles(){
    $assinged_roles     = get_option( 'cwms1661_can_view_returns_roles', null );
    if( $assinged_roles === null ){
        $assinged_roles = array( 'cwms_manager', 'cwms_encoder' );
    }
    $assinged_roles[]   = 'administrator';
    return $assinged_roles;
}
function cwms1661_can_view_returns(){
    if( !is_user_logged_in() ){
        return false;
    }
    $allowed_roles = apply_filters('cwms1661_can_view_returns_roles', cwms1661_can_view_returns_roles() );
    return array_intersect( $allowed_roles,  cwms1661_current_user_roles() ) ? true : false ;
}
function cwms1661_can_receive_returns_roles(){
    $assinged_roles     = get_option( 'cwms1661_can_receive_returns_roles', null );
    if( $assinged_roles === null ){
        $assinged_roles = array( 'cwms_manager', 'cwms_encoder' );
    }
    $assinged_roles[]   = 'administrator';
    return $assinged_roles;
}
function cwms1661_can_receive_returns(){
    if( !is_user_logged_in() ){
        return false;
    }
    $allowed_roles = apply_filters('cwms1661_can_receive_returns_roles', cwms1661_can_receive_returns_roles() );
    return array_intersect( $allowed_roles,  cwms1661_current_user_roles() ) ? true : false ;
}
function cwms1661_can_access_returns(){
    if(
        cwms1661_can_view_returns() 
        || cwms1661_can_receive_returns()
    ){
        return true;
    }
    return false;
}
// Function helpers
function cwms1661_generate_return_invoice_number(){
    $numdigit  	= apply_filters('cwms1661_generate_return_invoice_digit', cwms1661_dr_senquence_length() );
    $numstr     = '';
    for ( $i = 1; $i < $numdigit; $i++ ) {
        $numstr .= 9;
    }
    $return_number  = str_pad( wp_rand( 0, $numstr ), $numdigit, "0", STR_PAD_LEFT );
    $has_return_invoice    = cwms1661_get_return_invoice_id( $return_number );
    if( $has_return_invoice ){
        return cwms1661_generate_return_invoice_number();
    }
    return apply_filters( 'cwms1661_generate_return_invoice_number', $return_number );
}
function cwms1661_return_options(){
    $options = array(
        '_wrong_price'    => __('Wrong Pricing', 'wpcodigo_wms' ),
        '_over_order'     => __('Over Order', 'wpcodigo_wms' ),
        '_wrong_order'    => __('Wrong Order', 'wpcodigo_wms' ),
        '_damage'         => __('Damage', 'wpcodigo_wms' )
    );
    return apply_filters( 'cwms1661_return_options', $options );
}
function cwms1661_return_invoice_table_headers(){
    $fields = array(
        '_return_invoice_number'    => __('Return No.', 'wpcodigo_wms' ),
        '_pullout_no'               => __('Pullout No.', 'wpcodigo_wms' ),
        '_invoice_number'           => __('Invoice No.', 'wpcodigo_wms' ),
        '_dr_no'                    => __('DR No.', 'wpcodigo_wms' ),
        '_customer_company'         => __('Company Name', 'wpcodigo_wms' ),
        '_created_by'               => __('Created By', 'wpcodigo_wms' ),
        '_date_created'             => __('Date Created', 'wpcodigo_wms' ),
        '_download'                 => __('Download', 'wpcodigo_wms' ),
    );
    return apply_filters( 'cwms1661_return_invoice_table_headers', $fields );
}
function cwms1661_get_return_invoice_id( $return_number ){
    global $wpdb;
    return $wpdb->get_var( $wpdb->prepare( "SELECT `ID` FROM {$wpdb->posts} WHERE `post_title` LIKE %s AND `post_type` LIKE %s", $return_number,  CWMS1661_RETURN_POST_TYPE ) );
}
function cwms1661_get_return_data( $post_id ){
    $invoice_headers = cwms1661_invoice_table_headers();
    $post             = get_post( $post_id );
    // Remove the title in metakeys
    $products         = maybe_unserialize( get_post_meta( $post->ID, '_products', true ) );
    $sub_total        = cwms1661_get_invoice_product_total( $products );
    $customer_details = maybe_unserialize( get_post_meta( $post->ID, '_customer_details', true ) );
    $customer_name    = !empty( $customer_details ) && is_array( $customer_details ) ? $customer_details['display_name'] : '' ;
    $customer_company = !empty( $customer_details ) && is_array( $customer_details ) ? $customer_details['_company'] : '' ;
    $payment_status_key   = get_post_meta( $post->ID, '_payment_status', true );
    $payment_status   = $payment_status_key ? cwms1661_invoice_payment_statuses()[$payment_status_key] : '' ;
    $invoice_id       = (int)get_post_meta( $post->ID, '_invoice_id', true ) ;
    $invoice_number   = $invoice_id ? get_the_title($invoice_id) : '';
    $data       = [ 
        'ID'                    => $post->ID, 
        'title'                 => $post->post_title,
        '_invoice_id'           => $invoice_id,
        '_invoice_number'       => $invoice_number,
        '_dr_no'                => get_post_meta( $invoice_id, '_dr_no', true ),
        '_pullout_no'           => get_post_meta( $post->ID, '_pullout_no', true ),
        '_products'             => $products,
        '_status_key'           => $post->post_status,
        '_status'               => cwms1661_post_statuses()[$post->post_status]['label'],
        '_payment_status_key'   => $payment_status_key,
        '_payment_status'       => $payment_status,
        '_remarks'              => get_post_meta( $post->ID, '_remarks', true ),
        '_customer_id'          => get_post_meta( $post->ID, '_customer_id', true ),
        '_customer'             => $customer_name,
        '_customer_company'     => $customer_company,
        '_customer_details'     => $customer_details,
        '_sub_total'            => $sub_total,
        '_assigned_agent'       => (int)get_post_meta( $post->ID, '_assigned_agent', true )
    ]; 
    $data['_assigned_agent_name'] = $data['_assigned_agent'] ? cwms1661_user_fullname( $data['_assigned_agent'] ) : '';
    foreach( array_keys($invoice_headers) as $metakey ){
        if( $metakey == '_date_created' ){
            $data[$metakey] = get_the_date(cwms1661_datetime_format(), $post->ID);
            continue;
        }
        if( $metakey == '_created_by' ){
            $data[$metakey] = cwms1661_user_fullname( $post->post_author );
            continue;
        }
    }
    $data['_total_amount']  = cwms1661_format_number( floatval( $data['_sub_total'] ) );

    return apply_filters('cwms1661_get_invoice_data', $data, $post_id );
}
function cwms1661_get_all_returns_data( $limit = null, $offset = 0 ){
    global $wpdb;
    $parameter = array( CWMS1661_RETURN_POST_TYPE );
    $sql = "SELECT `ID` as 'id'";
    $sql .= " FROM {$wpdb->posts}";
    $sql .= " WHERE `post_status` LIKE 'cwms-completed' AND `post_type` LIKE %s";
    if( $limit ){
        $sql .= " LIMIT %d OFFSET %d";
        $parameter = array_merge( $parameter, array( $limit, $offset ) );
    }
    $sql     = $wpdb->prepare( $sql, $parameter);
    return $wpdb->get_col( apply_filters( 'cwms1661_get_all_returns_data_sql', $sql, $limit, $offset ) );
}