<?php $table_headers  = cwms1661_return_invoice_table_headers(); ?>
<table id="cwms_returnsInvoiceTable" class="wcms1661_dataTable display" style="width:100%">
    <thead>
        <tr>
            <?php foreach( $table_headers as $metakey => $label ): ?>
                <th><?php echo apply_filters('cwms1661_return_invoice_table_headers_label_'.$metakey , $label ); ?></th>
            <?php endforeach; ?>
        </tr>
    </thead>
    <tfoot>
        <tr>
            <?php foreach( $table_headers as $metakey => $label ): ?>
                <th><?php echo apply_filters('cwms1661_return_invoice_table_headers_label_'.$metakey , $label ); ?></th>
            <?php endforeach; ?>
        </tr>
    </tfoot>
</table>    