<?php
$return_invoice             = cwms1661_get_return_data( (int)$_GET['id'] );
$general_settings           = cwms1661_get_general_settings();
$return_invoice_number      = $return_invoice['title'];
$current_date               = $return_invoice['_date_created'];
?>
<div class="col-md-offset-1 col-md-10 col-sm-12">
    <?php do_action('cwms1661_before_view_invoice_template', $return_invoice ); ?>
    <!-- Header -->
    <section id="po-header-section" class="row" style="margin-bottom:18px;">
        <div class="col-md-6 col-sm-12">
            <?php if($general_settings['_company_logo']):  ?>
                <img src="<?php echo $general_settings['_company_logo']; ?>" alt="<?php echo $general_settings['_company_name']; ?>" width="210">
            <?php endif; ?>
        </div>
        <div class="col-md-6 col-sm-12 text-right">
            <h1><?php esc_html_e('RETURN ORDER', 'wpcodigo_wms'); ?></h1>
            <?php esc_html_e('DATE', 'wpcodigo_wms'); ?>: <?php echo $current_date; ?><br/>      
            <span class="cwms-pullout_number"><?php esc_html_e('Pullout Number', 'wpcodigo_wms'); ?>#: <?php echo $return_invoice['_pullout_no']; ?></span></br>     
            <span class="cwms-return_invoice_number"><?php esc_html_e('Return', 'wpcodigo_wms'); ?>#: <?php echo $return_invoice_number; ?></span></br>        
            <span class="cwms-invoice_number"><?php esc_html_e('Invoice', 'wpcodigo_wms'); ?>#: <?php echo $return_invoice['_invoice_number']; ?></span></br>
            <span class="cwms-invoice_dr_no"><?php esc_html_e('DR', 'wpcodigo_wms'); ?>#: <?php echo $return_invoice['_dr_no']; ?></span></br>
        </div>
    </section>
    <!-- Vendors Information -->
    <section id="customer-info-section" class="row" style="margin-bottom:18px;">
        <div class="col-md-6 col-sm-12">
            <h3 class="info-header bg-header"><?php esc_html_e('From', ''); ?></h3>
            <span class="contact-name"><?php echo $general_settings['_company_name']; ?></span></br>
            <span class="company-address"><?php echo nl2br( $general_settings['_address'] ); ?></span><br/>
            <?php echo $general_settings['_phone']; ?>
        </div>
        <div class="col-md-6 col-sm-12">
            <h3 class="info-header bg-header"><?php esc_html_e('Customer', 'wpcodigo_wms'); ?></h3>
            <div id="cwms-customer-details">
                <?php if( (int)$return_invoice['_customer_id'] ): ?>
                    <strong><?php echo $return_invoice['_customer_company']; ?></strong><br/>
                    <span class="contact-name"><?php echo $return_invoice['_customer']; ?></span><br/>
                    <?php echo cwms1661_display_address_html( $return_invoice['_customer_details'] ); ?><br/>
                    <?php echo $return_invoice['_customer_details']['_phone']; ?><br/>
                    <?php echo $return_invoice['_customer_details']['_email']; ?>
                <?php endif; ?>
            </div>
        </div>
    </section>
    <section id="product-info" class="table-responsive cwms_invoice_items">
        <table id="cwms-poitems-table" class="table table-sm table-hover">
            <thead>
                <tr>
                    <th><?php esc_html_e('SKU', 'wpcodigo_wms'); ?></th>
                    <th><?php esc_html_e('Name', 'wpcodigo_wms'); ?></th>
                    <th class="cwms-input-header"><?php esc_html_e('Delivered Qty', 'wpcodigo_wms'); ?></th>
                    <th class="cwms-input-header"><?php esc_html_e('Returned Qty', 'wpcodigo_wms'); ?></th>
                    <th class="cwms-input-header"><?php esc_html_e('Unit', 'wpcodigo_wms'); ?></th>
                    <th class="cwms-input-header"><?php esc_html_e('Remarks', 'wpcodigo_wms'); ?></th>
                </tr>
            </thead>
            <tbody >
                <?php foreach ($return_invoice['_products'] as $product): ?>
                    <tr >
                        <td class="col-upc"><?php echo $product['upc']; ?></td>
                        <td class="col-name"><?php echo $product['name']; ?></td>
                        <td class="col-name"><?php echo $product['qty_delivered']; ?></td>
                        <td class="col-qty"><?php echo $product['qty_returned']; ?></td>
                        <td class="col-qty"><?php echo $product['unit']; ?></td>
                        <td class="col-unit_price"><?php echo $product['remarks']; ?></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </section>
    <div class="ln_solid"></div>
    <section id="action-section">
        <div class="col-md-6 form-group">
            <strong><?php esc_html_e('Date'); ?>: </strong> <?php echo $return_invoice['_date_created']; ?><br/>
            <strong><?php esc_html_e('Prepared by'); ?>:</strong> <?php echo $return_invoice['_created_by']; ?> 
        </div>
        <div class="col-md-6 text-right">
         <?php esc_html_e('Assign Agent', 'wpcodigo_wms'); ?> : <strong><?php echo $return_invoice['_assigned_agent_name']; ?> </strong>
        </div>
    </section>
    <?php do_action('cwms1661_after_view_invoice_template', $return_invoice ); ?>
</div>