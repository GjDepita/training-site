<?php
$return_invoice             = cwms1661_get_return_data( (int)$print_id );
$general_settings           = cwms1661_get_general_settings();
$return_invoice_number      = $return_invoice['title'];
$current_date               = $return_invoice['_date_created'];
?>
<div class="col-md-offset-1 col-md-10 col-sm-12">
    <table style="margin-bottom:48px;">
        <!-- header -->
        <tr>
            <td style="width:50%;">
                <?php if($general_settings['_company_logo']):  ?>
                    <img src="<?php echo $general_settings['_company_logo']; ?>" alt="<?php echo $general_settings['_company_name']; ?>" width="210">
                <?php endif; ?>
            </td>
            <td style="width:50%; text-align:right;">
                <h1><?php esc_html_e('INVOICE ORDER', 'wpcodigo_wms'); ?></h1>
                <?php esc_html_e('DATE', 'wpcodigo_wms'); ?>: <?php echo $current_date; ?><br/>
                <span class="cwms-pullout_number"><?php esc_html_e('Pullout Number', 'wpcodigo_wms'); ?>#: <?php echo $return_invoice['_pullout_no']; ?></span></br> 
                <span class="cwms-return_invoice_number"><?php esc_html_e('Return', 'wpcodigo_wms'); ?>#: <?php echo $return_invoice_number; ?></span></br>      
                <span class="cwms-invoice_number"><?php esc_html_e('Invoice', 'wpcodigo_wms'); ?>#: <?php echo $return_invoice['_invoice_number']; ?></span></br>
                <span class="cwms-invoice_dr_no"><?php esc_html_e('DR', 'wpcodigo_wms'); ?>#: <?php echo $return_invoice['_dr_no']; ?></span></br>
            </td>
        </tr>
        <tr><td colspan="2" style="padding: 18px;">&nbsp;</td></tr>
        <!-- Vendors Information -->
        <tr>
            <td style="width:50%;">
                <h3 class="info-header bg-header"><?php esc_html_e('From', ''); ?></h3>
                <span class="contact-name"><?php echo $general_settings['_company_name']; ?></span></br>
                <span class="company-address"><?php echo nl2br( $general_settings['_address'] ); ?></span><br/>
                <?php echo $general_settings['_phone']; ?>
            </td>
            <td style="width:50%;">
                <h3 class="info-header bg-header"><?php esc_html_e('Customer', 'wpcodigo_wms'); ?></h3>
                <div id="cwms-customer-details">
                    <?php if( (int)$return_invoice['_customer_id'] ): ?>
                        <strong><?php echo $return_invoice['_customer_company']; ?></strong><br/>
                        <span class="contact-name"><?php echo $return_invoice['_customer']; ?></span><br/>
                        <?php echo cwms1661_display_address_html( $return_invoice['_customer_details'] ); ?><br/>
                        <?php echo $return_invoice['_customer_details']['_phone']; ?><br/>
                        <?php echo $return_invoice['_customer_details']['_email']; ?>
                    <?php endif; ?>
                </div>
            </td>
        </tr>
    </table>
    
    <section id="product-info" class="table-responsive cwms_invoice_items" style="margin-bottom:48px;">
        <table id="cwms-poitems-table" class="bordered min-space header-black font-small">
            <thead>
                <tr>
                    <th><?php esc_html_e('SKU', 'wpcodigo_wms'); ?></th>
                    <th><?php esc_html_e('Name', 'wpcodigo_wms'); ?></th>
                    <th class="cwms-input-header"><?php esc_html_e('Delivered Qty', 'wpcodigo_wms'); ?></th>
                    <th class="cwms-input-header"><?php esc_html_e('Returned Qty', 'wpcodigo_wms'); ?></th>
                    <th class="cwms-input-header"><?php esc_html_e('Unit', 'wpcodigo_wms'); ?></th>
                    <th class="cwms-input-header"><?php esc_html_e('Total', 'wpcodigo_wms'); ?></th>
                </tr>
            </thead>
            <tbody >
                <?php foreach ($return_invoice['_products'] as $product): ?>
                    <tr >
                        <td class="col-upc"><?php echo $product['upc']; ?></td>
                        <td class="col-name"><?php echo $product['name']; ?></td>
                        <td class="col-name"><?php echo $product['qty_delivered']; ?></td>
                        <td class="col-qty"><?php echo $product['qty_returned']; ?></td>
                        <td class="col-qty"><?php echo $product['unit']; ?></td>
                        <td class="col-unit_price"><?php echo $product['remarks']; ?></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </section>
    </div>
    <div class="ln_solid"></div>
    <section id="action-section">
        <div class="col-md-6 form-group">
            <strong><?php esc_html_e('Date'); ?>: </strong> <?php echo $return_invoice['_date_created']; ?><br/>
            <strong><?php esc_html_e('Prepared by'); ?>:</strong> <?php echo $return_invoice['_created_by']; ?> 
        </div>
    </section>
</div>