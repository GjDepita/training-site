<?php  
    $general_settings   = cwms1661_get_general_settings(); 
    $return_number     = cwms1661_generate_return_invoice_number();
    $current_date       = date( cwms1661_datetime_format(), current_time( 'timestamp', 0 ) );
?>
<section id="cwms-search_return_action_wrapper" class="col-md-12">
    <select id="cwms-search_invoice_return" class="cwms-select2-search form-control form-control-sm" data-action="cwms_search_return_invoice" style="width: 280px;" aria-placeholder="<?php esc_html_e('Search Invoice Number', 'wpcodigo_wms'); ?>">
        <option value=""><?php esc_html_e('Search Invoice number', 'wpcodigo_wms'); ?></option>
    </select>
</section>
<section id="cwms-notification_action_wrapper" class="col-md-12" style="margin-top:36px;">
    <?php do_action( 'cwms1661_before_return_form' ); ?>
</section>
<section id="cwms-search_return_placeholder_wrapper" class="col-md-12" style="margin-top: 36px; position: relative; min-height: 180px;">
    <div class="return-details_placeholder">
        <span style="margin: 12px 0; font-style: italic; font-size: 1.2em;"><?php esc_html_e('Search Invoice number to create return.', 'wpcodigo_wms'); ?></span><br/>
        <span class="text-danger" style="margin: 12px 0; font-style: italic;"><?php esc_html_e('Note: Only invoice order with Completed status are allowed to generate return.', 'wpcodigo_wms'); ?></span>
    </div>
</section>
<div id="cwms-return_form_wrapper" class="col-md-offset-1 col-md-10 col-sm-12 d-none">
    <form id="cwms-return_invoice_form" class="form-horizontal form-label-left input_mask" action="" method="POST">
        <?php wp_nonce_field( 'cwms-create-return_invoice_form_action', 'cwms-create-return_invoice_form_nonce' ); ?>
        <input type="submit" style="display:none !important;" value="<?php esc_html_e('Create Return Invoice', 'wpcodigo_wms'); ?>">
        <!-- Header -->
        <section id="po-header-section" class="row" style="margin-bottom:18px;">
            <div class="col-md-6 col-sm-12">
                <?php if($general_settings['_company_logo']):  ?>
                    <img src="<?php echo $general_settings['_company_logo']; ?>" alt="<?php echo $general_settings['_company_name']; ?>" width="210">
                <?php endif; ?>
            </div>
            <div class="col-md-6 col-sm-12 text-right">
                <h1><?php esc_html_e('INVOICE ORDER', 'wpcodigo_wms'); ?></h1>
                <span class="cwms-invoice_date"><?php esc_html_e('DATE', 'wpcodigo_wms'); ?>: <input type="text" name="_invoice_date"  class="cwms-datetime-12hrs" value="<?php echo $current_date; ?>" style="border: 1px solid #dcdcdc;padding-right: 6px;text-align: right;margin-bottom: 4px;" required /></span><br/>
                <span class="cwms-pullout_no"><?php esc_html_e('Pullout Number', 'wpcodigo_wms'); ?>: <input type="text" name="_pullout_no"  value="" style="border: 1px solid #dcdcdc;padding-right: 6px;text-align: right;margin-bottom: 4px;" required /></span><br/>
                <span class="cwms-return_no"><?php esc_html_e('Return #', 'wpcodigo_wms'); ?>: <?php echo esc_html( $return_number ); ?></br>
                <span class="cwms-invoice_dr_no"><?php esc_html_e('DR #', 'wpcodigo_wms'); ?>: <span class="_invoice_dr_no"></span></span></br>
                <span class="cwms-invoice_number"><?php esc_html_e('Invoice', 'wpcodigo_wms'); ?>#: <span class="_invoice_number"></span></span>
                <input type="hidden" name="_invoice_return_no" value="<?php echo esc_attr($return_number); ?>" />
                <input type="hidden" name="_invoice_id" value="<?php echo esc_attr($return_number); ?>" />
            </div>
        </section>
        <!-- Vendors Information -->
        <section id="customer-info-section" class="row" style="margin-bottom:18px;">
            <div class="col-md-6 col-sm-12">
                <h3 class="info-header bg-header"><?php esc_html_e('From', ''); ?></h3>
                <span class="contact-name"><?php echo $general_settings['_company_name']; ?></span></br>
                <span class="company-address"><?php echo nl2br( $general_settings['_address'] ); ?></span><br/>
                <?php echo $general_settings['_phone']; ?>
            </div>
            <div class="col-md-6 col-sm-12">
                <h3 class="info-header bg-header"><?php esc_html_e('Customer', 'wpcodigo_wms'); ?></h3>
                <div id="cwms-customer-details">
                    <!-- Dynamic data here -->
                </div>
            </div>
        </section>
        <section id="product-info" class="table-responsive cwms_return_invoice_items">
            <table id="cwms-invoicing-returnitems-table" class="table table-sm table-hover">
                <thead>
                    <tr>
                        <th><?php esc_html_e('SKU', 'wpcodigo_wms'); ?></th>
                        <th><?php esc_html_e('Name', 'wpcodigo_wms'); ?></th>
                        <th class="cwms-input-header"><?php esc_html_e('Delivered Qty', 'wpcodigo_wms'); ?></th>
                        <th class="cwms-input-header"><?php esc_html_e('Returned Qty', 'wpcodigo_wms'); ?></th>
                        <th class="cwms-input-header"><?php esc_html_e('Unit', 'wpcodigo_wms'); ?></th>
                        <th class="cwms-input-header"><?php esc_html_e('Remarks', 'wpcodigo_wms'); ?></th>
                    </tr>
                </thead>
                <tbody data-repeater-list="cwms_invoice_products">
                </tbody>
            </table>
        </section>
        <div class="ln_solid"></div>
        <section id="action-section">
            <div class="col-md-6 form-group">
                <?php esc_html_e('Assign Agent', 'wpcodigo_wms'); ?> : <strong><span class="_assigned_agent_name"></span></strong>
            </div>
            <div class="col-md-6 text-right">
                <input id="cmws-submit-form_invoice" type="submit" class="btn btn-md btn-success" value="<?php echo __('Create Return Invoice', 'wpcodigo_wms'); ?>">
            </div>
        </section>
    </form>
</div>