<?php
/**
 * Post Types
 *
 * Registers post types and taxonomies.
 */

defined( 'ABSPATH' ) || exit;

/**
 * Post types Class.
 */
class CWMS1661_PO_Post_Type {

    public static function register_post_type(){
        if ( post_type_exists( CWMS1661_PO_POST_TYPE ) ) {
			return;
		}
        $supports   = apply_filters( 'cwms1661_post_type_support', array( ) );
        $debug      = apply_filters( 'cwms1661_post_type_debug', false );
        // Register Custom Post Type
        $po_labels = array(
            'name'                  => _x( 'POs', 'Post Type General Name', 'wpcodigo_wms' ),
            'singular_name'         => _x( 'PO', 'Post Type Singular Name', 'wpcodigo_wms' ),
            'menu_name'             => __( 'POs', 'wpcodigo_wms' ),
            'name_admin_bar'        => __( 'PO', 'wpcodigo_wms' ),
            'archives'              => __( 'PO Archives', 'wpcodigo_wms' ),
            'attributes'            => __( 'PO Attributes', 'wpcodigo_wms' ),
            'parent_item_colon'     => __( 'Parent PO:', 'wpcodigo_wms' ),
            'all_items'             => __( 'All POs', 'wpcodigo_wms' ),
            'add_new_item'          => __( 'Add New PO', 'wpcodigo_wms' ),
            'add_new'               => __( 'Add New', 'wpcodigo_wms' ),
            'new_item'              => __( 'New PO', 'wpcodigo_wms' ),
            'edit_item'             => __( 'Edit PO', 'wpcodigo_wms' ),
            'update_item'           => __( 'Update PO', 'wpcodigo_wms' ),
            'view_item'             => __( 'View PO', 'wpcodigo_wms' ),
            'view_items'            => __( 'View PO', 'wpcodigo_wms' ),
            'search_items'          => __( 'Search PO', 'wpcodigo_wms' ),
            'not_found'             => __( 'Not found', 'wpcodigo_wms' ),
            'not_found_in_trash'    => __( 'Not found in Trash', 'wpcodigo_wms' ),
            'featured_image'        => __( 'Featured Image', 'wpcodigo_wms' ),
            'set_featured_image'    => __( 'Set featured image', 'wpcodigo_wms' ),
            'remove_featured_image' => __( 'Remove featured image', 'wpcodigo_wms' ),
            'use_featured_image'    => __( 'Use as featured image', 'wpcodigo_wms' ),
            'insert_into_item'      => __( 'Insert into PO', 'wpcodigo_wms' ),
            'uploaded_to_this_item' => __( 'Uploaded to this PO', 'wpcodigo_wms' ),
            'items_list'            => __( 'POs list', 'wpcodigo_wms' ),
            'items_list_navigation' => __( 'POs list navigation', 'wpcodigo_wms' ),
            'filter_items_list'     => __( 'Filter POs list', 'wpcodigo_wms' ),
        );
        $po_args = array(
            'label'                 => __( 'PO', 'wpcodigo_wms' ),
            'description'           => __( 'Purchase Order', 'wpcodigo_wms' ),
            'labels'                => $po_labels,
            'supports'              => $supports,
            'taxonomies'            => array(),
            'hierarchical'          => false,
            'public'                => false,
            'show_ui'               => $debug,
            'show_in_menu'          => $debug,
            'menu_position'         => 5,
            'show_in_admin_bar'     => $debug,
            'show_in_nav_menus'     => $debug,
            'rewrite'               => false,
            'can_export'            => true,
            'has_archive'           => false,
            'exclude_from_search'   => true,
            'publicly_queryable'    => false,
            'capability_type'       => 'post',
        );
        register_post_type( CWMS1661_PO_POST_TYPE, apply_filters( 'cwms_register_po_post_type', $po_args ) );
    }
}