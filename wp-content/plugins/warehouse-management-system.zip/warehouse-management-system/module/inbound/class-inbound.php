<?php
defined( 'ABSPATH' ) || exit;
/**
 * Product
 */
class CWMS1661_Inbound {

    public static function init(){
        // Saving PO data
        add_action('wp', array(__CLASS__, 'save_create_po' ));
        add_action('wp', array(__CLASS__, 'save_receiving_po' ));
        add_action( 'save_post_'.CWMS1661_PO_POST_TYPE, array( __CLASS__, 'save_po_post_meta'), 10, 3 );
        // add_action( 'save_post_'.CWMS1661_PO_POST_TYPE, array( __CLASS__, 'after_complete_po'), 99, 1 );
        add_action('template_redirect', array( __CLASS__, 'save_redirection') );
        // Ajax handlers
        add_action( 'wp_ajax_cwms_get_all_po', array(__CLASS__,  'get_all_po' ) );
        add_action( 'wp_ajax_cwms_delete_po', array(__CLASS__,  'po_delete' ) );
        add_action( 'wp_ajax_cwms_po_bulk_action', array(__CLASS__,  'po_bulk_action' ) );
        add_action( 'wp_ajax_cwms_search_receive_po', array(__CLASS__,  'search_receive_po' ) );
        add_action( 'wp_ajax_cwms_remove_po_product', array(__CLASS__,  'remove_product' ) );
        
        // Menu hooks
        add_filter( 'cwms1661_dashboard_menus', array(__CLASS__, 'menu' ) );
        add_filter( 'cwms1661_dashboard_shortcuts_menu', array(__CLASS__, 'shortcuts' ) );
        add_filter( 'cwms1661_registered_dashboard_pages', array(__CLASS__, 'page' ));
         // After page title hook
        //  add_action('cwms1661_after_page_title_view-po', array(__CLASS__, 'all_list_link'));
         add_action('cwms1661_after_page_title_update-po', array(__CLASS__, 'add_new_link'));
         add_action('cwms1661_after_page_title_all-po', array(__CLASS__, 'add_new_link'));
        // Script translation
        add_filter( 'cwms1661_ajax_localize_script_translations', array(__CLASS__,  'script_translations' ) );
        // Template
        add_filter( 'cwms1661_content_template_create-po', array(__CLASS__, 'add_po_template' ) );
        add_filter( 'cwms1661_content_template_all-po', array(__CLASS__, 'all_po_template' ) );
        add_filter( 'cwms1661_content_template_view-po', array(__CLASS__, 'view_po_template' ) );
        add_filter( 'cwms1661_content_template_update-po', array(__CLASS__, 'update_po_template' ) );
        add_filter( 'cwms1661_content_template_receive-po', array(__CLASS__, 'receive_po_template' ) );
        add_action( 'cwms1661_before_po_form', array(__CLASS__, 'notification_message' ) );
        add_action( 'cwms1661_before_receive_po_form', array(__CLASS__, 'notification_message' ) );
        add_action( 'cwms_before_page-all-po', array(__CLASS__, 'page_navigation' ) );

        // Permissions
        add_filter( 'cwms1661_permissions', array(__CLASS__, 'permissions' ) );
        // Print
        add_filter( 'cwms1661_print_html_body_inbound-po', array(__CLASS__, 'print' ), 10, 2 );
    }
    public static function all_list_link(){
        printf( '<a href="%s" class="btn btn-sm btn-primary">' . __( 'All suppliers', 'wpcodigo_wms' ) . '</a>', cwms1661_dashboard_home().'?cwmspage=all-suppliers' );
    }
    public static function menu( $menus ){
        if( !cwms1661_can_access_po() ){
            return $menus;
        }
        $menus[10] = array(
            'id'   => 'inbound',
            'label' => esc_html__('Purchase Orders', 'wpcodigo_wms'),
            'classes' => 'fa fa-cart-arrow-down',
            'subs'  => array(
                'all-po' => esc_html__('All PO', 'wpcodigo_wms'),
                'create-po' => esc_html__('Create PO', 'wpcodigo_wms'),
                'receive-po' => esc_html__('Receive PO', 'wpcodigo_wms')
            )
        );
        return $menus;
    }
    public static function shortcuts( $shortcuts ){
        if( !cwms1661_can_access_po() ){
            return $shortcuts;
        }
        $shortcuts[20] = array(
            'page-slug' => 'create-po',
            'label'     => esc_html__('Add new PO', 'wpcodigo_wms'),
            'icon'     => 'fa fa-cart-arrow-down'
        );
        return $shortcuts;
    }
    public static function add_new_link(){
        printf( '<a href="%s" class="btn btn-sm btn-primary">' . __( 'Add new PO', 'wpcodigo_wms' ) . '</a>', cwms1661_dashboard_home().'?cwmspage=create-po' );
    }
    public static function page( $pages ){
        $pages['view-po']       = esc_html__('PO details', 'wpcodigo_wms');
        $pages['update-po']     = esc_html__('Update PO', 'wpcodigo_wms');
        return $pages;
    }
    public static function add_po_template(){
        if( ! cwms1661_can_add_po() ){
            return cwms1661_get_template_path('403', 'dashboard');
        }
        return apply_filters( "cwms1661_get_template_create-po", CWMS1661_ABSPATH.'module/inbound/templates/create-po.php' );
    }
    public static function all_po_template(){
        if( ! cwms1661_can_view_po() ){
            return cwms1661_get_template_path('403', 'dashboard');
        }
        return apply_filters( "cwms1661_get_template_all-po", CWMS1661_ABSPATH.'module/inbound/templates/all-po.php' );
    }
    public static function view_po_template(){
        if( ! cwms1661_can_view_po() || !isset($_GET['id']) || !is_cwms1661_po($_GET['id']) ){
            return cwms1661_get_template_path('403', 'dashboard');
        }
        return apply_filters( "cwms1661_get_template_view-po", CWMS1661_ABSPATH.'module/inbound/templates/view-po.php' );
    }
    public static function update_po_template(){
        if( ! cwms1661_can_update_po() 
            || ! isset($_GET['id']) 
            || ! is_cwms1661_po($_GET['id']) 
            || ! in_array( get_post_status( $_GET['id'] ), cwms1661_edited_statuses() ) ){
            return cwms1661_get_template_path('403', 'dashboard');
        }
        return apply_filters( "cwms1661_get_template_update-po", CWMS1661_ABSPATH.'module/inbound/templates/update-po.php' );
    }
    public static function receive_po_template(){
        if( ! cwms1661_can_receive_po() ){
            return cwms1661_get_template_path('403', 'dashboard');
        }
        return apply_filters( "cwms1661_get_template_update-po", CWMS1661_ABSPATH.'module/inbound/templates/receive-po.php' );
    }
    public static function page_navigation(){
        include_once apply_filters( "cwms1661_get_template_all-po-navigation", CWMS1661_ABSPATH.'module/inbound/templates/navigation.php' );
    }
    public static function script_translations( $translations ){
        $empty_repeater = isset( $_GET['cwmspage'] ) && urldecode( $_GET['cwmspage'] ) == 'create-po' ? true : false;
        $translations['poTableData'] = array(
            'id'        => 'cwms_poTable',
            'delete'    => cwms1661_can_delete_product(),
            'headers'   => array_keys( cwms1661_po_table_headers() ),
            'status'    => cwms1661_current_status_filter(),
            'emptyRepeater' => $empty_repeater 
        );
        return $translations;
    }
    public static function save_create_po(){
        if ( ! isset( $_POST['cwms-po_form_nonce'] ) 
            || ! wp_verify_nonce( $_POST['cwms-po_form_nonce'], 'cwms-po_form_action' ) 
        ) {
            return false;
        } 
        $po_args    = array(
            'post_title'    => wp_strip_all_tags( $_POST['_po_number'] ),
            'post_status'   => 'cwms-for-approval',
            'post_type'     => CWMS1661_PO_POST_TYPE
        );
        if( isset($_POST['_receipt_date']) && !empty($_POST['_receipt_date']) ){
            $po_args['post_date'] = sanitize_text_field( $_POST['_receipt_date'] );
        }
        $po_id   = isset($_POST['cwms_po_id']) ? (int)$_POST['cwms_po_id'] : false;

        if( !$po_id ){
            if( ! cwms1661_can_add_po() ){
                printf( '<div id="message" class="error"><p>%s</p></div>', __('Permission denied. Please contact admin support', 'wpcodigo_wms') );
                wp_die();
            }
            // Insert the post into the database
            $po_id = wp_insert_post( $po_args );
        }else{
            if( ! cwms1661_can_update_po() || !is_cwms1661_post( $po_id, CWMS1661_PO_POST_TYPE ) ){
                printf( '<div id="message" class="error"><p>%s</p></div>', __('Permission denied. Please contact admin support', 'wpcodigo_wms') );
                wp_die();
            }
            // Update po data
            $po_args['ID']  = $po_id;
            unset($po_args['post_title']);
            if( !isset($_POST['_po_status']) ){
                unset($po_args['post_status']);
            }
            $po_id          = wp_update_post( $po_args );
        }
        // Check if process error
        if ( is_wp_error( $po_id ) ) {
            $error_string = $po_id->get_error_message();
            echo '<div id="message" class="error"><p>' . $error_string . '</p></div>';
            wp_die();
        }
        $_POST['cwms_po_redirection'] = array(
            'url'       => cwms1661_dashboard_home(),
            'subpage'   => 'update-po',
            'id'        => $po_id,
            'message'   => sprintf( __('PO %s successfully created!'), get_the_title($po_id) )
        );
    }
    public static function save_receiving_po(){
        if ( ! isset( $_POST['cwms-po_receiving_form_nonce'] ) 
            || ! wp_verify_nonce( $_POST['cwms-po_receiving_form_nonce'], 'cwms-po_receiving_form_action' ) 
        ) {
            return false;
        } 

        $post_id        = isset( $_POST['cwms_po_id'] ) ? (int)$_POST['cwms_po_id'] : null;
        $can_receive    = is_cwms1661_po( $post_id, cwms_receiving_po_statuses() );

        if( !$post_id || !$can_receive || !cwms1661_can_receive_po() ){
            printf( '<div id="message" class="error"><p>%s</p></div>', __('Permission denied. Please contact admin support', 'wpcodigo_wms') );
            wp_die();
        }
        // Update PO status
        $args       = array( 'ID' => $post_id, 'post_status'   => 'cwms-completed' );
        if( isset($_POST['_receipt_date']) && !empty($_POST['_receipt_date']) ){
            $args['post_date'] = sanitize_text_field( $_POST['_receipt_date'] );
        }
        $post_id    = wp_update_post( $args );

        if( is_wp_error( $post_id ) ){
            printf( '<div id="message" class="error"><p>%s</p></div>', __('Permission denied.', 'wpcodigo_wms'). ' ' .$post_id->get_error_message() );
            wp_die();
        }

        update_post_meta( $post_id, '_date_received', current_time( 'mysql' ) );
        update_post_meta( $post_id, '_received_by', cwms1661_user_fullname( get_current_user_id() ) );

        $_POST['cwms_po_redirection'] = array(
            'url'       => cwms1661_dashboard_home(),
            'subpage'   => 'receive-po',
            'id'        => $post_id,
            'message'   => sprintf( __('PO %s successfully received!'), get_the_title($post_id) )
        );

    }
    public static function save_po_post_meta( $post_id, $post, $update ){

        if( isset($_POST['_supplier_id']) && (int)$_POST['_supplier_id'] ){
            $supplier_data      = cwms1661_get_data( (int)$_POST['_supplier_id'], array_keys( cwms1661_supplier_fields() ), '_company_name' );
            update_post_meta( $post_id, '_supplier_id', (int)$_POST['_supplier_id'] );
            update_post_meta( $post_id, '_supplier_details', $supplier_data );
        }
        if( isset($_POST['cwms_po_products']) && is_array( $_POST['cwms_po_products'] ) ){

            $created_by     = cwms1661_user_fullname( get_current_user_id() );
            $vendor_info    = get_post_meta( $post_id, '_supplier_details', true );
            $vendor_id      = !empty( $vendor_info ) ? $vendor_info['ID'] : '' ;
            $vendor_name    = !empty( $vendor_info ) ? $vendor_info['_company_name'] : '' ;

            // Formatting products
            $products   = $_POST['cwms_po_products'];
            array_walk($products, function( &$product, $key ){
                if( ! array_key_exists( 'qty_delivered', $product ) ){
                    $product['qty_delivered']   = $product['qty_ordered'];
                }
                $product['discount_amount'] = 0;    
            });

            foreach( $products as $product ){ 
                if( get_post_status ($post_id) == 'cwms-completed' ){

                    $remarks    = sprintf( esc_html__( 'Add product qty from purchase order # %s', 'wpcodigo_wms' ), $post->post_title );
                    cwms1661_update_product_qty( $product['product_id'], $product['qty_delivered'], $post_id, $post->post_title, $remarks );

                    // Add price history product cost price is updated
                    $product_data           = get_cwms1661_product_data( $product['product_id'] );

                    if( floatval($product_data['_cost_price']) !== floatval($product['cost_price']) ){
                        $product['vendor_id']   = $vendor_id;
                        $product['vendor_name'] = $vendor_name;
                        $product['created_by']  = $created_by;
                        $product['po_id']       = $post_id;
                        cwms1661_add_product_price_history( $product );
                        update_post_meta( $product['product_id'], '_cost_price', floatval($product['cost_price']) );
                    }
                    update_post_meta( $product['product_id'], '_cost_discount', sanitize_text_field( $product['discount'] ) );
                }
                cwms1661_assign_product( $post_id, $product, 'cwms_po' );
            }
        }
        if( isset($_POST['_dr_number']) ){
            update_post_meta( $post_id, '_dr_number', sanitize_textarea_field( $_POST['_dr_number'] ) );
        }
        if( isset($_POST['remarks']) ){
            update_post_meta( $post_id, '_remarks', sanitize_textarea_field( $_POST['remarks'] ) );
        }
        if( isset($_POST['cod_discount']) ){
            update_post_meta( $post_id, '_cod_discount', floatval($_POST['cod_discount']) );
        }
        if( isset($_POST['tax']) ){
            update_post_meta( $post_id, '_tax', floatval($_POST['tax']) );
        }
        if( isset($_POST['others']) ){
            update_post_meta( $post_id, '_others', floatval($_POST['others']) );
        }
        if( !$update ){
            update_post_meta( $post_id, '_created_by', get_current_user_id() );
        }
        // Payment Status 
        if( isset($_POST['_payment_status']) ){
            update_post_meta( $post_id, '_payment_status', sanitize_text_field( $_POST['_payment_status'] ) );
        }else{
            update_post_meta( $post_id, '_payment_status', '_unpaid' );
        }

    }
    // After PO is completed
    public static function after_complete_po( $post_id ){
        if( 'cwms-completed' != get_post_status( $post_id ) ){
            return false;
        }
        $po_number  = get_the_title( $post_id );
        // Adding product to Invoice
        $po_data    = cwms1661_get_po_data( $post_id );
        $products   = $po_data['_products'];
        if( !is_array($products) || empty( $products  ) ){
            return false;
        }
        $remarks    = sprintf( esc_html__( 'Add product form purchase order # %s', 'wpcodigo_wms' ), $po_number );
        foreach ( $products  as $product ) {
            $product_id     = $product['id'];
            $qty            = $product['qty_ordered'];
            cwms1661_update_product_qty( $product_id, $qty, $post_id, $po_number, $remarks );
        }
    }
    // Save supplier redirection
    public static function save_redirection(){
        if( !isset($_POST['cwms_po_redirection']) || !is_array($_POST['cwms_po_redirection']) ){
            return false;
        }
        wp_redirect( $_POST['cwms_po_redirection']['url'] .'?cwmspage='. $_POST['cwms_po_redirection']['subpage'] .'&id='. $_POST['cwms_po_redirection']['id'] .'&cwms-message='. urlencode($_POST['cwms_po_redirection']['message']) );
        exit;
    }
    public static function notification_message(){
        if( !isset($_GET['cwmspage']) ){
            return false;
        }
        if( !isset($_GET['cwms-message']) || empty($_GET['cwms-message']) ){
            return false;
        }
        printf('<div class="submit-notification_message alert alert-success">%s</div>', urldecode($_GET['cwms-message']));
        ?>        
        <script>
            window.history.replaceState({}, document.title, '<?php echo cwms1661_dashboard_home().'?'.cwms1661_clean_url_parameter(['cwms-message']); ?>' );
            setTimeout(function(){
                jQuery('body').find('.submit-notification_message').remove();
            }, 6000 );
        </script>
        
        <?php
    }
    // AJAX
    public static function get_all_po(){
        $post_status    = $_GET['status'];
        $data           = cwms1661_get_all_po_data( array(  $post_status ) );
        if( $data ){
            $data = array_map( function( $value ) use($post_status) {
                $value['update_link']   = cwms1661_dashboard_home().'?cwmspage=update-po&id='.$value['ID'];
                $value['view_link']     = cwms1661_dashboard_home().'?cwmspage=view-po&id='.$value['ID'];
                $label_url              = esc_url_raw( cwms1661_dashboard_home().'?cwmspage=update-po&id='.$value['ID'] );
                $actions = [
                    'edit' => sprintf(
                        '<span class="edit"><a class="cwms-update_po text-primary" href="%s">%s</a> ',
                        esc_url_raw( cwms1661_dashboard_home().'?cwmspage=update-po&id='.$value['ID'] ),
                        esc_html__('Edit','wpcodigo_wms')
                    ),
                    'delete' => sprintf(
                        '<span class="trash"><a class="cwms-delete_po text-danger" href="#">%s</a></span>',
                        esc_html__('Delete','wpcodigo_wms')
                    ),
                    'view'  => sprintf(
                        '<span class="view"><a class="text-primary" href="%s">%s</a></span>',
                        esc_url_raw( cwms1661_dashboard_home().'?cwmspage=view-po&id='.$value['ID'] ),
                        esc_html__('View','wpcodigo_wms')
                    )
                ];
                if( !cwms1661_can_delete_po( ) || $post_status != 'cwms-for-approval' ):
                    unset($actions['delete']);
                endif;
                if( !cwms1661_can_update_po() || ! in_array( $post_status, cwms1661_edited_statuses() )  ):
                    unset($actions['edit']);
                    $label_url = esc_url_raw( cwms1661_dashboard_home().'?cwmspage=view-po&id='.$value['ID'] );
                endif;
                ob_start();
                ?>
                <strong data-id="<?php echo $value['ID']; ?>">
                    <a href="<?php echo $label_url; ?>"><?php echo $value['_po_number']; ?></a>
                </strong> 
                <div class="row-actions" data-id="<?php echo $value['ID']; ?>">
                    <?php echo implode( ' | ', array_values( $actions ) ) ?>
                </div>
                <?php
                $value['_po_number'] = ob_get_clean();
                return $value;
            }, $data );
        }
        wp_send_json( array( 'data' => $data ) );
    }
    public static function po_delete(){
        $pos_id    = (int)$_POST['poID'];
        if( get_post_status( $pos_id ) != 'cwms-for-approval' 
            || get_post_type( $pos_id ) != CWMS1661_PO_POST_TYPE 
            || !cwms1661_can_delete_po() ){
            wp_send_json( array(
                'status'    => 'error',
                'code'      => 401,
                'message'   => __('Request error, permission denied!', 'wpcodigo_wms')
            ) );
        }
        wp_trash_post( $pos_id );
        wp_send_json( array( 
            'status'    => 'success',
            'code'      => 200,
            'message'   => __('Request completed', 'wpcodigo_wms')
        ));
        wp_die();
    }
    public static function po_bulk_action(){
        $po_ids         = $_POST['poIds'];
        $action         = $_POST['actionType'];
        $table_data     = $_POST['poTableData'];
        $statuses       = array_keys( cwms1661_po_bulk_actions() );  

        if( $table_data['status'] == 'cwms-for-approval' ){
            $statuses[] = 'cwms-delete';
        }
        if( !in_array( $action, $statuses ) 
            || ( $action == 'cwms-delete' && !cwms1661_can_delete_po() ) ){
            wp_send_json( array(
                'status' => 'error',
                'message' => __('Request error, permission denied!', 'wpcodigo_wms')
            ) );
        }

          // Checked if there is complete status in the ID list
        $has_complete = array_filter( array_map( function( $id ){
            return get_post_status( $id ) == 'cwms-completed' ;
        },  $po_ids) );

        if( !empty( $has_complete ) ){
            wp_send_json( array(
                'status' => 'error',
                'message' => __('One request has a complete status, permission denied. please reloaded the page and try again.', 'wpcodigo_wms')
            ) );
        }

        // Delete PO
        foreach ( $po_ids as $id ) {
            if( get_post_type( (int)$id ) != CWMS1661_PO_POST_TYPE ){
                wp_send_json( array(
                    'status' => 'error',
                    'message' => __('One request is cancelled, permission denied. please reloaded the page and try again.', 'wpcodigo_wms')
                ) );
                break;
            }
            // Delete POs
            if( 'cwms-delete' ==  $action ){
                wp_trash_post( $id );
                continue;
            }
            // Update Po Status
            $update_post = wp_update_post( array( 'ID' => (int)$id, 'post_status' => $action ) );

            if( is_wp_error( $update_post ) ){
                wp_send_json( array(
                    'status' => 'error',
                    'message' => $update_post->get_error_message()
                ) );
                break;
            }
        } 

        wp_send_json( array( 
            'status' => 'success',
            'message' => __('Request completed', 'wpcodigo_wms')
        ));
        wp_die();
    }
    public static function search_receive_po(){
        $statuses   = cwms_receiving_po_statuses();
        $options    = cwms1661_search_po( $_GET['q'], $statuses );
        $data       = [];
        if( !empty( $options ) ){
            foreach ($options as $po_id ) {
                $data[] = cwms1661_get_po_data( $po_id );
            }
        }
        wp_send_json( $data );
        wp_die();
    }
    public static function remove_product(){
        $po_id      = (int)$_POST['poID'];
        $product_id = (int)$_POST['productID'];
        $results    = cwms1661_remove_assign_product( $po_id, $product_id );
        $message    = $results ? __('Assinged product successfull remove.', 'wpcodigo_wms') : __('Something went wrong cannot remove product. please reload and try again', 'wpcodigo_wms') ;
        wp_send_json( array( 
            'result' => $results,
            'message' => $message
        ) );
    }
    public static function permissions( $permissions ){
        $permissions[20] = array(
            'label' => esc_html__('Purchase Orders', 'wpcodigo_wms' ),
			'options' => array(
                'cwms1661_can_view_po_roles' => esc_html__('View', 'wpcodigo_wms' ), 
                'cwms1661_can_add_po_roles' => esc_html__('Add', 'wpcodigo_wms' ), 
                'cwms1661_can_update_po_roles' => esc_html__('Edit', 'wpcodigo_wms' ),
                'cwms1661_can_delete_po_roles' => esc_html__('Delete', 'wpcodigo_wms' ),
                'cwms1661_can_receive_po_roles' => esc_html__('Receive', 'wpcodigo_wms' )
            )
        );
        return $permissions;
    }
    public static function print( $file_path, $print_id){
        if( !(int)$print_id  ){
            return $file_path;
        }
        return apply_filters( "cwms1661_inbound_print_template", CWMS1661_ABSPATH.'module/inbound/templates/print.php' );
    }
}