<?php 
defined( 'ABSPATH' ) || exit;

function cwms1661_po_table_headers(){
    $fields = array(
        '_po_number'        => __('PO No.', 'wpcodigo_wms' ),
        '_dr_number'        => __('DR No.', 'wpcodigo_wms' ),
        '_supplier'         => __('Supplier', 'wpcodigo_wms' ),
        '_date_created'     => __('Date Created', 'wpcodigo_wms' ),
        '_created_by'       => __('Created By', 'wpcodigo_wms' ),
        '_date_received'    => __('Date Received', 'wpcodigo_wms' ),
        '_received_by'      => __('Received By', 'wpcodigo_wms' ),
        '_total_amount'     => __('Total Amount', 'wpcodigo_wms' ),
        '_download'         => __('Actions', 'wpcodigo_wms' )
    );
    return apply_filters( 'cwms1661_po_table_headers', $fields );
}
function cwms_receiving_po_statuses(){
    $statuses = ['cwms-approved', 'cwms-processing'];
    return apply_filters( 'cwms_receiving_po_statuses', $statuses );
}
function cwms1661_po_bulk_actions(){
    $statuses   = cwms1661_post_statuses();
    $options    = [];
    foreach ($statuses as $key => $value) {
        $options[$key] = $value['label'];
    }
    unset($options['cwms-reserve']);
    return apply_filters('cwms1661_po_bulk_actions', $options );
}
function cwms1661_current_status_filter(){
    if( isset($_GET['status']) 
        && in_array( urldecode($_GET['status']), array_keys( cwms1661_post_statuses() ) ) 
        && urldecode($_GET['status']) != 'cwms-for-approval' ){
            return urldecode($_GET['status']);
    }
    return 'cwms-for-approval';
}
function cwms1661_generate_po_number(){
    $numdigit  	= apply_filters('cwms1661_generate_po_digit', 12 );
    $numstr     = '';
    for ( $i = 1; $i < $numdigit; $i++ ) {
        $numstr .= 9;
    }
    $po_number = str_pad( wp_rand( 0, $numstr ), $numdigit, "0", STR_PAD_LEFT );
    return apply_filters( 'cwms1661_generate_po_number', $po_number );
}
// Access permission functions

function cwms1661_can_access_po(){
    if(
        cwms1661_can_view_po() 
        || cwms1661_can_add_po() 
        || cwms1661_can_update_po() 
        || cwms1661_can_delete_po() 
        || cwms1661_can_receive_po() 
    ){
        return true;
    }
    return false;
}

function cwms1661_can_view_po_roles(){
    $assinged_roles     = get_option( 'cwms1661_can_view_po_roles', null );
    if( $assinged_roles === null ){
        $assinged_roles = array( 'cwms_manager', 'cwms_encoder' );
    }
    $assinged_roles[]   = 'administrator';
    return $assinged_roles;
}
function cwms1661_can_view_po(){
    if( !is_user_logged_in() ){
        return false;
    }
    $allowed_roles = apply_filters('cwms1661_can_view_po_roles', cwms1661_can_view_po_roles() );
    return array_intersect( $allowed_roles,  cwms1661_current_user_roles() ) ? true : false ;
}
function cwms1661_can_add_po_roles(){
    $assinged_roles     = get_option( 'cwms1661_can_add_po_roles', null );
    if( $assinged_roles === null ){
        $assinged_roles = array( 'cwms_manager', 'cwms_encoder' );
    }
    $assinged_roles[]   = 'administrator';
    return $assinged_roles;
}
function cwms1661_can_add_po(){
    if( !is_user_logged_in() ){
        return false;
    }
    $allowed_roles = apply_filters('cwms1661_can_add_po_roles', cwms1661_can_add_po_roles() );
    return array_intersect( $allowed_roles,  cwms1661_current_user_roles() ) ? true : false ;
}
function cwms1661_can_update_po_roles(){
    $assinged_roles     = get_option( 'cwms1661_can_update_po_roles', null );
    if( $assinged_roles === null ){
        $assinged_roles = array( 'cwms_manager' );
    }
    $assinged_roles[]   = 'administrator';
    return $assinged_roles;
}
function cwms1661_can_update_po(){
    if( !is_user_logged_in() ){
        return false;
    }
    $allowed_roles = apply_filters('cwms1661_can_update_po_roles', cwms1661_can_update_po_roles() );
    return array_intersect( $allowed_roles,  cwms1661_current_user_roles() ) ? true : false ;
}
function cwms1661_can_delete_po_roles(){
    $assinged_roles     = get_option( 'cwms1661_can_delete_po_roles', null );
    if( $assinged_roles === null ){
        $assinged_roles = array( 'cwms_manager' );
    }
    $assinged_roles[]   = 'administrator';
    return $assinged_roles;
}
function cwms1661_can_delete_po(){
    if( !is_user_logged_in() ){
        return false;
    }
    $allowed_roles = apply_filters('cwms1661_can_delete_po_roles', cwms1661_can_delete_po_roles() );
    return array_intersect( $allowed_roles,  cwms1661_current_user_roles() ) ? true : false ;
}
function cwms1661_can_receive_po_roles(){
    $assinged_roles     = get_option( 'cwms1661_can_receive_po_roles', null );
    if( $assinged_roles === null ){
        $assinged_roles = array( 'cwms_manager' );
    }
    $assinged_roles[]   = 'administrator';
    return $assinged_roles;
}
function cwms1661_can_receive_po(){
    if( !is_user_logged_in() ){
        return false;
    }
    $allowed_roles = apply_filters('cwms1661_can_receive_po_roles', cwms1661_can_receive_po_roles() );
    return array_intersect( $allowed_roles,  cwms1661_current_user_roles() ) ? true : false ;
}
function cwms1661_get_po_product_total( $products ){
    if( !is_array($products) ){
        return 0;
    }
    return array_reduce( $products, function( $acc, $product ){
        $acc  += $product['total'];
        return $acc;
    });
}
function cwms1661_get_po_products( $po_id ){
    global $wpdb;

    if( ! is_cwms1661_po( $po_id, array('cwms-completed') ) ){
        return maybe_unserialize( get_post_meta( $po_id, '_products', true ) );
    }

    $table  = $wpdb->prefix.CWMS1661_TB_PRODUCTS;
    $sql    = "SELECT * FROM {$table} WHERE `trans_id` = %d ORDER BY `ID` ASC";
    return $wpdb->get_results( $wpdb->prepare( $sql, $po_id ), ARRAY_A );
}
function cwms1661_get_po_product_data( $po_id ){
    $products   = maybe_unserialize( cwms1661_get_po_products( $po_id ) );
    array_walk($products, function( &$product, $key ){
        $cost                   = floatval( $product['qty_delivered'] ) * floatval( $product['cost_price'] );
        $product['total']       = $cost - $product['discount_amount'];
    });
    return $products;
}
function cwms1661_get_po_cost( &$data, $post_id ){
    $products         = cwms1661_get_po_product_data( $post_id );
    $sub_total        = cwms1661_get_invoice_product_total( $products );
    $cod_discount     = floatval( get_post_meta( $post_id, '_cod_discount', true ) );
    $tax              = floatval( get_post_meta( $post_id, '_tax', true ) );
    $others           = floatval( get_post_meta( $post_id, '_others', true ) );

    $total_amount     = ( $sub_total + $tax + $others ) - $cod_discount;

    $data['_products']      = $products;
    $data['_cod_discount']  = $cod_discount;
    $data['_tax']           = $tax;
    $data['_others']        = $others;
    $data['_sub_total']     = $sub_total;
    $data['_total_amount']  = $total_amount;
}
function cwms1661_get_po_data( $post_id ){
    $po_headers = cwms1661_po_table_headers();
    $post       = get_post( $post_id );
    // Remove the title in metakeys
    // $products   = maybe_unserialize( get_post_meta( $post->ID, '_products', true  ) );
    $products   = cwms1661_get_assign_product( $post->ID );
    array_walk($products, function( &$product, $key ){
        $qty                    = $product['qty_delivered'] > 0 ? $product['qty_delivered'] : $product['qty_ordered'] ;
        // $cost                   = floatval( $qty ) * floatval( $product['cost_price'] );
        // $product['total']       = $cost - $product['discount_amount'];
        $product['total']       = cwms1661_calculate_item_cost( $qty, $product['cost_price'], $product['discount'] );
    });
    $sub_total  = cwms1661_get_po_product_total( $products );

    $date_received      = get_post_meta( $post->ID, '_date_received', true );
    $date_created       = get_the_date( cwms1661_date_format(), $post->ID );
    $payment_stat_key   = get_post_meta( $post->ID, '_payment_status', true );
    $payment_stat_key   = $payment_stat_key ? $payment_stat_key : '_unpaid';
    $data       = [ 
        'ID'            => $post->ID, 
        'title'         => $post->post_title,
        '_po_number'    => $post->post_title,
        '_dr_number'    => get_post_meta( $post->ID, '_dr_number', true ),
        '_products'     => $products,
        '_status_key'   => $post->post_status,
        '_status'       => cwms1661_post_statuses()[$post->post_status]['label'],
        '_remarks'      => get_post_meta( $post->ID, '_remarks', true ),
        '_date_received'  => '',
        '_cod_discount' => floatval( get_post_meta( $post->ID, '_cod_discount', true ) ),
        '_tax'          => floatval( get_post_meta( $post->ID, '_tax', true ) ),
        '_others'       => floatval( get_post_meta( $post->ID, '_others', true ) ),
        '_supplier_details'     => get_post_meta( $post->ID, '_supplier_details', true ),
        '_total_amount'         => 0,
        '_payment_stat_key'     => $payment_stat_key,
        '_payment_status'       => cwms1661_invoice_payment_statuses()[$payment_stat_key],
        '_sub_total'            => $sub_total
    ]; 
    if( $date_received ){
        $data['_date_received'] = date( cwms1661_datetime_format(), strtotime($date_received) );
    }
    // $data['supplier_html_address'] = cwms1661_supplier_address_html( $data['_supplier_details'] );
    foreach( array_keys($po_headers) as $metakey ){
        if( $metakey == '_date_created' ){
            $data[$metakey] = $date_created;
            continue;
        }
        if( $metakey == '_created_by' ){
            $data[$metakey] = cwms1661_user_fullname( $post->post_author );
            continue;
        }
        if( $metakey == '_received_by' ){
            $data[$metakey] = get_post_meta( $post->ID, '_received_by', true );
            continue;
        }
        if( $metakey == '_supplier' ){
            $data[$metakey]     = $data['_supplier_details']['_company_name'];
            continue;
        }
        if( $metakey == '_total_amount' ){
            $total_amount   = ( $data['_sub_total'] + $data['_tax'] + $data['_others'] ) -  $data['_cod_discount'] ;
            $data[$metakey] = cwms1661_format_number( floatval($total_amount) );
        }
        if( $metakey == '_download' ){
            $data[$metakey] =  sprintf( '<a href="%s" class="downloadPDF" data-id="%s" data-type="inbound-po"><i class="fa fa-2x fa-file-pdf-o" title="%s" style="margin-right:12px;"></i></a>', '#', $post->ID, __('Download purchase order PDF', 'wpcodigo_wms') );
        } 
    }

    return apply_filters('cwms1661_get_po_data', $data, $post_id );
}
function cwms1661_get_all_po_data( $post_status = array(), $limit = null, $offset = 0  ){
    global $wpdb;
    $post_status = array_filter( (array)$post_status );
    if( empty( $post_status ) || !is_array( $post_status ) ){
        $post_status = array_keys( cwms1661_post_statuses() );
    }
    $parameter = array( CWMS1661_PO_POST_TYPE );
    $sql = "SELECT `ID` as 'id'";
    $sql .= " FROM {$wpdb->posts}";
    $sql .= " WHERE `post_status`  IN ('".implode( "','", $post_status )."') AND `post_type` LIKE %s";
    if( $limit ){
        $sql .= " LIMIT %d OFFSET %d";
        $parameter = array_merge( $parameter, array( $limit, $offset ) );
    }
    $sql     = $wpdb->prepare( $sql, $parameter);
    $results = $wpdb->get_col( apply_filters( 'cwms1661_get_all_po_data_sql', $sql, $limit, $offset ) );
    if( empty($results) ){
        return false;
    }
    $data = [];
    foreach ($results as $post_id ) {
        $data[] = cwms1661_get_po_data( $post_id );
    }
    return $data;
}
function cwms1661_get_po_status_count( $status ){
    global $wpdb;
    return $wpdb->get_var ( $wpdb->prepare( "SELECT count(*) FROM {$wpdb->posts} WHERE `post_status` LIKE %s AND `post_type` LIKE %s", $status, CWMS1661_PO_POST_TYPE ) );
}
function is_cwms1661_po( $po_id, $statuses = array() ){
    global $wpdb;
    if( empty($statuses) || !is_array($statuses) ){
        $statuses = array_keys( cwms1661_post_statuses() );
    }
    return $wpdb->get_row( $wpdb->prepare( "SELECT `ID`, `post_status` FROM {$wpdb->posts} WHERE `ID` LIKE %d AND `post_type` LIKE %s AND `post_status` IN ('".implode( "','", $statuses )."') LIMIT 1", $po_id, CWMS1661_PO_POST_TYPE ) );
}
function has_cwms1661_po_product( $po_id, $product_id ){
    global $wpdb;
    $table_name = $wpdb->prefix.CWMS1661_TB_PRODUCTS;
    $sql = "SELECT `ID` FROM {$table_name} WHERE `product_id` LIKE %d AND `trans_id` LIKE %d LIMIT 1";
    return $wpdb->get_var( $wpdb->prepare( $sql, $product_id, $po_id ) );
}
function cwms1661_search_po( $po_number, $statuses = array() ){
    global $wpdb;
    if( empty($statuses) || !is_array($statuses) ){
        $statuses = array_keys( cwms1661_post_statuses() );
    }
    $sql = "SELECT tblposts.ID FROM {$wpdb->posts} AS tblposts";
    $sql .= " RIGHT JOIN {$wpdb->postmeta} AS tblmeta ON tblposts.ID = tblmeta.post_id ";
    $sql .= " WHERE tblposts.post_type LIKE %s AND tblposts.post_status IN ('".implode( "','", $statuses )."') ";
    $sql .= " AND ( tblposts.post_title LIKE %s OR ( tblmeta.meta_key LIKE '_dr_number' AND tblmeta.meta_value LIKE %s ) )";
    $sql .= " GROUP BY tblposts.ID ORDER BY tblposts.post_date DESC";
    $sql        = $wpdb->prepare( $sql, CWMS1661_PO_POST_TYPE, '%'.$po_number.'%', '%'.$po_number.'%' );
    return $wpdb->get_col( $sql );
}

function cwms1661_po_by_date( $dateStart, $dateEnd ){
    global $wpdb;
    $sql = " SELECT tblposts.ID FROM {$wpdb->posts} as tblposts";
    $sql .= " WHERE tblposts.post_status LIKE %s AND tblposts.post_type LIKE %s AND CAST( tblposts.post_date as date) between %s and %s";
    $sql = $wpdb->prepare( $sql, 'cwms-completed', CWMS1661_PO_POST_TYPE, $dateStart, $dateEnd );
    return $wpdb->get_col( $sql );
}

function cwms1661_po_total_cost( $dateStart, $dateEnd ){
    $po_data = cwms1661_po_by_date( $dateStart, $dateEnd );
    if( empty( $po_data ) ){
        return 0;
    }
    return array_reduce( $po_data, function( $carry, $item ){
        $data = array();
        cwms1661_get_po_cost( $data, $item );
        $carry += floatval( $data['_total_amount'] );
        return $carry;
    }, 0 );
}