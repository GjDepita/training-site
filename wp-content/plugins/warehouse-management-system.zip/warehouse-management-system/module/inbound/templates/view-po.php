<?php
$po               = cwms1661_get_po_data( (int)$_GET['id'] );
$general_settings = cwms1661_get_general_settings();
$po_number        = $po['_po_number'];
$dr_number        = $po['_dr_number'];
$date_created     = $po['_date_created'];

$product_total    = cwms1661_get_po_product_total($po['_products']);
$tax              = $po['_tax'];
$others           = $po['_others'];
$total            = $po['_total_amount'];

?>
<div class="col-md-offset-1 col-md-10 col-sm-12">
    <?php do_action('cwms1661_before_view_po', $po ); ?>
        <!-- Header -->
        <section id="po-header-section" class="row" style="margin-bottom:18px;">
            <div class="col-md-6 col-sm-12">
                <?php if($general_settings['_company_logo']):  ?>
                    <img src="<?php echo $general_settings['_company_logo']; ?>" alt="<?php echo $general_settings['_company_name']; ?>" width="210">
                <?php endif; ?>
            </div>
            <div class="col-md-6 col-sm-12 text-right">
                <h1><?php esc_html_e('PURCHASE ORDER', 'wpcodigo_wms'); ?></h1>
                <?php esc_html_e('DATE', 'wpcodigo_wms'); ?>: <?php echo $date_created; ?><br/>
                <span class="cwms-po_number"><?php esc_html_e('PO', 'wpcodigo_wms'); ?>#: <?php echo $po_number; ?></span><br/>
                <span class="cwms-po_number"><?php esc_html_e('DR', 'wpcodigo_wms'); ?>#: <?php echo $dr_number; ?></span><br/>
                <strong><?php echo $po['_status']; ?></strong>
            </div>
        </section>
        <!-- Vendors Information -->
        <section id="supplier-info-section" class="row" style="margin-bottom:18px;">
            <div class="col-md-6 col-sm-12">
                <h3 class="info-header bg-header"><?php esc_html_e('SUPPLIER', 'wpcodigo_wms'); ?></h3>
                <div id="cwms-supplier-details">
                    <strong><?php echo $po['_supplier']; ?></strong><br/>
                    <span class="contact-name"><?php echo $po['_supplier_details']['_name']; ?></span><br/>
                    <?php echo cwms1661_supplier_address_html( $po['_supplier_details'] ); ?><br/>
                    <?php echo $po['_supplier_details']['_phone']; ?><br/>
                    <?php echo $po['_supplier_details']['_email']; ?>
                </div>
            </div>
            <div class="col-md-6 col-sm-12">
                <h3 class="info-header bg-header"><?php esc_html_e('SHIP TO', ''); ?></h3>
                <span class="contact-name"><strong><?php echo $general_settings['_company_name']; ?></strong></span></br>
                <span class="supplier-address"><?php echo nl2br( $general_settings['_address'] ); ?></span><br/>
                <?php echo $general_settings['_phone']; ?>
            </div>
        </section>
        <section id="product-info" class="table-responsive cwms_po_items">
            <table id="cwms-poitems-table" class="table table-sm table-hover">
                <thead>
                    <tr>
                        <th><?php esc_html_e('SKU', 'wpcodigo_wms'); ?></th>
                        <th><?php esc_html_e('Name', 'wpcodigo_wms'); ?></th>
                        <th class="cwms-input-header"><?php esc_html_e('Ordered Qty', 'wpcodigo_wms'); ?></th>
                        <?php if( $po['_status_key'] == 'cwms-completed'): ?>
                            <th class="cwms-input-header"><?php esc_html_e('Delivered Qty', 'wpcodigo_wms'); ?></th>
                        <?php endif; ?>
                        <th class="cwms-input-header"><?php esc_html_e('Unit', 'wpcodigo_wms'); ?></th>
                        <th class="cwms-input-header"><?php esc_html_e('Cost Price', 'wpcodigo_wms'); ?></th>
                        <th class="cwms-input-header"><?php esc_html_e('Discount(s)', 'wpcodigo_wms'); ?></th>
                        <th class="cwms-input-header text-right" style="width:120px;"><?php esc_html_e('Total', 'wpcodigo_wms'); ?></th>
                    </tr>
                </thead>
                <tbody >
                    <?php if( is_array($po['_products']) ): ?>
                        <?php foreach ($po['_products'] as $product): ?>
                            <tr>
                                <td class="col-upc"><?php echo $product['upc']; ?></td>
                                <td class="col-name"><?php echo $product['name']; ?></td>
                                <td class="col-qty"><?php echo (int)$product['qty_ordered']; ?></td>
                                <?php if( $po['_status_key'] == 'cwms-completed'): ?>
                                    <td class="col-qty_delivered text-primary" style="font-weight:700;"><?php echo (int)$product['qty_delivered']; ?></td>
                                <?php endif; ?>
                                <td class="col-unit"><?php echo $product['unit']; ?></td>
                                <td class="col-cost_price"><?php echo cwms1661_format_number( $product['cost_price'], 2, ',' ); ?></td>
                                <td class="col-discount"><?php echo $product['discount']; ?></td>
                                <td class="col-total text-right"><?php echo cwms1661_format_number( $product['total'], 2, ',' ); ?></td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </section>
        <div class="row" id="amount-breakdown">
            <!-- Remarks column -->
            <div class="col-xs-6">
                <p class="lead"><?php esc_html_e('Remarks', 'wpcodigo_wms'); ?>:</p>
                <textarea name="remarks" rows="6" style="width:100%;" disabled><?php echo $po['_remarks']; ?></textarea>
            </div>
            <!-- /.col -->
            <div class="col-xs-6">
                <p class="lead"><?php esc_html_e('Amount Due', 'wpcodigo_wms'); ?></p>
                <div class="table-responsive">
                    <table id="cwms-amountdue-table" class="table">
                        <tbody>
                            <tr>
                                <th class="text-right"><?php esc_html_e('SubTotal', 'wpcodigo_wms'); ?>:</th>
                                <td class="amount_due_subtotal text-right" style="width:120px;"><?php echo cwms1661_format_number( $product_total, 2, ',' ); ?></td>
                            </tr>
                            <tr>
                                <th class="text-right"><?php esc_html_e('COD Discount', 'wpcodigo_wms'); ?>:</th>
                                <td class="amount_coddisc text-right"><?php echo cwms1661_format_number( $po['_cod_discount'], 2, ',' ) ; ?></td>
                            </tr>
                            <tr>
                                <th class="text-right"><?php esc_html_e('Tax', 'wpcodigo_wms'); ?>:</th>
                                <td class="amount_due_tax text-right"><?php echo cwms1661_format_number($tax, 2, ','); ?></td>
                            </tr>
                            <tr>
                                <th class="text-right"><?php esc_html_e('Others', 'wpcodigo_wms'); ?>:</th>
                                <td class="amount_due_others text-right"><?php echo cwms1661_format_number($others, 2, ','); ?></td>
                            </tr>
                            <tr>
                                <th class="text-right"><?php esc_html_e('Total', 'wpcodigo_wms'); ?>:</th>
                                <td class="amount_due_total text-right"><?php echo cwms1661_format_number($total, 2, ','); ?></td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
            <!-- /.col -->
        </div>
        <div class="ln_solid"></div>
        <section id="action-section">
            <div class="col-md-6 form-group">
                <strong><?php esc_html_e('Date'); ?>: </strong> <?php echo $po['_date_created']; ?><br/>
                <strong><?php esc_html_e('Prepared by'); ?>:</strong> <?php echo $po['_created_by']; ?> 
            </div>
            <div class="col-md-6 text-right">
                <?php if( $po['_status_key'] ==  'cwms-completed' ): ?>
                    <strong><?php esc_html_e('Date'); ?>: </strong> <?php echo $po['_date_received']; ?><br/>
                    <strong><?php esc_html_e('Received by'); ?>: </strong> <?php echo $po['_received_by']; ?>
                <?php endif; ?>
            </div>
        </section>
    <?php do_action('cwms1661_after_view_po', $po ); ?>
</div>