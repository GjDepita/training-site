<div class="col-md-offset-1 w-100 col-md-10 col-sm-12">
    <?php do_action('cwms1661_before_po_form', $po ); ?>
    <form id="cwms-po_form" class="form-horizontal form-label-left input_mask" action="" method="POST">
        <?php wp_nonce_field( 'cwms-po_form_action', 'cwms-po_form_nonce' ); ?>
        <input type="submit" style="display:none !important;" value="<?php esc_html_e('Create PO', 'wpcodigo_wms'); ?>">
        <?php if( ! $is_new ): ?>
            <input type="hidden" name="cwms_po_id" value="<?php echo (int)$po['ID']; ?>">
        <?php endif; ?>
        <!-- Header -->
        <section id="po-header-section" class="row" style="margin-bottom:18px;">
            <div class="col-md-6 col-sm-12">
                <?php if($general_settings['_company_logo']):  ?>
                    <img src="<?php echo $general_settings['_company_logo']; ?>" alt="<?php echo $general_settings['_company_name']; ?>" width="210">
                <?php endif; ?>
            </div>
            <div class="col-md-6 col-sm-12 text-right">
                <h1><?php esc_html_e('PURCHASE ORDER', 'wpcodigo_wms'); ?></h1>
                <?php esc_html_e('DATE', 'wpcodigo_wms'); ?>: <input type="text" name="_receipt_date" class="cwms-date" value="<?php echo $current_date; ?>"><br/>
                <span class="cwms-po_number"><?php esc_html_e('PO', 'wpcodigo_wms'); ?>#: <?php echo $po_number; ?></span>
                <input type="hidden" name="_po_number" value="<?php echo $po_number; ?>">
            </div>
        </section>
        <!-- Vendors Information -->
        <section id="supplier-info-section" class="row" style="margin-bottom:18px;">
            <div class="col-md-6 col-sm-12">
                <h3 class="info-header bg-header"><?php esc_html_e('SUPPLIER', 'wpcodigo_wms'); ?> <span class="cwms-search-supplier glyphicon glyphicon-folder-open text-primary" aria-hidden="true" data-toggle="modal" data-target="#cwms-search-supplier-modal" style="font-size: 1.2em;float: right;"></span></h3>
                <div id="cwms-supplier-details">
                    <?php if( $is_new || !$po['_supplier'] ): ?>
                        <section class="supplier-details_placeholder" data-toggle="modal" data-target="#cwms-search-supplier-modal">
                            <?php esc_html_e('Search Supplier', 'wpcodigo_wms'); ?>
                        </section>
                    <?php else: ?>
                        <strong><?php echo $po['_supplier']; ?></strong><br/>
                        <span class="contact-name"><?php echo $po['_supplier_details']['_name']; ?></span><br/>
                        <?php echo cwms1661_supplier_address_html( $po['_supplier_details'] ); ?><br/>
                        <?php echo $po['_supplier_details']['_phone']; ?><br/>
                        <?php echo $po['_supplier_details']['_email']; ?>
                        <input type="hidden" name="_supplier_id" value="<?php echo (int)$po['_supplier_details']['ID']; ?>">
                    <?php endif; ?>
                </div>
            </div>
            <div class="col-md-6 col-sm-12">
                <h3 class="info-header bg-header"><?php esc_html_e('SHIP TO', ''); ?></h3>
                <span class="contact-name"><?php echo $general_settings['_company_name']; ?></span></br>
                <span class="supplier-address"><?php echo nl2br( $general_settings['_address'] ); ?></span><br/>
                <?php echo $general_settings['_phone']; ?>
            </div>
        </section>
        <section id="product-info" class="table-responsive cwms_po_items">
            <div id="table-select-action">
                <select id="cwms-search_product" class="cwms-select2-search form-control form-control-sm" data-action="cwms_product_options" style="width: 280px;float:right;" aria-placeholder="<?php esc_html_e('Search Product', 'wpcodigo_wms'); ?>">
                    <option value=""><?php esc_html_e('Search Product', 'wpcodigo_wms'); ?></option>
                </select>
                <button data-repeater-create type="button" class="btn btn-sm btn-primary" style="height: 34px;" disabled><?php esc_html_e('Add Item', 'wpcodigo_wms'); ?></button>
            </div>
            <table id="cwms-poitems-table" class="table table-sm table-hover" data-poid="<?php echo !$is_new ? (int)$po['ID'] : 0; ?>">
                <thead>
                    <tr>
                        <th colspan="2"><?php esc_html_e('SKU', 'wpcodigo_wms'); ?></th>
                        <th><?php esc_html_e('Name', 'wpcodigo_wms'); ?></th>
                        <th class="cwms-input-header"><?php esc_html_e('Order Qty', 'wpcodigo_wms'); ?></th>
                        <th class="cwms-input-header"><?php esc_html_e('Unit', 'wpcodigo_wms'); ?></th>
                        <th class="cwms-input-header"><?php esc_html_e('Cost Price', 'wpcodigo_wms'); ?></th>
                        <th class="cwms-input-header"><?php esc_html_e('Discount(s)', 'wpcodigo_wms'); ?></th>
                        <th class="cwms-input-header"><?php esc_html_e('Total', 'wpcodigo_wms'); ?></th>
                    </tr>
                </thead>
                <tbody data-repeater-list="cwms_po_products">
                    <?php if( $is_new || empty( $po['_products'] ) ): ?>
                        <tr data-repeater-item>
                            <td class="col-delete" style="width:24px;">
                                <i data-repeater-delete class="fa fa-trash text-danger"></i>
                                <input type="hidden" data-name="id" name="product_id">
                                <input type="hidden" data-name="upc" name="upc">
                                <input type="hidden" data-name="name" name="name">
                                <input type="hidden" data-name="unit" name="unit">
                                <input type="hidden" data-name="retail-price" name="retail_price">
                            </td>
                            <td class="col-upc">&nbsp;</td>
                            <td class="col-name">&nbsp;</td>
                            <td class="col-qty"><input type="text" class="cmws-number cwms-calculate" data-name="qty" name="qty_ordered" value="1" /> </td>
                            <td class="col-unit"></td>
                            <td class="col-cost_price"><input type="text" class="cmws-currency cwms-calculate" data-name="cost-price" name="cost_price" value="0.00" /></td>
                            <td class="col-discount"><input type="text" class="cmws-discount cwms-calculate" data-name="discount" name="discount" value="" /></td>
                            <td class="col-total">0.00</td>
                        </tr>
                    <?php else: ?>
                        <?php foreach ($po['_products'] as $product): ?>
                            <tr data-row="<?php echo $product['ID']; ?>" data-repeater-item>
                                <td class="col-delete" style="width:24px;">
                                    <i data-repeater-delete class="fa fa-trash text-danger"></i>
                                    <input type="hidden" data-name="id" name="product_id" value="<?php echo $product['product_id']; ?>">
                                    <input type="hidden" data-name="upc" name="upc" value="<?php echo $product['upc']; ?>">
                                    <input type="hidden" data-name="name" name="name" value="<?php echo $product['name']; ?>">
                                    <input type="hidden" data-name="unit" name="unit" value="<?php echo $product['unit']; ?>">
                                    <input type="hidden" data-name="retail-price" name="retail_price" value="<?php echo $product['retail_price']; ?>" />
                                </td>
                                <td class="col-upc"><?php echo $product['upc']; ?></td>
                                <td class="col-name"><?php echo $product['name']; ?></td>
                                <td class="col-qty"><input type="text" class="cmws-number cwms-calculate" data-name="qty" name="qty_ordered" value="<?php echo (int)$product['qty_ordered']; ?>" /> </td>
                                <td class="col-unit"><?php echo $product['unit']; ?></td>
                                <td class="col-cost_price"><input type="text" class="cmws-currency cwms-calculate" data-name="cost-price" name="cost_price" value="<?php echo $product['cost_price']; ?>" /></td>
                                <td class="col-discount"><input type="text" class="cmws-discount cwms-calculate" data-name="discount" name="discount" value="<?php echo $product['discount']; ?>" /></td>
                                <td class="col-total"><?php echo cwms1661_format_number( $product['total'] ); ?></td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </section>
        <div class="row" id="amount-breakdown">
            <!-- Remarks column -->
            <div class="col-md-6 col-xs-12">
                <p class="lead"><?php esc_html_e('Remarks', 'wpcodigo_wms'); ?>:</p>
                <textarea name="remarks" rows="6" style="width:100%;" placeholder="<?php esc_html_e('Add remarks here.', 'wpcodigo_wms'); ?>"><?php echo $is_new ? '' : $po['_remarks'] ; ?></textarea>
            </div>
            <!-- /.col -->
            <div class="col-md-6 col-xs-12">
                <p class="lead"><?php esc_html_e('Amount Due', 'wpcodigo_wms'); ?></p>
                <div class="table-responsive">
                    <table id="cwms-amountdue-table" class="table">
                        <tbody>
                        <tr>
                            <th style="width:50%"><?php esc_html_e('SubTotal', 'wpcodigo_wms'); ?>:</th>
                            <td class="amount_due_subtotal"><?php echo $is_new ? 0.00 : cwms1661_format_number( $po['_sub_total'] ) ; ?></td>
                        </tr>
                        <tr>
                            <th><?php esc_html_e('COD Discount', 'wpcodigo_wms'); ?>:</th>
                            <td class="amount_cod_discount">
                                <input type="text" class="cmws-currency cwms-calculate" name="cod_discount" value="<?php echo $is_new ? 0.00 : cwms1661_format_number( $po['_cod_discount'] ) ; ?>" />
                            </td>
                        </tr>
                        <tr>
                            <th><?php esc_html_e('Tax', 'wpcodigo_wms'); ?>:</th>
                            <td class="amount_due_tax">
                                <input type="text" class="cmws-currency cwms-calculate" name="tax" value="<?php echo $is_new ? 0.00 : cwms1661_format_number( $po['_tax'] ) ; ?>" />
                            </td>
                        </tr>
                        <tr>
                            <th><?php esc_html_e('Others', 'wpcodigo_wms'); ?>:</th>
                            <td class="amount_due_others">
                                <input type="text" class="cmws-currency cwms-calculate" name="others" value="<?php echo $is_new ? 0.00 : cwms1661_format_number( $po['_others'] ) ; ?>" />
                            </td>
                        </tr>
                        <tr>
                            <th><?php esc_html_e('Total', 'wpcodigo_wms'); ?>:</th>
                            <td class="amount_due_total"><?php echo $is_new ? 0.00 : $po['_total_amount'] ; ?></td>
                        </tr>
                        </tbody>
                    </table>
                </div>
            </div>
            <!-- /.col -->
            </div>
        <div class="ln_solid"></div>
        <section id="action-section">
            <div class="col-md-6 form-group">
                <!-- <label>
                    <input type="checkbox" name="send_mail" value="1" > <?php //esc_html_e('Send email to vendor', 'wpcodigo_wms'); ?>
                </label> -->
            </div>
            <div class="col-md-6 text-right">
                <input id="cmws-submit-form_po" type="button" class="btn btn-md btn-success" value="<?php echo $is_new ? __('Create Purchase Order', 'wpcodigo_wms') : __('Update PO', 'wpcodigo_wms') ; ?>">
            </div>
        </section>
    </form>
    <?php do_action('cwms1661_after_po_form', $po ); ?>
</div>
<!-- Search Vendor -->
<div id="cwms-search-supplier-modal" class="modal fade" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog modal-md">
        <div class="modal-content">

            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="<?php esc_html_e('Close', 'wpcodigo_wms'); ?>"><span aria-hidden="true">×</span>
                </button>
                <h4 class="modal-title" id="uploadLogoModalLabel"><?php esc_html_e('Search Supplier', 'wpcodigo_wms'); ?></h4>
            </div>
            <div class="modal-body text-center">
                <select id="cwms-search_supplier" class="form-control form-control-sm" data-action="cwms_search_supplier" style="width: 280px; display: inline-block;" aria-placeholder="<?php esc_html_e('Search Supplier', 'wpcodigo_wms'); ?>">
                    <option value=""><?php esc_html_e('Search Supplier', 'wpcodigo_wms'); ?></option>
                </select>
                <button id="cwms-add_searched_supplier" type="button" class="btn btn-sm btn-primary d-inline" style="height: 34px;" disabled><?php esc_html_e('Add Supplier', 'wpcodigo_wms'); ?></button>
            </div>
        </div>
    </div>
</div>