<?php
    $po               = cwms1661_get_po_data( (int)$_GET['id'] );
    $general_settings = cwms1661_get_general_settings();
    $po_number        = $po['_po_number'];
    $dr_number        = $po['_dr_number'];
    $current_date     = $po['_date_created'];
    $is_new           = false;
    include_once apply_filters( "cwms1661_get_template_form-po", CWMS1661_ABSPATH.'module/inbound/templates/form-po.php' );
?>