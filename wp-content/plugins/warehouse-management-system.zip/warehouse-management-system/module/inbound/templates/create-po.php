<?php
    $po                 = [];
    $general_settings   = cwms1661_get_general_settings();
    $po_number          = cwms1661_generate_po_number();
    $dr_number          = '';
    $current_date       = cwms1661_current_date();
    $is_new             = true;
    include_once apply_filters( "cwms1661_get_template_form-po", CWMS1661_ABSPATH.'module/inbound/templates/form-po.php' );
?>