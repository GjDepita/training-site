<?php  $general_settings   = cwms1661_get_general_settings(); ?>
<section id="cwms-search_po_action_wrapper" class="col-md-12">
    <select id="cwms-search_po" class="cwms-select2-search form-control form-control-sm" data-action="cwms_search_receive_po" style="width: 280px;" aria-placeholder="<?php esc_html_e('Search PO Number', 'wpcodigo_wms'); ?>">
        <option value=""><?php esc_html_e('Search PO number', 'wpcodigo_wms'); ?></option>
    </select>
</section>
<?php do_action('cwms1661_before_receive_po_form' ); ?>
<section id="cwms-search_po_result_wrapper" class="col-md-12" style="margin-top: 36px; position: relative; min-height: 180px;">
    <div class="po-details_placeholder">
        <?php esc_html_e('Search PO number to receive.', 'wpcodigo_wms'); ?>
    </div>
</section>
<div id="cwms-po_receiving_form_wrapper" class="col-md-offset-1 col-md-10 col-sm-12 d-none">
    <form id="cwms-po_receiving_form" class="form-horizontal form-label-left input_mask" action="" method="POST">
        <?php wp_nonce_field( 'cwms-po_receiving_form_action', 'cwms-po_receiving_form_nonce' ); ?>
        <input type="hidden" name="cwms_po_id" value="">
        <!-- Header -->
        <section id="po-header-section" class="row" style="margin-bottom:18px;">
            <div class="col-md-6 col-sm-12">
                <?php if($general_settings['_company_logo']):  ?>
                    <img src="<?php echo $general_settings['_company_logo']; ?>" alt="<?php echo $general_settings['_company_name']; ?>" width="210">
                <?php endif; ?>
            </div>
            <div id="po-header-po-details" class="col-md-6 col-sm-12 text-right">
                <!-- Dyname data here -->
            </div>
        </section>
        <!-- Vendors Information -->
        <section id="supplier-info-section" class="row" style="margin-bottom:18px;">
            <div class="col-md-6 col-sm-12">
                <h3 class="info-header bg-header"><?php esc_html_e('SUPPLIER', 'wpcodigo_wms'); ?></h3>
                <div id="cwms-supplier-details">
                    <!-- Dyname data here -->
                </div>
            </div>
            <div class="col-md-6 col-sm-12">
                <h3 class="info-header bg-header"><?php esc_html_e('SHIP TO', ''); ?></h3>
                <span class="contact-name"><?php echo $general_settings['_company_name']; ?></span></br>
                <span class="supplier-address"><?php echo nl2br( $general_settings['_address'] ); ?></span><br/>
                <?php echo $general_settings['_phone']; ?>
            </div>
        </section>
        <section id="product-info" class="table-responsive cwms_po_items">
            <table id="cwms-receiving-poitems-table" class="table table-sm table-hover" data-poid="">
                <thead>
                    <tr>
                        <th><?php esc_html_e('SKU', 'wpcodigo_wms'); ?></th>
                        <th><?php esc_html_e('Name', 'wpcodigo_wms'); ?></th>
                        <th class="cwms-input-header"><?php esc_html_e('Order Qty', 'wpcodigo_wms'); ?></th>
                        <th class="cwms-input-header"><?php esc_html_e('Delivered Qty', 'wpcodigo_wms'); ?></th>
                        <th class="cwms-input-header"><?php esc_html_e('Unit', 'wpcodigo_wms'); ?></th>
                        <th class="cwms-input-header"><?php esc_html_e('Cost Price', 'wpcodigo_wms'); ?></th>
                        <th class="cwms-input-header"><?php esc_html_e('Discount(s)', 'wpcodigo_wms'); ?></th>
                        <th class="cwms-input-header"><?php esc_html_e('Total', 'wpcodigo_wms'); ?></th>
                    </tr>
                </thead>
                <tbody data-repeater-list="cwms_po_products"></tbody>
            </table>
        </section>
        <div class="row" id="amount-breakdown">
            <!-- Remarks column -->
            <div class="col-xs-6">
                <p class="lead"><?php esc_html_e('Remarks', 'wpcodigo_wms'); ?>:</p>
                <textarea name="remarks" rows="6" style="width:100%;" placeholder="<?php esc_html_e('Add remarks here.', 'wpcodigo_wms'); ?>"><!-- Dyname data here --></textarea>
            </div>
            <!-- /.col -->
            <div class="col-xs-6">
                <p class="lead"><?php esc_html_e('Amount Due', 'wpcodigo_wms'); ?></p>
                <div class="table-responsive">
                    <table id="cwms-receiving-amountdue-table" class="table">
                        <tbody>
                        <tr>
                            <th style="width:50%"><?php esc_html_e('SubTotal', 'wpcodigo_wms'); ?>:</th>
                            <td class="amount_due_subtotal"><!-- Dyname data here --></td>
                        </tr>
                        <tr>
                            <th><?php esc_html_e('COD Discount', 'wpcodigo_wms'); ?>:</th>
                            <td class="amount_cod_discount">
                                <input type="text" class="cmws-currency cwms-calculate" name="cod_discount" value="" />
                            </td>
                        </tr>
                        <tr>
                            <th><?php esc_html_e('Tax', 'wpcodigo_wms'); ?>:</th>
                            <td class="amount_due_tax">
                                <input type="text" class="cmws-currency cwms-calculate" name="tax" value="" />
                            </td>
                        </tr>
                        <tr>
                            <th><?php esc_html_e('Others', 'wpcodigo_wms'); ?>:</th>
                            <td class="amount_due_others">
                                <input type="text" class="cmws-currency cwms-calculate" name="others" value="" />
                            </td>
                        </tr>
                        <tr>
                            <th><?php esc_html_e('Total', 'wpcodigo_wms'); ?>:</th>
                            <td class="amount_due_total"></td>
                        </tr>
                        </tbody>
                    </table>
                </div>
            </div>
            <!-- /.col -->
            </div>
        <div class="ln_solid"></div>
        <section id="action-section">
            <div class="col-md-6 form-group">
                <!-- <label>
                    <input type="checkbox" name="send_mail" value="1" > <?php //esc_html_e('Send email to vendor', 'wpcodigo_wms'); ?>
                </label> -->
            </div>
            <div class="col-md-6 text-right">
                <input id="cmws-submit-form_po_receiving" type="submit" class="btn btn-md btn-success" value="<?php esc_html_e('Receive PO', 'wpcodigo_wms') ; ?>">
            </div>
        </section>
    </form>
</div>
<?php do_action('cwms1661_after_receive_po_form' ); ?>