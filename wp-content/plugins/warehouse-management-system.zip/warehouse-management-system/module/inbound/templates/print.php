<?php
$po               = cwms1661_get_po_data( (int)$print_id  );
$general_settings = cwms1661_get_general_settings();
$po_number        = $po['_po_number'];
$dr_number        = $po['_dr_number'];
$date_created     = $po['_date_created'];

$product_total    = cwms1661_get_po_product_total($po['_products']);
$tax              = $po['_tax'];
$others           = $po['_others'];
$total            = $po['_total_amount'];
?>
<div class="col-md-offset-1 col-md-10 col-sm-12">
        <table style="margin-bottom:48px;">
            <!-- Header -->
            <tr>
                <td style="width:50%">
                    <?php if($general_settings['_company_logo']):  ?>
                        <img src="<?php echo $general_settings['_company_logo']; ?>" alt="<?php echo $general_settings['_company_name']; ?>" width="210">
                    <?php endif; ?>
                </td>
                <td style="width:50%; text-align:right;">
                    <h1><?php esc_html_e('PURCHASE ORDER', 'wpcodigo_wms'); ?></h1>
                    <?php esc_html_e('DATE', 'wpcodigo_wms'); ?>: <?php echo $date_created; ?><br/>
                    <span class="cwms-po_number"><?php esc_html_e('PO', 'wpcodigo_wms'); ?>#: <?php echo $po_number; ?></span><br/>
                    <span class="cwms-dr_number"><?php esc_html_e('DR', 'wpcodigo_wms'); ?>#: <strong><?php echo $dr_number; ?></strong></span><br/>
                    <strong><?php echo $po['_status']; ?></strong>
                </td>
            </tr>
            <!-- Vendors Information -->
            <tr><td colspan="2" style="padding: 26px;">&nbsp;</td></tr>
            <tr>
                <td style="width:50%;">
                    <h3 class="info-header bg-header"><?php esc_html_e('SUPPLIER', 'wpcodigo_wms'); ?></h3>
                    <div id="cwms-supplier-details">
                        <strong><?php echo $po['_supplier']; ?></strong><br/>
                        <span class="contact-name"><?php echo $po['_supplier_details']['_name']; ?></span><br/>
                        <?php echo cwms1661_supplier_address_html( $po['_supplier_details'] ); ?><br/>
                        <?php echo $po['_supplier_details']['_phone']; ?><br/>
                        <?php echo $po['_supplier_details']['_email']; ?>
                    </div>
                </td>
                <td style="width:50%;">
                    <h3 class="info-header bg-header"><?php esc_html_e('SHIP TO', ''); ?></h3>
                    <span class="contact-name"><strong><?php echo $general_settings['_company_name']; ?></strong></span></br>
                    <span class="supplier-address"><?php echo nl2br( $general_settings['_address'] ); ?></span><br/>
                    <?php echo $general_settings['_phone']; ?>
                </td>
            </tr>
        </table>
        <section id="product-info" class="table-responsive cwms_po_items">
            <table id="cwms-poitems-table" class="bordered min-space header-black">
                <thead>
                    <tr>
                        <th><?php esc_html_e('SKU', 'wpcodigo_wms'); ?></th>
                        <th><?php esc_html_e('Name', 'wpcodigo_wms'); ?></th>
                        <th class="cwms-input-header"><?php esc_html_e('Ordered Qty.', 'wpcodigo_wms'); ?></th>
                        <th class="cwms-input-header"><?php esc_html_e('Delivered Qty.', 'wpcodigo_wms'); ?></th>
                        <th ><?php esc_html_e('Unit', 'wpcodigo_wms'); ?></th>
                        <th class="cwms-input-header"><?php esc_html_e('Cost Price', 'wpcodigo_wms'); ?></th>
                        <th class="cwms-input-header"><?php esc_html_e('Discount(s)', 'wpcodigo_wms'); ?></th>
                        <th class="cwms-input-header text-right" style="width:120px;"><?php esc_html_e('Total', 'wpcodigo_wms'); ?></th>
                    </tr>
                </thead>
                <tbody >
                    <?php if( is_array($po['_products']) ): ?>
                        <?php foreach ($po['_products'] as $product): ?>
                            <tr>
                                <td class="col-upc"><?php echo $product['upc']; ?></td>
                                <td class="col-name"><?php echo $product['name']; ?></td>
                                <td class="col-qty"><?php echo (int)$product['qty_ordered']; ?></td>
                                <td class="col-qty"><?php echo (int)$product['qty_delivered']; ?></td>
                                <td class="col-unit"><?php echo $product['unit']; ?></td>
                                <td class="col-cost_price"><?php echo cwms1661_format_number( $product['cost_price'], 2, ',' ); ?></td>
                                <td class="col-discount"><?php echo $product['discount']; ?></td>
                                <td class="col-total text-right"><?php echo cwms1661_format_number( $product['total'], 2, ',' ); ?></td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </section>
        <div style="margin-top:48px;">
            <table>
                <tr>
                    <td style="width:50%;">
                        <p class="lead"><?php esc_html_e('Remarks', 'wpcodigo_wms'); ?>:</p>
                        <textarea row="6"  disabled style="width:75%;padding:12px;min-heigth:160px;"><?php echo $po['_remarks']; ?></textarea>
                    </td>
                    <td style="width:50%;">
                        <p class="lead"><?php esc_html_e('Amount Due', 'wpcodigo_wms'); ?></p>
                        <div class="table-responsive">
                            <table id="cwms-amountdue-table" class="bordered min-space">
                                <tbody>
                                    <tr>
                                        <th class="text-right"><?php esc_html_e('SubTotal', 'wpcodigo_wms'); ?>:</th>
                                        <td class="amount_due_subtotal text-right" style="width:120px;"><?php echo cwms1661_format_number( $product_total, 2, ',' ); ?></td>
                                    </tr>
                                    <tr>
                                        <th class="text-right"><?php esc_html_e('COD Discount', 'wpcodigo_wms'); ?>:</th>
                                        <td class="amount_coddisc text-right"><?php echo cwms1661_format_number( $po['_cod_discount'], 2, ',' ) ; ?></td>
                                    </tr>
                                    <tr>
                                        <th class="text-right"><?php esc_html_e('Tax', 'wpcodigo_wms'); ?>:</th>
                                        <td class="amount_due_tax text-right"><?php echo cwms1661_format_number($tax, 2, ','); ?></td>
                                    </tr>
                                    <tr>
                                        <th class="text-right"><?php esc_html_e('Others', 'wpcodigo_wms'); ?>:</th>
                                        <td class="amount_due_others text-right"><?php echo cwms1661_format_number($others, 2, ','); ?></td>
                                    </tr>
                                    <tr>
                                        <th class="text-right"><?php esc_html_e('Total', 'wpcodigo_wms'); ?>:</th>
                                        <td class="amount_due_total text-right"><?php echo cwms1661_format_number($total, 2, ','); ?></td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </td>
                </tr>
            </table>
        </div>
        <div class="ln_solid"></div>
        <section id="action-section" style="margin-top:36px;">
            <table>
                <tr>
                    <td style="width:50%">
                        <strong><?php esc_html_e('Date'); ?>: </strong> <?php echo $po['_date_created']; ?><br/>
                        <strong><?php esc_html_e('Prepared by'); ?>:</strong> <?php echo $po['_created_by']; ?> 
                    </td>
                    <td style="width:50%text-align:right;">
                        <?php if( $po['_status_key'] ==  'cwms-completed' ): ?>
                            <strong><?php esc_html_e('Date'); ?>: </strong> <?php echo $po['_date_received']; ?><br/>
                            <strong><?php esc_html_e('Received by'); ?>: </strong> <?php echo $po['_received_by']; ?>
                        <?php endif; ?>
                    </td>
                </tr>
            </table>
        </section>
</div>