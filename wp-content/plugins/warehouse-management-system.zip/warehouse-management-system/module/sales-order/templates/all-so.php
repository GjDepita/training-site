<?php 
    $bulk_actions   = cwms1661_so_bulk_actions(); 
    $table_headers  = cwms1661_so_table_headers();
    // Remove Actions that are not for the "For Approval" and "On Hold" Status
?>
<?php if( cwms1661_current_status_filter() !=  'cwms-completed' ): ?>
    <div class="cwms-table_actions" class="row">
        <div class="btn-group">
            <button data-toggle="dropdown" class="btn btn-primary dropdown-toggle" type="button" aria-expanded="true"><?php esc_html_e('Change Status', 'wpcodigo_wms'); ?> <span class="caret"></span>
            </button>
            <ul role="menu" class="dropdown-menu">
                <?php foreach ( $bulk_actions as $key => $label ): ?>
                    <li class="<?php echo cwms1661_current_status_filter() == $key ? 'disabled' : '' ; ?>">
                        <a href="#" class="cwms-so_bulk_actions" data-action="<?php echo $key; ?>" ><?php echo $label; ?></a>
                    </li>
                <?php endforeach; ?>
                <?php if( cwms1661_current_status_filter() == 'cwms-for-approval' ): ?>
                    <li class="divider"></li>
                    <li class="text-danger">
                        <a href="#" class="cwms-so_bulk_actions" data-action="cwms-delete" style="color: #a94442;" ><?php echo esc_html__('Delete', 'wpcodigo_wms'); ?></a>
                    </li>
                    <li class="divider"></li>
                <?php endif; ?>
            </ul>
        </div>
    </div>
<?php endif; ?>
<table id="cwms_soTable" class="wcms1661_dataTable display" style="width:100%">
    <thead>
        <tr>
            <?php do_action( 'cwms1661_so_before_table_header' ); ?>
            <?php if( cwms1661_current_status_filter() !=  'cwms-completed' ): ?>
                <th></th>
            <?php endif; ?>
            <?php foreach( $table_headers as $metakey => $label ): ?>
                <th><?php echo apply_filters('cwms1661_so_product_table_headers_label_'.$metakey , $label ); ?></th>
            <?php endforeach; ?>
            <?php do_action( 'cwms1661_so_after_table_header' ); ?>
        </tr>
    </thead>
    <tfoot>
        <tr>
            <?php do_action( 'cwms1661_so_before_table_header' ); ?>
            <?php if( cwms1661_current_status_filter() !=  'cwms-completed' ): ?>
                <th></th>
            <?php endif; ?>
            <?php foreach( $table_headers as $metakey => $label ): ?>
                <th><?php echo apply_filters('cwms1661_so_product_table_headers_label_'.$metakey , $label ); ?></th>
            <?php endforeach; ?>
            <?php do_action( 'cwms1661_so_after_table_header' ); ?>
        </tr>
    </tfoot>
</table>    