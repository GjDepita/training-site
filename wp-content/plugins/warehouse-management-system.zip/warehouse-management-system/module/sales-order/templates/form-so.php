<div class="col-md-offset-1 col-md-10 col-sm-12 w-100">
    <?php do_action('cwms1661_before_so_form', $so ); ?>
    <form id="cwms-so_form" class="form-horizontal form-label-left input_mask" action="" method="POST">
        <?php wp_nonce_field( 'cwms-so_form_action', 'cwms-so_form_nonce' ); ?>
        <input type="submit" style="display:none !important;" value="<?php esc_html_e('Create Sales Order', 'wpcodigo_wms'); ?>">
        <?php if( ! $is_new ): ?>
            <input type="hidden" name="cwms_so_id" value="<?php echo (int)$so['ID']; ?>">
        <?php endif; ?>
        <!-- Header -->
        <section id="po-header-section" class="row" style="margin-bottom:18px;">
            <div class="col-md-6 col-sm-12">
                <?php if($general_settings['_company_logo']):  ?>
                    <img src="<?php echo $general_settings['_company_logo']; ?>" alt="<?php echo $general_settings['_company_name']; ?>" width="210">
                <?php endif; ?>
            </div>
            <div class="col-md-6 col-sm-12 text-right">
                <h1><?php esc_html_e('SALES ORDER', 'wpcodigo_wms'); ?></h1>
                <?php esc_html_e('DATE', 'wpcodigo_wms'); ?>: <?php echo $current_date; ?><br/>
                <span class="cwms-so_number"><?php esc_html_e('SO', 'wpcodigo_wms'); ?>#: <?php echo $so_number; ?></span>
                <input type="hidden" name="_so_number" value="<?php echo $so_number; ?>">
            </div>
        </section>
        <!-- Vendors Information -->
        <section id="customer-info-section" class="row" style="margin-bottom:18px;">
            <div class="col-md-6 col-sm-12">
                <h3 class="info-header bg-header"><?php esc_html_e('From', ''); ?></h3>
                <span class="contact-name"><?php echo $general_settings['_company_name']; ?></span></br>
                <span class="company-address"><?php echo nl2br( $general_settings['_address'] ); ?></span><br/>
                <?php echo $general_settings['_phone']; ?>
            </div>
            <div class="col-md-6 col-sm-12">
                <h3 class="info-header bg-header"><?php esc_html_e('Customer', 'wpcodigo_wms'); ?> <span class="cwms-search-customer fa fa-users text-primary" aria-hidden="true" data-toggle="modal" data-target="#cwms-search-customer-modal" style="font-size: 1.2em;float: right;"></span></h3>
                <div id="cwms-customer-details">
                    <?php if( $is_new || !$so['_customer'] ): ?>
                        <section class="customer-details_placeholder" data-toggle="modal" data-target="#cwms-search-customer-modal">
                            <?php esc_html_e('Search Customer/Company', 'wpcodigo_wms'); ?>
                        </section>
                    <?php else: ?>
                        <strong><?php echo $so['_customer_company']; ?></strong><br/>
                        <span class="contact-name"><?php echo $so['_customer']; ?></span><br/>
                        <?php echo cwms1661_display_address_html( $so['_customer_details'] ); ?><br/>
                        <?php echo $so['_customer_details']['_phone']; ?><br/>
                        <?php echo $so['_customer_details']['_email']; ?>
                        <input type="hidden" name="_customer_id" value="<?php echo (int)$so['_customer_details']['ID']; ?>">
                    <?php endif; ?>
                </div>
            </div>
        </section>
        <section id="product-info" class="table-responsive cwms_so_items">
            <div id="table-select-action">
                <select id="cwms-search_product" class="cwms-select2-search form-control form-control-sm" data-action="cwms_product_options" style="width: 280px;float:right;" aria-placeholder="<?php esc_html_e('Search Product', 'wpcodigo_wms'); ?>">
                    <option value=""><?php esc_html_e('Search Product', 'wpcodigo_wms'); ?></option>
                </select>
                <button data-repeater-create type="button" class="btn btn-sm btn-primary" style="height: 34px;" disabled><?php esc_html_e('Add Item', 'wpcodigo_wms'); ?></button>
            </div>
            <p class="text-danger" style="margin: 12px 0; font-style: italic; font-size: 1.2em;"><?php esc_html_e('Note: In adding multiple discount please add comma (,) to separate each discount.', 'wpcodigo_wms'); ?></p>
            <table id="cwms-poitems-table" class="table table-sm table-hover">
                <thead>
                    <tr>
                        <th colspan="2"><?php esc_html_e('SKU', 'wpcodigo_wms'); ?></th>
                        <th><?php esc_html_e('Name', 'wpcodigo_wms'); ?></th>
                        <th class="cwms-input-header"><?php esc_html_e('Qty', 'wpcodigo_wms'); ?></th>
                        <th ><?php esc_html_e('Unit', 'wpcodigo_wms'); ?></th>
                        <th class="cwms-input-header"><?php esc_html_e('Retail Price', 'wpcodigo_wms'); ?></th>
                        <th class="cwms-input-header"><?php esc_html_e('Discount(s)', 'wpcodigo_wms'); ?></th>
                        <th class="cwms-input-header"><?php esc_html_e('Total', 'wpcodigo_wms'); ?></th>
                    </tr>
                </thead>
                <tbody data-repeater-list="cwms_so_products">
                    <?php if( $is_new ): ?>
                        <tr data-repeater-item>
                            <td class="col-delete" style="width:24px;">
                                <i data-repeater-delete class="fa fa-trash text-danger"></i>
                                <input type="hidden" data-name="id" name="id">
                                <input type="hidden" data-name="upc" name="upc">
                                <input type="hidden" data-name="name" name="name">
                                <input type="hidden" data-name="cost-price" name="cost_price">
                                <input type="hidden" data-name="unit" name="unit">
                            </td>
                            <td class="col-upc">&nbsp;</td>
                            <td class="col-name">&nbsp;</td>
                            <td class="col-qty"><input type="text" class="cmws-decimal cwms-calculate" data-name="qty" name="qty_ordered" value="1" /> </td>
                            <td class="col-unit">&nbsp;</td>
                            <td class="col-unit_price"><input type="text" class="cmws-number cwms-calculate" data-name="retail-price" name="retail_price" value="" /></td>
                            <td class="col-discount"><input type="text" class="cmws-discount cwms-calculate" data-name="discount" name="discount" value="" /></td>
                            <td class="col-total">0.00</td>
                        </tr>
                    <?php else: ?>
                        <?php foreach ($so['_products'] as $product): ?>
                            <tr data-repeater-item>
                                <td class="col-delete" style="width:24px;">
                                    <i data-repeater-delete class="fa fa-trash text-danger"></i>
                                    <input type="hidden" data-name="id" name="id" value="<?php echo (int)$product['id']; ?>">
                                    <input type="hidden" data-name="upc" name="upc" value="<?php echo esc_html( $product['upc'] ) ; ?>">
                                    <input type="hidden" data-name="name" name="name" value="<?php echo esc_html( $product['name'] ); ?>">
                                    <input type="hidden" data-name="unit" name="unit" value="<?php echo esc_html( $product['unit'] ); ?>">
                                </td>
                                <td class="col-upc"><?php echo esc_html( $product['upc'] ); ?></td>
                                <td class="col-name"><?php echo esc_html( $product['name'] ); ?></td>
                                <td class="col-qty"><input type="text" class="cmws-number cwms-calculate" data-name="qty" name="qty_ordered" value="<?php echo floatval( $product['qty_ordered'] ); ?>" /> </td>
                                <td class="col-unit"><?php echo esc_html( $product['unit'] ); ?></td>
                                <td class="col-unit_price"><input type="text" class="cmws-number cwms-calculate" data-name="retail-price" name="retail_price" value="<?php echo floatval( $product['retail_price'] ); ?>" /></td>
                                <td class="col-discount"><input type="text" class="cmws-discount cwms-calculate" data-name="discount" name="discount" value="<?php echo esc_html( $product['discount'] ); ?>" /></td>
                                <td class="col-total"><?php echo cwms1661_format_number( $product['total'] ); ?></td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </section>
        <div class="row" id="amount-breakdown">
            <!-- Remarks column -->
            <div class="col-md-6 col-xs-12">
                <p class="lead"><?php esc_html_e('Remarks', 'wpcodigo_wms'); ?>:</p>
                <textarea class="form-control form-control-sm" name="remarks" rows="6" style="width:100%; margin-bottom:20px;" placeholder="<?php esc_html_e('Add remarks here.', 'wpcodigo_wms'); ?>"><?php echo $is_new ? '' : $so['_remarks'] ; ?></textarea>
                <p class="lead"><?php esc_html_e('Terms', 'wpcodigo_wms'); ?>:</p>
                <select class="form-control form-control-sm" style="width: 280px; display: inline-block;" name="terms" required >
                    <option value=""><?php esc_html_e('Select Term', 'wpcodigo_wms'); ?></option>
                    <?php foreach( cwms1661_term_options() as $term_key => $term_value ): ?>
                        <option value="<?php echo (int)$term_key; ?>" <?php selected( $assigned_term, (int)$term_key ); ?> ><?php echo esc_html( $term_value ); ?></option>
                    <?php endforeach; ?>
                </select>
                <p class="lead" style="margin-top:28px"><?php esc_html_e('Invoice Status', 'wpcodigo_wms'); ?>:</p>
                <select class="form-control form-control-sm" style="width: 280px; display: inline-block;" name="_so_status" required >
                    <option value=""><?php esc_html_e('Select Status', 'wpcodigo_wms'); ?></option>
                    <?php foreach( cwms1661_so_bulk_actions() as $stat_key => $status_value ): ?>
                        <option value="<?php echo $stat_key; ?>" <?php selected( $status_key, $stat_key ); ?>><?php echo esc_html( $status_value ); ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <!-- /.col -->
            <div class="col-md-6 col-xs-12">
                <p class="lead"><?php esc_html_e('Amount Due', 'wpcodigo_wms'); ?></p>
                <div class="table-responsive">
                    <table id="cwms-amountdue-table" class="table">
                        <tbody>
                        <tr>
                            <th style="width:50%"><?php esc_html_e('SubTotal', 'wpcodigo_wms'); ?>:</th>
                            <td class="amount_due_subtotal"><?php echo $is_new ? 0.00 : cwms1661_format_number($so['_sub_total']) ; ?></td>
                        </tr>
                        <tr>
                            <th><?php esc_html_e('COD Discount', 'wpcodigo_wms'); ?>:</th>
                            <td class="amount_cod_discount">
                                <input type="text" class="form-control form-control-sm cmws-currency cwms-calculate" name="cod_discount" value="<?php echo $is_new ? 0.00 : cwms1661_format_number( $so['_cod_discount'] ) ; ?>" />
                            </td>
                        </tr>
                        <tr>
                            <th><?php esc_html_e('Tax', 'wpcodigo_wms'); ?>:</th>
                            <td class="amount_due_tax">
                                <input type="text" class="form-control form-control-sm cmws-currency cwms-calculate" name="tax" value="<?php echo $is_new ? 0.00 : cwms1661_format_number( $so['_tax'] ) ; ?>" />
                            </td>
                        </tr>
                        <tr>
                            <th><?php esc_html_e('Others', 'wpcodigo_wms'); ?>:</th>
                            <td class="amount_due_others">
                                <input type="text" class="form-control form-control-sm cmws-currency cwms-calculate" name="others" value="<?php echo $is_new ? 0.00 : cwms1661_format_number( $so['_others'] ) ; ?>" />
                            </td>
                        </tr>
                        <tr>
                            <th><?php esc_html_e('Total', 'wpcodigo_wms'); ?>:</th>
                            <td class="amount_due_total"><?php echo $is_new ? 0.00 : cwms1661_format_number( $so['_total_amount'] ) ; ?></td>
                        </tr>
                        </tbody>
                    </table>
                </div>
            </div>
            <!-- /.col -->
            </div>
        <div class="ln_solid"></div>
        <section id="action-section">
            <div class="col-md-6 form-group">
                <?php if( $agents ): ?>
                    <div style="margin-bottom:12px;">
                        <label for="cwms-search_agent" style="margin-right:12px;min-width:120px;"><?php esc_html_e('Assign Saleman', 'wpcodigo_wms'); ?></label>
                        <select id="cwms-search_agent" class="form-control form-control-sm cwms-select2" style="width: 280px; display: inline-block;" name="_assigned_agent" required >
                            <option value=""><?php esc_html_e('Search Saleman', 'wpcodigo_wms'); ?></option>
                            <?php foreach( $agents as $agent ): ?>
                                <option value="<?php echo (int)$agent['ID']; ?>" <?php selected( $assigned_agent, (int)$agent['ID'] ); ?> ><?php echo esc_html( $agent['display_name'] ); ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                <?php endif; ?>
                <?php if( $whsemans ): ?>
                    <div>
                        <label for="cwms-search_whseman" style="margin-right:12px;min-width:120px;"><?php esc_html_e('Checked By', 'wpcodigo_wms'); ?></label>
                        <select id="cwms-search_whseman" class="form-control form-control-sm cwms-select2" style="width: 280px; display: inline-block;" name="_assigned_whseman" required >
                            <option value=""><?php esc_html_e('Assign Whse. Clerk', 'wpcodigo_wms'); ?></option>
                            <?php foreach( $whsemans as $whseman ): ?>
                                <option value="<?php echo (int)$whseman['ID']; ?>" <?php selected( $assigned_whseman, (int)$whseman['ID'] ); ?> ><?php echo esc_html( $whseman['display_name'] ); ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                <?php endif; ?>
            </div>
            <div class="col-md-6 text-right">
                <input id="cmws-submit-form_so" type="button" class="btn btn-md btn-success" value="<?php echo $is_new ? __('Create Sales Order', 'wpcodigo_wms') : __('Update Sales Order', 'wpcodigo_wms') ; ?>">
            </div>
        </section>
    </form>
    <?php do_action('cwms1661_after_so_form', $so ); ?>
</div>
<!-- Search Vendor -->
<div id="cwms-search-customer-modal" class="modal fade" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog modal-md">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="<?php esc_html_e('Close', 'wpcodigo_wms'); ?>"><span aria-hidden="true">×</span>
                </button>
                <h4 class="modal-title" id="uploadLogoModalLabel"><?php esc_html_e('Search Customer/Company', 'wpcodigo_wms'); ?></h4>
            </div>
            <div class="modal-body">
                <select id="cwms-search_customer" class="form-control form-control-sm" data-action="cwms_search_active_customer" style="width: 280px; display: inline-block;" aria-placeholder="<?php esc_html_e('Search Customer/Company', 'wpcodigo_wms'); ?>">
                    <option value=""><?php esc_html_e('Search Customer/Company', 'wpcodigo_wms'); ?></option>
                </select>
                <button id="cwms-add_searched_customer" type="button" class="btn btn-sm btn-primary d-inline" style="height: 34px;" disabled><?php esc_html_e('Add Customer/Company', 'wpcodigo_wms'); ?></button>
            </div>
        </div>
    </div>
</div>