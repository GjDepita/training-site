<?php
    $discounts = array(
        'cust_disc' => array(
            'label' => 'Customer Discount',
            'amount' => 7,
            'type' => 'pct'
        ),
        'hol_disc' => array(
            'label' => 'Holiday Discount',
            'amount' => 100,
            'type' => 'fxd'
        ),
        'fix_disc' => array(
            'label' => 'Fixed Discount',
            'amount' => 0,
            'type' => 'input'
        ),
        'pct_disc' => array(
            'label' => 'Percentage Discount',
            'amount' => 0,
            'type' => 'input'
        )
    );
?>

<div class="col-md-offset-1 col-md-10 col-sm-12">
    <?php do_action('cwms1661_before_so_form', $so ); ?>
    <form id="cwms-so_form" class="form-horizontal form-label-left input_mask" action="" method="POST">
        <?php wp_nonce_field( 'cwms-so_form_action', 'cwms-so_form_nonce' ); ?>
 
        <section id="product-info" class="table-responsive cwms_so_items">
            <div id="table-select-action">
                <select id="cwms-search_product" class="cwms-select2-search form-control form-control-sm" data-action="cwms_product_options" style="width: 280px;float:right;" aria-placeholder="<?php esc_html_e('Search Product', 'wpcodigo_wms'); ?>">
                    <option value=""><?php esc_html_e('Search Product', 'wpcodigo_wms'); ?></option>
                </select>
                <button data-repeater-create type="button" class="btn btn-sm btn-primary" style="height: 34px;" disabled><?php esc_html_e('Add Item', 'wpcodigo_wms'); ?></button>
            </div>
            <p class="text-danger" style="margin: 12px 0; font-style: italic; font-size: 1.2em;"><?php esc_html_e('Note: In adding multiple discount please add comma (,) to separate each discount.', 'wpcodigo_wms'); ?></p>
            <table id="cwms-poitems-table" class="table table-sm table-hover">
                <thead>
                    <tr>
                        <th colspan="2"><?php esc_html_e('SKU', 'wpcodigo_wms'); ?></th>
                        <th><?php esc_html_e('Name', 'wpcodigo_wms'); ?></th>
                        <th class="cwms-input-header"><?php esc_html_e('Qty', 'wpcodigo_wms'); ?></th>
                        <th class="cwms-input-header"><?php esc_html_e('Retail Price', 'wpcodigo_wms'); ?></th>
                        <th class="cwms-input-header"><?php esc_html_e('Discount', 'wpcodigo_wms'); ?></th>
                        <th class="cwms-input-header"><?php esc_html_e('Disc. Amount', 'wpcodigo_wms'); ?></th>
                        <th class="cwms-input-header"><?php esc_html_e('Total', 'wpcodigo_wms'); ?></th>
                    </tr>
                </thead>
                <tbody data-repeater-list="cwms_so_products">
                    <tr data-repeater-item>
                        <td class="col-delete" style="width:24px;">
                            <i data-repeater-delete class="fa fa-trash text-danger"></i>
                            <input type="hidden" data-name="id" name="id">
                            <input type="hidden" data-name="upc" name="upc">
                            <input type="hidden" data-name="name" name="name">
                        </td>
                        <td class="col-upc">&nbsp;</td>
                        <td class="col-name">&nbsp;</td>
                        <td class="col-qty"><input type="text" class="cmws-number cwms-calculate" data-name="qty" name="qty_ordered" value="1" /> </td>
                        <td class="col-unit_price"><input type="text" class="cmws-number cwms-calculate" data-name="retail-price" name="retail_price" value="" /></td>
                        <td class="col-disc_option">
                            <select class="disc_option">
                                <?php foreach( $discounts as $key => $discInfo ): ?>
                                    <option><?php echo $discInfo['label'] ?></option>
                                <?php endforeach; ?>
                            </select>
                        </td>
                        <td class="col-discount"><input type="text" class="cmws-discount cwms-calculate" data-name="discount" name="discount" value="" /></td>
                        <td class="col-total">0.00</td>
                    </tr>
                </tbody>
            </table>
        </section>
        <div class="row" id="amount-breakdown">
            <!-- Remarks column -->
            <div class="col-xs-6">
                <p class="lead"><?php esc_html_e('Remarks', 'wpcodigo_wms'); ?>:</p>
                <textarea name="remarks" rows="6" style="width:100%;" placeholder="<?php esc_html_e('Add remarks here.', 'wpcodigo_wms'); ?>"></textarea>
            </div>
            <!-- /.col -->
            <div class="col-xs-6">
                <p class="lead"><?php esc_html_e('Amount Due', 'wpcodigo_wms'); ?></p>
                <div class="table-responsive">
                    <table id="cwms-amountdue-table" class="table">
                        <tbody>
                        <tr>
                            <th style="width:50%"><?php esc_html_e('SubTotal', 'wpcodigo_wms'); ?>:</th>
                            <td class="amount_due_subtotal">0.00 </td>
                        </tr>
                        <tr>
                            <th><?php esc_html_e('Tax', 'wpcodigo_wms'); ?>:</th>
                            <td class="amount_due_tax">
                                <input type="text" class="cmws-currency cwms-calculate" name="tax" value="0.00" />
                            </td>
                        </tr>
                        <tr>
                            <th><?php esc_html_e('Others', 'wpcodigo_wms'); ?>:</th>
                            <td class="amount_due_others">
                                <input type="text" class="cmws-currency cwms-calculate" name="others" value="0.00" />
                            </td>
                        </tr>
                        <tr>
                            <th><?php esc_html_e('Total', 'wpcodigo_wms'); ?>:</th>
                            <td class="amount_due_total">0.00</td>
                        </tr>
                        </tbody>
                    </table>
                </div>
            </div>
            <!-- /.col -->
        </div>
    </form>
    <?php do_action('cwms1661_after_so_form', $so ); ?>
</div>