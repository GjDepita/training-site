<?php
    $so                 = [];
    $general_settings   = cwms1661_get_general_settings();
    $so_number          = cwms1661_generate_so_number();
    $current_date       = cwms1661_current_date();
    $is_new             = true;
    $agents             = cwms1661_get_all_users( 'cwms_agent' );
    $whsemans           = cwms1661_get_all_users( 'cwms_whseman' );
    $assigned_agent     = null;
    $assigned_whseman   = null;
    $assigned_term      = null;
    $status_key         = null;
    include_once apply_filters( "cwms1661_get_template_form-so", CWMS1661_ABSPATH.'module/sales-order/templates/form-so.php' );
?>