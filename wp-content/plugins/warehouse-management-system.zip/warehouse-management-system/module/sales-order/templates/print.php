<?php
$so                 = cwms1661_get_so_data( (int)$print_id );
$general_settings   = cwms1661_get_general_settings();
$so_number          = $so['title'];
$current_date       = $so['_date_created'];
?>
<div class="col-md-offset-1 col-md-10 col-sm-12">
    <table style="margin-bottom:48px;">
        <!-- Header -->
        <tr>
            <td colspan="4">
                <h1 style="font-size:32px;"><?php echo esc_html($general_settings['_company_name']); ?></h1>
                <span class="company-address"><?php echo nl2br( $general_settings['_address'] ); ?></span><br/>
                Tel. No. <?php echo esc_html($general_settings['_phone']); ?>
            </td>
            <td class="text-right"><strong><?php esc_html_e('NO.', 'wpcodigo_wms'); ?>:</strong></td>
            <td><div class="text-underline"><?php echo esc_html($so_number); ?></div></td>
        </tr>
        <tr><td colspan="6" style="padding: 26px 0;"><h2><?php esc_html_e('SALES ORDER', 'wpcodigo_wms'); ?></h2></td></tr>
        <tr>
            <td ><strong><?php esc_html_e('Customer', 'wpcodigo_wms'); ?>:</strong></td>
            <td colspan="2" class="text-underline"><?php echo esc_html($so['_customer_company']); ?><</td>
            <td class="text-right"><strong><?php esc_html_e('Date', 'wpcodigo_wms'); ?>:</strong></td>
            <td colspan="2" class="text-underline"><?php echo esc_html($current_date); ?></td>
        </tr>
        <tr>
            <td ><strong><?php esc_html_e('Address', 'wpcodigo_wms'); ?>:</strong> </td>
            <td colspan="2" class="text-underline"><?php echo cwms1661_display_address_html( $so['_customer_details'] ); ?></td>
            <td class="text-right"><strong><?php esc_html_e('Salesman', 'wpcodigo_wms'); ?>:</strong></td>
            <td colspan="2"><div class="text-underline"><?php echo esc_html($so['_assigned_agent_name']); ?></div></td>
        </tr>
        <tr><td colspan="3" style="padding: 12px 0;">&nbsp;</td></tr>
        <tr>
            <td><strong><?php esc_html_e('Terms', 'wpcodigo_wms'); ?>:</strong></td>
            <td><span class="text-underline"><?php echo cwms1661_term_options()[$so['_terms']]; ?></span></td>
            <td class="text-right"><strong><?php esc_html_e('Delivery Instructions', 'wpcodigo_wms'); ?>:</strong></td>
            <td colspan="3" class="text-underline">
                <?php echo esc_html( $so['_remarks'] ); ?>
                <div style="padding:36px 0;"></div>
            </td>
        </tr>
    </table>
    <section id="product-info" class="table-responsive cwms_so_items">
        <table id="cwms-poitems-table" class="bordered min-space header-black">
            <thead>
                <tr>
                    <th><?php esc_html_e('Qty.', 'wpcodigo_wms'); ?></th>
                    <th><?php esc_html_e('Product Description', 'wpcodigo_wms'); ?></th>
                    <th class="cwms-input-header"><?php esc_html_e('Unit Price', 'wpcodigo_wms'); ?></th>
                    <th class="cwms-input-header"><?php esc_html_e('Discount(s)', 'wpcodigo_wms'); ?></th>
                    <th class="cwms-input-header text-right"><?php esc_html_e('Total', 'wpcodigo_wms'); ?></th>
                </tr>
            </thead>
            <tbody >
                <?php foreach ($so['_products'] as $product): ?>
                    <tr >
                        <td class="col-qty"><?php echo floatval( $product['qty_ordered'] ); ?> <?php echo esc_html( $product['unit'] ); ?></td>
                        <td class="col-name"><?php echo cwms_trim_chars( $product['name'] ); ?></td>
                        <td class="col-unit_price"><?php echo cwms1661_format_number( $product['retail_price'], 2, ','); ?></td>
                        <td class="col-discount"><?php echo esc_html($product['discount']); ?></td>
                        <td class="col-total text-right"><?php echo cwms1661_format_number( $product['total'], 2, ',' ); ?></td>
                    </tr>
                <?php endforeach; ?>
                <?php $row_space = cwms1661_product_limit() - count($so['_products'] ); ?>
                <?php for ($i=0; $i < $row_space; $i++): ?>
                    <tr >
                        <td class="col-qty">&nbsp;</td>
                        <td class="col-name">&nbsp;</td>
                        <td class="col-unit_price">&nbsp;</td>
                        <td class="col-discount">&nbsp;</td>
                        <td class="col-total">&nbsp;</td>
                    </tr>
                <?php endfor; ?>
            </tbody>
            <tfoot>
                <tr><td colspan="5">&nbsp;</td></tr>
                <tr>
                    <td colspan="4" style="text-align:right;"><?php esc_html_e('SubTotal', 'wpcodigo_wms'); ?></td>
                    <td style="text-align:right;"><?php echo cwms1661_format_number($so['_sub_total'], 2, ',') ; ?></td>
                </tr>
                <tr>
                    <td colspan="4" style="text-align:right;"><?php esc_html_e('COD Discount', 'wpcodigo_wms'); ?></td>
                    <td style="text-align:right;"><?php echo cwms1661_format_number($so['_cod_discount'], 2, ',') ; ?></td>
                </tr>
                <tr>
                    <td colspan="4" style="text-align:right;"><?php esc_html_e('Tax', 'wpcodigo_wms'); ?></td>
                    <td style="text-align:right;"><?php echo cwms1661_format_number($so['_tax'], 2, ',') ; ?></td>
                </tr>
                <tr>
                    <td colspan="4" style="text-align:right;"><?php esc_html_e('Others', 'wpcodigo_wms'); ?></td>
                    <td style="text-align:right;"><?php echo cwms1661_format_number($so['_others'], 2, ',') ; ?></td>
                </tr>
                <tr>
                    <td colspan="4" style="text-align:right;"><?php esc_html_e('Total', 'wpcodigo_wms'); ?></td>
                    <td style="text-align:right;"><?php echo cwms1661_format_number($so['_total_amount'], 2, ',') ; ?></td>
                </tr>
            </tfoot>
        </table>
    </section>
</div>