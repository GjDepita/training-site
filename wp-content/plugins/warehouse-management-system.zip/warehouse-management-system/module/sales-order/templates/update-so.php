<?php
    $so                 = cwms1661_get_so_data( (int)$_GET['id'] );
    $general_settings   = cwms1661_get_general_settings();
    $so_number          = $so['title'];
    $current_date       = $so['_date_created'];
    $is_new             = false;
    $agents             = cwms1661_get_all_users( 'cwms_agent' );
    $whsemans           = cwms1661_get_all_users( 'cwms_whseman' );
    $assigned_agent     = $so['_assigned_agent'];
    $assigned_whseman   = $so['_assigned_whseman'];
    $assigned_term      = $so['_terms'];
    $status_key         = $so['_status_key'];
    include_once apply_filters( "cwms1661_get_template_form-so", CWMS1661_ABSPATH.'module/sales-order/templates/form-so.php' );
?>