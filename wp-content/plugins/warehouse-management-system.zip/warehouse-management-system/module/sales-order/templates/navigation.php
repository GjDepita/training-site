<div class="row">
    <?php foreach ( cwms1661_so_bulk_actions() as $key => $value): ?>
        <?php $is_active = cwms1661_current_status_filter() == $key ? true : false; ?>
        <div class="cwms-po-status animated flipInY col-lg-3 col-md-3 col-sm-6 col-xs-12 <?php echo $is_active ? 'active' : '' ; ?>">
            <a href="<?php echo cwms1661_dashboard_home(); ?>?cwmspage=all-so&status=<?php echo $key; ?>">
                <div class="tile-stats">
                    <div class="icon"><i class="fa <?php echo $is_active ? 'fa-folder-open-o' : 'fa-folder-o' ; ?>"></i>
                    </div>
                    <div class="count"><?php echo cwms1661_format_number( cwms1661_get_status_count( $key, CWMS1661_SO_POST_TYPE ), 0, ',' ); ?></div>
                    <h3><?php echo $value; ?></h3>
                </div>
            </a>
        </div>
    <?php endforeach; ?>
</div>