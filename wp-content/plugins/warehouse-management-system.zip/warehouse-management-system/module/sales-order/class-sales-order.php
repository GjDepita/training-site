<?php
defined( 'ABSPATH' ) || exit;
/**
 * Product
 */
class CWMS1661_Sales_Order {

    public static function init(){
        // Saving PO data
        add_action('wp', array(__CLASS__, 'save_create_so' ));
        add_action( 'save_post_'.CWMS1661_SO_POST_TYPE, array( __CLASS__, 'save_po_post_meta'), 10, 3 );
        add_action('template_redirect', array( __CLASS__, 'save_redirection') );
        // Ajax handlers
        add_action( 'wp_ajax_cwms_get_all_so', array(__CLASS__,  'get_all_so' ) );
        add_action( 'wp_ajax_cwms_delete_so', array(__CLASS__,  'so_delete' ) );
        add_action( 'wp_ajax_cwms_so_bulk_action', array(__CLASS__,  'so_bulk_action' ) );

        // Menu hooks
        add_filter( 'cwms1661_dashboard_menus', array(__CLASS__, 'menu' ) );
        add_filter( 'cwms1661_dashboard_shortcuts_menu', array(__CLASS__, 'shortcuts' ) );
        add_filter( 'cwms1661_registered_dashboard_pages', array(__CLASS__, 'page' ));
         // After page title hook
        //  add_action('cwms1661_after_page_title_view-po', array(__CLASS__, 'all_list_link'));
         add_action('cwms1661_after_page_title_update-so', array(__CLASS__, 'add_new_link'));
         add_action('cwms1661_after_page_title_all-so', array(__CLASS__, 'add_new_link'));
        // Script translation
        add_filter( 'cwms1661_ajax_localize_script_translations', array(__CLASS__,  'script_translations' ) );
        // Template
        add_filter( 'cwms1661_content_template_create-so', array(__CLASS__, 'add_so_template' ) );
        add_filter( 'cwms1661_content_template_all-so', array(__CLASS__, 'all_so_template' ) );
        add_filter( 'cwms1661_content_template_view-so', array(__CLASS__, 'view_so_template' ) );
        add_filter( 'cwms1661_content_template_update-so', array(__CLASS__, 'update_so_template' ) );
        add_action( 'cwms1661_before_so_form', array(__CLASS__, 'notification_message' ) );
        add_action( 'cwms_before_page-all-so', array(__CLASS__, 'page_navigation' ) );

        // Permissions
        add_filter( 'cwms1661_permissions', array(__CLASS__, 'permissions' ) );
        // Print
        add_filter( 'cwms1661_print_html_body_sales-order', array(__CLASS__, 'print' ), 10, 2 );
    }
    public static function save_create_so(){
        if ( ! isset( $_POST['cwms-so_form_nonce'] ) 
            || ! wp_verify_nonce( $_POST['cwms-so_form_nonce'], 'cwms-so_form_action' ) 
        ) {
            return false;
        } 
        $status_list    = array_keys( cwms1661_so_bulk_actions() );
        $post_status    = isset( $_POST['_so_status'] ) && in_array( $_POST['_so_status'], $status_list ) ? sanitize_text_field($_POST['_so_status']) : 'cwms-for-approval' ;

        $so_args    = array(
            'post_title'    => wp_strip_all_tags( $_POST['_so_number'] ),
            'post_status'   => $post_status,
            'post_type'     => CWMS1661_SO_POST_TYPE
        );
        $so_id      = isset($_POST['cwms_so_id']) ? (int)$_POST['cwms_so_id'] : false;
        $is_update  = true;

        if( !$so_id ){
            if( ! cwms1661_can_add_so() ){
                printf( '<div id="message" class="error"><p>%s</p></div>', __('Permission denied. Please contact admin support', 'wpcodigo_wms') );
                wp_die();
            }
            // Insert the post into the database
            $so_id = wp_insert_post( $so_args );
            $is_update = false;
        }else{
            if( ! cwms1661_can_update_so() || !is_cwms1661_post( $so_id, CWMS1661_SO_POST_TYPE ) ){
                printf( '<div id="message" class="error"><p>%s</p></div>', __('Permission denied. Please contact admin support', 'wpcodigo_wms') );
                wp_die();
            }
            // Update po data
            $so_args['ID']  = $so_id;
            unset($so_args['post_title']);
            if( !isset($_POST['_po_status']) ){
                unset($so_args['post_status']);
            }
            $so_id    = wp_update_post( $so_args );
        }
        // Check if process error
        if ( is_wp_error( $so_id ) ) {
            $error_string = $so_id->get_error_message();
            echo '<div id="message" class="error"><p>' . $error_string . '</p></div>';
            wp_die();
        }
        $subpage    = $is_update ? 'update-so' : 'create-so' ;
        $message    = $is_update ? __('updated', 'wpcodigo_wms') : __('created', 'wpcodigo_wms') ;
        $_POST['cwms_so_redirection'] = array(
            'url'       => cwms1661_dashboard_home(),
            'subpage'   => $subpage,
            'id'        => $so_id,
            'message'   => sprintf( __('Sales order #%s successfully %s.', 'wpcodigo_wms'), get_the_title($so_id), $message )
        );
    }
    public static function save_po_post_meta( $post_id, $post, $update ){
        if( isset($_POST['_customer_id']) && (int)$_POST['_customer_id'] ){
            $user_info = get_userdata( (int)$_POST['_customer_id'] );
            update_post_meta( $post_id, '_customer_id', $user_info->ID );
            update_post_meta( $post_id, '_customer_details', cwms1661_get_user_info( $user_info ) );
        }
        if( isset($_POST['cwms_so_products']) && is_array( $_POST['cwms_so_products'] ) ){
            update_post_meta( $post_id, '_products', (array)$_POST['cwms_so_products'] );
        }
        if( isset($_POST['remarks']) ){
            update_post_meta( $post_id, '_remarks', sanitize_textarea_field( $_POST['remarks'] ) );
        }
        if( isset($_POST['terms']) ){
            update_post_meta( $post_id, '_terms', sanitize_textarea_field( $_POST['terms'] ) );
        }
        if( isset($_POST['cod_discount']) ){
            update_post_meta( $post_id, '_cod_discount', floatval($_POST['cod_discount']) );
        }
        if( isset($_POST['tax']) ){
            update_post_meta( $post_id, '_tax', floatval($_POST['tax']) );
        }
        if( isset($_POST['others']) ){
            update_post_meta( $post_id, '_others', floatval($_POST['others']) );
        }
        if( !$update ){
            update_post_meta( $post_id, '_created_by', get_current_user_id() );
        }
        if( isset($_POST['_assigned_agent']) ){
            update_post_meta( $post_id, '_assigned_agent', (int)$_POST['_assigned_agent'] ) ;
        }
        if( isset($_POST['_assigned_whseman']) ){
            update_post_meta( $post_id, '_assigned_whseman', (int)$_POST['_assigned_whseman'] ) ;
        }
    }
    public static function save_redirection(){
        if( !isset($_POST['cwms_so_redirection']) || !is_array($_POST['cwms_so_redirection']) ){
            return false;
        }
        wp_redirect( $_POST['cwms_so_redirection']['url'] .'?cwmspage='. $_POST['cwms_so_redirection']['subpage'] .'&id='. $_POST['cwms_so_redirection']['id'] .'&cwms-message='. urlencode($_POST['cwms_so_redirection']['message']) );
        exit;
    }
    public static function notification_message(){
        if( !isset($_GET['cwmspage']) ){
            return false;
        }
        if( !isset($_GET['cwms-message']) || empty($_GET['cwms-message']) ){
            return false;
        }
        printf('<div class="submit-notification_message alert alert-success">%s</div>', urldecode($_GET['cwms-message']));
        $clear_parameter = ['cwms-message'];
        if( $_GET['cwmspage'] == 'create-so' ){
            $clear_parameter[] = 'id';
        }
        ?>        
        <script>
            window.history.replaceState({}, document.title, '<?php echo cwms1661_dashboard_home().'?'.cwms1661_clean_url_parameter($clear_parameter); ?>' );
            setTimeout(function(){
                jQuery('body').find('.submit-notification_message').remove();
            }, 6000 );
        </script>
        
        <?php
    }
    public static function all_list_link(){
        printf( '<a href="%s" class="btn btn-sm btn-primary">' . __( 'All sales order', 'wpcodigo_wms' ) . '</a>', cwms1661_dashboard_home().'?cwmspage=all-so' );
    }
    public static function menu( $menus ){

        if( !cwms1661_can_access_so() ){
            return $menus;
        }

        $menus[15] = array(
            'id'   => 'sales-order',
            'label' => esc_html__('Sales Order', 'wpcodigo_wms'),
            'classes' => 'fa fa-folder-open-o',
            'subs'  => array(
                'all-so' => esc_html__('All Sales Order', 'wpcodigo_wms'),
                'create-so' => esc_html__('Create Sales Order', 'wpcodigo_wms')
            )
        );
        return $menus;
    }
    public static function shortcuts( $shortcuts ){
        if( !cwms1661_can_access_so() ){
            return $shortcuts;
        }
        $shortcuts[30] = array(
            'page-slug' => 'create-so',
            'label'     => esc_html__('Add new SO', 'wpcodigo_wms'),
            'icon'     => 'fa fa-folder-open-o'
        );
        return $shortcuts;
    }
    public static function script_translations( $translations ){
        $empty_soRepeater = isset( $_GET['cwmspage'] ) && urldecode( $_GET['cwmspage'] ) == 'create-so' ? true : false;
        $translations['soTableData'] = array(
            'id'        => 'cwms_soTable',
            'delete'    => cwms1661_can_delete_so(),
            'headers'   => array_keys( cwms1661_so_table_headers() ),
            'status'    => cwms1661_current_status_filter(),
            'emptyRepeater'    => $empty_soRepeater
        );
        return $translations;
    }
    public static function add_new_link(){
        printf( '<a href="%s" class="btn btn-sm btn-primary">' . __( 'Add new Sales Order', 'wpcodigo_wms' ) . '</a>', cwms1661_dashboard_home().'?cwmspage=create-so' );
    }
    public static function page_navigation(){
        include_once apply_filters( "cwms1661_get_template_all-so-navigation", CWMS1661_ABSPATH.'module/sales-order/templates/navigation.php' );
    }
    public static function page( $pages ){
        $pages['view-so']       = esc_html__('Sales Order details', 'wpcodigo_wms');
        $pages['update-so']     = esc_html__('Update Sales Order', 'wpcodigo_wms');
        return $pages;
    }
    public static function add_so_template(){
        if( ! cwms1661_can_add_so() ){
            return cwms1661_get_template_path('403', 'dashboard');
        }
        return apply_filters( "cwms1661_get_template_create-so", CWMS1661_ABSPATH.'module/sales-order/templates/create-so.php' );
    }
    public static function all_so_template(){
        if( ! cwms1661_can_view_so() ){
            return cwms1661_get_template_path('403', 'dashboard');
        }
        return apply_filters( "cwms1661_get_template_all-so", CWMS1661_ABSPATH.'module/sales-order/templates/all-so.php' );
    }
    public static function view_so_template(){
        if( ! cwms1661_can_view_so() || !isset($_GET['id']) || !is_cwms1661_so($_GET['id']) ){
            return cwms1661_get_template_path('403', 'dashboard');
        }
        return apply_filters( "cwms1661_get_template_view-so", CWMS1661_ABSPATH.'module/sales-order/templates/view-so.php' );
    }
    public static function update_so_template(){

        $can_edited_statuses    = cwms1661_edited_statuses();
        $can_edited_statuses[]  = 'cwms-processing';

        if( ! cwms1661_can_update_so() 
            || ! isset($_GET['id']) 
            || ! is_cwms1661_so($_GET['id']) 
            || ! in_array( get_post_status( $_GET['id'] ), $can_edited_statuses ) ){
            return cwms1661_get_template_path('403', 'dashboard');
        }
        return apply_filters( "cwms1661_get_template_update-so", CWMS1661_ABSPATH.'module/sales-order/templates/update-so.php' );
    }
    // AJAX table data
    public static function get_all_so(){
        $post_status    = $_GET['status'];
        $data           = cwms1661_get_all_so_data( array(  $post_status ) );
        if( $data ){
            $data = array_map( function( $value ) use($post_status) {
                $value['update_link']   = cwms1661_dashboard_home().'?cwmspage=update-so&id='.$value['ID'];
                $value['view_link']     = cwms1661_dashboard_home().'?cwmspage=view-so&id='.$value['ID'];
                $label_url              = esc_url_raw( cwms1661_dashboard_home().'?cwmspage=update-so&id='.$value['ID'] );

                // Allow to update processing SO status
                $can_edited_statuses    = cwms1661_edited_statuses();
                $can_edited_statuses[]  = 'cwms-processing';

                // Assigned Angent
                $actions = [
                    'edit' => sprintf(
                        '<span class="edit"><a class="cwms-update_so text-primary" href="%s">%s</a> ',
                        esc_url_raw( cwms1661_dashboard_home().'?cwmspage=update-so&id='.$value['ID'] ),
                        esc_html__('Edit','wpcodigo_wms')
                    ),
                    'delete' => sprintf(
                        '<span class="trash"><a class="cwms-delete_so text-danger" href="#">%s</a></span>',
                        esc_html__('Delete','wpcodigo_wms')
                    ),
                    'view'  => sprintf(
                        '<span class="view"><a class="text-primary" href="%s">%s</a></span>',
                        esc_url_raw( cwms1661_dashboard_home().'?cwmspage=view-so&id='.$value['ID'] ),
                        esc_html__('View','wpcodigo_wms')
                    )
                ];
                if( !cwms1661_can_delete_so( ) || $post_status != 'cwms-for-approval' ):
                    unset($actions['delete']);
                endif;
                if( !cwms1661_can_update_so() || ! in_array( $post_status, $can_edited_statuses )  ):
                    unset($actions['edit']);
                    $label_url = esc_url_raw( cwms1661_dashboard_home().'?cwmspage=view-so&id='.$value['ID'] );
                endif;
                ob_start();
                ?>
                <strong data-id="<?php echo $value['ID']; ?>">
                    <a href="<?php echo $label_url; ?>"><?php echo $value['_so_number']; ?></a>
                </strong> 
                <div class="row-actions" data-id="<?php echo $value['ID']; ?>">
                    <?php echo implode( ' | ', array_values( $actions ) ) ?>
                </div>
                <?php
                $value['_total_amount'] = cwms1661_format_number( $value['_total_amount'], 2, ',' );
                $value['_so_number'] = ob_get_clean();
                $value['_actions']  = sprintf( '<a href="%s" class="downloadPDF" data-id="%s" data-type="sales-order"><i class="fa fa-2x fa-file-pdf-o" title="%s" style="margin-right:12px;"></i></a>', '#', $value['ID'], __('Download PDF', 'wpcodigo_wms') );
                return $value;
            }, $data );
        }
        wp_send_json( array( 'data' => $data ) );
    }   
    public static function so_delete(){
        $pos_id    = (int)$_POST['soID'];
        if( get_post_status( $pos_id ) != 'cwms-for-approval' 
            || get_post_type( $pos_id ) != CWMS1661_SO_POST_TYPE 
            || ! cwms1661_can_delete_so() ){
            wp_send_json( array(
                'status'    => 'error',
                'code'      => 401,
                'message'   => __('Request error, permission denied!', 'wpcodigo_wms')
            ) );
        }
        wp_trash_post( $pos_id );
        wp_send_json( array( 
            'status'    => 'success',
            'code'      => 200,
            'message'   => __('Request completed', 'wpcodigo_wms')
        ));
        wp_die();
    }
    public static function so_bulk_action(){
        $so_ids         = $_POST['soIds'];
        $action         = $_POST['actionType'];
        $table_data     = $_POST['poTableData'];
        $statuses       = array_keys( cwms1661_po_bulk_actions() );  

        if( $table_data['status'] == 'cwms-for-approval' ){
            $statuses[] = 'cwms-delete';
        }
        if( !in_array( $action, $statuses ) 
            || ( $action == 'cwms-delete' && ! cwms1661_can_delete_so() ) ){
            wp_send_json( array(
                'status' => 'error',
                'message' => __('Request error, permission denied!', 'wpcodigo_wms')
            ) );
        }
        // Checked if there is complete status in the ID list
        $has_complete = array_filter( array_map( function( $id ){
            return get_post_status( $id ) == 'cwms-completed' ;
        },  $so_ids) );

        if( !empty( $has_complete ) ){
            wp_send_json( array(
                'status' => 'error',
                'message' => __('One request has a complete status, permission denied. please reloaded the page and try again.', 'wpcodigo_wms')
            ) );
        }

        foreach ( $so_ids as $id ) {
            if( get_post_type( (int)$id ) != CWMS1661_SO_POST_TYPE  ){
                wp_send_json( array(
                    'status' => 'error',
                    'message' => __('One request is cancelled, permission denied. please reloaded the page and try again.', 'wpcodigo_wms')
                ) );
                break;
            }

            // Delete Sales order
            if( 'cwms-delete' ==  $action ){
                wp_trash_post( $id );
                continue;
            }
            // Update Sales order Status
            $update_post = wp_update_post( array( 'ID' => (int)$id, 'post_status' => $action ) );
            if( is_wp_error( $update_post ) ){
                wp_send_json( array(
                    'status' => 'error',
                    'message' => $update_post->get_error_message()
                ) );
                break;
            }
            do_action( 'cwms1661_after_so_update_status', (int)$id );
        } 

        wp_send_json( array( 
            'status' => 'success',
            'message' => __('Request completed', 'wpcodigo_wms')
        ));
        wp_die();
    }

    public static function permissions( $permissions ){
        $permissions[30] = array(
            'label' => esc_html__('Sales Orders', 'wpcodigo_wms' ),
			'options' => array(
                'cwms1661_can_view_so_roles' => esc_html__('View', 'wpcodigo_wms' ), 
                'cwms1661_can_add_so_roles' => esc_html__('Add', 'wpcodigo_wms' ), 
                'cwms1661_can_update_so_roles' => esc_html__('Edit', 'wpcodigo_wms' ),
                'cwms1661_can_delete_so_roles' => esc_html__('Delete', 'wpcodigo_wms' ),
                // 'cwms1661_can_approve_so_roles' => esc_html__('Receive', 'wpcodigo_wms' )
            )
        );
        return $permissions;
    }

    public static function print( $file_path, $print_id){
        if( !(int)$print_id  ){
            return $file_path;
        }
        return apply_filters( "cwms1661_sales_order_print_template", CWMS1661_ABSPATH.'module/sales-order/templates/print.php' );
    }
}