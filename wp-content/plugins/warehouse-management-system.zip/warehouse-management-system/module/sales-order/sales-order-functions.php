<?php 
defined( 'ABSPATH' ) || exit;

function cwms1661_so_table_headers(){
    $fields = array(
        '_so_number'            => __('SO No.', 'wpcodigo_wms' ),
        '_date_created'         => __('Date Created', 'wpcodigo_wms' ),
        '_customer_company'     => __('Company Name', 'wpcodigo_wms' ),
        '_created_by'           => __('Created By', 'wpcodigo_wms' ),
        '_assigned_agent_name'  => __('Salesman', 'wpcodigo_wms' ),
        '_assigned_whseman_name'  => __('Checked By', 'wpcodigo_wms' ),
        '_total_amount'         => __('Total Amount', 'wpcodigo_wms' ),
        '_actions'             => __('Actions', 'wpcodigo_wms' ),
    );
    return apply_filters( 'cwms1661_so_table_headers', $fields );
}
function cwms1661_so_bulk_actions(){
    $statuses   = cwms1661_post_statuses();
    $options    = [];
    foreach ($statuses as $key => $value) {
        $options[$key] = $value['label'];
    }
    return apply_filters('cwms1661_so_bulk_actions', $options );
}
function is_cwms1661_so( $so_id, $statuses = array() ){
    global $wpdb;
    if( empty($statuses) || !is_array($statuses) ){
        $statuses = array_keys( cwms1661_post_statuses() );
    }
    return $wpdb->get_row( $wpdb->prepare( "SELECT `ID`, `post_status` FROM {$wpdb->posts} WHERE `ID` LIKE %d AND `post_type` LIKE %s AND `post_status` IN ('".implode( "','", $statuses )."') LIMIT 1", $so_id, CWMS1661_SO_POST_TYPE ) );
}
function cwms1661_search_so( $so_number, $statuses = array() ){
    global $wpdb;
    if( empty($statuses) || !is_array($statuses) ){
        $statuses = array_keys( cwms1661_post_statuses() );
    }
    $sql = "SELECT tlbpost.ID";
    $sql .= " FROM {$wpdb->posts} as tlbpost";
    $sql .= " INNER JOIN {$wpdb->postmeta} as tblmeta ON ( tblmeta.post_id = tlbpost.ID AND tblmeta.meta_key LIKE '_customer_id' AND ( SELECT COUNT(*) FROM {$wpdb->users} WHERE `ID` = tblmeta.meta_value ) )";
    $sql .= " WHERE tlbpost.post_title LIKE %s";
    $sql .= " AND `post_type` LIKE %s";
    $sql .= " AND `post_status` IN ('".implode( "','", $statuses )."')";
    $sql = $wpdb->prepare( $sql, '%'.$so_number.'%', CWMS1661_SO_POST_TYPE );
    return $wpdb->get_col( $sql );
}
function cwms1661_search_so_info( $so_number, $statuses = array() ){
    $so_ids = cwms1661_search_so( $so_number, $statuses );
    if( empty( $so_ids ) ){
        return false;
    }
    $data = array();
    foreach ($so_ids as $so_id ) {
        $data[] = cwms1661_get_so_data( $so_id );
    }
    return $data;
}

function cwms1661_get_so_product_total( $products ){
    if( !is_array($products) ){
        return 0;
    }
    return array_reduce( $products, function( $acc, $product ){
        $acc  += $product['total'];
        return $acc;
    });
}
function cwms1661_get_so_data( $post_id ){
    $so_headers = cwms1661_so_table_headers();
    $post       = get_post( $post_id );
    // Remove the title in metakeys
    $products   = maybe_unserialize( get_post_meta( $post->ID, '_products', true  ) );
    array_walk($products, function( &$product, $key ){
        $cost                   = floatval( $product['qty_ordered'] ) * floatval( $product['retail_price'] );
        // $discAmount             = cwms1661_calculate_discount( $product );
        // $product['discount_amount'] = $discAmount;
        // $product['total']       = $cost - $discAmount;
        $product['total']       = cwms1661_calculate_item_cost( $product['qty_ordered'], $product['retail_price'], $product['discount'] );

    });
    $sub_total        = cwms1661_get_so_product_total( $products );
    $date_received    = get_post_meta( $post->ID, '_date_approved', true );
    $customer_details = get_post_meta( $post->ID, '_customer_details', true );
    $customer_name    = !empty( $customer_details ) && is_array( $customer_details ) ? $customer_details['display_name'] : '' ;
    $customer_company = !empty( $customer_details ) && is_array( $customer_details ) ? $customer_details['_company'] : '' ;
    $data       = [ 
        'ID'                => $post->ID, 
        'title'             => $post->post_title,
        '_so_number'        => $post->post_title,
        '_products'         => $products,
        '_status_key'       => $post->post_status,
        '_status'           => cwms1661_post_statuses()[$post->post_status]['label'],
        '_remarks'          => get_post_meta( $post->ID, '_remarks', true ),
        '_terms'            => get_post_meta( $post->ID, '_terms', true ),
        '_date_approved'    => '',
        '_cod_discount'     => floatval( get_post_meta( $post->ID, '_cod_discount', true ) ),
        '_tax'              => floatval( get_post_meta( $post->ID, '_tax', true ) ),
        '_others'           => floatval( get_post_meta( $post->ID, '_others', true ) ),
        '_customer_id'      => get_post_meta( $post->ID, '_customer_id', true ),
        '_customer'         => $customer_name,
        '_customer_company' => $customer_company,
        '_customer_details' => $customer_details,
        '_total_amount'     => 0,
        '_sub_total'        => $sub_total,
        '_received_by'      => '',
        '_date_received'    => '',
        '_assigned_agent'   => (int)get_post_meta( $post->ID, '_assigned_agent', true ),
        '_assigned_whseman' => (int)get_post_meta( $post->ID, '_assigned_whseman', true )
    ]; 
    if( $date_received ){
        $data['_date_approved'] = date( cwms1661_datetime_format(), strtotime($date_received) );
    }
    $data['_assigned_agent_name']   = $data['_assigned_agent'] ? cwms1661_user_fullname( $data['_assigned_agent'] ) : '';
    $data['_assigned_whseman_name'] = $data['_assigned_whseman'] ? cwms1661_user_fullname( $data['_assigned_whseman'] ) : '';

    foreach( array_keys($so_headers) as $metakey ){
        if( $metakey == '_date_created' ){
            $data[$metakey] = get_the_date(cwms1661_datetime_format(), $post->ID);
            continue;
        }
        if( $metakey == '_created_by' ){
            $data[$metakey] = cwms1661_user_fullname( $post->post_author );
            continue;
        }
        if( $metakey == '_received_by' ){
            $data[$metakey] = get_post_meta( $post->ID, '_received_by', true );
            continue;
        }
        if( $metakey == '_date_received' ){
            $data[$metakey] = get_post_meta( $post->ID, '_date_received', true );
            continue;
        }
        if( $metakey == '_supplier' ){
            $data[$metakey]     = $data['_supplier_details']['_company_name'];
            continue;
        }
        if( $metakey == '_total_amount' ){
            $total_amount   = ( $data['_sub_total'] + $data['_tax'] + $data['_others'] ) -  $data['_cod_discount'] ;
            $data[$metakey] = cwms1661_format_number( floatval($total_amount) );
        }
    }

    return apply_filters('cwms1661_get_so_data', $data, $post_id );
}
function cwms1661_get_all_so_data( $post_status = array(), $page = null, $limit = 12  ){
    global $wpdb;
    $post_status = array_filter( (array)$post_status );
    $offset      = 0;
    if( empty( $post_status ) || !is_array( $post_status ) ){
        $post_status = array_keys( cwms1661_post_statuses() );
    }
    $parameter = array( CWMS1661_SO_POST_TYPE );
    $sql = "SELECT `ID` as 'id'";
    $sql .= " FROM {$wpdb->posts}";
    $sql .= " WHERE `post_status`  IN ('".implode( "','", $post_status )."') AND `post_type` LIKE %s";
    if( $page ){
        $offset = ($page - 1) * $limit;
        $sql .= " LIMIT %d OFFSET %d";
        $parameter = array_merge( $parameter, array( $limit, $offset ) );
    }
    $sql     = $wpdb->prepare( $sql, $parameter);
    $results = $wpdb->get_col( apply_filters( 'cwms1661_get_all_so_data_sql', $sql, $limit, $offset ) );
    if( empty($results) ){
        return false;
    }
    $data = [];
    foreach ($results as $post_id ) {
        $data[] = cwms1661_get_so_data( $post_id );
    }
    return $data;
}
// Restriction functions
function cwms1661_can_access_so(){
    if(
        cwms1661_can_view_so() 
        || cwms1661_can_add_so() 
        || cwms1661_can_update_so() 
        || cwms1661_can_delete_so() 
        || cwms1661_can_approve_so()
    ){
        return true;
    }
    return false;
}

function cwms1661_can_view_so_roles(){
    $assinged_roles     = get_option( 'cwms1661_can_view_so_roles', null );
    if( $assinged_roles === null ){
        $assinged_roles = array( 'cwms_manager', 'cwms_encoder', 'cwms_agent' );
    }
    $assinged_roles[]   = 'administrator';
    return $assinged_roles;
}
function cwms1661_can_view_so(){
    if( !is_user_logged_in() ){
        return false;
    }
    $allowed_roles = apply_filters('cwms1661_can_view_so_roles', cwms1661_can_view_so_roles() );
    return array_intersect( $allowed_roles,  cwms1661_current_user_roles() ) ? true : false ;
}
function cwms1661_can_add_so_roles(){
    $assinged_roles     = get_option( 'cwms1661_can_add_so_roles', null );
    if( $assinged_roles === null ){
        $assinged_roles = array( 'cwms_manager', 'cwms_encoder', 'cwms_agent' );
    }
    $assinged_roles[]   = 'administrator';
    return $assinged_roles;
}
function cwms1661_can_add_so(){
    if( !is_user_logged_in() ){
        return false;
    }
    $allowed_roles = apply_filters('cwms1661_can_add_so_roles', cwms1661_can_add_so_roles() );
    return array_intersect( $allowed_roles,  cwms1661_current_user_roles() ) ? true : false ;
}
function cwms1661_can_update_so_roles(){
    $assinged_roles     = get_option( 'cwms1661_can_update_so_roles', null );
    if( $assinged_roles === null ){
        $assinged_roles = array( 'cwms_manager', 'cwms_encoder', 'cwms_agent' );
    }
    $assinged_roles[]   = 'administrator';
    return $assinged_roles;
}
function cwms1661_can_update_so(){
    if( !is_user_logged_in() ){
        return false;
    }
    $allowed_roles = apply_filters('cwms1661_can_update_so_roles', cwms1661_can_update_so_roles() );
    return array_intersect( $allowed_roles,  cwms1661_current_user_roles() ) ? true : false ;
}
function cwms1661_can_delete_so_roles(){
    $assinged_roles     = get_option( 'cwms1661_can_delete_so_roles', null );
    if( $assinged_roles === null ){
        $assinged_roles = array( 'cwms_manager' );
    }
    $assinged_roles[]   = 'administrator';
    return $assinged_roles;
}
function cwms1661_can_delete_so(){
    if( !is_user_logged_in() ){
        return false;
    }
    $allowed_roles = apply_filters('cwms1661_can_delete_so_roles', cwms1661_can_delete_so_roles() );
    return array_intersect( $allowed_roles,  cwms1661_current_user_roles() ) ? true : false ;
}
function cwms1661_can_approve_so_roles(){
    $assinged_roles     = get_option( 'cwms1661_can_approve_so_roles', null );
    if( $assinged_roles === null ){
        $assinged_roles = array( 'cwms_manager' );
    }
    $assinged_roles[]   = 'administrator';
    return $assinged_roles;
}
function cwms1661_can_approve_so(){
    if( !is_user_logged_in() ){
        return false;
    }
    $allowed_roles = apply_filters('cwms1661_can_approve_so_roles', cwms1661_can_approve_so_roles() );
    return array_intersect( $allowed_roles,  cwms1661_current_user_roles() ) ? true : false ;
}
function cwms1661_generate_so_number(){
    $numdigit  	= apply_filters('cwms1661_generate_po_digit', 12 );
    $numstr     = '';
    for ( $i = 1; $i < $numdigit; $i++ ) {
        $numstr .= 9;
    }
    $so_numebr = str_pad( wp_rand( 0, $numstr ), $numdigit, "0", STR_PAD_LEFT );
    return apply_filters( 'cwms1661_generate_so_number', $so_numebr );
}