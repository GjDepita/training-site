<?php
/**
 * Post Types
 *
 * Registers post types and taxonomies.
 */

defined( 'ABSPATH' ) || exit;

/**
 * Post types Class.
 */
class CWMS1661_SO_POST_TYPE {

    public static function register_post_type(){
        if ( post_type_exists( CWMS1661_SO_POST_TYPE ) ) {
			return;
		}
        $supports   = apply_filters( 'cwms1661_post_type_support', array( ) );
        $debug      = apply_filters( 'cwms1661_post_type_debug', false );
        // Register Custom Post Type
        $po_labels = array(
            'name'                  => _x( 'Sales Orders', 'Post Type General Name', 'wpcodigo_wms' ),
            'singular_name'         => _x( 'Sales Order', 'Post Type Singular Name', 'wpcodigo_wms' ),
            'menu_name'             => __( 'Sales Orders', 'wpcodigo_wms' ),
            'name_admin_bar'        => __( 'Sales Order', 'wpcodigo_wms' ),
            'archives'              => __( 'Sales Order Archives', 'wpcodigo_wms' ),
            'attributes'            => __( 'Sales Order Attributes', 'wpcodigo_wms' ),
            'parent_item_colon'     => __( 'Parent Sales Order:', 'wpcodigo_wms' ),
            'all_items'             => __( 'All Sales Orders', 'wpcodigo_wms' ),
            'add_new_item'          => __( 'Add New Sales Order', 'wpcodigo_wms' ),
            'add_new'               => __( 'Add New', 'wpcodigo_wms' ),
            'new_item'              => __( 'New Sales Order', 'wpcodigo_wms' ),
            'edit_item'             => __( 'Edit Sales Order', 'wpcodigo_wms' ),
            'update_item'           => __( 'Update Sales Order', 'wpcodigo_wms' ),
            'view_item'             => __( 'View Sales Order', 'wpcodigo_wms' ),
            'view_items'            => __( 'View Sales Order', 'wpcodigo_wms' ),
            'search_items'          => __( 'Search Sales Order', 'wpcodigo_wms' ),
            'not_found'             => __( 'Not found', 'wpcodigo_wms' ),
            'not_found_in_trash'    => __( 'Not found in Trash', 'wpcodigo_wms' ),
            'featured_image'        => __( 'Featured Image', 'wpcodigo_wms' ),
            'set_featured_image'    => __( 'Set featured image', 'wpcodigo_wms' ),
            'remove_featured_image' => __( 'Remove featured image', 'wpcodigo_wms' ),
            'use_featured_image'    => __( 'Use as featured image', 'wpcodigo_wms' ),
            'insert_into_item'      => __( 'Insert into Sales Order', 'wpcodigo_wms' ),
            'uploaded_to_this_item' => __( 'Uploaded to this Sales Order', 'wpcodigo_wms' ),
            'items_list'            => __( 'Sales Orders list', 'wpcodigo_wms' ),
            'items_list_navigation' => __( 'Sales Orders list navigation', 'wpcodigo_wms' ),
            'filter_items_list'     => __( 'Filter Sales Orders list', 'wpcodigo_wms' ),
        );
        $po_args = array(
            'label'                 => __( 'Sales Order', 'wpcodigo_wms' ),
            'description'           => __( 'Sales Order', 'wpcodigo_wms' ),
            'labels'                => $po_labels,
            'supports'              => $supports,
            'taxonomies'            => array(),
            'hierarchical'          => false,
            'public'                => false,
            'show_ui'               => $debug,
            'show_in_menu'          => $debug,
            'menu_position'         => 5,
            'show_in_admin_bar'     => $debug,
            'show_in_nav_menus'     => $debug,
            'rewrite'               => false,
            'can_export'            => true,
            'has_archive'           => false,
            'exclude_from_search'   => true,
            'publicly_queryable'    => false,
            'capability_type'       => 'post',
        );
        register_post_type( CWMS1661_SO_POST_TYPE, apply_filters( 'cwms_register_so_post_type', $po_args ) );
    }
}