<?php 
defined( 'ABSPATH' ) || exit;
// Permissions #####
function cwms1661_can_view_rtv_roles(){
    $assinged_roles     = get_option( 'cwms1661_can_view_rtv_roles', null );
    if( $assinged_roles === null ){
        $assinged_roles = array( 'cwms_manager', 'cwms_encoder' );
    }
    $assinged_roles[]   = 'administrator';
    return $assinged_roles;
}
function cwms1661_can_view_rtvs(){
    if( !is_user_logged_in() ){
        return false;
    }
    $allowed_roles = apply_filters('cwms1661_can_view_rtv_roles', cwms1661_can_view_rtv_roles() );
    return array_intersect( $allowed_roles,  cwms1661_current_user_roles() ) ? true : false ;
}
function cwms1661_can_access_rtvs(){
    if(
        cwms1661_can_view_rtvs() 
    ){
        return true;
    }
    return false;
}
// Function helpers
function cwms1661_rtv_table_headers(){
    $fields = array(
        'name'              => __('Product Name', 'wpcodigo_wms' ),
        'created_by'        => __('Created by', 'wpcodigo_wms' ),
        'created_on'        => __('Date created', 'wpcodigo_wms' ),
        'return_number'     => __('Return Number', 'wpcodigo_wms' ),
        'invoice_number'    => __('Invoice Number', 'wpcodigo_wms' ),
        'qty_returned'      => __('Returned Qty.', 'wpcodigo_wms' ),
        'remarks'           => __('Remarks', 'wpcodigo_wms' ),
    );
    return apply_filters( 'cwms1661_rtv_table_headers', $fields );
}
function cwms1661_rsvn_current_status_filter(){
    if( isset($_GET['status']) 
        && in_array( urldecode($_GET['status']), array_keys( cwms1661_post_statuses() ) ) 
        && urldecode($_GET['status']) != 'cwms-completed' ){
            return urldecode($_GET['status']);
    }
    return 'cwms-completed';
}
function cwms1661_format_rtv_data( $data ){
    array_walk($data, function( &$data, $key ){ 
        $created_on                 = date( cwms1661_datetime_format(), strtotime($data['created_date']) );
        $data['created_on']         = $created_on;
        $data['return_number']      = get_the_title( $data['return_id'] );
        $data['invoice_number']     = get_the_title( $data['invoice_id'] );
    });
    return $data;
}
function cwms1661_get_all_rtv_items( $limit = null, $offset = 0  ){
    global $wpdb;
    $table  = $wpdb->prefix.CWMS1661_TBL_RTV_ITEMS;
    $sql    = "SELECT * FROM {$table}";
    $sql    .= " ORDER BY `ID` DESC";
    if( $limit ){
        $sql .= " LIMIT %d OFFSET %d";
        return $wpdb->get_results( $wpdb->prepare( $sql, array( $limit, $offset ) ) );
    }
    return $wpdb->get_results( $sql, ARRAY_A );
}

function cwms1661_add_rtv_item( $data ){
    global $wpdb;
    if( ! is_cwms1661_product( $data['product_id'] ) ){
        return false;
    }

    $table          = $wpdb->prefix.CWMS1661_TBL_RTV_ITEMS;
    $inserted_row   = $wpdb->insert($table,
        array(
            'pullout_no'     => sanitize_text_field( $data['pullout_no'] ),
            'return_id'     => (int)$data['return_id'], 
            'invoice_id'    => (int)$data['invoice_id'], 
            'created_by'    => sanitize_text_field( $data['created_by'] ), 
            'product_id'    => (int)$data['product_id'],
            'name'          => sanitize_text_field( $data['name'] ),
            'retail_price'  => sanitize_text_field( $data['retail_price'] ),
            'cost_price'    => sanitize_text_field( $data['cost_price'] ),
            'qty_returned'  => sanitize_text_field( $data['qty_returned'] ),
            'remarks'       => sanitize_text_field( $data['remarks'] ),
        ),
        array( '%d', '%d', '%d', '%s', '%d', '%s', '%f', '%f', '%f', '%s' )
    );
    if( !$inserted_row ){
        return false;
    }
    return $wpdb->insert_id;
}