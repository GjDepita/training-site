<?php
defined( 'ABSPATH' ) || exit;
/**
 * Invoice
 */

class CWMS1661_RTV {
    public static function init(){
        // Menu hooks
        add_filter( 'cwms1661_dashboard_menus', array(__CLASS__, 'menu' ) );
        add_filter( 'cwms1661_registered_dashboard_pages', array(__CLASS__, 'page' ));

        // Script translation
        add_filter( 'cwms1661_ajax_localize_script_translations', array(__CLASS__,  'script_translations' ) );

        // Page Template
        add_filter( 'cwms1661_content_template_rtvs', array(__CLASS__, 'all_rtvs_template' ) );
        add_filter( 'cwms1661_content_template_view-rtv', array(__CLASS__, 'view_rtv_template' ) );
        add_filter( 'cwms1661_content_template_create-rtv', array(__CLASS__, 'create_rtv_template' ) );
        add_action( 'cwms1661_before_rtv_form', array(__CLASS__, 'notification_message' ) );

        // After page title
        add_action('cwms1661_after_page_title_create-rtv', array(__CLASS__, 'all_list_link'));
        add_action('cwms1661_after_page_title_view-rtv', array(__CLASS__, 'all_list_link'));

        // Saving
        add_action( 'wp', array( __CLASS__, 'create_rtv_invoice'), 99, 1 );

        // Redirection
        add_action('template_redirect', array( __CLASS__, 'save_redirection') );

        // Ajax handlers
        // add_action( 'wp_ajax_cwms_search_rtv_invoice', array(__CLASS__,  'search_rtv_invoice' ) );
        add_action( 'wp_ajax_cwms_get_all_rtvs', array(__CLASS__,  'get_all_rtvs' ) );

        // Permissions
        add_filter( 'cwms1661_permissions', array(__CLASS__, 'permissions' ) );

        // Print
        add_filter( 'cwms1661_print_html_body_rtv', array(__CLASS__, 'print' ), 10, 2 );
    }

    // Menu hooks callback
    public static function menu( $menus ){
        if( !cwms1661_can_access_rtvs() ){
            return $menus;
        }

        $menus[27] = array(
            'id'   => 'rtvs',
            'label' => esc_html__("RTV's", 'wpcodigo_wms'),
            'classes' => 'fa fa-ticket',
            'subs'  => array(
                'rtvs' => esc_html__("All RTV's", 'wpcodigo_wms')
            )
        );
        return $menus;
    }
    public static function page( $pages ){
        $pages['rtvs']           = esc_html__('All rtvs', 'wpcodigo_wms');
        $pages['view-rtv']       = esc_html__('rtv Details', 'wpcodigo_wms');
        return $pages;
    }

    // Page callback
    public static function all_rtvs_template(){
        if( ! cwms1661_can_view_rtvs() ){
            return cwms1661_get_template_path('403', 'dashboard');
        }
        return apply_filters( "cwms1661_get_template_all-rtvs", CWMS1661_ABSPATH.'module/rtv/templates/all-rtvs.php' );
    }
    public static function view_rtv_template(){
        if( ! cwms1661_can_view_rtvs() || !isset( $_GET['id']) ){
            return cwms1661_get_template_path('403', 'dashboard');
        }
        return apply_filters( "cwms1661_get_template_view-rtv", CWMS1661_ABSPATH.'module/rtv/templates/view-rtv.php' );
    }
    public static function create_rtv_template(){
        if( ! cwms1661_can_create_rtv() ){
            return cwms1661_get_template_path('403', 'dashboard');
        }
        return apply_filters( "cwms1661_get_template_create-rtv", CWMS1661_ABSPATH.'module/rtv/templates/create-rtv.php' );
    }

    // After page title Callback
    public static function all_list_link(){
        printf( '<a href="%s" class="btn btn-sm btn-primary">' . __( "All RTV's", 'wpcodigo_wms' ) . '</a>', cwms1661_dashboard_home().'?cwmspage=rtvs' );
    }

    // Script Translation callback
    public static function script_translations( $translations ){
        $translations['rtvTable'] = array(
            'id'            => 'cwms_rtvTable',
            'reportLabel'   => __( "RTV Report", 'wpcodigo_wms' ),
            'headers'       => array_keys( cwms1661_rtv_table_headers() )
        );
        return $translations;
    }


    public static function notification_message(){
        if( !isset($_GET['cwmspage']) ){
            return false;
        }
        if( !isset($_GET['cwms-message']) || empty($_GET['cwms-message']) ){
            return false;
        }
        printf('<div class="submit-notification_message alert alert-success">%s</div>', urldecode($_GET['cwms-message']));
        ?>        
        <script>
            window.history.replaceState({}, document.title, '<?php echo cwms1661_dashboard_home().'?'.cwms1661_clean_url_parameter(['cwms-message']); ?>' );
            setTimeout(function(){
                jQuery('body').find('.submit-notification_message').remove();
            }, 6000 );
        </script>
        
        <?php
    }

    // Saving Callback
    public static function create_rtv_invoice( ){

    }

    // AJAX Callback
    public static function get_all_rtvs(){
        $rtv_items = cwms1661_get_all_rtv_items();
        $data = [];
        if( !empty($rtv_items) ){
            $data = cwms1661_format_rtv_data( $rtv_items );  
        }
        wp_send_json( array( 'data' => $data ) );
    }  

    public static function save_redirection(){
      
    }

    // Print callback
    public static function print( $file_path, $print_id ){
        if( !(int)$print_id  ){
            return $file_path;
        }
        return apply_filters( "cwms1661_rtv_print_template", CWMS1661_ABSPATH.'module/rtv/templates/print.php' );
    }

    // Permission Callback
    public static function permissions( $permissions ){
        return $permissions;
    }
}