<?php
    $reservation        = [];
    $general_settings   = cwms1661_get_general_settings();
    $reservation_number = cwms1661_generate_reservation_number();
    $current_date       = cwms1661_current_date();
    $is_new             = true;
    $agents             = cwms1661_get_all_users( 'cwms_agent' );
    $assigned_agent     = null;
    include_once apply_filters( "cwms1661_get_template_form-reservation", CWMS1661_ABSPATH.'module/reservation/templates/form-reservation.php' );
?>