<?php
$reservation        = cwms1661_get_reservation_data( (int)$print_id );
$reservation_number = $reservation['title'];
$current_date       = $reservation['_date_created'];
$general_settings   = cwms1661_get_general_settings();
?>
<div class="col-md-offset-1 col-md-10 col-sm-12">
    <table style="margin-bottom:48px;">
        <!-- header -->
        <tr>
            <td style="width:50%;">
                <?php if($general_settings['_company_logo']):  ?>
                    <img src="<?php echo $general_settings['_company_logo']; ?>" alt="<?php echo $general_settings['_company_name']; ?>" width="210">
                <?php endif; ?>
            </td>
            <td style="width:50%; text-align:right;">
                <h1><?php esc_html_e('RESERVATION REQUEST', 'wpcodigo_wms'); ?></h1>
                <?php esc_html_e('DATE', 'wpcodigo_wms'); ?>: <?php echo $current_date; ?><br/>
                <span class="cwms-reservation_number"><?php esc_html_e('Reservation', 'wpcodigo_wms'); ?>#: <?php echo $reservation_number; ?></span>
            </td>
        </tr>
        <tr><td colspan="2" style="padding: 18px;">&nbsp;</td></tr>
        <!-- Vendors Information -->
        <tr>
            <td style="width:50%;">
                <h3 class="info-header bg-header"><?php esc_html_e('Customer', 'wpcodigo_wms'); ?> <span class="cwms-search-customer fa fa-users text-primary" aria-hidden="true" data-toggle="modal" data-target="#cwms-search-customer-modal" style="font-size: 1.2em;float: right;"></span></h3>
                <div id="cwms-customer-details">
                    <strong><?php echo $reservation['_customer_company']; ?></strong><br/>
                    <span class="contact-name"><?php echo $reservation['_customer']; ?></span><br/>
                    <?php echo cwms1661_display_address_html( $reservation['_customer_details'] ); ?><br/>
                    <?php echo $reservation['_customer_details']['_phone']; ?><br/>
                    <?php echo $reservation['_customer_details']['_email']; ?>
                </div>
            </td>
            <td style="width:50%;">&nbsp;</td>
        </tr>
    </table>
    
    <section id="product-info" class="table-responsive cwms_invoice_items" style="margin-bottom:48px;">
        <table id="cwms-poitems-table" class="bordered min-space header-black font-small">
            <thead>
                <tr>
                    <th><?php esc_html_e('SKU', 'wpcodigo_wms'); ?></th>
                    <th><?php esc_html_e('Name', 'wpcodigo_wms'); ?></th>
                    <th class="cwms-input-header"><?php esc_html_e('Qty', 'wpcodigo_wms'); ?></th>
                    <th ><?php esc_html_e('Unit', 'wpcodigo_wms'); ?></th>
                    <th ><?php esc_html_e('Retail Price', 'wpcodigo_wms'); ?></th>
                    <th ><?php esc_html_e('Total', 'wpcodigo_wms'); ?></th>
                </tr>
            </thead>
            <tbody data-repeater-list="cwms_reservation_products">
                <?php foreach ($reservation['_products'] as $product): ?>
                    <tr data-repeater-item>
                        <td class="col-upc"><?php echo $product['upc']; ?></td>
                        <td class="col-name"><?php echo $product['name']; ?></td>
                        <td class="col-qty"><?php echo $product['qty_ordered']; ?></td>
                        <td class="col-unit"><?php echo $product['unit']; ?></td>
                        <td class="col-unit"><?php echo cwms1661_format_number( $product['retail_price'] ); ?></td>
                        <td class="col-unit"><?php echo cwms1661_format_number( $product['total'] ); ?></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </section>
    <div class="row" id="amount-breakdown">
        <table>
            <tr>
                <td style="width:50%">
                    <p class="lead"><?php esc_html_e('Remarks', 'wpcodigo_wms'); ?>:</p>
                    <?php echo nl2br( $reservation['_remarks'] ) ; ?>
                </td>
                <td style="width:50%">
                    <p class="lead"><?php esc_html_e('Reservation Amount', 'wpcodigo_wms'); ?></p>
                    <div class="table-responsive">
                        <table id="cwms-amountdue-table" class="bordered min-space header-black font-small">
                            <tbody>
                                <tr>
                                    <th class="text-right"><?php esc_html_e('Reservation Total', 'wpcodigo_wms'); ?>:</th>
                                    <td class="amount_due_total text-right"><?php echo cwms1661_format_number( $reservation['_total_amount'] ) ; ?></td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </td>
            </tr>
        </table>
    </div>
    <div class="ln_solid"></div>
    <section id="action-section" style="margin-top:36px;">
        <div class="col-md-6 form-group">
            <table>
                <tr>
                    <td style="width:50%"><strong><?php esc_html_e('Prepared by'); ?>:</strong> <?php echo $reservation['_created_by']; ?></td>
                    <td style="width:50%; text-align:right;" ><strong><?php esc_html_e('Assigned Agent'); ?>: </strong> <?php echo $reservation['_assigned_agent_name']; ?></td>
                </tr>
            </table>
        </div>
    </section>
</div>