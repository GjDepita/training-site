<div class="col-md-offset-1 col-md-10 col-sm-12">
    <?php do_action('cwms1661_before_reservation_form', $reservation ); ?>
    <form id="cwms-reservation_form" class="form-horizontal form-label-left input_mask" action="" method="POST">
        <?php wp_nonce_field( 'cwms-reservation_form_action', 'cwms-reservation_form_nonce' ); ?>
        <input type="submit" style="display:none !important;" value="<?php esc_html_e('Create Reservation', 'wpcodigo_wms'); ?>">
        <?php if( ! $is_new ): ?>
            <input type="hidden" name="cwms_reservation_id" value="<?php echo (int)$reservation['ID']; ?>">
        <?php endif; ?>
        <!-- Header -->
        <section id="po-header-section" class="row" style="margin-bottom:18px;">
            <div class="col-md-6 col-sm-12">
                <?php if($general_settings['_company_logo']):  ?>
                    <img src="<?php echo $general_settings['_company_logo']; ?>" alt="<?php echo $general_settings['_company_name']; ?>" width="210">
                <?php endif; ?>
            </div>
            <div class="col-md-6 col-sm-12 text-right">
                <h1><?php esc_html_e('RESERVATION REQUEST', 'wpcodigo_wms'); ?></h1>
                <?php esc_html_e('DATE', 'wpcodigo_wms'); ?>: <?php echo $current_date; ?><br/>
                <span class="cwms-reservation_number"><?php esc_html_e('Reservation', 'wpcodigo_wms'); ?>#: <?php echo $reservation_number; ?></span>
                <input type="hidden" name="_reservation_number" value="<?php echo $reservation_number; ?>">
            </div>
        </section>
        <!-- Vendors Information -->
        <section id="customer-info-section" class="row" style="margin-bottom:18px;">
            <div class="col-md-6 col-sm-12">
                <h3 class="info-header bg-header"><?php esc_html_e('Customer', 'wpcodigo_wms'); ?> <span class="cwms-search-customer fa fa-users text-primary" aria-hidden="true" data-toggle="modal" data-target="#cwms-search-customer-modal" style="font-size: 1.2em;float: right;"></span></h3>
                <div id="cwms-customer-details">
                    <?php if( $is_new || !$reservation['_customer'] ): ?>
                        <section class="customer-details_placeholder" data-toggle="modal" data-target="#cwms-search-customer-modal">
                            <?php esc_html_e('Search Customer/Company', 'wpcodigo_wms'); ?>
                        </section>
                    <?php else: ?>
                        <strong><?php echo $reservation['_customer_company']; ?></strong><br/>
                        <span class="contact-name"><?php echo $reservation['_customer']; ?></span><br/>
                        <?php echo cwms1661_display_address_html( $reservation['_customer_details'] ); ?><br/>
                        <?php echo $reservation['_customer_details']['_phone']; ?><br/>
                        <?php echo $reservation['_customer_details']['_email']; ?>
                        <input type="hidden" name="_customer_id" value="<?php echo (int)$reservation['_customer_details']['ID']; ?>">
                    <?php endif; ?>
                </div>
            </div>
        </section>
        <section id="product-info" class="table-responsive cwms_reservation_items">
            <div id="table-select-action">
                <select id="cwms-search_product" class="cwms-select2-search form-control form-control-sm" data-action="cwms_product_options" style="width: 280px;float:right;" aria-placeholder="<?php esc_html_e('Search Product', 'wpcodigo_wms'); ?>">
                    <option value=""><?php esc_html_e('Search Product', 'wpcodigo_wms'); ?></option>
                </select>
                <button data-repeater-create type="button" class="btn btn-sm btn-primary" style="height: 34px;" disabled><?php esc_html_e('Add Item', 'wpcodigo_wms'); ?></button>
            </div>
            <table id="cwms-rsvnitems-table" class="table table-sm table-hover">
                <thead>
                    <tr>
                        <th colspan="2"><?php esc_html_e('SKU', 'wpcodigo_wms'); ?></th>
                        <th><?php esc_html_e('Name', 'wpcodigo_wms'); ?></th>
                        <th class="cwms-input-header"><?php esc_html_e('Qty', 'wpcodigo_wms'); ?></th>
                        <th ><?php esc_html_e('Unit', 'wpcodigo_wms'); ?></th>
                        <th ><?php esc_html_e('Retail Price', 'wpcodigo_wms'); ?></th>
                        <th ><?php esc_html_e('Total', 'wpcodigo_wms'); ?></th>
                    </tr>
                </thead>
                <tbody data-repeater-list="cwms_reservation_products">
                    <?php if( $is_new ): ?>
                        <tr data-repeater-item>
                            <td class="col-delete" style="width:24px;">
                                <i data-repeater-delete class="fa fa-trash text-danger"></i>
                                <input type="hidden" data-name="product_id" name="product_id">
                                <input type="hidden" data-name="upc" name="upc">
                                <input type="hidden" data-name="name" name="name">
                                <input type="hidden" data-name="unit" name="unit">
                                <input type="hidden" data-name="retail_price" name="retail_price">
                            </td>
                            <td class="col-upc">&nbsp;</td>
                            <td class="col-name">&nbsp;</td>
                            <td class="col-qty"><input type="text" class="cmws-number cwms-calculate" data-name="qty" name="qty_ordered" value="1" /> </td>
                            <td class="col-unit">&nbsp;</td>
                            <td class="col-retail_price">&nbsp;</td>
                            <td class="col-total">&nbsp;</td>
                        </tr>
                    <?php else: ?>
                        <?php foreach ($reservation['_products'] as $product): ?>
                            <tr data-repeater-item>
                                <td class="col-delete" style="width:24px;">
                                    <i data-repeater-delete class="fa fa-trash text-danger"></i>
                                    <input type="hidden" data-name="product_id" name="product_id" value="<?php echo $product['product_id']; ?>">
                                    <input type="hidden" data-name="upc" name="upc" value="<?php echo $product['upc']; ?>">
                                    <input type="hidden" data-name="name" name="name" value="<?php echo $product['name']; ?>">
                                    <input type="hidden" data-name="unit" name="unit" value="<?php echo $product['unit']; ?>">
                                    <input type="hidden" data-name="unit" name="retail_price" value="<?php echo $product['retail_price']; ?>">
                                </td>
                                <td class="col-upc"><?php echo $product['upc']; ?></td>
                                <td class="col-name"><?php echo $product['name']; ?></td>
                                <td class="col-qty"><input type="text" class="cmws-number cwms-calculate" data-name="qty" name="qty_ordered" value="<?php echo $product['qty_ordered']; ?>" /></td>
                                <td class="col-unit"><?php echo $product['unit']; ?></td>
                                <td class="col-retail_price"><?php echo $product['retail_price']; ?></td>
                                <td class="col-total"><?php echo $product['total']; ?></td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </section>
        <div class="row" id="amount-breakdown" style="margin-top:18px">
            <!-- Remarks column -->
            <div class="col-xs-6">
                <p class="lead"><?php esc_html_e('Remarks', 'wpcodigo_wms'); ?>:</p>
                <textarea name="remarks" rows="6" style="width:100%;" placeholder="<?php esc_html_e('Add remarks here.', 'wpcodigo_wms'); ?>"><?php echo $is_new ? '' : $reservation['_remarks'] ; ?></textarea>
            </div>
            <!-- /.col -->
            <div class="col-xs-6">
                <p class="lead"><?php esc_html_e('Amount Due', 'wpcodigo_wms'); ?></p>
                <div class="table-responsive">
                    <table id="cwms-amountdue-table" class="table">
                        <tbody>
                            <tr>
                                <th class="text-right"><?php esc_html_e('Total', 'wpcodigo_wms'); ?>:</th>
                                <td class="amount_due_total"><?php echo $is_new ? 0.00 : cwms1661_format_number( $reservation['_total_amount'] ) ; ?></td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
            <!-- /.col -->
        </div>
        <div class="ln_solid"></div>
        <section id="action-section">
            <div class="col-md-6 form-group">
                <?php if( $agents ): ?>
                    <label for="cwms-search_agent" style="margin-right:12px;"><?php esc_html_e('Assign Agent', 'wpcodigo_wms'); ?></label>
                    <select id="cwms-search_agent" class="form-control form-control-sm cwms-select2" style="width: 280px; display: inline-block;" name="_assigned_agent" required >
                        <option value=""><?php esc_html_e('Search Agent', 'wpcodigo_wms'); ?></option>
                        <?php foreach( $agents as $agent ): ?>
                            <option value="<?php echo (int)$agent['ID']; ?>" <?php selected( $assigned_agent, (int)$agent['ID'] ); ?> ><?php echo esc_html( $agent['display_name'] ); ?></option>
                        <?php endforeach; ?>
                    </select>
                <?php endif; ?>
            </div>
            <div class="col-md-6 text-right">
                <input id="cmws-submit-form_reservation" type="button" class="btn btn-md btn-success" value="<?php echo $is_new ? __('Create Reservation', 'wpcodigo_wms') : __('Update Sales Order', 'wpcodigo_wms') ; ?>">
            </div>
        </section>
    </form>
    <?php do_action('cwms1661_after_reservation_form', $reservation ); ?>
</div>
<!-- Search Vendor -->
<div id="cwms-search-customer-modal" class="modal fade" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog modal-md">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="<?php esc_html_e('Close', 'wpcodigo_wms'); ?>"><span aria-hidden="true">×</span>
                </button>
                <h4 class="modal-title" id="uploadLogoModalLabel"><?php esc_html_e('Search Customer/Company', 'wpcodigo_wms'); ?></h4>
            </div>
            <div class="modal-body">
                <select id="cwms-search_customer" class="form-control form-control-sm" data-action="cwms_search_customer" style="width: 280px; display: inline-block;" aria-placeholder="<?php esc_html_e('Search Customer/Company', 'wpcodigo_wms'); ?>">
                    <option value=""><?php esc_html_e('Search Customer/Company', 'wpcodigo_wms'); ?></option>
                </select>
                <button id="cwms-add_searched_customer" type="button" class="btn btn-sm btn-primary d-inline" style="height: 34px;" disabled><?php esc_html_e('Add Customer/Company', 'wpcodigo_wms'); ?></button>
            </div>
        </div>
    </div>
</div>