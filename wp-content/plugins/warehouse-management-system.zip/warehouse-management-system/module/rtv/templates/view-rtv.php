<?php
    $reservation        = cwms1661_get_reservation_data( (int)$_GET['id'] );
    $reservation_number = $reservation['title'];
    $current_date       = $reservation['_date_created'];
    $general_settings   = cwms1661_get_general_settings();
?>
<div class="col-md-offset-1 col-md-10 col-sm-12">
    <?php do_action('cwms1661_before_reservation_form', $reservation ); ?>
    <section id="cwms-reservation_form" class="form-horizontal form-label-left input_mask" action="" method="POST">
        <!-- Header -->
        <section id="po-header-section" class="row" style="margin-bottom:18px;">
            <div class="col-md-6 col-sm-12">
                <?php if($general_settings['_company_logo']):  ?>
                    <img src="<?php echo $general_settings['_company_logo']; ?>" alt="<?php echo $general_settings['_company_name']; ?>" width="210">
                <?php endif; ?>
            </div>
            <div class="col-md-6 col-sm-12 text-right">
                <h1><?php esc_html_e('RESERVATION REQUEST', 'wpcodigo_wms'); ?></h1>
                <?php esc_html_e('DATE', 'wpcodigo_wms'); ?>: <?php echo $current_date; ?><br/>
                <span class="cwms-reservation_number"><?php esc_html_e('Reservation', 'wpcodigo_wms'); ?>#: <?php echo $reservation_number; ?></span>
            </div>
        </section>
        <!-- Vendors Information -->
        <section id="customer-info-section" class="row" style="margin-bottom:18px;">
            <div class="col-md-6 col-sm-12">
                <h3 class="info-header bg-header"><?php esc_html_e('Customer', 'wpcodigo_wms'); ?> <span class="cwms-search-customer fa fa-users text-primary" aria-hidden="true" data-toggle="modal" data-target="#cwms-search-customer-modal" style="font-size: 1.2em;float: right;"></span></h3>
                <div id="cwms-customer-details">
                    <strong><?php echo $reservation['_customer_company']; ?></strong><br/>
                    <span class="contact-name"><?php echo $reservation['_customer']; ?></span><br/>
                    <?php echo cwms1661_display_address_html( $reservation['_customer_details'] ); ?><br/>
                    <?php echo $reservation['_customer_details']['_phone']; ?><br/>
                    <?php echo $reservation['_customer_details']['_email']; ?>
                </div>
            </div>
        </section>
        <section id="product-info" class="table-responsive cwms_reservation_items">
            <table id="cwms-rsvnitems-table" class="table table-sm table-hover">
                <thead>
                    <tr>
                        <th><?php esc_html_e('SKU', 'wpcodigo_wms'); ?></th>
                        <th><?php esc_html_e('Name', 'wpcodigo_wms'); ?></th>
                        <th class="cwms-input-header"><?php esc_html_e('Qty', 'wpcodigo_wms'); ?></th>
                        <th ><?php esc_html_e('Unit', 'wpcodigo_wms'); ?></th>
                        <th ><?php esc_html_e('Retail Price', 'wpcodigo_wms'); ?></th>
                        <th ><?php esc_html_e('Total', 'wpcodigo_wms'); ?></th>
                    </tr>
                </thead>
                <tbody data-repeater-list="cwms_reservation_products">
                    <?php foreach ($reservation['_products'] as $product): ?>
                        <tr data-repeater-item>
                            <td class="col-upc"><?php echo $product['upc']; ?></td>
                            <td class="col-name"><?php echo $product['name']; ?></td>
                            <td class="col-qty"><?php echo $product['qty_ordered']; ?></td>
                            <td class="col-unit"><?php echo $product['unit']; ?></td>
                            <td class="col-unit"><?php echo cwms1661_format_number( $product['retail_price'] ); ?></td>
                            <td class="col-unit"><?php echo cwms1661_format_number( $product['total'] ); ?></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </section>
        <div class="row" id="amount-breakdown" style="margin-top:18px">
            <!-- Remarks column -->
            <div class="col-xs-6">
                <p class="lead"><?php esc_html_e('Remarks', 'wpcodigo_wms'); ?>:</p>
                <textarea name="remarks" rows="6" style="width:100%;" placeholder="<?php esc_html_e('Add remarks here.', 'wpcodigo_wms'); ?>" disabled><?php echo esc_html( $reservation['_remarks'] ) ; ?></textarea>
            </div>
            <!-- /.col -->
            <div class="col-xs-6">
                <p class="lead"><?php esc_html_e('Amount Due', 'wpcodigo_wms'); ?></p>
                <div class="table-responsive">
                    <table id="cwms-amountdue-table" class="table">
                        <tbody>
                            <tr>
                                <th class="text-right"><?php esc_html_e('Total', 'wpcodigo_wms'); ?>:</th>
                                <td class="amount_due_total"><?php echo cwms1661_format_number( $reservation['_total_amount'] ) ; ?></td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
            <!-- /.col -->
        </div>
        <div class="ln_solid"></div>
        <section id="action-section">
            <div class="col-md-6 form-group">
                <label for="cwms-search_agent" style="margin-right:12px;"><?php esc_html_e('Assigned Agent', 'wpcodigo_wms'); ?></label>: 
                <?php echo $reservation['_assigned_agent_name']; ?>
            </div>
        </section>
    </section>
    <?php do_action('cwms1661_after_reservation_form', $reservation ); ?>
</div>