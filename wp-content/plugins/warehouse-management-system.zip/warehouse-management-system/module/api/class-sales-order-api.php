<?php
if (!defined('ABSPATH')){
    exit; // Exit if accessed directly
}
class CWMS_SALES_ORDER_API extends WP_REST_Controller {
    var $namespace  = 'cwms/v';
    var $version    = '1';   
    
    // register route
    public function register_routes() {
        $namespace = $this->namespace . $this->version;
        $base      = 'api';
        register_rest_route( $namespace, '/sales-order/create', array(
            array(
                'methods'               => WP_REST_Server::CREATABLE,
                'callback'              => array( $this, 'created_order' ),
                'permission_callback'   => array( $this, 'auth_premission' )
              )
        ) );
        register_rest_route( $namespace, '/sales-orders/search/(?P<number>[a-zA-Z0-9-]+)', array(
            array(
                'methods'               => WP_REST_Server::READABLE,
                'callback'              => array( $this, 'search_sales_order' ),
                'permission_callback'   => array( $this, 'auth_premission' )
              )
        ) );
        register_rest_route( $namespace, '/sales-orders(?:/(?P<page>\d+))?', array(
            array(
                'methods'               => WP_REST_Server::READABLE,
                'callback'              => array( $this, 'sales_orders' ),
                'permission_callback'   => array( $this, 'auth_premission' )
              )
        ) );
        
    }

    public function sales_orders( WP_REST_Request $request ){
        $page = $request->get_param( 'page' );
        $page = $page ? $page : 1;
        return cwms1661_get_all_so_data( array(), $page, 12 );
    }
    public function search_sales_order( WP_REST_Request $request ){
        $so_number = sanitize_text_field( $request->get_param( 'number' ) );
        if( empty( $so_number ) ){
            return array(
                'status' => 'error',
                'message' => __('Empty request parameter', 'wpcodigo_wms' )
            );
        }
        $result = cwms1661_search_so_info( $so_number );
        if( empty( $result ) ){
            return array(
                'status' => 'success',
                'message' => __('No sales order found', 'wpcodigo_wms' )
            );
        }
        return $result;
    }
    public function created_order( WP_REST_Request $request ){
        return array(
            'request' => 'create sales order',
            'parameters' => $_POST,
        );
    }
    public function auth_premission( WP_REST_Request $request ){
        return true;
        if( !is_user_logged_in() ){
          return new WP_Error( 'rest_forbidden', __('Permission denied'), array( 'status' => 401 ) );
        }
        return true;
    }

    public function hook_rest_server(){
        add_action( 'rest_api_init', array( $this, 'register_routes' ) );
    }
}

$CWMS_SALES_ORDER_API = new CWMS_SALES_ORDER_API();
$CWMS_SALES_ORDER_API->hook_rest_server();