<?php
if (!defined('ABSPATH')){
    exit; // Exit if accessed directly
}
class CWMS_Customer_API extends WP_REST_Controller {
    var $namespace  = 'cwms/v';
    var $version    = '1';   
    
    // register route
    public function register_routes() {
        $namespace = $this->namespace . $this->version;
        $base      = 'api';
        register_rest_route( $namespace, '/customer/search/(?P<name>[a-zA-Z0-9-]+)', array(
            array(
                'methods'               => WP_REST_Server::READABLE,
                'callback'              => array( $this, 'search_customer' ),
                'permission_callback'   => array( $this, 'auth_premission' )
              )
        ) );
        register_rest_route( $namespace, '/customers(?:/(?P<page>\d+))?', array(
            array(
                'methods'               => WP_REST_Server::READABLE,
                'callback'              => array( $this, 'customers' ),
                'permission_callback'   => array( $this, 'auth_premission' )
              )
        ) );
        
    }

    public function customers( WP_REST_Request $request ){
        $page = $request->get_param( 'page' );
        $page = $page ? $page : 1;
        $options        = array();
        $customers      = get_users( array( 
            'role'              => array( 'cwms_customer' ),
            'paged' => $page,
            'number' => 12
        ) );
        if( !empty( $customers ) ){
            foreach ($customers as $customer ) {
                $options[] = cwms1661_get_user_info( $customer );
            }
        }
        return array(
            'status' => 'success',
            'data' => $options
        );
        
    }
    public function search_customer( WP_REST_Request $request ){
        $name = sanitize_text_field( $request->get_param( 'name' ) );
        if( empty( $name ) ){
            return array(
                'status' => 'error',
                'message' => __('Empty request parameter', 'wpcodigo_wms' )
            );
        }
        $options        = array();
        $customers      = get_users( array( 
            'role'              => array( 'cwms_customer' ),
            'search'            => "*{$name}*",
	        'search_columns'    => array( 'user_login', 'user_email', 'user_nicename', 'display_name' )
        ) );
        if( !empty( $customers ) ){
            foreach ($customers as $customer ) {
                $options[] = cwms1661_get_user_info( $customer );
            }
        }
        return array(
            'status' => 'success',
            'data' => $options
        );
    }
    public function auth_premission( WP_REST_Request $request ){
        return true;
        if( !is_user_logged_in() ){
          return new WP_Error( 'rest_forbidden', __('Permission denied'), array( 'status' => 401 ) );
        }
        return true;
    }

    public function hook_rest_server(){
        add_action( 'rest_api_init', array( $this, 'register_routes' ) );
    }
}

$CWMS_Customer_API = new CWMS_Customer_API();
$CWMS_Customer_API->hook_rest_server();