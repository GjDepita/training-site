<?php
if (!defined('ABSPATH')){
    exit; // Exit if accessed directly
}
class CWMS_Product_API extends WP_REST_Controller {
    var $namespace  = 'cwms/v';
    var $version    = '1';   
    
    // register route
    public function register_routes() {
        $namespace = $this->namespace . $this->version;
        $base      = 'api';
        register_rest_route( $namespace, '/product/search/(?P<name>[a-zA-Z0-9-]+)', array(
            array(
                'methods'               => WP_REST_Server::READABLE,
                'callback'              => array( $this, 'search_product' ),
                'permission_callback'   => array( $this, 'auth_premission' )
              )
        ) );
        register_rest_route( $namespace, '/products(?:/(?P<page>\d+))?', array(
            array(
                'methods'               => WP_REST_Server::READABLE,
                'callback'              => array( $this, 'products' ),
                'permission_callback'   => array( $this, 'auth_premission' )
              )
        ) );
        
    }

    public function products( WP_REST_Request $request ){
        $page       = $request->get_param( 'page' );
        $page       = $page ? $page : 1;
        $metakeys   = cwms1661_product_table_headers();
        $data       =  cwms1661_get_all_data( CWMS1661_PRODUCT_POST_TYPE, $metakeys, '_name', null, $page, 10 );
        if( !$data ){
            return array(
                'status' => 'success',
                'message' => __('Empty data', 'wpcodigo_wms' )
            );
        }
        return array(
            'status' => 'success',
            'data' => $data
        );
        
    }
    public function search_product( WP_REST_Request $request ){
        $name = sanitize_text_field( $request->get_param( 'name' ) );
        if( empty( $name ) ){
            return array(
                'status' => 'error',
                'message' => __('Empty request parameter', 'wpcodigo_wms' )
            );
        }
        $data    = array( );
        $options = cwms1661_search_product( $name );
        if( $options ){
            foreach ( (array)$options as $post_id ) {
                $data[] = cwms1661_get_data( $post_id, array_keys(cwms1661_product_fields()), '_name', '_description' );
            }
        }
        return array(
            'status' => 'success',
            'data' => $data
        );
    }
    public function auth_premission( WP_REST_Request $request ){
        return true;
        if( !is_user_logged_in() ){
          return new WP_Error( 'rest_forbidden', __('Permission denied'), array( 'status' => 401 ) );
        }
        return true;
    }

    public function hook_rest_server(){
        add_action( 'rest_api_init', array( $this, 'register_routes' ) );
    }
}

$CWMS_Product_API = new CWMS_Product_API();
$CWMS_Product_API->hook_rest_server();