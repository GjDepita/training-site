<?php
defined( 'ABSPATH' ) || exit;

require_once CWMS1661_ABSPATH . 'lib/dompdf/vendor/autoload.php';

use Dompdf\Dompdf;
use Dompdf\Options;

if ( ! class_exists( 'CWMS1661_Settings', false ) ) :

    class CWMS1661_Settings {
        function __construct()
        {

            // Frontend
            add_action( 'wp_enqueue_scripts', array( __CLASS__, 'scripts' ) );
            // Register Script and Styles to dashboard
            add_filter( 'cwms1661_registered_styles', array(__CLASS__,'register_style') );
            add_filter( 'cwms1661_registered_scripts', array(__CLASS__,'register_script') );

            // Save Settings
            add_action('wp', array( __CLASS__, 'save_general_settings') );
            add_action('wp', array( __CLASS__, 'save_permission_settings') );
            add_action('wp', array( __CLASS__, 'save_email_settings') );
            add_action('wp', array( __CLASS__, 'save_others_settings') );
            add_action('wp', array( __CLASS__, 'save_product_category') );
            add_action('template_redirect', array(__CLASS__, 'save_redirection'));

            // AJAX
            add_action( 'wp_ajax_cwms_get_product_categories', array(__CLASS__,  'get_product_categories' ) );
            add_action( 'wp_ajax_cwms_delete_term', array(__CLASS__,  'delete_term' ) );

            // Email notifications
            add_action( 'save_post_'.CWMS1661_PO_POST_TYPE, array( __CLASS__, 'po_email_notification'), 100, 3 );
            add_action( 'save_post_'.CWMS1661_INVOICE_POST_TYPE, array( __CLASS__, 'invoice_email_notification'), 100, 3 );

            // Templates
            add_filter( 'cwms1661_content_template_settings', array(__CLASS__, 'template' ) );
            add_action( 'cwms1661_before_setting_form', array(__CLASS__, 'notification_message'));
            add_action( 'cwms1661_before_permission_form', array(__CLASS__, 'notification_message'));
            add_action( 'cwms1661_before_others_settings_form', array(__CLASS__, 'notification_message'));
            add_action( 'cwms1661_before_product_category_settings_page', array(__CLASS__, 'notification_message'));

            // Form field filter
            add_filter( 'cwms1661_field_html_prodcat_parent', array(__CLASS__, 'parent_category_form_field'), 10, 3 );
            add_action( 'cwms_after_form_field', array(__CLASS__, 'category_slug_description') );
        }

        public static function scripts(){
            if( !isset($_GET['cwmspage']) || $_GET['cwmspage'] != 'settings' ){
                return false;
            }
            
            wp_enqueue_style( 'cwms1661-croppie-style', CWMS1661_PLUGIN_URL.'assets/css/croppie.css' );
            wp_enqueue_style( 'cwms1661-switchery-style', CWMS1661_PLUGIN_URL.'assets/css/switchery.min.css' );
            wp_enqueue_script( 'cwms1661-croppie-script', CWMS1661_PLUGIN_URL.'assets/js/croppie.js' , array(), CWMS1661_VERSION, true );
            wp_enqueue_script( 'cwms1661-switchery-script', CWMS1661_PLUGIN_URL.'assets/js/switchery.min.js' , array(), CWMS1661_VERSION, true );
            wp_enqueue_script( 'cwms1661-settings-script', CWMS1661_PLUGIN_URL.'assets/js/settings.js' , array( 'cwms1661-dataTables-script', 'cwms1661-bootstrap-buttons-script', ), CWMS1661_VERSION, true );

            wp_localize_script( 'cwms1661-settings-script', 'cwmsAjaxHandler', array(
                'ajaxurl'               => admin_url( 'admin-ajax.php' ),
                'dataTableLabels'       => cwms1661_datatable_labels( ),
                'prodCatTableHeader'    =>  array_keys( cwms1661_product_category_table_headers() ),
                'noFile'                => esc_html__('NO file to upload found!', 'wpcodigo_wms'),
                'proceedConfirmation'   => esc_html__('Are you sure you want to proceed your request?', 'wpcodigo_wms'),
            ) );
        }
        public static function register_style( $styles ){
            if( isset($_GET['cwmspage']) && $_GET['cwmspage'] == 'settings' ){
                $styles[] = 'cwms1661-croppie-style';
            }
            return $styles;
        }
        public static function register_script( $scripts ){
            if( isset($_GET['cwmspage']) && $_GET['cwmspage'] == 'settings' ){
                $scripts[] = 'cwms1661-croppie-script';
                $scripts[] = 'cwms1661-settings-script';
            }
            return $scripts;
        }
        public static function save_general_settings(){
            if ( ! isset( $_POST['cwms1661_general_settings_nonce'] ) 
                || ! wp_verify_nonce( $_POST['cwms1661_general_settings_nonce'], 'cwms1661_general_settings_action' ) 
            ) {
                return false;
            } 
            $logo ='';
            if( isset($_POST['_company_logo']) && !empty($_POST['_company_logo']) ){
                $logo = sanitize_text_field( $_POST['_company_logo'] );
            }
            update_option('cwms1661_general_settings-_company_logo', $logo);
            foreach( cwms1661_setting_fields() as $key => $field ){
                $value = isset( $_POST[$key] ) ? $_POST[$key] : '';
                if( $field['type'] == 'textarea'){
                    $value = sanitize_textarea_field( $value );
                }elseif( $field['type'] == 'email' ){
                    $value = sanitize_email($value);
                }elseif( $field['type'] == 'radio' || $field['type'] == 'checkbox' ){
                    $value = (array)$value;
                }else{
                    $value = sanitize_text_field( $value );
                }
                update_option('cwms1661_general_settings-'.$key, $value);
            }
            update_option('cwms1661_general_settings-_address', sanitize_textarea_field( $_POST['_address'] ));
            $_POST['cwms_settings_redirection'] = array(
                'cwmspage'   => 'settings',
                'tab'       => 'general',
                'cwms-message'   => esc_html__('Settings successfully saved!', 'wpcodigo_wms')
            );
        }
        public static function save_permission_settings(){
            if ( ! isset( $_POST['cwms1661_permission_settings_nonce'] ) 
                || ! wp_verify_nonce( $_POST['cwms1661_permission_settings_nonce'], 'cwms1661_permission_settings_action' ) 
            ) {
                return false;
            }
            $permissions        = cwms1661_permissions();

            foreach( $permissions as $permission ){
                $permission_keys = array_keys( $permission['options'] );
                // Save options based on the permission keys
                foreach( $permission_keys as $key ){
                    $roles = array();
                    if( array_key_exists( $key, $_POST ) ){
                        $roles = (array)$_POST[$key];
                    }
                    update_option( $key, $roles );
                }
            }

            $_POST['cwms_settings_redirection'] = array(
                'cwmspage'   => 'settings',
                'tab'       => 'permissions',
                'cwms-message'   => esc_html__('Pemissions successfully saved!', 'wpcodigo_wms')
            );
        }
        public static function save_email_settings(){
            if ( ! isset( $_POST['cwms1661_emails_settings_nonce'] ) 
                || ! wp_verify_nonce( $_POST['cwms1661_emails_settings_nonce'], 'cwms1661_emails_settings_action' ) 
            ) {
                return false;
            }
            // PO email notification settings
            $enable_email_po = isset($_POST['_enable_email_po']) ? 1 : 0;
            update_option( '_enable_email_po', $enable_email_po );

            if( isset($_POST['_email_po_status']) ){
                update_option( '_email_po_status', sanitize_text_field( $_POST['_email_po_status'] ) );
            }
            // Invoice email notification settings
            $enable_email_invoice = isset($_POST['_enable_email_invoice']) ? 1 : 0;
            update_option( '_enable_email_invoice', $enable_email_invoice );

            if( isset($_POST['_email_invoice_status']) ){
                update_option( '_email_invoice_status', sanitize_text_field( $_POST['_email_invoice_status'] ) );
            }

            $_POST['cwms_settings_redirection'] = array(
                'cwmspage'      => 'settings',
                'tab'           => 'emails',
                'cwms-message'  => esc_html__('Email seetings successfully saved!', 'wpcodigo_wms')
            );
        }
        public static function save_others_settings(){
            if ( ! isset( $_POST['cwms1661_others_settings_nonce'] ) 
                || ! wp_verify_nonce( $_POST['cwms1661_others_settings_nonce'], 'cwms1661_others_settings_action' ) 
            ) {
                return false;
            }
            $enable_dr_sequence = isset( $_POST['_enable_dr_sequence'] ) ? true : false;
            update_option( '_enable_dr_sequence', $enable_dr_sequence );
            if( isset($_POST['_dr_sequence_length']) ){
                update_option( '_dr_sequence_length', sanitize_text_field( $_POST['_dr_sequence_length']) );
            }
            if( isset($_POST['_dr_sequence_no']) ){
                update_option( '_dr_sequence_no', sanitize_text_field( $_POST['_dr_sequence_no']) );
            }
            if( isset($_POST['_product_units']) ){
                $product_units = (array) explode( PHP_EOL, trim( $_POST['_product_units'] ) );
                update_option( '_product_units', $product_units );
            }
            $_POST['cwms_settings_redirection'] = array(
                'cwmspage'   => 'settings',
                'tab'       => 'others',
                'cwms-message'   => esc_html__('Others successfully saved!', 'wpcodigo_wms')
            );
        }
        public static function save_product_category(){
            if ( ! isset( $_POST['cwms1661_product_category_nonce'] ) 
                || ! wp_verify_nonce( $_POST['cwms1661_product_category_nonce'], 'cwms1661_product_category_action' ) 
            ) {
                return false;
            }

            $term_id        = isset($_REQUEST['id']) ? (int)$_REQUEST['id'] : 0;
            $name           = sanitize_text_field( $_REQUEST['prodcat_name'] );
            $slug           = sanitize_text_field( $_REQUEST['prodcat_slug'] );
            $description    = sanitize_text_field( $_REQUEST['prodcat_description'] );
            $parent         = isset($_REQUEST['prodcat_parent']) ? (int)$_REQUEST['prodcat_parent'] : 0;
            $slug           = !empty( $slug ) ? strtolower( preg_replace('/\s+/', '-', trim( $slug ) ) ) : '' ;
            $term_args = array(
                'description' =>  $description,
                'slug'        => $slug,
                'parent'      => $parent,
            );
            if( $term_id ){
                $term_args['name'] = $name;
                $insert_term = wp_update_term( $term_id,  CWMS1661_PRODUCT_TAXONOMY,  $term_args);
            }else{
                $insert_term = wp_insert_term( $name,  CWMS1661_PRODUCT_TAXONOMY,  $term_args);
            }
        
            if( is_wp_error( $insert_term ) ){
                $error_string = $insert_term->get_error_message();
                echo '<div id="message" class="error"><p>' . $error_string . '</p></div>';
                wp_die();
            }

            $_POST['cwms_settings_redirection'] = array(
                'cwmspage'   => 'settings',
                'tab'       => 'product-category',
                'cwms-message'   => __('Category successfully saved!', 'wpcodigo_wms')
            );
            if( $term_id ){
                $_POST['cwms_settings_redirection']['action'] = 'edit';
                $_POST['cwms_settings_redirection']['id'] = $term_id;
                $_POST['cwms_settings_redirection']['cwms-message'] = __('Category successfully updated!', 'wpcodigo_wms');
            }
            return false;
        }
        public static function template(){
            if( !is_cwms1661_admin( ) ){
                return cwms1661_get_template_path('403', 'dashboard');
            }
            return apply_filters( "cwms1661_get_template_settings", CWMS1661_ABSPATH.'module/setting/templates/settings.php' );
        }

        public static function parent_category_form_field( $html, $field, $value ){
            ob_start();

            if( empty($field['options']) || !is_array($field['options']) ){
                return false;
            }
            $required       = $field['required'] ? 'required' : '';
            $default_value  = esc_html__('Choose parent', 'wpcodigo_wms');
            ?>
            <div class="form-group ">
                <label class="control-label col-md-3 col-sm-3 col-xs-12"><?php echo esc_html( $field['label']  ); ?></label>
                <div class="col-md-9 col-sm-9 col-xs-12">
                    <select name="<?php echo $field['id']; ?>" class="form-control" <?php echo $required; ?>>
                        <option value=""><?php echo $default_value; ?></option>
                        <?php foreach( $field['options'] as $key => $option ): ?>
                        <option value="<?php echo $key; ?>" <?php selected( $value, $key ); ?>><?php echo $option; ?></option>
                        <?php endforeach; ?>
                    </select>
                    <?php do_action( 'cwms_after_form_field', $field ); ?>
                </div>
            </div>
            <?php
            return ob_get_clean();
        }

        public static function category_slug_description( $field_info ){
            if( 'prodcat_slug' !== $field_info['id'] ){
                return false;
            }
            ob_start();
            printf( '<p class="description">%s</p>', __('The “slug” is the URL-friendly version of the name. It is usually all lowercase and contains only letters, numbers, and hyphens.', 'wpcodigo_wms') );
            echo ob_get_clean();
        }

        public static function notification_message(){
            if( !isset($_GET['cwmspage']) || $_GET['cwmspage'] != 'settings' ){
                return false;
            }
            if( !isset($_GET['cwms-message']) || empty($_GET['cwms-message']) ){
                return false;
            }
            printf('<div class="notification-message alert alert-success">%s</div>', urldecode($_GET['cwms-message']));
            ?>        
            <script>
                window.history.replaceState({}, document.title, '<?php echo cwms1661_dashboard_home().'?'.cwms1661_clean_url_parameter(['cwms-message']); ?>' );
                setTimeout( function(){
                    jQuery('#cwms-page-settings').find('.notification-message').remove();
                }, 6000 );
            </script>
            
            <?php
        }
        public static function format_product_category_data( $term, $parent = true ){
            $edit_url  = cwms1661_dashboard_home().'?cwmspage=settings&tab=product-category&action=edit&id='.$term->term_id;
                $actions = [
                    'edit' => sprintf(
                        '<span class="edit"><a class="cwms-update_prodcat text-primary" href="%s">%s</a> ',
                        esc_url_raw( $edit_url ),
                        esc_html__('Edit','wpcodigo_wms')
                    ),
                    'delete' => sprintf(
                        '<span class="trash"><a class="cwms-delete_prodcat text-danger" href="#">%s</a></span>',
                        esc_html__('Delete','wpcodigo_wms')
                    )
                ];
                ob_start();
                ?>
                <strong data-id="<?php echo (int)$term->term_id; ?>" class="<?php echo ! $parent ? 'child-row' : 'parent-row' ; ?>"><a href="<?php echo $edit_url; ?>"><?php echo $term->name; ?></a></strong> 
                <div class="row-actions" data-id="<?php echo (int)$term->term_id; ?>">
                    <?php echo implode( ' | ', array_values( $actions ) ) ?>
                </div>
                <?php
                $name     = ob_get_clean();
                return array(
                    'name' => $name,
                    'slug' => $term->slug,
                    'description' => $term->description,
                );
        }
        public static function get_product_categories(){
            $term_list = [];
            $terms = get_terms( array(
                'taxonomy'   => CWMS1661_PRODUCT_TAXONOMY,
                'hide_empty' => false,
                'parent'   => 0
            ) );
            foreach ($terms as $term ) {
                $term_list[] = self::format_product_category_data( $term ) ;
                // check if has child
                $child_terms = get_terms( array(
                    'taxonomy'   => CWMS1661_PRODUCT_TAXONOMY,
                    'hide_empty' => false,
                    'parent'   => $term->term_id
                ) );
                if( $child_terms ){
                    foreach ($child_terms as $_term ) {
                        $term_list[] = self::format_product_category_data( $_term, false ) ;
                    }
                }
            }
            wp_send_json( array( 'data' => $term_list )  );
        }
        public static function delete_term(){
            $term_id = (int)$_POST['termID'];
            $delete_term = wp_delete_term( $term_id, CWMS1661_PRODUCT_TAXONOMY );
            if( is_wp_error( $delete_term ) ){
                wp_send_json( array(
                    'status' => 'error',
                    'message' => $delete_term->get_error_message()
                ) );
            }
            if( !$delete_term ){
                wp_send_json( array(
                    'status' => 'error',
                    'message' => __( 'Category failed to deleted, please reload the page and try again.', 'wpcodigo_wms')
                ) );
            }
            wp_send_json( array(
                'status' => 'success',
                'message' => __( 'Category successfully deleted', 'wpcodigo_wms')
            ) );
        }
        public static function email_attachment( $print_id, $attchment_type ){

            $directory    = CWMS1661_ABSPATH.'module/print/storage/';

            // Check if directory exist
            if( !is_dir( $directory ) ){
                mkdir( $directory );
            }

            // Clean directory before adding new file
            foreach( glob($directory.'*.pdf') as $pdf_file){
                unlink($pdf_file);
            }
            $pdf_title 	    = get_the_title($print_id).'-'.time();	
            // instantiate and use the dompdf class
            $options 		= new Options();
            $options->setDpi( 160 );
            $options->set('isRemoteEnabled', true);
            $dompdf 		= new Dompdf( $options );
            $dompdf->setPaper( CWMS1661_PDF_PAPER_SIZE, 'portrait');
            $dompdf->loadHtml( self::html( $print_id, $attchment_type ), 'UTF-8' );
            $dompdf->render();
            $output = $dompdf->output();
            if( file_put_contents( $directory.$pdf_title.'.pdf', $output) ){
                return $directory.$pdf_title.'.pdf';  
            }
            return null;
        }

        public static function html( $print_id, $attchment_type ){
            ob_start();
            $file_path = cwms1661_get_template_path( 'body', 'print/templates/', true );
            include_once cwms1661_get_template_path( 'header', 'print/templates/', true );
            include_once apply_filters( 'cwms1661_print_html_body_'.$attchment_type, $file_path, $print_id);
            include_once cwms1661_get_template_path( 'footer', 'print/templates/', true );
            return ob_get_clean();
        }

        public static function po_email_notification( $post_id, $post, $update ){

            if( cwms1661_enable_email_po() &&  $post->post_status != cwms1661_email_po_status() ){
                return false;
            }
            
            // Get the PO supplier ID 
            $supplier_id = get_post_meta( $post_id, '_supplier_id', true );
            if( ! (int)$supplier_id ){
                return false;
            }
            // Get supplier email
            $supplier_email = get_post_meta( $supplier_id, '_email', true );
            if( !$supplier_email || !filter_var($supplier_email, FILTER_VALIDATE_EMAIL) ){
                return false;
            }
            $supplier   = get_post_meta( $post_id, '_supplier_details', true );
            $settings   = cwms1661_get_general_settings();
            $title      = sprintf('%s - %s', $settings['_company_name'], __('Purchase Order Email Notification', 'wpcodigo_wms'));
            $to         = $supplier_email;  
            $subject    = sprintf( __('%s # %s from %s', 'wpcodigo_wms'), __('Purchase Order', 'wpcodigo_wms'), $post->post_title, $settings['_company_name'] );


            ob_start();
            include_once( CWMS1661_ABSPATH .'module/setting/templates/email-notification/header.php' ); 
            include_once( CWMS1661_ABSPATH .'module/setting/templates/email-notification/body-po.php' ); 
            include_once( CWMS1661_ABSPATH .'module/setting/templates/email-notification/footer.php' ); 
            $body       = ob_get_clean();

            $headers    = array('Content-Type: text/html; charset=UTF-8');
            $headers[]  = sprintf( 'Cc: %s <%s>', $settings['_company_name'], $settings['_email'] );
            $attachments = array( self::email_attachment( $post_id, 'inbound-po') );
            wp_mail( $to, $subject, $body, $headers, $attachments );

        }
        public static function invoice_email_notification( $post_id, $post, $update ){
            if( cwms1661_enable_email_po() &&  $post->post_status != cwms1661_email_po_status() ){
                return false;
            }

            // Get the Invioce Customer data  
            $customer = maybe_unserialize( get_post_meta( $post_id, '_customer_details', true ) );
            if( empty( $customer) ){
                return false;
            }
            // Get supplier email
            $customer_email = $customer['_email'];
            if( !$customer_email || !filter_var($customer_email, FILTER_VALIDATE_EMAIL) ){
                return false;
            }
            $settings   = cwms1661_get_general_settings();
            $title      = sprintf('%s - %s', $settings['_company_name'], __('Invoice Email Notification', 'wpcodigo_wms'));
            $to         = $customer_email;
            $subject    = sprintf( __('%s # %s from %s', 'wpcodigo_wms'), __('Invoice', 'wpcodigo_wms'), $post->post_title, $settings['_company_name'] );

            ob_start();
            include_once( CWMS1661_ABSPATH .'module/setting/templates/email-notification/header.php' ); 
            include_once( CWMS1661_ABSPATH .'module/setting/templates/email-notification/body-invoice.php' ); 
            include_once( CWMS1661_ABSPATH .'module/setting/templates/email-notification/footer.php' ); 
            $body       = ob_get_clean();

            $headers    = array('Content-Type: text/html; charset=UTF-8');
            $headers[]  = sprintf( 'Cc: %s <%s>', $settings['_company_name'], $settings['_email'] );
            $attachments = array( self::email_attachment( $post_id, 'invoice') );
            wp_mail( $to, $subject, $body, $headers, $attachments );

        }

        public static function save_redirection(){
            if( !isset($_POST['cwms_settings_redirection']) || !is_array($_POST['cwms_settings_redirection']) ){
                return false;
            }
            wp_redirect( cwms1661_dashboard_home().'?'.http_build_query( $_POST['cwms_settings_redirection'] ) );
            exit;
        }
    }

endif;

return new CWMS1661_Settings();