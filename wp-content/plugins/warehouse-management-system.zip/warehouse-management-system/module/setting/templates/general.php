<div role="tabpanel" class="tab-pane fade <?php echo $current_tab == 'general' ? 'active in' : '' ; ?>" id="cmws-general_setttings" aria-labelledby="home-tab">
    <div class="row">
        <section class="col-md-offset-2 col-md-8">
            <?php do_action('cwms1661_before_setting_form'); ?>
            <form method="POST" id="cwms-general-settings-form" class="form-horizontal form-label-left">
                <?php wp_nonce_field( 'cwms1661_general_settings_action', 'cwms1661_general_settings_nonce' ); ?>
                <div class="form-group">
                    <label class="control-label col-md-3 col-sm-3 col-xs-12" for="company_logo"><?php esc_html_e('Company Logo', 'wpcodigo_wms'); ?> <span class="required">*</span>
                    </label>
                    <div class="col-md-6 col-sm-6 col-xs-12">
                        <section id="cwms-logo-holder">
                            <?php if($general_settings['_company_logo']): ?>
                                <img style='width:100%' id='base64image' src='<?php echo $general_settings['_company_logo']; ?>' />
                            <?php endif; ?>
                        </section>
                        <input type="hidden" name="_company_logo" value="<?php echo $general_settings['_company_logo']; ?>">
                        <button id="company_logo" type="button" class="btn btn-secondary" data-toggle="modal" data-target="#cwms-upload-logo-modal"><?php esc_html_e('Upload Logo', 'wpcodigo_wms'); ?></button>
                    </div>
                </div>
                <?php do_action('cwms1661_before_setting_form_fields'); ?>
                <?php 
                foreach( cwms1661_setting_fields() as $key => $field ): 
                    $field_attr = $field['type'] == 'textarea' ? array('rows="4"') : '';
                    $value = $general_settings != null && array_key_exists( $key, $general_settings ) ? $general_settings[$key] : '';
                    $field = new CWMS_Field( $field, $value, $field_attr );
                    echo $field->html();
                endforeach; 
                ?>
                <?php do_action('cwms1661_after_setting_form_fields'); ?>
                <div class="ln_solid"></div>
                <div class="form-group">
                    <div class="col-md-6 col-sm-6 col-xs-12 col-md-offset-3">
                        <button type="submit" class="btn btn-success"><?php esc_html_e('Save', 'wpcodigo_wms'); ?></button>
                    </div>
                </div>
            </form>
        </section>
    </div>
</div>
<!-- Modal Upload Logo -->
<div id="cwms-upload-logo-modal" class="modal fade" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog modal-md">
        <div class="modal-content">

        <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal" aria-label="<?php esc_html_e('Close', 'wpcodigo_wms'); ?>"><span aria-hidden="true">×</span>
            </button>
            <h4 class="modal-title" id="uploadLogoModalLabel"><?php esc_html_e('Upload Logo', 'wpcodigo_wms'); ?></h4>
        </div>
        <div class="modal-body">
            <div class="cmws-upload-msg">
                <?php esc_html_e('Upload a file to start cropping', 'wpcodigo_wms'); ?>
            </div>
            <div class="cwms-upload-wrap">
                <div id="cwms-uploaded-logo"></div>
            </div>
            <a class="btn btn-secondary file-btn">
                <span><?php esc_html_e('Upload', 'wpcodigo_wms'); ?></span>
                <input type="file" id="cwms-upload_logo" value="<?php esc_html_e('Choose a file"', 'wpcodigo_wms'); ?> accept="image/*" />
            </a>
        </div>
        <div class="modal-footer">
            <button type="button" class="btn btn-default" data-dismiss="modal"><?php esc_html_e('Close', 'wpcodigo_wms'); ?></button>
            <button id="cwms-save_logo" type="button" class="btn btn-primary"><?php esc_html_e('Save Logo', 'wpcodigo_wms'); ?></button>
        </div>

        </div>
    </div>
</div>