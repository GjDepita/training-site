<table align="center" role="presentation" cellspacing="0" cellpadding="0" border="0" width="100%" style="margin: auto; background-color: #fff;">
    <tr>
        <td valign="top" class="bg_white" style="padding: 1em 2.5em 0 2.5em;">
        <table role="presentation" border="0" cellpadding="0" cellspacing="0" width="100%">
            <tr>
                <td class="logo" style="text-align: center;">
                    <img src="<?php echo $settings['_company_logo']; ?>" alt="<?php echo esc_html( $settings['_company_name'] ); ?> <?php echo esc_attr( 'Logo', 'wpcodigo_wms'); ?>" style="width:30%;" />
                    <h1 style="margin-top:0;"><a href="<?php echo esc_url( bloginfo('url') ); ?>"><?php echo esc_html( $settings['_company_name'] ); ?></a></h1>
                </td>
            </tr>
        </table>
        </td>
    </tr><!-- end tr -->
    <tr>
        <td valign="middle" class="hero bg_white" style="padding: 2em 0 4em 0;">
        <table>
            <tr>
                <td>
                    <div class="text" style="padding: 0 2.5em;">
                        <p><?php printf( __('Dear %s,','wpcodigo_wms'), $supplier['_company_name'] ); ?></p>
                        <p><?php printf( __('With reference Purchase Order Number %s, we would like to confirm that the order has been %s. We hope that you begin production immediately as we wish to have them delivered to our warehouse address %s', 'wpcodigo_wms'), '<strong>'.$post->post_title.'</strong>', cwms1661_post_statuses()[$post->post_status]['label'], $settings['_address'] ); ?></p>
                        <p><?php printf( __('Please see attachment fot the purchase order reference.', 'wpcodigo_wms' ) ); ?><p>
                        <p><?php printf( __('Best regards,', 'wpcodigo_wms' ) ); ?></p>
                        <p><?php echo $settings['_owner']; ?></p>
                    </div>
                </td>
            </tr>
        </table>
        </td>
    </tr><!-- end tr -->
</table>