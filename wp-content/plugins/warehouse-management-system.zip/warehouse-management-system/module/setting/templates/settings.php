<?php 
    $general_settings   = cwms1661_get_general_settings(); 
    $permissions        = cwms1661_permissions();
    $product_units      = cwms1661_product_units();
    $roles              = cwms1661_dashboard_roles();
    $current_tab        = isset( $_GET['tab'] ) && !empty( $_GET['tab'] ) ? sanitize_text_field( $_GET['tab'] ) : 'general' ;
    $term_id            = isset( $_GET['action'] ) && $_GET['action'] == 'edit' && (int)$_GET['id'] ? (int)$_GET['id'] : null ;
    $selected_term      = array();
    
    if( $term_id ){
        $curr_term = (array)get_term( $term_id, CWMS1661_PRODUCT_TAXONOMY );
        foreach ( array_keys( cwms1661_product_category_fields() ) as $key) {
            $term_key = str_replace('prodcat_','', $key );
            $selected_term[$key] = $curr_term[$term_key];
        }
    }
    ksort(  $permissions );
?>
<div class="" role="tabpanel" data-example-id="togglable-tabs">
    <ul id="cwms-settints_tab_navigation" class="nav nav-tabs bar_tabs" role="tablist">
        <li role="presentation" class="<?php echo $current_tab == 'general' ? 'active' : '' ; ?>">
            <a href="#cmws-general_setttings" id="home-tab" role="tab" data-toggle="tab" aria-expanded="true"><?php esc_html_e('General Setting', 'wpcodigo_wms'); ?></a>
        </li>
        <li role="presentation" class="<?php echo $current_tab == 'permissions' ? 'active' : '' ; ?>">
            <a href="#cwms-permissions" role="tab" id="profile-tab" data-toggle="tab" aria-expanded="false"><?php esc_html_e('Permissions', 'wpcodigo_wms'); ?></a>
        </li>
        <li role="presentation" class="<?php echo $current_tab == 'emails' ? 'active' : '' ; ?>">
            <a href="#cwms-emails" role="tab" id="emails-tab" data-toggle="tab" aria-expanded="false"><?php esc_html_e('Emails', 'wpcodigo_wms'); ?></a>
        </li>
        <li role="presentation" class="<?php echo $current_tab == 'product-category' ? 'active' : '' ; ?>">
            <?php if( $term_id ): ?>
                <a href="<?php echo esc_url( cwms1661_dashboard_home().'?cwmspage=settings&tab=product-category'); ?>"><?php esc_html_e('Product Categories', 'wpcodigo_wms'); ?></a>
            <?php else: ?>
                <a href="#cwms-product-category" role="tab" id="product-categpry-tab" data-toggle="tab" aria-expanded="false"><?php esc_html_e('Product Categories', 'wpcodigo_wms'); ?></a>
            <?php endif; ?>
        </li>
        <li role="presentation" class="<?php echo $current_tab == 'others' ? 'active' : '' ; ?>">
            <a href="#cwms-others" role="tab" id="others-tab" data-toggle="tab" aria-expanded="false"><?php esc_html_e('Others', 'wpcodigo_wms'); ?></a>
        </li>
    </ul>
    <div id="cwms-settints_tab_content" class="tab-content">
        <?php include_once( CWMS1661_ABSPATH.'module/setting/templates/general.php' ); ?>
        <?php include_once( CWMS1661_ABSPATH.'module/setting/templates/permission.php' ); ?>
        <?php include_once( CWMS1661_ABSPATH.'module/setting/templates/emails.php' ); ?>
        <?php include_once( CWMS1661_ABSPATH.'module/setting/templates/product-category.php' ); ?>
        <?php include_once( CWMS1661_ABSPATH.'module/setting/templates/others.php' ); ?>
    </div>
</div>