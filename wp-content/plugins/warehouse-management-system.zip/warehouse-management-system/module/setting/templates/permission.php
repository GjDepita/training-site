<div role="tabpanel" class="tab-pane fade <?php echo $current_tab == 'permissions' ? 'active in' : '' ; ?>" id="cwms-permissions" aria-labelledby="profile-tab">       
    <form method="POST" id="cwms-general-settings-form" class="form-horizontal form-label-left">
        <?php do_action('cwms1661_before_permission_form'); ?>
        <?php wp_nonce_field( 'cwms1661_permission_settings_action', 'cwms1661_permission_settings_nonce' ); ?>
        <table id="cwms-permission-table" class="table table-bordered">
            <thead>
                <tr>
                    <th style="width:180px;"></th>
                    <?php foreach( $roles as $role ): ?>
                        <th  class="cwms-permission_header text-center"><?php echo $role; ?></th>
                    <?php endforeach; ?>
                </tr>
            </thead>
            <tbody>
                <tbody>
                    <?php foreach( $permissions as $permission ): ?>
                        <!-- Permission header -->
                        <tr class="cwms-permission_header_row">
                            <th colspan="<?php echo count( $roles ) + 1; ?>" class="cwms-permission_header"><?php echo $permission['label']; ?></th>
                        </tr>
                        <!-- Permission optiond -->
                        <?php foreach( $permission['options'] as $key => $label ): ?>
                            <tr class="cwms-permission_subheader_row">
                                <th class="cwms-permission_subheader" style="padding-left:28px !important;"><?php echo $label; ?></th>
                                <?php foreach( array_keys($roles) as $role_key ): ?>
                                    <?php $assigned_roles = $key( ); ?>
                                    <td class="text-center"><input type="checkbox" class="js-switch" name="<?php echo $key; ?>[]" value="<?php echo $role_key; ?>" <?php echo in_array( $role_key, $assigned_roles) ? 'checked' : '' ; ?> /></td>
                                <?php endforeach; ?>
                            </tr>
                        <?php endforeach; ?>
                    <?php endforeach; ?>
                </tbody>
            </tbody>
        </table>
        <?php do_action('cwms1661_after_permission_form'); ?>
        <button type="submit" class="btn btn-primary btn-md"><?php esc_html_e('Save Permission', 'wpcodigo_wms'); ?></button>
    </form>
</div>