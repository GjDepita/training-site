<div role="tabpanel" class="tab-pane fade <?php echo $current_tab == 'emails' ? 'active in' : '' ; ?>" id="cwms-emails" aria-labelledby="profile-tab">   
    <div class="col-md-offset-2 col-md-8"> 
        <form method="POST" id="cwms-emails-settings-form" class="form-horizontal form-label-left">
            <?php do_action('cwms1661_before_emails_settings_form'); ?>
            <?php wp_nonce_field( 'cwms1661_emails_settings_action', 'cwms1661_emails_settings_nonce' ); ?>
            <div class="form-group">
                <label class="control-label col-md-4 col-sm-4 col-xs-12" for="_enable_email_po"><?php esc_html_e('Enable PO Email notifications?', 'wpcodigo_wms'); ?></label>
                <div class="col-md-6 col-sm-6 col-xs-12">
                    <input id="_enable_email_po" type="checkbox" class="js-switch" name="_enable_email_po" <?php checked( cwms1661_enable_email_po(), 1 ); ?> value="1" >
                </div>
            </div>
            <div class="form-group ">
                <label class="control-label col-md-4 col-sm-4 col-xs-12"><?php esc_html_e('PO notification status', 'wpcodigo_wms'); ?></label>
                <div class="col-md-6 col-sm-6 col-xs-12">
                    <select name="_email_po_status" class="form-control">
                        <option value=""><?php esc_html_e('Choose Status', 'wpcodigo_wms'); ?></option>
                        <?php foreach ( cwms1661_post_statuses() as $key => $value): ?>
                            <option value="<?php echo esc_attr( $key ); ?>" <?php selected( cwms1661_email_po_status(), $key ); ?>><?php echo esc_html( $value['label'] ); ?></option>
                        <?php endforeach; ?>
                    </select>
                    <p class="description text-danger font-italic"><?php esc_html_e('Note: Selected status will trigger the emails notification when enabled','wpcodigo_wms'); ?></p>
                </div>
            </div>
            <div class="form-group">
                <label class="control-label col-md-4 col-sm-4 col-xs-12" for="_enable_email_invoice"><?php esc_html_e('Enable Invoice Email notification?', 'wpcodigo_wms'); ?></label>
                <div class="col-md-6 col-sm-6 col-xs-12">
                    <input id="_enable_email_invoice" type="checkbox" class="js-switch" name="_enable_email_invoice" <?php checked( cwms1661_enable_email_invoice(), 1 ); ?> value="1" >
                </div>
            </div>
            <div class="form-group ">
                <label class="control-label col-md-4 col-sm-4 col-xs-12"><?php esc_html_e('Invoice notification status', 'wpcodigo_wms'); ?></label>
                <div class="col-md-6 col-sm-6 col-xs-12">
                    <select name="_email_invoice_status" class="form-control">
                        <option value=""><?php esc_html_e('Choose Status', 'wpcodigo_wms'); ?></option>
                        <?php foreach ( cwms1661_post_statuses() as $key => $value): ?>
                            <option value="<?php echo esc_attr( $key ); ?>" <?php selected( cwms1661_email_po_status(), $key ); ?>><?php echo esc_html( $value['label'] ); ?></option>
                        <?php endforeach; ?>
                    </select>
                    <p class="description text-danger font-italic"><?php esc_html_e('Note: Selected status will trigger the emails notification when enabled','wpcodigo_wms'); ?></p>
                </div>
            </div>
            <?php do_action('cwms1661_after_emails_settings_form'); ?>
            <div class="ln_solid"></div>
            <div class="form-group">
                <div class="col-md-6 col-sm-6 col-xs-12 col-md-offset-3">
                    <button type="submit" class="btn btn-success"><?php esc_html_e('Save', 'wpcodigo_wms'); ?></button>
                </div>
            </div>
        </form>
    </div> 
</div>