<div role="tabpanel" class="tab-pane fade <?php echo $current_tab == 'product-category' ? 'active in' : '' ; ?>" id="cwms-product-category" aria-labelledby="profile-tab">   
    <?php do_action('cwms1661_before_product_category_settings_page'); ?>   
    <div class="col-sm-12 col-md-4 ">      
        <?php if( $term_id ): ?>
            <h4><?php echo esc_html('Update category', 'wpcodigo_wms'); ?></h4>
        <?php else: ?>
            <h4><?php echo esc_html('Add new category', 'wpcodigo_wms'); ?></h4>
        <?php endif; ?>
        <form method="POST" id="cwms-product-category-form" class="form-horizontal form-label-left">
            <?php wp_nonce_field( 'cwms1661_product_category_action', 'cwms1661_product_category_nonce' ); ?>
            <?php do_action('cwms1661_before_product_category_settings_form'); ?>
            <?php 
            foreach( cwms1661_product_category_fields() as $key => $field ): 
                $field_attr = $field['type'] == 'textarea' ? array('rows="4"') : '';
                $value = !empty( $selected_term ) ?  $selected_term[$key] : '';
                $field = new CWMS_Field( $field, $value, $field_attr );
                echo $field->html();
            endforeach; 
            ?>
            <?php do_action('cwms1661_after_product_category_form_fields'); ?>
            <div class="ln_solid"></div>
            <div class="form-group">
                <div class="col-md-6 col-sm-6 col-xs-12 col-md-offset-3">
                    <button type="submit" class="btn btn-success"><?php esc_html_e('Save Category', 'wpcodigo_wms'); ?></button>
                </div>
            </div>
        </form>
    </div> 
    <?php if( !$term_id ): ?>
        <div class="col-sm-12 col-md-8 "> 
            <table id="cwms_product_category_table" class="wcms1661_dataTable display" style="width:100%">
                <thead>
                    <tr>
                        <!-- <th></th> -->
                        <?php foreach( cwms1661_product_category_table_headers() as $metakey => $label ): ?>
                            <th><?php echo apply_filters('cwms1661_product_category_table_headers_label_'.$metakey , $label ); ?></th>
                        <?php endforeach; ?>
                    </tr>
                </thead>
                <tfoot>
                    <tr>
                        <!-- <th></th> -->
                        <?php foreach( cwms1661_product_category_table_headers() as $metakey => $label ): ?>
                            <th><?php echo apply_filters('cwms1661_product_category_table_headers_label_'.$metakey , $label ); ?></th>
                        <?php endforeach; ?>
                    </tr>
                </tfoot>
            </table>
        </div> 
    <?php endif; ?>
</div>