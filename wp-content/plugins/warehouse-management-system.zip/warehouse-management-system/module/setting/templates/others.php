<div role="tabpanel" class="tab-pane fade <?php echo $current_tab == 'others' ? 'active in' : '' ; ?>" id="cwms-others" aria-labelledby="profile-tab">   
    <div class="col-md-offset-2 col-md-8"> 
        <form method="POST" id="cwms-general-settings-form" class="form-horizontal form-label-left">
            <?php do_action('cwms1661_before_others_settings_form'); ?>
            <?php wp_nonce_field( 'cwms1661_others_settings_action', 'cwms1661_others_settings_nonce' ); ?>
            <div class="form-group">
                <label class="control-label col-md-4 col-sm-4 col-xs-12" for="_enable_dr_sequence"><?php esc_html_e('Enable DR Number Sequence?', 'wpcodigo_wms'); ?></label>
                <div class="col-md-6 col-sm-6 col-xs-12">
                    <input id="_enable_dr_sequence" type="checkbox" class="js-switch" name="_enable_dr_sequence" <?php checked( cwms1661_dr_senquence_enable(), 1 ); ?> value="1" >
                </div>
            </div>
            <div class="form-group">
                <label class="control-label col-md-4 col-sm-4 col-xs-12" for="_dr_sequence_no"><?php esc_html_e('DR Number Sequence', 'wpcodigo_wms'); ?></label>
                <div class="col-md-6 col-sm-6 col-xs-12">
                    <input id="_dr_sequence_no" type="text" class="form-control cmws-number" name="_dr_sequence_no" value="<?php echo cwms1661_dr_senquence_number(); ?>" required="">
                    <p class="text-danger font-italic"><?php esc_html_e('Note: Make sure that the starting sequence is not yet or greater that the last DR number in the system to avoid duplication.', 'wpcodigo_wms'); ?></p>
                </div>
            </div>
            <div class="form-group">
                <label class="control-label col-md-4 col-sm-4 col-xs-12" for="_dr_sequence_length"><?php esc_html_e('DR Number Length', 'wpcodigo_wms'); ?></label>
                <div class="col-md-6 col-sm-6 col-xs-12">
                    <input id="_dr_sequence_length" type="text" class="form-control cmws-number" name="_dr_sequence_length" value="<?php echo cwms1661_dr_senquence_length(); ?>" required="">
                </div>
            </div>
            <div class="form-group">
                <label class="control-label col-md-4 col-sm-4 col-xs-12" for="_product_units"><?php esc_html_e('Product Units', 'wpcodigo_wms'); ?></label>
                <div class="col-md-6 col-sm-6 col-xs-12">
                    <textarea name="_product_units" id="_product_units" class="form-control" cols="30" rows="10" ><?php echo implode("\n", $product_units ) ?></textarea>
                    <p><?php echo esc_html('Note: 1 option per line.','wpcodigo_wms'); ?></p>
                </div>
            </div>
            <?php do_action('cwms1661_after_others_settings_form'); ?>
            <div class="ln_solid"></div>
            <div class="form-group">
                <div class="col-md-6 col-sm-6 col-xs-12 col-md-offset-3">
                    <button type="submit" class="btn btn-success"><?php esc_html_e('Save', 'wpcodigo_wms'); ?></button>
                </div>
            </div>
        </form>
    </div> 
</div>