<?php
defined( 'ABSPATH' ) || exit;
function cwms1661_setting_fields(){
    $headers = array(
        '_company_name' => array(
            'id'        => '_company_name',
            'label'     => __('Company Name', 'wpcodigo_wms' ),
            'type'      => 'text',
            'required'  => true,
            'options'   => array(),
            'classes'   => ''
        ),
        '_owner' => array(
            'id'        => '_owner',
            'label'     => __('Owner', 'wpcodigo_wms' ),
            'type'      => 'text',
            'required'  => true,
            'options'   => array(),
            'classes'   => ''
        ),
        '_vat_tin' => array(
            'id'        => '_vat_tin',
            'label'     => __('VAT TIN', 'wpcodigo_wms' ),
            'type'      => 'text',
            'required'  => true,
            'options'   => array(),
            'classes'   => ''
        ),
        '_address'             => array(
            'id'        => '_address',
            'label'     => __('Address', 'wpcodigo_wms' ),
            'type'      => 'textarea',
            'required'  => true,
            'options'   => array(),
            'classes'   => ''
        ),
        '_email'             => array(
            'id'        => '_email',
            'label'     => __('Email', 'wpcodigo_wms' ),
            'type'      => 'email',
            'required'  => true,
            'options'   => array(),
            'classes'   => ''
        ),
        '_phone'             => array(
            'id'        => '_phone',
            'label'     => __('Phone No.', 'wpcodigo_wms' ),
            'type'      => 'text',
            'required'  => true,
            'options'   => array(),
            'classes'   => ''
        )
    );
    return apply_filters( 'cwms1661_setting_fields', $headers );
}
function cwms1661_product_category_fields(){
    $headers = array(
        'prodcat_name'          => array(
            'id'        => 'prodcat_name',
            'label'     => __('Name', 'wpcodigo_wms' ),
            'type'      => 'text',
            'required'  => true,
            'options'   => array(),
            'classes'   => ''
        ),
        'prodcat_slug'          => array(
            'id'        => 'prodcat_slug',
            'label'     => __('Slug', 'wpcodigo_wms' ),
            'type'      => 'text',
            'required'  => false,
            'options'   => array(),
            'classes'   => ''
        ),
        'prodcat_parent'          => array(
            'id'        => 'prodcat_parent',
            'label'     => __('Parent', 'wpcodigo_wms' ),
            'type'      => 'select',
            'required'  => false,
            'options'   => cwms1661_product_parent_categories(),
            'classes'   => ''
        ),
        'prodcat_description'   => array(
            'id'        => 'prodcat_description',
            'label'     => __('Description', 'wpcodigo_wms' ),
            'type'      => 'textarea',
            'required'  => false,
            'options'   => array(),
            'classes'   => ''
        )
    );
    return apply_filters( 'cwms1661_product_category_fields', $headers );
}
function cwms1661_product_category_table_headers(){
    $headers = array(
        'name'          => __('Name', 'wpcodigo_wms' ),
        'slug'          => __('Slug', 'wpcodigo_wms' ),
        'description'   => __('Description', 'wpcodigo_wms' )
    );
    return apply_filters( 'cwms1661_product_category_table_headers', $headers );
}
function cwms1661_product_parent_categories(){
    $terms = get_terms( array(
        'taxonomy'   => CWMS1661_PRODUCT_TAXONOMY,
        'hide_empty' => false,
        'parent'   => 0
    ) );
    if( empty( $terms ) ){
        return array();
    }
    $term_list = [];
    foreach ($terms as $term ) {
        $term_list[$term->term_id] = $term->name;
    }
    return $term_list;
}
function cwms1661_product_child_categories(){
    $parents = array_keys(  cwms1661_product_parent_categories() );
    $terms = get_terms( array( 
        'taxonomy'      => CWMS1661_PRODUCT_TAXONOMY,
        'hide_empty'    => false,
        'exclude'       => $parents
    ) );
    if( empty( $terms ) ){
        return array();
    }
    $term_list = [];
    foreach ($terms as $term ) {
        $term_list[$term->term_id] = $term->name;
    }
    return $term_list;
}
function cwms1661_product_all_categories(){
    $terms = get_terms( array(
        'taxonomy' => CWMS1661_PRODUCT_TAXONOMY,
        'hide_empty' => false,
    ) );
    if( empty( $terms ) ){
        return array();
    }
    $term_list = [];
    foreach ($terms as $term ) {
        $term_list[$term->term_id] = $term->name;
    }
    return $term_list;
}
function cwms1661_get_general_settings(){
    $default_logo = CWMS1661_PLUGIN_URL.'assets/img/logo-transparent.png';
    $settings = array(
        '_company_logo' => get_option( 'cwms1661_general_settings-_company_logo', $default_logo )
    );

    foreach( array_keys( cwms1661_setting_fields() ) as $key ){
        $settings[$key] = get_option( 'cwms1661_general_settings-'.$key, null );
    }
    return $settings;
}
function cwms1661_logo( $image = true ){
    $default_logo   = CWMS1661_PLUGIN_URL.'assets/img/logo-transparent.png';
    $base64         = get_option( 'cwms1661_general_settings-_company_logo', $default_logo );
    if( $image ){
        return sprintf( '<img id="cwms-logo" src="%s" />', $base64 );
    }
    return $base64;
}
function cwms1661_dr_senquence_enable(){
    return get_option( '_enable_dr_sequence', false );
}
function cwms1661_dr_senquence_length(){
    return get_option( '_dr_sequence_length', 6 );
}
function cwms1661_dr_senquence_number(){
    return get_option( '_dr_sequence_no', 0 );
}
function cwms1661_dr_update_senquence_number( $latest_sequence ){
    update_option( '_dr_sequence_no', (int)$latest_sequence );
}
function cwms1661_enable_email_po(){
    return get_option( '_enable_email_po', 1 );
}
function cwms1661_email_po_status(){
    return get_option( '_email_po_status', 'cwms-approved' );
}
function cwms1661_enable_email_invoice(){
    return get_option( '_enable_email_invoice', 1 );
}
function cwms1661_email_invoice_status(){
    return get_option( '_email_invoice_status', 'cwms-approved' );
}