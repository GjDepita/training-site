    <?php do_action( 'cwms1661_after_print_html_body_'.$print_type, $print_id  ); ?>
    </body>
</html>