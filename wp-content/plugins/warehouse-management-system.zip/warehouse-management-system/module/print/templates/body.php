<?php $general_settings   = cwms1661_get_general_settings(); ?>
<div style="text-align:center;">
    <?php echo cwms1661_logo( ); ?>
    <p><strong><?php echo $general_settings['_company_name']; ?></strong><br/>
        <span class="owner text-uppercase"><?php echo $general_settings['_owner']; ?> - PROP.</span></br>
        <span class="company-address"><?php echo $general_settings['_address']; ?></span><br/>
        <span class="company-tin"><?php esc_html_e('VAT TIN', 'wpcodigo_wms'); ?><?php echo $general_settings['_vat_tin']; ?></span><br/>
        <?php esc_html_e('Phone', 'wpcodigo_wms'); ?>:<?php echo $general_settings['_phone']; ?>
    </p>
    <h3>Blank Template</h3>
    <p><?php echo $print_id . ' : ' . $print_type; ?></p>
</div>
