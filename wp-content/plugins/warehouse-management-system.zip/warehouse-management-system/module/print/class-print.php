<?php
defined( 'ABSPATH' ) || exit;

require_once CWMS1661_ABSPATH . 'lib/dompdf/vendor/autoload.php';

use Dompdf\Dompdf;
use Dompdf\Options;

class CWMS1661_Print {
    public static function init(){
        add_action( 'wp_ajax_cwms_print', array(__CLASS__, 'print' ) );
    }

    public static function  print( $sub_menus ){
        $print_type = sanitize_text_field( $_POST['printType'] );
        $print_id   = (int)$_POST['printID'];

        $directory    = CWMS1661_ABSPATH.'module/print/storage/';

        // Check if directory exist
        if( !is_dir( $directory ) ){
            mkdir( $directory );
        }

        // Clean directory before adding new file
        foreach( glob($directory.'*.pdf') as $pdf_file){
            unlink($pdf_file);
        }
        $pdf_title 	    = get_the_title($print_id).'-'.time();	
        // instantiate and use the dompdf class
        $options 		= new Options();
        $options->setDpi( 160 );
        $options->set('isRemoteEnabled', true);
        $dompdf 		= new Dompdf( $options );
        $dompdf->setPaper( CWMS1661_PDF_PAPER_SIZE, 'portrait');
        $dompdf->loadHtml( self::html( $print_id, $print_type ), 'UTF-8' );
        $dompdf->render();
        $output = $dompdf->output();
        $data_info = array();
        if( file_put_contents( $directory.$pdf_title.'.pdf', $output) ){
            $data_info = array(
                'file_url' => CWMS1661_PLUGIN_URL.'module/print/storage/'.$pdf_title.'.pdf',
                'file_name' => $pdf_title
            );  
        }
        wp_send_json( $data_info );
        wp_die();

    }
    public static function html( $print_id, $print_type ){
        ob_start();
        self::header( $print_id, $print_type );
        self::body( $print_id, $print_type );
        self::footer( $print_id, $print_type );
        return ob_get_clean();
    }
    public static function header( $print_id, $print_type ){
        include_once cwms1661_get_template_path( 'header', 'print/templates/', true );
    }
    public static function body( $print_id, $print_type ){
        $file_path = cwms1661_get_template_path( 'body', 'print/templates/', true );
        $file_path = apply_filters( 'cwms1661_print_html_body_'.$print_type, $file_path, $print_id);
        include_once $file_path;
    }
    public static function footer( $print_id, $print_type ){
        include_once cwms1661_get_template_path( 'footer', 'print/templates/', true );
    }
}