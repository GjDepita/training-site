<?php
defined( 'ABSPATH' ) || exit;
function cwms1661_product_units(){
    $units      = array( 'pc.', 'box.', 'ctn.', 'bndl.', 'pack', 'sack', 'bag' );
    $opt_units  = get_option( '_product_units', array() );
    $units      = !empty( $opt_units ) && is_array( $opt_units ) ? $opt_units : $units;
    return apply_filters( 'cwms1661_product_units', $units );
}
function cwms1661_product_fields( $include_category = false ){
    $parent_categories = cwms1661_product_parent_categories();
    $child_categories  = cwms1661_product_child_categories();
    $fields = array(
        '_name' => array(
            'id'        => '_name',
            'label'     => __('Product Name', 'wpcodigo_wms' ),
            'type'      => 'text',
            'required'  => true,
            'options'   => array(),
            'classes'   => '',
            'attribute' => array(
                'data-limitchar="36"'
            )
        ),
        '_upc' => array(
            'id'        => '_upc',
            'label'     => __('SKU', 'wpcodigo_wms' ),
            'type'      => 'text',
            'required'  => false,
            'options'   => array(),
            'classes'   => ''
        ),
        '_description'  => array(
            'id'        => '_description',
            'label'     => __('Description', 'wpcodigo_wms' ),
            'type'      => 'textarea',
            'required'  => false,
            'options'   => array(),
            'classes'   => ''
        ),
        '_category'  => array(
            'id'        => '_category',
            'label'     => __('Category', 'wpcodigo_wms' ),
            'type'      => 'select',
            'required'  => false,
            'options'   => $parent_categories,
            'classes'   => ''
        ),
        '_sub_category'  => array(
            'id'        => '_sub_category',
            'label'     => __('Subcategory', 'wpcodigo_wms' ),
            'type'      => 'select',
            'required'  => false,
            'options'   => $child_categories,
            'classes'   => ''
        ),
        '_qty' => array(
            'id'        => '_qty',
            'label'     => __('Qty.', 'wpcodigo_wms' ),
            'type'      => 'text',
            'required'  => true,
            'options'   => array(),
            'classes'   => 'wcms-number'
        ),
        '_unit' => array(
            'id'        => '_unit',
            'label'     => __('Unit', 'wpcodigo_wms' ),
            'type'      => 'select',
            'required'  => true,
            'options'   => cwms1661_product_units(),
            'classes'   => ''
        ),
        '_cost_price'   => array(
            'id'        => '_cost_price',
            'label'     => __('COG', 'wpcodigo_wms' ),
            'type'      => 'text',
            'required'  => true,
            'options'   => array(),
            'classes'   => 'wcms-currency'
        ),
        '_cost_discount'=> array(
            'id'        => '_cost_discount',
            'label'     => __('COG Disc.', 'wpcodigo_wms' ),
            'type'      => 'text',
            'required'  => true,
            'options'   => array(),
            'classes'   => 'wcms-currency'
        ),
        '_retail_price' => array(
            'id'        => '_retail_price',
            'label'     => __('Retail Price', 'wpcodigo_wms' ),
            'type'      => 'text',
            'required'  => true,
            'options'   => array(),
            'classes'   => 'wcms-currency'
        ),
        '_discount' => array(
            'id'        => '_discount',
            'label'     => __('Discount', 'wpcodigo_wms' ),
            'type'      => 'text',
            'required'  => false,
            'options'   => array(),
            'classes'   => ''
        ),
        '_threshold_qty' => array(
            'id'        => '_threshold_qty',
            'label'     => __('Threshold Qty.', 'wpcodigo_wms' ),
            'type'      => 'text',
            'required'  => false,
            'options'   => array(),
            'classes'   => 'wcms-number'
        )
    );
    if( empty( $parent_categories ) && !$include_category ){
        unset( $fields['_category'] );
        unset( $fields['_sub_category'] );
    }
    if( ! cwms1661_can_view_cog() ){
        unset( $fields['_cost_price'] );
        unset( $fields['_cost_discount'] );
    }
    return apply_filters( 'cwms1661_product_fields', $fields );
}
function cwms1661_product_table_headers(){
    $product_fields   = cwms1661_product_fields();
    $product_fields['_history'] = __( 'History', 'wpcodigo_wms');
    unset( $product_fields['_description'] );
    unset( $product_fields['_threshold_qty'] );
    return apply_filters( 'cwms1661_product_table_headers', array_keys( $product_fields ) );
}
// Access permissions
function cwms1661_can_access_products(){
    if(
        cwms1661_can_add_product() 
        || cwms1661_can_update_product() 
        || cwms1661_can_delete_product() 
        || cwms1661_can_view_product()
    ){
        return true;
    }
    return false;
}
function cwms1661_can_view_product_roles(){
    $assinged_roles     = get_option( 'cwms1661_can_view_product_roles', null );
    if( $assinged_roles === null ){
        $assinged_roles = array( 'cwms_manager', 'cwms_encoder' );
    }
    $assinged_roles[]   = 'administrator';
    return $assinged_roles;
}
function cwms1661_can_view_product(){
    if( !is_user_logged_in() ){
        return false;
    }
    $allowed_roles      = apply_filters('cwms1661_can_view_product_roles', cwms1661_can_view_product_roles() );
    return array_intersect( $allowed_roles,  cwms1661_current_user_roles() ) ? true : false ;
}
function cwms1661_can_add_product_roles(){
    $assinged_roles     = get_option( 'cwms1661_can_add_product_roles', null );
    if( $assinged_roles === null ){
        $assinged_roles = array( 'cwms_manager', 'cwms_encoder' );
    }
    $assinged_roles[]   = 'administrator';
    return $assinged_roles;
}
function cwms1661_can_add_product(){
    if( !is_user_logged_in() ){
        return false;
    }
    $allowed_roles      = apply_filters('cwms1661_can_add_product_roles', cwms1661_can_add_product_roles() );
    return array_intersect( $allowed_roles,  cwms1661_current_user_roles() ) ? true : false ;
}
function cwms1661_can_update_product_roles(){
    $assinged_roles     = get_option( 'cwms1661_can_update_product_roles', null );
    if( $assinged_roles === null ){
        $assinged_roles = array( 'cwms_manager' );
    }
    $assinged_roles[]   = 'administrator';
    return $assinged_roles;
}
function cwms1661_can_update_product(){
    if( !is_user_logged_in() ){
        return false;
    }
    $allowed_roles      = apply_filters('cwms1661_can_update_product_roles', cwms1661_can_update_product_roles()  );
    return array_intersect( $allowed_roles,  cwms1661_current_user_roles() ) ? true : false ;
}
function cwms1661_can_delete_product_roles(){
    $assinged_roles     = get_option( 'cwms1661_can_delete_product_roles', null );
    if( $assinged_roles === null ){
        $assinged_roles = array( 'cwms_manager' );
    }
    $assinged_roles[]   = 'administrator';
    return $assinged_roles;
}
function cwms1661_can_delete_product(){
    if( !is_user_logged_in() ){
        return false;
    }
    $allowed_roles      = apply_filters('cwms1661_can_delete_product_roles', cwms1661_can_delete_product_roles() );
    return array_intersect( $allowed_roles,  cwms1661_current_user_roles() ) ? true : false ;
}
function cwms1661_get_products( $terms = null, $threshold = null, $page = null, $limit = 12 ){
    global $wpdb;
    $parameter = [ CWMS1661_PRODUCT_POST_TYPE ];
    $sql = "SELECT posts.ID";
	$sql .= " FROM {$wpdb->posts} AS posts";  
	$sql .= " INNER JOIN {$wpdb->postmeta} AS meta1 ON ( posts.ID = meta1.post_id )"; 
	$sql .= " INNER JOIN {$wpdb->postmeta} AS meta2 ON ( posts.ID = meta2.post_id )";
    $sql .= " WHERE 1=1 ";  
    if( is_array( $terms ) && !empty($terms) ):
        $term_count = count($terms);
	    $sql .= "AND ( ( SELECT COUNT(1) FROM {$wpdb->term_relationships} AS term WHERE term.term_taxonomy_id IN ('" . implode("','", $terms) ."') AND term.object_id = posts.ID ) = {$term_count} )";
    endif;
    if( $threshold ):
        $sql .= " AND ( ( meta1.meta_key = '_threshold_qty' AND meta1.meta_value > 0 ) AND ( meta2.meta_key = '_qty' AND CAST( meta2.meta_value AS SIGNED integer ) <= CAST( meta1.meta_value AS SIGNED integer) ) )";
    endif;
	$sql .= " AND ( (posts.post_type = %s AND posts.post_status = 'publish' ) )";
	$sql .= " GROUP BY posts.ID";
	$sql .= " ORDER BY posts.post_date DESC";
    if( $page ){
        $offset = ($page - 1) * $limit;
        $sql .= " LIMIT %d OFFSET %d";
        $parameter = array_merge( $parameter, array( $limit, $offset ) );
    }
    $sql = apply_filters( 'cwms1661_get_products_sql', $sql, $terms, $threshold, $page, $limit );
    return $wpdb->get_col( $wpdb->prepare( $sql, $parameter ) );
}
function cwms1661_has_duplicate_sku( $product_name, $sku ){
    global $wpdb;
    $parameter = [ CWMS1661_PRODUCT_POST_TYPE, $product_name, $sku ];
    $sql = "SELECT posts.post_title";
	$sql .= " FROM {$wpdb->posts} AS posts";  
	$sql .= " INNER JOIN {$wpdb->postmeta} AS meta1 ON ( posts.ID = meta1.post_id )"; 
    $sql .= " WHERE 1=1 ";  
	$sql .= " AND posts.post_type = %s AND posts.post_status = 'publish'";
    $sql .= " AND posts.post_title NOT LIKE %s AND meta1.meta_key LIKE '_upc' AND meta1.meta_value LIKE %s ";
    return $wpdb->get_col( $wpdb->prepare( $sql, $parameter ) );
}
function is_cwms1661_threshold_product( $product_id ){
    global $wpdb;
    $parameter = [ CWMS1661_PRODUCT_POST_TYPE ];
    $sql = "SELECT post.ID FROM {$wpdb->posts} AS `post`";
    $sql .= " LEFT JOIN {$wpdb->postmeta} AS tblthreshold on post.ID = tblthreshold.post_id";
    $sql .= " LEFT JOIN {$wpdb->postmeta} AS tblqty on post.ID = tblqty.post_id";
    $sql .= " WHERE post.post_status LIKE 'publish' AND post.post_type LIKE %s";

    if( (int)$product_id ){
        $sql .= " AND post.ID = %d";
        $parameter[] = (int)$product_id;
    }

    $sql .= " AND tblthreshold.meta_key LIKE '_threshold_qty' AND tblthreshold.meta_value > 0";
    $sql .= " AND tblqty.meta_key LIKE '_qty' AND tblqty.meta_value <= tblthreshold.meta_value";
    $sql .= " GROUP BY post.ID ORDER BY post.post_title";
    $sql = $wpdb->prepare( $sql, $parameter );
    $sql = apply_filters( 'is_cwms1661_threshold_product_sql', $sql, $product_id );
    return $wpdb->get_var( $sql );
}
function cwms1661_search_product( $search ){
    global $wpdb;
    if( !$search ){
        return false;
    }
    $post_type = CWMS1661_PRODUCT_POST_TYPE;
    $sql = "SELECT post.ID FROM {$wpdb->posts} AS `post`";
    $sql .= " LEFT JOIN {$wpdb->postmeta} AS meta on post.ID = meta.post_id";
    $sql .= " WHERE post.post_status LIKE 'publish' AND post.post_type LIKE '{$post_type}'";
    $sql .= " AND ( post.post_title LIKE %s OR ( meta.meta_key LIKE '_upc' AND meta.meta_value LIKE %s ) )";
    $sql .= " GROUP BY post.ID ORDER BY post.post_title";
    $sql = apply_filters( 'cwms1661_search_product_sql', $wpdb->prepare( $sql, '%'.$search.'%', '%'.$search.'%' ), $search );
    return $wpdb->get_col( $sql );
}
function cwms1661_get_product_history( $product_id, $limit = null, $offset = 0  ){
    global $wpdb;
    $parameter  = array( $product_id );
    $table_name = $wpdb->prefix.CWMS1661_TBL_PRODUCT_HISTORY;
    $sql = "SELECT * FROM {$table_name} WHERE `product_id` = %d ORDER BY `created_date` DESC";
    if( $limit ){
        $sql .= " LIMIT %d OFFSET %d";
        $parameter = array_merge( $parameter, array( $limit, $offset ) );
    }
    return $wpdb->get_results( $wpdb->prepare( $sql, $parameter ), ARRAY_A );
}
function is_cwms1661_product( $product_id ){
    global $wpdb;
    if( ! (int)$product_id  ){
        return false;
    }
    $post_type = CWMS1661_PRODUCT_POST_TYPE;
    $sql = "SELECT ID FROM {$wpdb->posts} WHERE `post_status` LIKE 'publish' AND `post_type` LIKE '{$post_type}' AND `ID` = %d LIMIT 1";
    $sql = apply_filters( 'is_cwms1661_product_sql', $wpdb->prepare( $sql, $product_id ) );
    return $wpdb->get_var( $sql );
}
function get_cwms1661_product_data( $product_id ){
    global $wpdb;
    if( ! is_cwms1661_product( $product_id )  ){
        return false;
    }
    $data = [];
    $product_metakeys = array_keys( cwms1661_product_fields() );
    foreach ($product_metakeys as $key) {
        $value      = $key == '_name' ? get_the_title( $product_id ) : get_post_meta( $product_id, $key, true );
        $data[$key] = $value;
    }
    return $data;
}

function cwms1661_update_product_qty( $product_id, $qty, $trans_id = 0, $trans_number = '', $remarks = '' ){
    global $wpdb;
    $product_id = (int)$product_id;
    if( ! is_cwms1661_product( $product_id ) ){
        return false;
    }
    $user_id        = get_current_user_id();
    $created_by     = cwms1661_user_fullname( $user_id );
    $current_qty    = get_post_meta( $product_id, '_qty', true );
    $current_date   = current_time( 'mysql' );
    $post_type      = get_post_type( $trans_id );
    if( $trans_id == 'cwms-import' ){
        $post_type = __('Import', 'wpcodigo_wms');
    }

    $table          = $wpdb->prefix.CWMS1661_TBL_PRODUCT_HISTORY;
    $inserted_row   = $wpdb->insert($table,
        array(
            'trans_id'      => $trans_id, 
            'trans_number'  => $trans_number,
            'post_type'     => $post_type,
            'qty_current'   => $current_qty,
            'qty_added'     => $qty,
            'product_id'    => $product_id,
            'created_date'  => $current_date,
            'created_by'    => $created_by,
            'remarks'       => $remarks
        ),
        array( '%d', '%s', '%s', '%f', '%f', '%d', '%s', '%s', '%s' )
    );
    if( !$inserted_row ){
        return false;
    }
    $updated_qty = floatval( $current_qty ) + floatval( $qty );
    update_post_meta( $product_id, '_qty', $updated_qty );
    return $wpdb->insert_id;
}
function cwms1661_get_product_price_history( $product_id, $limit = null, $offset = 0 ){
    global $wpdb;
    $parameter  = array( $product_id );
    $table_name = $wpdb->prefix.CWMS1661_TBL_PRODUCT_PRICE_HISTORY;
    $sql = "SELECT * FROM {$table_name} WHERE `product_id` = %d ORDER BY `created_date` DESC";
    if( $limit ){
        $sql .= " LIMIT %d OFFSET %d";
        $parameter = array_merge( $parameter, array( $limit, $offset ) );
    }
    return $wpdb->get_results( $wpdb->prepare( $sql, $parameter ), ARRAY_A );
}
function cwms1661_add_product_price_history( $data ){
    global $wpdb;
    if( ! is_cwms1661_product( (int)$data['product_id'] ) ){
        return false;
    }

    $table          = $wpdb->prefix.CWMS1661_TBL_PRODUCT_PRICE_HISTORY;
    $inserted_row   = $wpdb->insert($table,
        array(
            'product_id'    => (int)$data['product_id'],
            'name'          => sanitize_text_field( $data['name']), 
            'po_id'         => (int)$data['po_id'], 
            'vendor_id'     => (int)$data['vendor_id'], 
            'vendor_name'   => sanitize_text_field( $data['vendor_name'] ), 
            'created_by'    => sanitize_text_field( $data['created_by'] ),
            'cost_price'    => sanitize_text_field( $data['cost_price'] )
        ),
        array( '%d', '%s', '%d', '%d', '%s', '%s', '%f' )
    );
    if( !$inserted_row ){
        return false;
    }
    return $wpdb->insert_id;
}

function cwms1661_product_po_suppliers( $product_id ){
    global $wpdb;
    // Get list of supplier that products PO'ed
    $tblproducts = $wpdb->prefix.CWMS1661_TB_PRODUCTS;
    $sql = "SELECT tblmeta2.meta_value AS supplier_details";
    $sql .= " FROM {$tblproducts} AS tblproduct";
    $sql .= " INNER JOIN {$wpdb->postmeta} AS tblmeta ON tblproduct.trans_id = tblmeta.post_id AND tblmeta.meta_key LIKE '_supplier_id'";
    $sql .= " INNER JOIN {$wpdb->postmeta} AS tblmeta2 ON tblproduct.trans_id = tblmeta2.post_id AND tblmeta2.meta_key LIKE '_supplier_details'";
    $sql .= " WHERE tblproduct.trans_type LIKE 'cwms_po' AND tblproduct.product_id = %d";
    $sql .= " GROUP BY tblmeta.meta_value";
    $suppliers = $wpdb->get_col( $wpdb->prepare( $sql, $product_id ) );
    $suppliers = array_map( function( $supplier ){
        return maybe_unserialize( $supplier );
    }, $suppliers );
    return $suppliers;
}

function cwms1661_product_po_suppliers_list( $product_id, $supplier_id, $page = null, $limit = 12 ){
    global $wpdb;
    $parameter   = [$product_id, $supplier_id];
    $tblproducts = $wpdb->prefix.CWMS1661_TB_PRODUCTS;
    $sql = "SELECT tblproduct.*, tblposts.ID AS po_id, tblposts.post_title AS po_number, CAST( tblposts.post_date as date) as created_date";
    $sql .= " FROM {$tblproducts} AS tblproduct";
    $sql .= " INNER JOIN  {$wpdb->posts} AS tblposts ON tblproduct.trans_id = tblposts.ID";
    $sql .= " INNER JOIN {$wpdb->postmeta} AS tblmeta ON tblproduct.trans_id = tblmeta.post_id AND tblmeta.meta_key LIKE '_supplier_id'";
    $sql .= " WHERE tblproduct.trans_type LIKE 'cwms_po' AND tblproduct.product_id = %d AND tblmeta.meta_value = %d";
    $sql .= " ORDER BY tblposts.post_date DESC";
    if( $page ){
        $offset = ($page - 1) * $limit;
        $sql .= " LIMIT %d OFFSET %d";
        $parameter = array_merge( $parameter, array( $limit, $offset ) );
    }
    $sql = $wpdb->prepare( $sql, $parameter );
    return $wpdb->get_results( $sql, ARRAY_A );
}