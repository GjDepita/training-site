<?php
defined( 'ABSPATH' ) || exit;
/**
 * Product
 */
class CWMS1661_Product {

    public static function init(){
        // Saving Product data
        add_action('wp', array( __CLASS__, 'save_product') );
        add_action('template_redirect', array( __CLASS__, 'save_product_redirection') );
        add_action( 'save_post_'.CWMS1661_PRODUCT_POST_TYPE, array( __CLASS__, 'save_post_meta'), 10, 3 );
        // Product dashboard hooks
        // Ajax handlers
        add_action( 'wp_ajax_cwms_product_options', array(__CLASS__,  'get_product_options' ) );
        add_action( 'wp_ajax_cwms_getproducts', array(__CLASS__,  'get_products' ) );
        add_action( 'wp_ajax_cwms_delete_product', array(__CLASS__,  'delete_products' ) );
        add_action( 'wp_ajax_cwms_bulkdelete_product', array(__CLASS__,  'bulk_delete_data' ) );
        add_action( 'wp_ajax_cwms_get_product_history', array(__CLASS__,  'get_history' ) );
        add_action( 'wp_ajax_cwms_get_product_price_history', array(__CLASS__,  'get_price_history' ) );
        add_action( 'wp_ajax_cwms_get_product_suppliers_price_history', array(__CLASS__,  'get_supplier_price_history' ) );

        // Localize Script translations
        add_filter( 'cwms1661_ajax_localize_script_translations', array(__CLASS__,  'script_translations' ) );
        // Product page script - add/remove URL message parameters
        add_action( 'cwms1661_before_product_form', array(__CLASS__, 'notification_message'));
        add_action( 'cwms_before_page_content', array(__CLASS__, 'threshold_notification') );
        add_action( 'cwms_after_form_field', array(__CLASS__, 'threshold_field_description'));
        // After page title hook
        add_action('cwms1661_after_page_title_view-product', array(__CLASS__, 'all_list_link'));
        add_action('cwms1661_after_page_title_update-product', array(__CLASS__, 'add_new_link'));
        add_action('cwms1661_after_page_title_all-products', array(__CLASS__, 'add_new_link'));
        // Form template hook
        add_action( 'cwms_after_form_field', array(__CLASS__, 'product_name_description') );
        // Register products pages
        add_filter( 'cwms1661_dashboard_menus', array(__CLASS__, 'menus' ) );
        add_filter( 'cwms1661_dashboard_shortcuts_menu', array(__CLASS__, 'shortcuts' ) );
        add_filter( 'cwms1661_registered_dashboard_pages', array(__CLASS__, 'pages' ));
        // Template
        add_filter( 'cwms1661_content_template_view-product', array(__CLASS__, 'view_template' ) );
        add_filter( 'cwms1661_content_template_add-product', array(__CLASS__, 'add_template' ) );
        add_filter( 'cwms1661_content_template_update-product', array(__CLASS__, 'update_template' ) );
        add_filter( 'cwms1661_content_template_all-products', array(__CLASS__, 'all_template' ) );
        

        if( !( isset($_GET['cwmspage']) && $_GET['cwmspage'] == 'view-product' ) ){
            add_filter( 'cwms1661_field_html__category', array(__CLASS__, 'parent_category_form_field'), 10, 3 );
            add_filter( 'cwms1661_field_html__sub_category', array(__CLASS__, 'sub_category_form_field'), 10, 3 );
        }
        
        // Permissions
        add_filter( 'cwms1661_permissions', array(__CLASS__, 'permissions' ) );
        
    }
    public static function view_template(){
        return apply_filters( "cwms1661_get_template_view-product", CWMS1661_ABSPATH.'module/product/templates/view-product.php' );
    }
    public static function add_template(){
        if( ! cwms1661_can_add_product() ){
            return cwms1661_get_template_path('403', 'dashboard');
        }
        return apply_filters( "cwms1661_get_template_add-product", CWMS1661_ABSPATH.'module/product/templates/add-product.php' );
    }
    public static function update_template(){
        if( ! cwms1661_can_update_product() ){
            return cwms1661_get_template_path('403', 'dashboard');
        }
        return apply_filters( "cwms1661_get_template_update-product", CWMS1661_ABSPATH.'module/product/templates/update-product.php' );
    }
    public static function all_template(){
        return apply_filters( "cwms1661_get_template_all-products   ", CWMS1661_ABSPATH.'module/product/templates/all-products.php' );
    }
    public static function parent_category_form_field( $html, $field, $value ){
        ob_start();

        if( empty($field['options']) || !is_array($field['options']) ){
            return false;
        }
        $required       = $field['required'] ? 'required' : '';
        $default_value  = esc_html__('Choose Category', 'wpcodigo_wms');
        ?>
        <div class="form-group ">
            <label class="control-label col-md-3 col-sm-3 col-xs-12"><?php echo esc_html( $field['label']  ); ?></label>
            <div class="col-md-9 col-sm-9 col-xs-12">
                <select name="<?php echo $field['id']; ?>" class="form-control cwms-select2" data-placeholder="<?php echo esc_html( $default_value ); ?>" <?php echo $required; ?>>
                    <option value=""><?php echo $default_value; ?></option>
                    <?php foreach( $field['options'] as $key => $option ): ?>
                        <?php
                            // Get Category child
                            $children = [];
                            $child_terms = get_terms( array( 'taxonomy' => CWMS1661_PRODUCT_TAXONOMY, 'hide_empty' => false, 'parent' => $key ) );
                            if( !empty( $child_terms ) ){
                                foreach ($child_terms as $child ) {
                                    $children[] = array( 'id' => $child->term_id, 'label' => $child->name );
                                }
                            }
                        ?>
                        <option value="<?php echo $key; ?>" <?php selected( $value, $key ); ?> data-children="<?php echo htmlspecialchars(json_encode($children), ENT_QUOTES, 'UTF-8') ?>"><?php echo $option; ?></option>
                    <?php endforeach; ?>
                </select>
                <?php do_action( 'cwms_after_form_field', $field ); ?>
            </div>
        </div>
        <?php
        return ob_get_clean();
    }
    public static function sub_category_form_field( $html, $field, $value ){
        ob_start();

        if( empty($field['options']) || !is_array($field['options']) ){
            return false;
        }
        $post_id        = isset( $_GET['id'] ) && (int)$_GET['id'] ? (int)$_GET['id'] : 0 ;
        $p_category     = $post_id ? (int)get_post_meta( $post_id, '_category', true ) : false ;
        $sb_category    = $post_id ? (int)get_post_meta( $post_id, '_sub_category', true ) : false ;
        $child_terms    = [];
        $default_value  = esc_html__('Choose Subcategory', 'wpcodigo_wms');
        $disabled       = '';

        $term_args      = array(
            'taxonomy'   => CWMS1661_PRODUCT_TAXONOMY,
            'hide_empty' => false,
            'parent'     => $p_category
        );

        if( cwms1661_subcategory_options_all() ){
            $term_args['exclude'] = array_keys(  cwms1661_product_parent_categories() );
            unset( $term_args['parent'] );
            $child_terms = get_terms( $term_args );
        }elseif(  $post_id ){
            $child_terms = get_terms( $term_args );
        }
        // Disabled the sub category when empty
        if( ( !cwms1661_subcategory_options_all() && ( $post_id && !$p_category ) ) || empty( $child_terms ) ){
            $disabled = 'disabled';
        }
        
        ?>
        <div class="form-group">
            <label class="control-label col-md-3 col-sm-3 col-xs-12"><?php echo esc_html( $field['label']  ); ?> </label>
            <div class="col-md-9 col-sm-9 col-xs-12">
                <select name="<?php echo $field['id']; ?>" class="form-control cwms-select2" <?php echo $disabled; ?> data-placeholder="<?php echo esc_html( $default_value ); ?>">
                    <option value=""><?php echo esc_html( $default_value ); ?></option>
                    <?php if( !empty( $child_terms ) ): ?>
                        <?php foreach( $child_terms as $term ): ?>
                            <option value="<?php echo $term->term_id; ?>" <?php selected( $sb_category, $term->term_id ); ?>><?php echo $term->name; ?></option>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </select>
            </div>
        </div>
        <?php
        return ob_get_clean();
    }
    public static function save_product(){
        // Do not run if the condition is NOT meet
        if ( ! isset( $_POST['cwms-product_form_nonce'] ) 
            || ! wp_verify_nonce( $_POST['cwms-product_form_nonce'], 'cwms-product_form_action' ) 
        ) {
            return true;
        }
        $product_name   = '';
        if( isset($_POST['_name']) ){
            $product_name = wp_strip_all_tags( $_POST['_name'] );
        }
        $product_args = array(
            'post_title'    => $product_name,
            'post_content'  => wp_strip_all_tags( $_POST['_description'] ),
            'post_status'   => 'publish',
            'post_type'     => CWMS1661_PRODUCT_POST_TYPE
        );
        // Check if add new product
        $is_update    = true;
        $product_id   = isset($_POST['cwms_product_id']) ? (int)$_POST['cwms_product_id'] : false;

        if( !$product_id ){
            if( ! cwms1661_can_add_product() ){
                printf( '<div id="message" class="error"><p>%s</p></div>', __('Permission denied. Please contact admin support', 'wpcodigo_wms') );
                wp_die();
            }
            // Insert the post into the database
            $product_id = wp_insert_post( $product_args );
            $is_update  = false;
        }else{
            if( ! cwms1661_can_update_product() ){
                printf( '<div id="message" class="error"><p>%s</p></div>', __('Permission denied. Please contact admin support', 'wpcodigo_wms') );
                wp_die();
            }
            // Update product data
            $product_args['ID'] = $product_id;
            $product_id = wp_update_post( $product_args );
        }

        if ( is_wp_error( $product_id ) ) {
            $error_string = $product_id->get_error_message();
            echo '<div id="message" class="error"><p>' . $error_string . '</p></div>';
            wp_die();
        }
        $message = $is_update ? __('Updated', 'wpcodigo_wms') : __('Created', 'wpcodigo_wms') ;
        $_POST['cwms_product_redirection'] = array(
            'url'       => cwms1661_dashboard_home(),
            'subpage'   => 'update-product',
            'id'        => $product_id,
            'message'   => sprintf( __('Product %s successfully %s.'), get_the_title($product_id), $message )
        );
    }
    public static function save_post_meta( $post_id, $post, $update ){
        $product_metakeys  = cwms1661_product_fields();

        // Unset Product name and description
        unset($product_metakeys['_name']);
        unset($product_metakeys['_description']);
        // Return if METAKEYS is empty
        if( empty($product_metakeys) ){
            return false;
        }

        $terms = [];
        if( isset( $_POST['_category'] ) && (int)$_POST['_category'] ){
            $terms[] = (int)$_POST['_category'];
        }  
        if( isset( $_POST['_sub_category'] ) && (int)$_POST['_sub_category'] ){
            $terms[] = (int)$_POST['_sub_category'];
        }   
        wp_set_post_terms( $post_id, $terms, CWMS1661_PRODUCT_TAXONOMY );

        foreach ( $product_metakeys as $metakey => $field_info ) {
            if( !array_key_exists($metakey, $_POST)){
                continue;
            }
            update_post_meta( $post_id, $metakey, sanitize_text_field( $_POST[$metakey] ) );
        }
    }
    // Save product redirection
    public static function save_product_redirection(){
        if( !isset($_POST['cwms_product_redirection']) || !is_array($_POST['cwms_product_redirection']) ){
            return false;
        }
        wp_redirect( $_POST['cwms_product_redirection']['url'] .'?cwmspage='. $_POST['cwms_product_redirection']['subpage'] .'&id='. $_POST['cwms_product_redirection']['id'] .'&cwms-message='. urlencode($_POST['cwms_product_redirection']['message']) );
        exit;
    }
    public static function notification_message(){
        if( !isset($_GET['cwmspage']) || $_GET['cwmspage'] != 'update-product' ){
            return false;
        }
        if( !isset($_GET['cwms-message']) || empty($_GET['cwms-message']) ){
            return false;
        }
        printf('<div class="alert alert-success">%s</div>', urldecode($_GET['cwms-message']));
        ?>        
        <script>
            window.history.replaceState({}, document.title, '<?php echo cwms1661_dashboard_home().'?'.cwms1661_clean_url_parameter(['cwms-message']); ?>' );
        </script>
        
        <?php
    }
    public static function threshold_field_description( $field ){
        if( $field['id'] != '_threshold_qty' || ( isset($_GET['cwmspage']) && $_GET['cwmspage'] == 'view-product' ) ){
            return false;
        }

        ob_start();
        ?><p class="text-danger font-italic"><?php esc_html_e('Note: This will add notification to the dashboard when the product reach the threshold qty.', 'wpcodigo_wms'); ?></p><?php
        echo ob_get_clean();
    }
    public static function threshold_notification(){
        if( !cwms1661_get_products([], true ) ){
            return false;
        }
        $threshold_count = count( cwms1661_get_products([], true ) );
        ob_start();
        ?>
        <div class="col-md-12 col-sm-12 col-xs-12 p-4">
            <div class="alert alert-info">
                <?php printf( _n( 'Warning: There is %s threshold product that need to replenish.', 'Warning: There are %s threshold products that needs to replenish.', $threshold_count, 'wpcodigo_wms' ), number_format_i18n( $threshold_count ) ); ?>
                <a href="<?php echo esc_url( cwms1661_dashboard_home() ); ?>?cwmspage=all-products&threshold=1"><i class="fa fa-cubes"></i></a>
            </div>
        </div>
        <?php
        echo ob_get_clean();
    }
    public static function all_list_link(){
        printf( '<a href="%s" class="btn btn-sm btn-primary">' . __( 'All products', 'wpcodigo_wms' ) . '</a>', cwms1661_dashboard_home().'?cwmspage=all-products' );
    }
    public static function add_new_link(){
        printf( '<a href="%s" class="btn btn-sm btn-primary">' . __( 'Add new product', 'wpcodigo_wms' ) . '</a>', cwms1661_dashboard_home().'?cwmspage=add-product ' );
    }
    public static function product_name_description( $field ){
        if(  $field['id'] !== '_name' ){
            return false;
        }
        printf( '<p class="desciption">' . __( 'Note: only 36 character is allowed', 'wpcodigo_wms' ) . '</p>' );
    }
    public static function menus( $menus ){

        if( !cwms1661_can_access_products() ){
            return $menus;
        }

        $menus[5] = array(
            'id'   => 'products',
            'label' => esc_html__('Products', 'wpcodigo_wms'),
            'classes' => 'fa fa-cubes',
            'subs'  => array(
                'all-products' => esc_html__('All Products', 'wpcodigo_wms'),
                'add-product' => esc_html__('Add new', 'wpcodigo_wms')
            )
        );
        return $menus;
    }
    public static function shortcuts( $shortcuts ){
        if( !cwms1661_can_access_products() ){
            return $shortcuts;
        }
        $shortcuts[10] = array(
            'page-slug' => 'add-product',
            'label'     => esc_html__('Add new product', 'wpcodigo_wms'),
            'icon'      => 'fa fa-cubes'
        );
        return $shortcuts;
    }
    public static function pages( $pages ){
        $pages['update-product']    = esc_html__('Update Product', 'wpcodigo_wms');
        $pages['view-product']    = esc_html__('Product Information', 'wpcodigo_wms');
        return $pages;
    }
    public static function get_product_options(){
        $data    = array( );
        $options = cwms1661_search_product( $_GET['q'] );
        $field_keys = array_keys(cwms1661_product_fields());
        $field_keys[] = '_cost_price';
        if( $options ){
            foreach ( (array)$options as $post_id ) {
                $data[] = cwms1661_get_data( $post_id, $field_keys, '_name', '_description' );
            }
        }
        wp_send_json( $data );
        wp_die();
    }
    public static function get_products(){

        if( !is_user_logged_in() ){
            wp_send_json( array( 'status' => 'error', 'message' => esc_html__('Cannot process your request, permission denied', 'wpcodigo_wms') ) );
        }

        $threshold          = (int)$_GET['threshold'];      
        $category_id        = (int)$_GET['cat'];      
        $subcategory_id     = (int)$_GET['subcat'];      
        $metakeys           = cwms1661_product_table_headers();
        $results            = [];
        $terms              = [];
        if( $category_id ){
            $terms[] = $category_id;
        }
        if( $subcategory_id ){
            $terms[] = $subcategory_id;
        }
        $products = cwms1661_get_products( $terms, $threshold );
        if( $products ){
            foreach ($products as $post_id ) {
                $results[] = cwms1661_get_data( $post_id, $metakeys, '_name' );
            }
        }
        if( $results ){
            $results = array_map( function( $value ){

                $threshold_qty          = get_post_meta( $value['ID'], '_threshold_qty', true );
                $value['_data']         = $value;
                $value['_cost_price']   = cwms1661_format_number( $value['_cost_price'] );
                $value['_retail_price'] = cwms1661_format_number( $value['_retail_price'] );
                $value['_qty']          = $value['_qty'] <= $threshold_qty ? '<span class="text-danger">'.$value['_qty'].'<span>' : $value['_qty'] ;

                $value['_category']     =  $value['_category'] ? get_term( $value['_category'], CWMS1661_PRODUCT_TAXONOMY )->name : '';
                $value['_sub_category'] =  $value['_sub_category'] ? get_term( $value['_sub_category'], CWMS1661_PRODUCT_TAXONOMY )->name : '';

                $value['update_link']   = cwms1661_dashboard_home().'?cwmspage=update-product&id='.$value['ID'];
                $value['view_link']     = cwms1661_dashboard_home().'?cwmspage=view-product&id='.$value['ID'];
                $label_url              = esc_url_raw( cwms1661_dashboard_home().'?cwmspage=update-product&id='.$value['ID'] );
                $actions = [
                    'edit' => sprintf(
                        '<span class="edit"><a class="cwms-update_product text-primary" href="%s">%s</a> ',
                        esc_url_raw( cwms1661_dashboard_home().'?cwmspage=update-product&id='.$value['ID'] ),
                        esc_html__('Edit','wpcodigo_wms')
                    ),
                    'delete' => sprintf(
                        '<span class="trash"><a class="cwms-delete_product text-danger" href="#">%s</a></span>',
                        esc_html__('Delete','wpcodigo_wms')
                    ),
                    'view'  => sprintf(
                        '<span class="view"><a class="text-primary" href="%s">%s</a></span>',
                        esc_url_raw( cwms1661_dashboard_home().'?cwmspage=view-product&id='.$value['ID'] ),
                        esc_html__('View','wpcodigo_wms')
                    )
                ];
                if( !cwms1661_can_delete_product( ) ):
                    unset($actions['delete']);
                endif;
                if( !cwms1661_can_update_product()  ):
                    unset($actions['edit']);
                    $label_url = esc_url_raw( cwms1661_dashboard_home().'?cwmspage=view-product&id='.$value['ID'] );
                endif;
                ob_start();
                ?>
                <strong data-id="<?php echo $value['ID']; ?>"><a href="<?php echo $label_url; ?>"><?php echo $value['_name']; ?></a></strong> 
                <div class="row-actions" data-id="<?php echo $value['ID']; ?>">
                    <?php echo implode( ' | ', array_values( $actions ) ) ?>
                </div>
                <?php
                $value['_name']     = ob_get_clean();
                $histories          = sprintf('<span class="cursor-pointer cwms-view-history fa fa-2x fa-history" style="margin-right: 12px;" data-id="%d" data-title="%s" title="%s"  data-toggle="modal" data-target="#cwms-product-history-modal"></span>', (int)$value['ID'], esc_attr( get_the_title($value['ID']) ), esc_attr( __('View product qty. history','wpcodigo_wms') ) );
                $histories          .= ' '.sprintf('<span class="cursor-pointer cwms-view-price_history fa fa-2x fa-tags" data-id="%d" data-title="%s" title="%s" data-toggle="modal" data-target="#cwms-product-price_history-modal"></span>', (int)$value['ID'], esc_attr( get_the_title($value['ID']) ), esc_attr( __('View product price history','wpcodigo_wms') ) );

                if( cwms1661_can_view_cog() ){
                    $histories      .= ' '.sprintf('<span class="cursor-pointer cwms-view-price_supplier fa fa-2x fa-book" data-id="%d" data-title="%s" title="%s" data-toggle="modal" data-target="#cwms-product-price_supplier-modal"></span>', (int)$value['ID'], esc_attr( get_the_title($value['ID']) ), esc_attr( __('View Supplier price history','wpcodigo_wms') ) );
                }

                $value['_history'] = $histories;
                return $value;
            }, $results );
        }
        wp_send_json( array( 'data' => $results ) );
    }
    public static function script_translations( $translations ){
        $translations['productTableData'] = array(
            'id'            => 'cwms_productsTable',
            'delete'        => cwms1661_can_delete_po(),
            'productFields' => cwms1661_product_fields(),
            'headers'       => cwms1661_product_table_headers(),
            'modalID'       => 'cwms-product-history-modal',
            'priceModalID'  => 'cwms-product-price_history-modal',
            'supplierPriceModalID'  => 'cwms-product-price_supplier-modal'
        );
        return $translations;
    }
    public static function delete_products(){
        if( !cwms1661_can_delete_product() ){
            wp_send_json( array(
                'status' => 'error',
                'code'  => 401,
                'message' => esc_html__('Cannot process your request, permission denied', 'wpcodigo_wms')
            ));
        }
        $product_id = (int) $_POST['productID'];
        $result     = wp_trash_post( $product_id );
        $code       = 200;
        $message    = esc_html__('Product successfully deleted.', 'wpcodigo_wms');
        do_action('cwms_after_delete_product', $product_id, $result );
        if( !$result ){
            $code       = 400;
            $message    = esc_html__('Request failed.', 'wpcodigo_wms');
        }
        wp_send_json( array(
            'code'      => $code,
            'message'   => $message,
            'product_id' => $product_id
        ));
    }
    public static function bulk_delete_data(){
        if( !cwms1661_can_delete_product() ){
            wp_send_json( array(
                'status' => 'error',
                'code'  => 401,
                'message' => esc_html__('Cannot process your request, permission denied', 'wpcodigo_wms')
            ));
        }
        $selected_ids = $_POST['ids'];
        $deleted_ids   = [];
        foreach ($selected_ids as $id ) {
            $deleted_ids[] = wp_trash_post( $id );
        }   
        wp_send_json( 
            array(
                'status' => 'success',
                'code'  => 200,
                'message' => esc_html__('Request successfully completed', 'wpcodigo_wms')
            )
        );
        wp_die();
    }
    public static function get_history(){
        $product_id     = (int)$_POST['productID'];
        $curr_page      = (int)$_POST['currPage'];
        $per_page       = 12;
        $offset         = ($curr_page-1) * $per_page; 
        $history        = cwms1661_get_product_history( $product_id, $per_page, $offset );
        $history        = array_map( function( $value ){
            $type_label = $value['post_type'];
            if( $value['post_type'] == 'cwms_invoice'){
                $type_label = __('Invoice', 'wpcodigo_wms');
            }elseif( $value['post_type'] == 'cwms_inbound'){
                $type_label = __('PO', 'wpcodigo_wms');
            }
            $value['type_label'] = $type_label;
            return $value;
        }, $history );
        wp_send_json( $history );
    }
    public static function get_price_history(){
        $product_id     = (int)$_POST['currProdPriceID'];
        $curr_page      = (int)$_POST['currPricePage'];
        $per_page       = 12;
        $offset         = ($curr_page-1) * $per_page; 
        $history        = cwms1661_get_product_price_history( $product_id, $per_page, $offset );
        $history        = array_map( function( $value ){
            $value['created_date']  = date( cwms1661_datetime_format(), strtotime( $value['created_date'] ) );
            $value['po_number']     = (int)$value['po_id'] ? get_the_title( (int)$value['po_id'] ) : '' ;
            return $value;
        }, $history );
        wp_send_json( $history );
    }

    public static function get_supplier_price_history(){
        $product_id     = (int)$_POST['currProdPriceID'];
        $curr_page      = (int)$_POST['currPricePage'];
        $per_page       = 5;
        $records        = [];
        $suppliers      = cwms1661_product_po_suppliers( $product_id );
        if( !empty( $suppliers ) ){
            foreach ($suppliers as $supplier ) {
                $product_list = cwms1661_product_po_suppliers_list( $product_id, $supplier['ID'], $curr_page, $per_page );
                if( empty($product_list) ){
                    continue;
                }
                $records[] = [
                    'id'            => $supplier['ID'],
                    'supplier_name' => $supplier['_company_name'],
                    'owner'         => $supplier['_name'],
                    'email'         => $supplier['_email'],
                    'phone'         => $supplier['_phone'],
                    'records'       => $product_list
                ];
            }
        }
        wp_send_json( $records );
    }

    public static function permissions( $permissions ){
        $permissions[10] = array(
            'label' => esc_html__('Products', 'wpcodigo_wms' ),
			'options' => array(
                'cwms1661_can_view_product_roles'   => esc_html__('View Products', 'wpcodigo_wms' ), 
                'cwms1661_can_add_product_roles'    => esc_html__('Add Products', 'wpcodigo_wms' ), 
                'cwms1661_can_update_product_roles' => esc_html__('Edit Products', 'wpcodigo_wms' ), 
                'cwms1661_can_delete_product_roles' => esc_html__('Delete', 'wpcodigo_wms' )
            )
        );
        return $permissions;
    }
}