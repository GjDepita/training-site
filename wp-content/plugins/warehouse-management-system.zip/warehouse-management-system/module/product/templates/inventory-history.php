<div id="cwms-product-history-modal" class="cwms-modal modal fade" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="<?php esc_html_e('Close', 'wpcodigo_wms'); ?>"><span aria-hidden="true">×</span>
                </button>
                <h4 class="modal-title" id="uploadLogoModalLabel"></h4>
            </div>
            <div class="modal-body">
                <div id="cwms-payment-records_wrapper" class="table-responsive">
                    <div class="profile_title">
                        <div class="col-md-6">
                            <h4><?php echo esc_html('Inventory History','wpcodigo_wms'); ?></h4>
                        </div>
                    </div>
                    <table id="cwms-payment-records_table" class="table table-striped jambo_table">
                        <thead>
                            <tr class="headings">
                                <th><?php echo esc_html('Transaction','wpcodigo_wms'); ?></th>
                                <th><?php echo esc_html('Trans. No','wpcodigo_wms'); ?></th>
                                <th><?php echo esc_html('Qty.','wpcodigo_wms'); ?></th>
                                <th><?php echo esc_html('Date','wpcodigo_wms'); ?></th>
                                <th><?php echo esc_html('Created By','wpcodigo_wms'); ?></th>
                                <th><?php echo esc_html('Remarks','wpcodigo_wms'); ?></th>
                            </tr>
                        </thead>
                        <tbody></tbody>
                        <tfoot></tfoot>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
