<div class="col-md-offset-3 col-md-6 col-sm-12">
    <?php do_action('cwms1661_before_product_form', $product ); ?>
    <form id="cwms-product-form" class="form-horizontal form-label-left input_mask" action="" method="POST">
        <?php wp_nonce_field( 'cwms-product_form_action', 'cwms-product_form_nonce' ); ?>
        <?php if( $product ): ?>
            <input type="hidden" name="cwms_product_id" value="<?php echo $product['ID']; ?>">
        <?php endif; ?>
        <?php do_action('cwms1661_before_product_form_fields', $product ); ?>
        <?php 
        foreach( cwms1661_product_fields() as $key => $field ): 
            $value = $product != null && array_key_exists( $key, $product ) ? $product[$key] : '';
            $attr  = array_key_exists( 'attribute', $field ) ? $field['attribute'] : array();
            $field = new CWMS_Field( $field, $value, $attr );
            echo $field->html();
        endforeach; 
        ?>
        <?php do_action('cwms1661_after_product_form_fields', $product ); ?>
        <div class="ln_solid"></div>
        <div class="form-group">
            <div class="col-md-9 col-sm-9 col-xs-12 col-md-offset-3">
                <button type="submit" class="btn btn-success"><?php echo esc_html__('Save Product', 'wpcodigo_wms' ); ?></button>
            </div>
        </div>
    </form>
    <?php do_action('cwms1661_after_product_form', $product ); ?>
</div>