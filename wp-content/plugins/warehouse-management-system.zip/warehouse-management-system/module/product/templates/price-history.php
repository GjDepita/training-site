<div id="cwms-product-price_history-modal" class="cwms-modal modal fade" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="<?php esc_html_e('Close', 'wpcodigo_wms'); ?>"><span aria-hidden="true">×</span>
                </button>
                <h4 class="modal-title" id="uploadLogoModalLabel"></h4>
            </div>
            <div class="modal-body">
                <div id="cwms-product-price-records_wrapper" class="table-responsive">
                    <div class="profile_title">
                        <div class="col-md-6">
                            <h4><?php echo esc_html('Price History','wpcodigo_wms'); ?></h4>
                        </div>
                    </div>
                    <table id="cwms-product-price-records_table" class="table table-striped jambo_table">
                        <thead>
                            <tr class="headings">
                                <th><?php echo esc_html('PO Number','wpcodigo_wms'); ?></th>
                                <th><?php echo esc_html('Vendor Name','wpcodigo_wms'); ?></th>
                                <th style="width:180px;"><?php echo esc_html('Date','wpcodigo_wms'); ?></th>
                                <th><?php echo esc_html('Cost Price','wpcodigo_wms'); ?></th>
                            </tr>
                        </thead>
                        <tbody></tbody>
                        <tfoot></tfoot>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
