<?php
    $parent_categories = cwms1661_product_parent_categories();
    $child_categories  = cwms1661_product_child_categories();
?>
<div id="cwms-all-products-wrapper" style="min-height: 260px;">
    <div class="filter-section profile_title" style="margin-bottom:18px;">
        <?php $threshold = isset( $_GET['threshold'] ) ? (int)$_GET['threshold'] : 0; ?>
        <section class="filter-wrapper" style="margin-right:12px;">
            <select id="product_threshold_filter" data-action="cwms_search_threshold" data-placeholder="<?php echo esc_html('All Products','wpcodigo_wms'); ?>" class="form-control form-control-sm cwms-select2" style="width:180px;margin-right:8px;display:inline-block;">
                <option value="0" <?php selected( 0, $threshold ); ?>><?php echo esc_html('All Products','wpcodigo_wms'); ?></option>
                <option value="1" <?php selected( 1, $threshold ); ?>><?php echo esc_html('Threshold Products','wpcodigo_wms'); ?></option>
            </select>
        </section>

        <?php if( $parent_categories ): ?>
            <section class="filter-wrapper" style="margin-right:12px;">
                <select id="product_cat_filter" data-placeholder="<?php echo esc_html('All Categories','wpcodigo_wms'); ?>" class="form-control form-control-sm cwms-select2" style="width:180px;margin-right:8px;display:inline-block;">
                    <option value=""><?php echo esc_html('All Categories','wpcodigo_wms'); ?></option>
                    <?php foreach( $parent_categories as $pcat_id =>  $pcat_name ): ?>
                        <option value="<?php echo (int)$pcat_id; ?>"><?php echo esc_html( $pcat_name ); ?></option>
                    <?php endforeach; ?>
                </select>
            </section>
        <?php endif; ?>
        <?php if( $child_categories ): ?>
            <section class="filter-wrapper" style="margin-right:12px;">
                <select id="product_subcat_filter" data-placeholder="<?php echo esc_html('All Subcategories','wpcodigo_wms'); ?>" class="form-control form-control-sm cwms-select2" style="width:180px;margin-right:8px;display:inline-block;">
                    <option value=""><?php echo esc_html('All Subcategories','wpcodigo_wms'); ?></option>
                    <?php foreach( $child_categories as $ccat_id => $ccat_name ): ?>
                        <option value="<?php echo (int)$ccat_id; ?>"><?php echo esc_html( $ccat_name ); ?></option>
                    <?php endforeach; ?>
                </select>
            </section>
        <?php endif; ?>
    </div>

    <table id="cwms_productsTable" class="wcms1661_dataTable display" style="width:100%">
    <thead>
        <tr>
            <?php do_action( 'cwms1661_product_before_table_header' ); ?>
            <th></th>
            <?php foreach( cwms1661_product_fields() as $metakey => $field_info ): ?>
                <?php if( !in_array($metakey, cwms1661_product_table_headers() ) ) continue; ?>
                <th><?php echo apply_filters('cwms1661_product_table_headers_label_'.$metakey , $field_info['label'] ); ?></th>
            <?php endforeach; ?>
            <th><?php esc_html_e( 'History', 'wpcodigo_wms'); ?></th>
            <?php do_action( 'cwms1661_product_after_table_header' ); ?>
        </tr>
    </thead>
    <tfoot>
        <tr>
            <?php do_action( 'cwms1661_product_before_table_header' ); ?>
            <th></th>
            <?php foreach( cwms1661_product_fields() as $metakey => $field_info ): ?>
                <?php if( !in_array($metakey, cwms1661_product_table_headers() ) ) continue; ?>
                <th><?php echo apply_filters('cwms1661_product_table_headers_label_'.$metakey , $field_info['label'] ); ?></th>
            <?php endforeach; ?>
            <th><?php esc_html_e( 'History', 'wpcodigo_wms'); ?></th>
            <?php do_action( 'cwms1661_product_after_table_header' ); ?>
        </tr>
    </tfoot>
    </table>
</div>
<!-- Product Histories-->

<?php include_once cwms1661_get_template_path( 'inventory-history', 'product/templates', true ); ?>
<?php include_once cwms1661_get_template_path( 'price-history', 'product/templates', true ); ?>
<?php include_once cwms1661_get_template_path( 'price-suppliers', 'product/templates', true ); ?>