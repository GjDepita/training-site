<?php
    $product        = null;
    include_once apply_filters( "cwms1661_get_template_form-product", CWMS1661_ABSPATH.'module/product/templates/form-product.php' );
?>