<div id="cwms-product-price_supplier-modal" class="cwms-modal modal fade" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="<?php esc_html_e('Close', 'wpcodigo_wms'); ?>"><span aria-hidden="true">×</span>
                </button>
                <h4 class="modal-title" id="uploadLogoModalLabel"></h4>
            </div>
            <div class="modal-body">
                <div id="cwms-product-supplier-price-records_wrapper" class="table-responsive">
                    <div class="profile_title">
                        <div class="col-md-6">
                            <h4 ><?php esc_html_e('Suppliers Price Records', 'wpcodigo_wms'); ?></h4>
                        </div>
                    </div>
                    <div id="cwms-product-supplier-price-records_content"></div>
                </div>
            </div>
        </div>
    </div>
</div>