<?php
$product_id     = isset( $_GET['id'] ) ? (int)$_GET['id'] : 0;
$metakeys       = array_keys( cwms1661_product_fields() );
$product        = cwms1661_get_data($product_id, $metakeys, '_name', '_description' );

?>
<style>
.form-group{
    border-bottom: 1px solid #eee !important;
} 
.form-control {
    border: none;
    box-shadow: none !important;
    background-color: #fff !important;
}
</style>
<div class="col-md-offset-3 col-md-6 col-sm-12">
    <?php do_action('cwms1661_before_product_view', $product ); ?>
    <div class="form-horizontal form-label-left input_mask">
        <?php do_action('cwms1661_before_product_view_fields', $product ); ?>
        <?php 
        foreach( cwms1661_product_fields() as $key => $field ): 
            $field['type']      = 'text';
            $field['required']  = false;
            $value             = $product[$key];
            // Change the term id to name
            if( in_array( $key, [ '_category', '_sub_category' ] ) && (int)$value ){
                $term = get_term_by('id', (int)$value, CWMS1661_PRODUCT_TAXONOMY );
                if($term){
                    $value = $term->name;
                }
            }
            $field = new CWMS_Field( $field, $value, array('disabled') );
            echo $field->html();
        endforeach; 
        ?>
        <?php do_action('cwms1661_after_product_views_fields', $product ); ?>
    </div>
    <?php do_action('cwms1661_after_product_view', $product ); ?>
</div>